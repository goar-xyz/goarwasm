//go:build js && wasm

package main

import (
	"encoding/json"
	"os"
	"path/filepath"
	"strings"
	"syscall/js"
)

// fsExportJSON walks AGENT_HOME and returns {files: {relPath: content}, dirs: []}.
func fsExportJSON() (string, error) {
	root := agentHome()
	files := map[string]string{}
	var dirs []string
	_ = filepath.Walk(root, func(path string, info os.FileInfo, err error) error {
		if err != nil {
			return nil
		}
		rel, err := filepath.Rel(root, path)
		if err != nil || rel == "." {
			if info.IsDir() && path == root {
				return nil
			}
			return nil
		}
		rel = filepath.ToSlash(rel)
		if info.IsDir() {
			dirs = append(dirs, rel)
			return nil
		}
		// Skip huge binaries; cap file size at 2MB
		if info.Size() > 2<<20 {
			return nil
		}
		b, err := os.ReadFile(path)
		if err != nil {
			return nil
		}
		files[rel] = string(b)
		return nil
	})
	payload, err := json.Marshal(map[string]any{"files": files, "dirs": dirs, "root": root})
	return string(payload), err
}

func fsImportJSON(raw string) error {
	var payload struct {
		Files map[string]string `json:"files"`
		Dirs  []string          `json:"dirs"`
	}
	if err := json.Unmarshal([]byte(raw), &payload); err != nil {
		return err
	}
	root := agentHome()
	_ = os.MkdirAll(root, 0o755)
	for _, d := range payload.Dirs {
		_ = os.MkdirAll(filepath.Join(root, filepath.FromSlash(d)), 0o755)
	}
	for rel, content := range payload.Files {
		abs := filepath.Join(root, filepath.FromSlash(rel))
		_ = os.MkdirAll(filepath.Dir(abs), 0o755)
		_ = os.WriteFile(abs, []byte(content), 0o644)
	}
	return nil
}

func agentHome() string {
	h := strings.TrimSpace(os.Getenv("AGENT_HOME"))
	if h == "" {
		h = "/tmp/goar-agent-home"
		_ = os.Setenv("AGENT_HOME", h)
	}
	return h
}

func registerFSAPI(goar js.Value) {
	goar.Set("fsExport", js.FuncOf(func(this js.Value, args []js.Value) any {
		result := js.Global().Get("Object").New()
		raw, err := fsExportJSON()
		if err != nil {
			result.Set("ok", false)
			result.Set("error", err.Error())
			return result
		}
		result.Set("ok", true)
		result.Set("json", raw)
		return result
	}))
	goar.Set("fsImport", js.FuncOf(func(this js.Value, args []js.Value) any {
		result := js.Global().Get("Object").New()
		raw := ""
		if len(args) > 0 {
			raw = args[0].String()
		}
		if err := fsImportJSON(raw); err != nil {
			result.Set("ok", false)
			result.Set("error", err.Error())
			return result
		}
		result.Set("ok", true)
		return result
	}))
	// Aliases expected by PWA
	goar.Set("fsHydrate", js.FuncOf(func(this js.Value, args []js.Value) any {
		result := js.Global().Get("Object").New()
		raw := ""
		if len(args) > 0 {
			raw = args[0].String()
		}
		if raw == "" {
			result.Set("ok", false)
			result.Set("error", "fsHydrate expects JSON string from OPFS")
			return result
		}
		if err := fsImportJSON(raw); err != nil {
			result.Set("ok", false)
			result.Set("error", err.Error())
			return result
		}
		result.Set("ok", true)
		result.Set("agentHome", agentHome())
		return result
	}))
	goar.Set("fsSync", js.FuncOf(func(this js.Value, args []js.Value) any {
		result := js.Global().Get("Object").New()
		raw, err := fsExportJSON()
		if err != nil {
			result.Set("ok", false)
			result.Set("error", err.Error())
			return result
		}
		result.Set("ok", true)
		result.Set("json", raw)
		result.Set("agentHome", agentHome())
		// If JS callback provided, invoke with json for OPFS write
		if len(args) > 0 && args[0].Type() == js.TypeFunction {
			args[0].Invoke(raw)
		}
		return result
	}))
}

func registerFSPathAPI(goar js.Value) {
	goar.Set("listDir", js.FuncOf(func(this js.Value, args []js.Value) any {
		dir := "/"
		handler := js.Undefined()
		if len(args) > 0 && args[0].Type() == js.TypeString {
			dir = args[0].String()
		}
		if len(args) > 1 {
			handler = args[1]
		}
		go func() {
			result := js.Global().Get("Object").New()
			root := agentHome()
			target := dir
			if !filepath.IsAbs(target) {
				target = filepath.Join(root, filepath.FromSlash(strings.TrimPrefix(dir, "/")))
			}
			entries, err := os.ReadDir(target)
			if err != nil {
				// try under agent home
				target = filepath.Join(root, filepath.FromSlash(strings.TrimPrefix(dir, "/")))
				entries, err = os.ReadDir(target)
			}
			if err != nil {
				result.Set("ok", false)
				result.Set("error", err.Error())
				invokeCB(handler, result)
				return
			}
			arr := js.Global().Get("Array").New()
			for i, e := range entries {
				o := js.Global().Get("Object").New()
				o.Set("name", e.Name())
				o.Set("isDir", e.IsDir())
				arr.SetIndex(i, o)
			}
			result.Set("ok", true)
			result.Set("entries", arr)
			result.Set("path", target)
			invokeCB(handler, result)
		}()
		return nil
	}))
	goar.Set("readFile", js.FuncOf(func(this js.Value, args []js.Value) any {
		path := ""
		handler := js.Undefined()
		if len(args) > 0 {
			path = args[0].String()
		}
		if len(args) > 1 {
			handler = args[1]
		}
		go func() {
			result := js.Global().Get("Object").New()
			b, err := os.ReadFile(path)
			if err != nil {
				root := agentHome()
				b, err = os.ReadFile(filepath.Join(root, filepath.FromSlash(strings.TrimPrefix(path, "/"))))
			}
			if err != nil {
				result.Set("ok", false)
				result.Set("error", err.Error())
				invokeCB(handler, result)
				return
			}
			result.Set("ok", true)
			result.Set("body", string(b))
			result.Set("content", string(b))
			invokeCB(handler, result)
		}()
		return nil
	}))
	goar.Set("writeFile", js.FuncOf(func(this js.Value, args []js.Value) any {
		path, body := "", ""
		if len(args) > 0 {
			path = args[0].String()
		}
		if len(args) > 1 {
			body = args[1].String()
		}
		result := js.Global().Get("Object").New()
		if path == "" {
			result.Set("ok", false)
			result.Set("error", "path required")
			return result
		}
		abs := path
		if !filepath.IsAbs(abs) {
			abs = filepath.Join(agentHome(), filepath.FromSlash(strings.TrimPrefix(path, "/")))
		}
		_ = os.MkdirAll(filepath.Dir(abs), 0o755)
		if err := os.WriteFile(abs, []byte(body), 0o644); err != nil {
			result.Set("ok", false)
			result.Set("error", err.Error())
			return result
		}
		result.Set("ok", true)
		result.Set("path", abs)
		return result
	}))
}
