//go:build js && wasm

package main

import (
	"context"
	"fmt"
	"io"
	"net"
	"sync"
	"sync/atomic"
	"syscall/js"
	"time"

	"github.com/goarxyz/goar/browsernet"
)

// TCP bridge for Firefox/Gecko: Go dials host:port via browsernet (Wisp) and
// streams bytes to JS. Used by web/vendor/gecko/browsernet-wisp-bridge.js so
// gecko network does not use epoxy/libcurl — only our SDN.

type tcpStream struct {
	id     uint64
	conn   net.Conn
	cancel context.CancelFunc
}

var (
	tcpMu      sync.Mutex
	tcpStreams = map[uint64]*tcpStream{}
	tcpSeq     atomic.Uint64
	tcpDataCBs []js.Value
	tcpCloseCBs []js.Value
)

func registerTCPBridge(goar js.Value) {
	goar.Set("tcpDial", js.FuncOf(jsTCPDial))
	goar.Set("tcpWrite", js.FuncOf(jsTCPWrite))
	goar.Set("tcpClose", js.FuncOf(jsTCPClose))
	goar.Set("onTcpData", js.FuncOf(func(this js.Value, args []js.Value) any {
		if len(args) > 0 && args[0].Type() == js.TypeFunction {
			tcpMu.Lock()
			tcpDataCBs = append(tcpDataCBs, args[0])
			tcpMu.Unlock()
		}
		return nil
	}))
	goar.Set("onTcpClose", js.FuncOf(func(this js.Value, args []js.Value) any {
		if len(args) > 0 && args[0].Type() == js.TypeFunction {
			tcpMu.Lock()
			tcpCloseCBs = append(tcpCloseCBs, args[0])
			tcpMu.Unlock()
		}
		return nil
	}))
}

func jsTCPDial(this js.Value, args []js.Value) any {
	result := js.Global().Get("Object").New()
	host, port := "", 0
	handler := js.Undefined()
	if len(args) > 0 && args[0].Type() == js.TypeObject {
		o := args[0]
		if v := o.Get("host"); v.Type() == js.TypeString {
			host = v.String()
		}
		if v := o.Get("port"); v.Type() == js.TypeNumber {
			port = int(v.Float())
		}
		if len(args) > 1 {
			handler = args[1]
		}
	} else {
		if len(args) > 0 {
			host = args[0].String()
		}
		if len(args) > 1 && args[1].Type() == js.TypeNumber {
			port = int(args[1].Float())
		}
		if len(args) > 2 {
			handler = args[2]
		}
	}
	if host == "" || port <= 0 || port > 65535 {
		result.Set("ok", false)
		result.Set("error", "tcpDial requires host and port")
		invokeCB(handler, result)
		return nil
	}
	go func() {
		ctx, cancel := context.WithTimeout(context.Background(), 60*time.Second)
		addr := fmt.Sprintf("%s:%d", host, port)
		conn, err := browsernet.DialContext(ctx, "tcp", addr)
		if err != nil {
			cancel()
			r := js.Global().Get("Object").New()
			r.Set("ok", false)
			r.Set("error", err.Error())
			invokeCB(handler, r)
			return
		}
		id := tcpSeq.Add(1)
		st := &tcpStream{id: id, conn: conn, cancel: cancel}
		tcpMu.Lock()
		tcpStreams[id] = st
		tcpMu.Unlock()
		r := js.Global().Get("Object").New()
		r.Set("ok", true)
		r.Set("id", float64(id))
		r.Set("addr", addr)
		invokeCB(handler, r)
		go readTCPLoop(st)
	}()
	return nil
}

func readTCPLoop(st *tcpStream) {
	buf := make([]byte, 32*1024)
	for {
		n, err := st.conn.Read(buf)
		if n > 0 {
			emitTCPData(st.id, buf[:n])
		}
		if err != nil {
			if err != io.EOF {
				// still close
			}
			emitTCPClose(st.id, err.Error())
			tcpMu.Lock()
			delete(tcpStreams, st.id)
			tcpMu.Unlock()
			_ = st.conn.Close()
			st.cancel()
			return
		}
	}
}

func emitTCPData(id uint64, data []byte) {
	// Pass as Uint8Array to JS
	u8 := js.Global().Get("Uint8Array").New(len(data))
	js.CopyBytesToJS(u8, data)
	ev := js.Global().Get("Object").New()
	ev.Set("id", float64(id))
	ev.Set("data", u8)
	tcpMu.Lock()
	cbs := append([]js.Value{}, tcpDataCBs...)
	tcpMu.Unlock()
	for _, cb := range cbs {
		if cb.Type() == js.TypeFunction {
			cb.Invoke(ev)
		}
	}
}

func emitTCPClose(id uint64, reason string) {
	ev := js.Global().Get("Object").New()
	ev.Set("id", float64(id))
	ev.Set("reason", reason)
	tcpMu.Lock()
	cbs := append([]js.Value{}, tcpCloseCBs...)
	tcpMu.Unlock()
	for _, cb := range cbs {
		if cb.Type() == js.TypeFunction {
			cb.Invoke(ev)
		}
	}
}

func jsTCPWrite(this js.Value, args []js.Value) any {
	result := js.Global().Get("Object").New()
	if len(args) < 2 {
		result.Set("ok", false)
		result.Set("error", "tcpWrite(id, data)")
		return result
	}
	id := uint64(args[0].Float())
	tcpMu.Lock()
	st := tcpStreams[id]
	tcpMu.Unlock()
	if st == nil {
		result.Set("ok", false)
		result.Set("error", "unknown stream")
		return result
	}
	var payload []byte
	data := args[1]
	if data.InstanceOf(js.Global().Get("Uint8Array")) {
		payload = make([]byte, data.Get("byteLength").Int())
		js.CopyBytesToGo(payload, data)
	} else if data.Type() == js.TypeString {
		payload = []byte(data.String())
	} else if data.InstanceOf(js.Global().Get("ArrayBuffer")) {
		u8 := js.Global().Get("Uint8Array").New(data)
		payload = make([]byte, u8.Get("byteLength").Int())
		js.CopyBytesToGo(payload, u8)
	} else {
		result.Set("ok", false)
		result.Set("error", "data must be Uint8Array/ArrayBuffer/string")
		return result
	}
	n, err := st.conn.Write(payload)
	if err != nil {
		result.Set("ok", false)
		result.Set("error", err.Error())
		return result
	}
	result.Set("ok", true)
	result.Set("n", n)
	return result
}

func jsTCPClose(this js.Value, args []js.Value) any {
	result := js.Global().Get("Object").New()
	if len(args) < 1 {
		result.Set("ok", false)
		return result
	}
	id := uint64(args[0].Float())
	tcpMu.Lock()
	st := tcpStreams[id]
	delete(tcpStreams, id)
	tcpMu.Unlock()
	if st != nil {
		_ = st.conn.Close()
		st.cancel()
	}
	result.Set("ok", true)
	return result
}
