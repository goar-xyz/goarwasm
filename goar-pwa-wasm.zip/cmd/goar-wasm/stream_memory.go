//go:build js && wasm

package main

import (
	"context"
	"encoding/json"
	"syscall/js"
	"time"

	"github.com/goarxyz/goar/internal/core"
	"github.com/goarxyz/goar/internal/core/persist"
)

func registerStreamAPI(goar js.Value) {
	goar.Set("runAgentStream", js.FuncOf(func(this js.Value, args []js.Value) any {
		prompt := ""
		if len(args) > 0 {
			prompt = args[0].String()
		}
		handler := js.Undefined()
		if len(args) > 1 {
			handler = args[1]
		}
		go func() {
			emit := func(typ string, fields map[string]any) {
				o := js.Global().Get("Object").New()
				o.Set("type", typ)
				for k, v := range fields {
					switch t := v.(type) {
					case string:
						o.Set(k, t)
					case bool:
						o.Set(k, t)
					case int:
						o.Set(k, t)
					default:
						b, _ := json.Marshal(t)
						o.Set(k, string(b))
					}
				}
				invokeCB(handler, o)
			}

			cfg := buildMemConfig()
			agentName := cfg.DefaultAgent
			stateMu.Lock()
			if memAgent != "" {
				agentName = memAgent
			}
			stateMu.Unlock()
			timeout := time.Duration(cfg.APITimeout) * time.Second
			if timeout <= 0 {
				timeout = 720 * time.Second
			}
			ctx, cancel := context.WithTimeout(context.Background(), timeout)
			stateMu.Lock()
			if agentCancel != nil {
				agentCancel()
			}
			agentCancel = cancel
			stateMu.Unlock()
			defer func() {
				cancel()
				stateMu.Lock()
				agentCancel = nil
				stateMu.Unlock()
			}()

			rt, err := core.NewRuntime(cfg, core.RuntimeOptions{
				AgentName:        agentName,
				Headless:         true,
				MaxTurns:         32,
				MCPRegistry:      getWasmMCPRegistry(),
				EnableStreaming:  true,
			})
			if err != nil {
				emit("error", map[string]any{"error": err.Error(), "ok": false})
				emit("done", map[string]any{"ok": false, "error": err.Error()})
				return
			}
			defer rt.Close()
			rt.SetUserInputCallback(askUserFromJS)

			var last string
			err = rt.ActStream(ctx, prompt, "", nil, func(ev core.Event) error {
				switch ev.Type {
				case "assistant":
					var ae core.AssistantEvent
					content := ""
					if json.Unmarshal(ev.Payload, &ae) == nil {
						content = ae.Content
					} else {
						content = string(ev.Payload)
					}
					if content != "" {
						last = content
					}
					emit("assistant", map[string]any{"content": content})
				case "reasoning", "thinking":
					content := ""
					var rm map[string]any
					if json.Unmarshal(ev.Payload, &rm) == nil {
						if c, ok := rm["content"].(string); ok {
							content = c
						}
					}
					if content == "" {
						content = string(ev.Payload)
					}
					emit("reasoning", map[string]any{"content": content})
				case "tool_call":
					var te core.ToolCallEvent
					_ = json.Unmarshal(ev.Payload, &te)
					emit("tool_call", map[string]any{"name": te.Name, "args": te.ArgsJSON, "id": te.ToolCallID})
					if memStore != nil {
						_, _ = memStore.AddToolEvent("stream", te.Name, te.ArgsJSON, "", "")
					}
				case "tool_result":
					var te core.ToolResultEvent
					_ = json.Unmarshal(ev.Payload, &te)
					emit("tool_result", map[string]any{"name": te.Name, "result": te.ResultJSON, "error": te.Error, "id": te.ToolCallID})
					if memStore != nil {
						_, _ = memStore.AddToolEvent("stream", te.Name, "", te.ResultJSON, te.Error)
					}
				default:
					emit(ev.Type, map[string]any{"payload": string(ev.Payload)})
				}
				return nil
			})
			if err != nil {
				emit("done", map[string]any{"ok": false, "error": err.Error(), "text": last})
				return
			}
			emit("done", map[string]any{"ok": true, "text": last})
		}()
		return nil
	}))
}

func registerMemoryAPI(goar js.Value) {
	goar.Set("memoryStats", js.FuncOf(func(this js.Value, args []js.Value) any {
		o := js.Global().Get("Object").New()
		if memStore == nil {
			o.Set("ok", false)
			o.Set("error", "persist store not open")
			return o
		}
		o.Set("ok", true)
		o.Set("engine", memStore.Engine())
		o.Set("path", memStore.Path())
		o.Set("schema", persist.SchemaDoc())
		st := js.Global().Get("Object").New()
		for k, v := range memStore.Stats() {
			st.Set(k, v)
		}
		o.Set("stats", st)
		return o
	}))
	goar.Set("memoryNote", js.FuncOf(func(this js.Value, args []js.Value) any {
		o := js.Global().Get("Object").New()
		if memStore == nil {
			o.Set("ok", false)
			o.Set("error", "persist store not open")
			return o
		}
		content := ""
		kind := "note"
		if len(args) > 0 {
			content = args[0].String()
		}
		if len(args) > 1 {
			kind = args[1].String()
		}
		row, err := memStore.AddMemoryNote(kind, content, "")
		if err != nil {
			o.Set("ok", false)
			o.Set("error", err.Error())
			return o
		}
		o.Set("ok", true)
		o.Set("id", row.ID)
		return o
	}))
	goar.Set("memoryExport", js.FuncOf(func(this js.Value, args []js.Value) any {
		o := js.Global().Get("Object").New()
		if memStore == nil {
			o.Set("ok", false)
			return o
		}
		raw, err := memStore.ExportJSON()
		if err != nil {
			o.Set("ok", false)
			o.Set("error", err.Error())
			return o
		}
		o.Set("ok", true)
		o.Set("json", raw)
		return o
	}))
}
