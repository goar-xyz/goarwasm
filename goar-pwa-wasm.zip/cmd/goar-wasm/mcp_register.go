//go:build js && wasm

package main

import (
	"strings"
	"syscall/js"

	"github.com/goarxyz/goar/internal/core/tools/mcp"
)

var wasmMCPRegistry = mcp.NewRegistry()

func registerMCPAPI(goar js.Value) {
	goar.Set("registerMcpServer", js.FuncOf(func(this js.Value, args []js.Value) any {
		result := js.Global().Get("Object").New()
		if len(args) == 0 || args[0].Type() != js.TypeObject {
			result.Set("ok", false)
			result.Set("error", "registerMcpServer expects { name, url|channel, transport? }")
			return result
		}
		o := args[0]
		cfg := mcp.ServerConfig{
			Name:      strings.TrimSpace(o.Get("name").String()),
			Transport: "",
			URL:       "",
			Env:       map[string]string{},
		}
		if v := o.Get("transport"); v.Type() == js.TypeString {
			cfg.Transport = strings.TrimSpace(v.String())
		}
		if v := o.Get("url"); v.Type() == js.TypeString {
			cfg.URL = strings.TrimSpace(v.String())
		}
		if v := o.Get("channel"); v.Type() == js.TypeString {
			ch := strings.TrimSpace(v.String())
			if ch != "" {
				cfg.Env["MCP_WASM_CHANNEL"] = ch
				if cfg.URL == "" {
					cfg.URL = "postmessage:" + ch
				}
				if cfg.Transport == "" {
					cfg.Transport = "postmessage"
				}
			}
		}
		if cfg.Name == "" {
			result.Set("ok", false)
			result.Set("error", "name required")
			return result
		}
		cfg = mcp.NormalizeServerConfig(cfg)
		wasmMCPRegistry.AddServer(cfg)
		result.Set("ok", true)
		result.Set("transport", cfg.Transport)
		result.Set("url", cfg.URL)
		return result
	}))
	goar.Set("listMcpServers", js.FuncOf(func(this js.Value, args []js.Value) any {
		arr := js.Global().Get("Array").New()
		i := 0
		for name, cfg := range wasmMCPRegistry.Servers() {
			o := js.Global().Get("Object").New()
			o.Set("name", name)
			o.Set("transport", cfg.Transport)
			o.Set("url", cfg.URL)
			arr.SetIndex(i, o)
			i++
		}
		return arr
	}))
}

func getWasmMCPRegistry() *mcp.Registry { return wasmMCPRegistry }
