//go:build js && wasm

// Command goar-wasm is the browser/WASM entry for the GOAR agent framework.
// It installs browsernet (Wisp v1 + optional Direct Sockets + embedded TLS
// roots) and exposes a JS API that runs core.RunProgrammatic / core.NewRuntime
// in-browser. Default fabric: wss://wisp.mercurywork.shop/.
package main

import (
	"context"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"os"
	"strings"
	"sync"
	"syscall/js"
	"time"

	"github.com/goarxyz/goar/browsernet"
	"github.com/goarxyz/goar/internal/appui"
	"github.com/goarxyz/goar/internal/core"
	"github.com/goarxyz/goar/internal/core/config"
	"github.com/goarxyz/goar/internal/core/persist"
	"github.com/goarxyz/goar/internal/core/tools"
	"github.com/goarxyz/goar/internal/core/tools/builtins"
	"github.com/goarxyz/goar/internal/core/utils"
)

const wasmVersion = "1.1.2-wasm"

var (
	stateMu sync.Mutex
	sdn     *browsernet.SDN
	// memAgent holds optional agent name from configure({agent}).
	memAgent string
	// agentCancel cancels the in-flight runAgent (if any).
	agentCancel context.CancelFunc
	memStore    *persist.Store
)

func main() {
	fmt.Println("goar-wasm: agent framework starting")

	// Prefer in-memory AGENT_HOME under /tmp so we do not require ~/.agent.
	if os.Getenv("AGENT_HOME") == "" {
		_ = os.Setenv("AGENT_HOME", "/tmp/goar-agent-home")
	}
	_ = os.MkdirAll(os.Getenv("AGENT_HOME"), 0o755)
	if st, err := persist.Open(""); err != nil {
		fmt.Println("goar-wasm: persist:", err)
	} else {
		memStore = st
		fmt.Println("goar-wasm: persist engine=", st.Engine(), "path=", st.Path())
	}

	wisp := browsernet.WispURLFromEnv()
	if err := applyNetwork("", wisp); err != nil {
		fmt.Println("goar-wasm: browsernet:", err)
	} else {
		stateMu.Lock()
		if sdn != nil {
			fmt.Println("goar-wasm: browsernet installed transport=", sdn.TransportMode(),
				"wisp=", sdn.WispURL(), "gateway=", sdn.GatewayURL())
		}
		stateMu.Unlock()
	}

	global := js.Global()
	goar := js.Global().Get("Object").New()
	goar.Set("version", versionString())
	refreshStaticProps(goar)

	goar.Set("configure", js.FuncOf(func(this js.Value, args []js.Value) any {
		result := js.Global().Get("Object").New()
		if len(args) == 0 || args[0].Type() != js.TypeObject {
			result.Set("ok", false)
			result.Set("error", "configure expects an object { wispURL?, apiKey, baseURL, model, agent?, ssh? }")
			return result
		}
		cfg := args[0]

		if v := cfg.Get("apiKey"); v.Type() == js.TypeString {
			_ = os.Setenv("OPENAI_API_KEY", strings.TrimSpace(v.String()))
		}
		if v := cfg.Get("baseURL"); v.Type() == js.TypeString {
			_ = os.Setenv("OPENAI_BASE_URL", strings.TrimSpace(v.String()))
		}
		if v := cfg.Get("model"); v.Type() == js.TypeString {
			_ = os.Setenv("OPENAI_MODEL", strings.TrimSpace(v.String()))
		}
		if v := cfg.Get("agent"); v.Type() == js.TypeString {
			a := strings.TrimSpace(v.String())
			stateMu.Lock()
			memAgent = a
			stateMu.Unlock()
			if a != "" {
				_ = os.Setenv("AGENT_DEFAULT_AGENT", a)
			}
		}
		if v := cfg.Get("thinking"); v.Type() == js.TypeString {
			t := strings.TrimSpace(v.String())
			if t != "" {
				_ = os.Setenv("AGENT_THINKING", t)
			}
		}

		if sshVal := cfg.Get("ssh"); sshVal.Type() == js.TypeObject {
			applySSHConfig(sshVal)
		}

		// proxyURL intentionally ignored (SOCKS removed from product).
		wispURL := ""
		if v := cfg.Get("wispURL"); v.Type() == js.TypeString {
			wispURL = strings.TrimSpace(v.String())
		}
		stateMu.Lock()
		needNet := wispURL != "" || sdn == nil
		stateMu.Unlock()
		if needNet {
			if wispURL != "" {
				_ = os.Setenv(browsernet.EnvWispURL, wispURL)
			}
			if err := applyNetwork("", wispURL); err != nil {
				result.Set("ok", false)
				result.Set("error", err.Error())
				refreshStaticProps(goar)
				return result
			}
		}

		refreshStaticProps(goar)
		result.Set("ok", true)
		result.Set("status", statusObject())
		return result
	}))

	goar.Set("status", js.FuncOf(func(this js.Value, args []js.Value) any {
		return statusObject()
	}))

	goar.Set("httpGet", js.FuncOf(func(this js.Value, args []js.Value) any {
		url := ""
		if len(args) > 0 {
			url = args[0].String()
		}
		handler := js.Undefined()
		if len(args) > 1 {
			handler = args[1]
		}
		go func() {
			result := js.Global().Get("Object").New()
			ctx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
			defer cancel()
			req, err := http.NewRequestWithContext(ctx, http.MethodGet, url, nil)
			if err != nil {
				invokeCB(handler, failResult(result, err.Error()))
				return
			}
			resp, err := http.DefaultClient.Do(req)
			if err != nil {
				invokeCB(handler, failResult(result, err.Error()))
				return
			}
			defer resp.Body.Close()
			body, _ := io.ReadAll(io.LimitReader(resp.Body, 1<<20))
			result.Set("ok", true)
			result.Set("status", resp.StatusCode)
			result.Set("body", string(body))
			invokeCB(handler, result)
		}()
		return nil
	}))

	// Lower-level OpenAI-compatible chat/completions smoke (no tool loop).
	goar.Set("runPrompt", js.FuncOf(func(this js.Value, args []js.Value) any {
		prompt := ""
		if len(args) > 0 {
			prompt = args[0].String()
		}
		handler := js.Undefined()
		if len(args) > 1 {
			handler = args[1]
		}
		go func() {
			result := js.Global().Get("Object").New()
			apiKey := strings.TrimSpace(os.Getenv("OPENAI_API_KEY"))
			baseURL := strings.TrimSpace(os.Getenv("OPENAI_BASE_URL"))
			model := strings.TrimSpace(os.Getenv("OPENAI_MODEL"))
			if model == "" {
				model = "gpt-4o-mini"
			}
			if baseURL == "" {
				baseURL = "https://api.openai.com/v1"
			}
			payload, err := json.Marshal(map[string]any{
				"model": model,
				"messages": []map[string]string{
					{"role": "user", "content": prompt},
				},
			})
			if err != nil {
				invokeCB(handler, failResult(result, err.Error()))
				return
			}
			ctx, cancel := context.WithTimeout(context.Background(), 60*time.Second)
			defer cancel()
			req, err := http.NewRequestWithContext(ctx, http.MethodPost, strings.TrimRight(baseURL, "/")+"/chat/completions", strings.NewReader(string(payload)))
			if err != nil {
				invokeCB(handler, failResult(result, err.Error()))
				return
			}
			req.Header.Set("Content-Type", "application/json")
			if apiKey != "" {
				req.Header.Set("Authorization", "Bearer "+apiKey)
			}
			client := utils.BuildHTTPClient(60, false) // direct browser fetch — not Wisp
			resp, err := client.Do(req)
			if err != nil {
				invokeCB(handler, failResult(result, err.Error()))
				return
			}
			defer resp.Body.Close()
			raw, _ := io.ReadAll(io.LimitReader(resp.Body, 2<<20))
			result.Set("ok", resp.StatusCode >= 200 && resp.StatusCode < 300)
			result.Set("status", resp.StatusCode)
			result.Set("body", string(raw))
			if result.Get("ok").Bool() {
				var parsed struct {
					Choices []struct {
						Message struct {
							Content string `json:"content"`
						} `json:"message"`
					} `json:"choices"`
				}
				if json.Unmarshal(raw, &parsed) == nil && len(parsed.Choices) > 0 {
					result.Set("text", parsed.Choices[0].Message.Content)
				}
			} else {
				result.Set("error", fmt.Sprintf("HTTP %d: %s", resp.StatusCode, truncate(string(raw), 400)))
			}
			invokeCB(handler, result)
		}()
		return nil
	}))

	// Full agent loop via core.RunProgrammatic (NewRuntime + Act) with full builtins.
	goar.Set("runAgent", js.FuncOf(func(this js.Value, args []js.Value) any {
		prompt := ""
		if len(args) > 0 {
			prompt = args[0].String()
		}
		handler := js.Undefined()
		if len(args) > 1 {
			handler = args[1]
		}
		go func() {
			result := js.Global().Get("Object").New()
			cfg := buildMemConfig()
			agentName := cfg.DefaultAgent
			stateMu.Lock()
			if memAgent != "" {
				agentName = memAgent
			}
			stateMu.Unlock()

			timeout := time.Duration(cfg.APITimeout) * time.Second
			if timeout <= 0 {
				timeout = 720 * time.Second
			}
			ctx, cancel := context.WithTimeout(context.Background(), timeout)
			stateMu.Lock()
			if agentCancel != nil {
				agentCancel()
			}
			agentCancel = cancel
			stateMu.Unlock()
			defer func() {
				cancel()
				stateMu.Lock()
				if agentCancel != nil {
					agentCancel = nil
				}
				stateMu.Unlock()
			}()

			rt, err := core.NewRuntime(cfg, core.RuntimeOptions{
				AgentName:   agentName,
				Headless:    true,
				MaxTurns:    32,
				MCPRegistry: getWasmMCPRegistry(),
			})
			if err != nil {
				result.Set("ok", false)
				result.Set("error", err.Error())
				invokeCB(handler, result)
				return
			}
			defer rt.Close()
			rt.SetUserInputCallback(askUserFromJS)
			text, _, err := rt.Act(ctx, prompt)
			if err != nil {
				result.Set("ok", false)
				result.Set("error", err.Error())
				result.Set("text", text)
				invokeCB(handler, result)
				return
			}
			result.Set("ok", true)
			result.Set("text", text)
			invokeCB(handler, result)
		}()
		return nil
	}))

	goar.Set("cancel", js.FuncOf(func(this js.Value, args []js.Value) any {
		result := js.Global().Get("Object").New()
		stateMu.Lock()
		cancel := agentCancel
		agentCancel = nil
		stateMu.Unlock()
		if cancel == nil {
			result.Set("ok", false)
			result.Set("error", "no in-flight agent run")
			return result
		}
		cancel()
		result.Set("ok", true)
		return result
	}))

	goar.Set("listTools", js.FuncOf(func(this js.Value, args []js.Value) any {
		m := tools.NewManager()
		builtins.RegisterAll(m)
		arr := js.Global().Get("Array").New()
		for i, ttool := range m.List() {
			o := js.Global().Get("Object").New()
			o.Set("name", ttool.Name())
			o.Set("description", ttool.Description())
			params, _ := json.Marshal(ttool.Parameters())
			o.Set("parametersJSON", string(params))
			arr.SetIndex(i, o)
		}
		return arr
	}))

	goar.Set("getConfig", js.FuncOf(func(this js.Value, args []js.Value) any {
		cfg := buildMemConfig()
		o := js.Global().Get("Object").New()
		o.Set("defaultAgent", cfg.DefaultAgent)
		o.Set("activeModel", cfg.ActiveModel)
		o.Set("apiTimeout", cfg.APITimeout)
		o.Set("bypassToolPermissions", cfg.BypassToolPermissions)
		o.Set("includeProjectContext", cfg.IncludeProjectContext)
		o.Set("agentHome", strings.TrimSpace(os.Getenv("AGENT_HOME")))
		o.Set("model", strings.TrimSpace(os.Getenv("OPENAI_MODEL")))
		o.Set("baseURL", strings.TrimSpace(os.Getenv("OPENAI_BASE_URL")))
		o.Set("hasAPIKey", strings.TrimSpace(os.Getenv("OPENAI_API_KEY")) != "")
		stateMu.Lock()
		if memAgent != "" {
			o.Set("agent", memAgent)
		} else {
			o.Set("agent", cfg.DefaultAgent)
		}
		stateMu.Unlock()
		// Full builtins always registered by RunProgrammatic → NewRuntime.
		m := tools.NewManager()
		builtins.RegisterAll(m)
		names := js.Global().Get("Array").New()
		for i, n := range m.RegisteredTools() {
			names.SetIndex(i, n)
		}
		o.Set("builtinTools", names)
		return o
	}))

	registerFSAPI(goar)
	registerFSPathAPI(goar)
	registerListModels(goar)
	registerTCPBridge(goar)
	registerAskUserAPI(goar)
	registerMCPAPI(goar)
	registerTermAPI(goar)
	registerSSHExecAPI(goar)
	registerStreamAPI(goar)
	registerMemoryAPI(goar)

	global.Set("goar", goar)
	global.Set("goarWasmReady", true)
	appui.SetGoar(goar)
	appui.Boot()
	fmt.Println("goar-wasm: single-app WASM ready (UI+agent+browsernet+persist)")

	// Keep the Go runtime schedulable under js/wasm while parked on JS I/O
	// (Wisp WebSocket open / SSH dial). Without a ticking wake, a lone
	// channel-wait can trip "all goroutines are asleep - deadlock".
	go wasmKeepalive()

	select {}
}

// buildMemConfig builds a Config from config.Default() + OPENAI_*/AGENT_* env
// without requiring ~/.agent on disk.
func buildMemConfig() *config.Config {
	cfg := config.Default()
	cfg.SessionLogging.Enabled = false
	cfg.SessionLogging.SaveDir = "/tmp/goar-agent-home/logs/session"
	cfg.IncludeProjectContext = true
	cfg.BypassToolPermissions = true

	if v := strings.TrimSpace(os.Getenv("OPENAI_MODEL")); v != "" {
		cfg.ActiveModel = v
		ensureModel(cfg, v)
	}
	if v := strings.TrimSpace(os.Getenv("OPENAI_BASE_URL")); v != "" {
		for i := range cfg.Providers {
			env := cfg.Providers[i].APIKeyEnvVar
			if env == "" {
				env = config.DefaultAPIEnvKey
			}
			if env == config.DefaultAPIEnvKey || cfg.Providers[i].Name == "openai" || cfg.Providers[i].Name == "custom" {
				cfg.Providers[i].APIBase = v
			}
		}
	}
	if v := strings.TrimSpace(os.Getenv("AGENT_DEFAULT_AGENT")); v != "" {
		cfg.DefaultAgent = v
	}
	if v := strings.TrimSpace(os.Getenv("AGENT_API_TIMEOUT")); v != "" {
		var f float64
		if _, err := fmt.Sscanf(v, "%f", &f); err == nil && f > 0 {
			cfg.APITimeout = f
		}
	}
	stateMu.Lock()
	if memAgent != "" {
		cfg.DefaultAgent = memAgent
	}
	stateMu.Unlock()
	applyThinkingToConfig(cfg)
	return cfg
}

func ensureModel(cfg *config.Config, name string) {
	for _, m := range cfg.Models {
		if m.Name == name || m.Alias == name {
			return
		}
	}
	provider := "openai"
	if len(cfg.Providers) > 0 {
		provider = cfg.Providers[0].Name
	}
	for _, p := range cfg.Providers {
		if p.Name == "openai" || p.Name == "custom" || p.APIKeyEnvVar == config.DefaultAPIEnvKey {
			provider = p.Name
			break
		}
	}
	think := strings.TrimSpace(os.Getenv("AGENT_THINKING"))
	if think == "" {
		think = "off"
	}
	cfg.Models = append(cfg.Models, config.ModelConfig{
		Name:                 name,
		Provider:             provider,
		Alias:                name,
		Temperature:          0.2,
		Thinking:             think,
		AutoCompactThreshold: 200_000,
	})
}

func applyThinkingToConfig(cfg *config.Config) {
	if cfg == nil {
		return
	}
	think := strings.TrimSpace(os.Getenv("AGENT_THINKING"))
	if think == "" {
		return
	}
	for i := range cfg.Models {
		if cfg.Models[i].Name == cfg.ActiveModel || cfg.Models[i].Alias == cfg.ActiveModel || cfg.ActiveModel == "" {
			cfg.Models[i].Thinking = think
		}
	}
}

func applySSHConfig(ssh js.Value) {
	setEnvFromJS(ssh, "host", "AGENT_SSH_HOST", true)
	setEnvFromJS(ssh, "user", "AGENT_SSH_USER", true)
	setEnvFromJS(ssh, "password", "AGENT_SSH_PASSWORD", false)
	setEnvFromJS(ssh, "privateKey", "AGENT_SSH_PRIVATE_KEY", false)
	setEnvFromJS(ssh, "secret", "AGENT_SSH_SECRET", false)
	setEnvFromJS(ssh, "reconnectHost", "AGENT_SSH_RECONNECT_HOST", true)
	if v := ssh.Get("port"); v.Truthy() {
		switch v.Type() {
		case js.TypeNumber:
			_ = os.Setenv("AGENT_SSH_PORT", fmt.Sprintf("%d", int(v.Float())))
		case js.TypeString:
			if s := strings.TrimSpace(v.String()); s != "" {
				_ = os.Setenv("AGENT_SSH_PORT", s)
			}
		}
	}
	// ports: [443,22] dial order (modular connectOnce)
	if v := ssh.Get("ports"); v.Truthy() && v.Type() == js.TypeObject {
		n := v.Length()
		parts := make([]string, 0, n)
		for i := 0; i < n; i++ {
			el := v.Index(i)
			switch el.Type() {
			case js.TypeNumber:
				parts = append(parts, fmt.Sprintf("%d", int(el.Float())))
			case js.TypeString:
				if s := strings.TrimSpace(el.String()); s != "" {
					parts = append(parts, s)
				}
			}
		}
		if len(parts) > 0 {
			_ = os.Setenv("AGENT_SSH_PORTS", strings.Join(parts, ","))
			if os.Getenv("AGENT_SSH_PORT") == "" {
				_ = os.Setenv("AGENT_SSH_PORT", parts[0])
			}
		}
	}
	// Kali defaults when configure omitted fields (same as resolveSshTarget)
	if strings.TrimSpace(os.Getenv("AGENT_SSH_HOST")) == "" {
		_ = os.Setenv("AGENT_SSH_HOST", "segfault.net")
	}
	if strings.TrimSpace(os.Getenv("AGENT_SSH_USER")) == "" {
		_ = os.Setenv("AGENT_SSH_USER", "root")
	}
	host := strings.TrimSpace(os.Getenv("AGENT_SSH_HOST"))
	if host == "segfault.net" && os.Getenv("AGENT_SSH_PASSWORD") == "" && os.Getenv("AGENT_SSH_PRIVATE_KEY") == "" {
		_ = os.Setenv("AGENT_SSH_PASSWORD", "segfault")
	}
	if os.Getenv("AGENT_SSH_PORT") == "" && os.Getenv("AGENT_SSH_PORTS") == "" {
		_ = os.Setenv("AGENT_SSH_PORTS", "443,22")
		_ = os.Setenv("AGENT_SSH_PORT", "443")
	}
	// Host key policy: trustOnFirstUse (default true) + optional knownHosts pin.
	if v := ssh.Get("trustOnFirstUse"); v.Type() == js.TypeBoolean {
		if v.Bool() {
			_ = os.Setenv("AGENT_SSH_TRUST_ON_FIRST_USE", "1")
		} else {
			_ = os.Setenv("AGENT_SSH_TRUST_ON_FIRST_USE", "0")
		}
	} else if os.Getenv("AGENT_SSH_TRUST_ON_FIRST_USE") == "" {
		_ = os.Setenv("AGENT_SSH_TRUST_ON_FIRST_USE", "1")
	}
	if v := ssh.Get("knownHosts"); v.Type() == js.TypeString {
		if s := v.String(); strings.TrimSpace(s) != "" {
			_ = os.Setenv("AGENT_SSH_KNOWN_HOSTS", s)
		}
	}
	// Prefer reconnect host as AGENT_SSH_HOST when provided (segfault).
	if rh := strings.TrimSpace(os.Getenv("AGENT_SSH_RECONNECT_HOST")); rh != "" {
		_ = os.Setenv("AGENT_SSH_HOST", rh)
	}
}

func setEnvFromJS(obj js.Value, jsKey, envKey string, trim bool) {
	v := obj.Get(jsKey)
	if v.Type() != js.TypeString {
		return
	}
	s := v.String()
	if trim {
		s = strings.TrimSpace(s)
	}
	if strings.TrimSpace(s) == "" {
		return
	}
	_ = os.Setenv(envKey, s)
}

func applyNetwork(proxyURL, wispURL string) error {
	_ = proxyURL // SOCKS removed; Wisp-only
	next, err := browsernet.NewSDNConfig(browsernet.SDNConfig{
		WispURL: wispURL,
	})
	if err != nil {
		return err
	}
	if err := next.Install(); err != nil {
		return err
	}
	stateMu.Lock()
	sdn = next
	stateMu.Unlock()
	builtins.InstallGitHTTPTransport()
	return nil
}

func refreshStaticProps(goar js.Value) {
	stateMu.Lock()
	defer stateMu.Unlock()
	goar.Set("proxyConfigured", sdn != nil)
	if sdn != nil {
		goar.Set("gatewayURL", sdn.GatewayURL())
		goar.Set("wispURL", sdn.WispURL())
		goar.Set("remoteDNS", sdn.RemoteDNS())
		goar.Set("transportMode", sdn.TransportMode())
		goar.Set("directSocketsAvailable", browsernet.DirectSocketsAvailable())
	} else {
		goar.Set("gatewayURL", "")
		goar.Set("wispURL", "")
		goar.Set("remoteDNS", false)
		goar.Set("transportMode", "")
		goar.Set("directSocketsAvailable", browsernet.DirectSocketsAvailable())
	}
	goar.Set("model", strings.TrimSpace(os.Getenv("OPENAI_MODEL")))
}

func statusObject() js.Value {
	stateMu.Lock()
	defer stateMu.Unlock()
	o := js.Global().Get("Object").New()
	o.Set("version", versionString())
	o.Set("proxyConfigured", sdn != nil)
	gateway := ""
	wisp := ""
	transport := ""
	if sdn != nil {
		gateway = sdn.GatewayURL()
		wisp = sdn.WispURL()
		transport = sdn.TransportMode()
	}
	o.Set("gatewayURL", gateway)
	o.Set("wispURL", wisp)
	o.Set("transportMode", transport)
	o.Set("directSocketsAvailable", browsernet.DirectSocketsAvailable())
	model := strings.TrimSpace(os.Getenv("OPENAI_MODEL"))
	o.Set("model", model)
	apiKey := strings.TrimSpace(os.Getenv("OPENAI_API_KEY"))
	base := strings.ToLower(strings.TrimSpace(os.Getenv("OPENAI_BASE_URL")))
	ready := sdn != nil && (apiKey != "" || strings.Contains(base, "free.ai") || base != "")
	o.Set("ready", ready)
	sshHost := strings.TrimSpace(os.Getenv("AGENT_SSH_HOST"))
	sshOK := sshHost != "" && strings.TrimSpace(os.Getenv("AGENT_SSH_USER")) != ""
	o.Set("sshConfigured", sshOK)
	o.Set("sshHost", sshHost)
	o.Set("sharedSSHConnected", builtins.SharedSSHConnected())
	o.Set("sharedSSHHost", builtins.SharedSSHHost())
	sshSt, _, _ := builtins.SharedSSHState()
	o.Set("sharedSSHState", sshSt)
	o.Set("sharedSSHWantLive", builtins.SharedSSHWantLive())
	wh := browsernet.WispHealth()
	whObj := js.Global().Get("Object").New()
	for k, v := range wh {
		switch t := v.(type) {
		case string:
			whObj.Set(k, t)
		case uint64:
			whObj.Set(k, t)
		default:
			whObj.Set(k, fmt.Sprint(v))
		}
	}
	o.Set("wispHealth", whObj)
	o.Set("bashViaSharedPTY", true)
	o.Set("termAPI", true)
	o.Set("wispDefault", browsernet.DefaultWispURL)
	o.Set("parity", true)
	o.Set("singleWasmApp", true)
	o.Set("gitSSHRewrite", true)
	o.Set("pipViaSSH", sshOK)
	eng := "pure-go-sqlite-shaped"
	stats := map[string]int{}
	if memStore != nil {
		eng = memStore.Engine()
		stats = memStore.Stats()
	}
	o.Set("persistEngine", eng)
	o.Set("persistPath", persist.DefaultPath())
	stObj := js.Global().Get("Object").New()
	for k, v := range stats {
		stObj.Set(k, v)
	}
	o.Set("persistStats", stObj)
	o.Set("puterBridge", true)
	return o
}

func versionString() string {
	if v := os.Getenv("AGENT_VERSION"); v != "" {
		return v
	}
	return wasmVersion
}

func failResult(result js.Value, errMsg string) js.Value {
	result.Set("ok", false)
	result.Set("error", errMsg)
	return result
}

func invokeCB(handler js.Value, result js.Value) {
	if handler.Type() == js.TypeFunction {
		handler.Invoke(result)
	}
}

func truncate(s string, n int) string {
	if len(s) <= n {
		return s
	}
	return s[:n] + "…"
}
