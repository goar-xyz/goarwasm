//go:build js && wasm

package main

import (
	"syscall/js"
	"time"
)

// retained interval callback — must not be GC/Release'd while the page is alive
var wasmKeepaliveFunc js.Func

// wasmKeepalive periodically yields to the JS event loop so channel waits on
// WebSocket / fetch callbacks cannot be misclassified as permanent deadlock.
func wasmKeepalive() {
	if js.Global().Get("setInterval").Type() == js.TypeFunction {
		wasmKeepaliveFunc = js.FuncOf(func(this js.Value, args []js.Value) any {
			go func() { time.Sleep(0) }()
			return nil
		})
		js.Global().Call("setInterval", wasmKeepaliveFunc, 250)
		return
	}
	for {
		time.Sleep(250 * time.Millisecond)
	}
}
