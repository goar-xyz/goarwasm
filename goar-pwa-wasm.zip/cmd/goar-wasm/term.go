//go:build js && wasm

package main

import (
	"context"
	"fmt"
	"os"
	"strings"
	"sync"
	"sync/atomic"
	"time"
	"syscall/js"

	"github.com/goarxyz/goar/internal/core/tools/builtins"
	"github.com/goarxyz/goar/internal/core/wasmshell"
)

type termSession struct {
	id     string
	mode   string // "ssh" | "local"
	cancel context.CancelFunc

	// ssh: attaches to the shared gateway (not a private OpenSSHTerm)
	unsub   func()
	state   string // "connecting" | "connected" | "failed" | "closed"
	errMsg  string
	host    string
	bytesIn int

	// local REPL
	lineBuf strings.Builder
}

var (
	termMu      sync.Mutex
	terms       = map[string]*termSession{}
	termSeq     atomic.Uint64
	termDataCBs []js.Value
	termExitCBs []js.Value
)

func registerTermAPI(goar js.Value) {
	goar.Set("openTerm", js.FuncOf(jsOpenTerm))
	goar.Set("termWrite", js.FuncOf(jsTermWrite))
	goar.Set("termResize", js.FuncOf(jsTermResize))
	goar.Set("closeTerm", js.FuncOf(jsCloseTerm))
	goar.Set("termStatus", js.FuncOf(jsTermStatus))
	goar.Set("sharedSSHStatus", js.FuncOf(jsSharedSSHStatus))
	goar.Set("reconnectSSH", js.FuncOf(jsReconnectSSH))
	goar.Set("onTermData", js.FuncOf(func(this js.Value, args []js.Value) any {
		if len(args) > 0 && args[0].Type() == js.TypeFunction {
			termMu.Lock()
			termDataCBs = append(termDataCBs, args[0])
			termMu.Unlock()
		}
		return nil
	}))
	goar.Set("onTermExit", js.FuncOf(func(this js.Value, args []js.Value) any {
		if len(args) > 0 && args[0].Type() == js.TypeFunction {
			termMu.Lock()
			termExitCBs = append(termExitCBs, args[0])
			termMu.Unlock()
		}
		return nil
	}))
}

func jsOpenTerm(this js.Value, args []js.Value) any {
	result := js.Global().Get("Object").New()
	cols, rows := 80, 24
	mode := ""
	cb := js.Undefined()
	if len(args) > 0 && args[0].Type() == js.TypeObject {
		o := args[0]
		if v := o.Get("cols"); v.Type() == js.TypeNumber {
			cols = int(v.Float())
		}
		if v := o.Get("rows"); v.Type() == js.TypeNumber {
			rows = int(v.Float())
		}
		if v := o.Get("mode"); v.Type() == js.TypeString {
			mode = strings.TrimSpace(strings.ToLower(v.String()))
		}
		if v := o.Get("callback"); v.Type() == js.TypeFunction {
			cb = v
		}
	}
	if len(args) > 1 && args[1].Type() == js.TypeFunction {
		cb = args[1]
	}
	if mode == "" {
		if builtins.IsSSHConfigured() {
			mode = "ssh"
		} else {
			mode = "local"
		}
	}
	id := fmt.Sprintf("t%d", termSeq.Add(1))
	ctx, cancel := context.WithCancel(context.Background())
	sess := &termSession{id: id, mode: mode, cancel: cancel, state: "connecting"}

	switch mode {
	case "ssh":
		// Attach to the shared SSH PTY gateway (same session agent bash uses).
		termMu.Lock()
		terms[id] = sess
		termMu.Unlock()

		already := builtins.SharedSSHConnected()
		if already {
			emitTermData(id, "\r\n\x1b[90m[goar] attaching to shared SSH PTY…\x1b[0m\r\n")
		} else {
			emitTermData(id, "\r\n\x1b[90m[goar] SSH connecting via browsernet/Wisp (shared PTY)…\x1b[0m\r\n")
		}

		unsub := builtins.OnSharedSSHData(func(data string) {
			termMu.Lock()
			if cur := terms[id]; cur != nil {
				cur.bytesIn += len(data)
			}
			termMu.Unlock()
			emitTermData(id, data)
		})
		termMu.Lock()
		if cur := terms[id]; cur != nil {
			cur.unsub = unsub
		} else {
			termMu.Unlock()
			unsub()
			return result
		}
		termMu.Unlock()

		go func() {
			dctx, dcancel := context.WithTimeout(ctx, 60*time.Second)
			defer dcancel()
			sshSess, err := builtins.EnsureSharedSSHTerm(dctx, cols, rows)
			if err != nil {
				emitTermData(id, fmt.Sprintf("\r\n\x1b[91m[goar] SSH connect failed: %v\x1b[0m\r\n", err))
				termMu.Lock()
				if cur := terms[id]; cur != nil {
					cur.state = "failed"
					cur.errMsg = err.Error()
					if cur.unsub != nil {
						cur.unsub()
						cur.unsub = nil
					}
				}
				termMu.Unlock()
				cancel()
				emitTermExit(id, 1)
				if cb.Type() == js.TypeFunction {
					fail := js.Global().Get("Object").New()
					fail.Set("ok", false)
					fail.Set("id", id)
					fail.Set("mode", "ssh")
					fail.Set("error", err.Error())
					fail.Set("connecting", false)
					fail.Set("connected", false)
					cb.Invoke(fail)
				}
				return
			}
			host := sshSess.Host()
			termMu.Lock()
			if cur := terms[id]; cur != nil {
				cur.state = "connected"
				cur.host = host
			} else {
				termMu.Unlock()
				unsub()
				return
			}
			termMu.Unlock()
			if already {
				emitTermData(id, fmt.Sprintf("\r\n\x1b[90m[goar] attached · %s\x1b[0m\r\n", host))
			}
			// Fresh connect: EnsureSharedSSHTerm already fanned out the shared-PTY banner.
			if cb.Type() == js.TypeFunction {
				ok := js.Global().Get("Object").New()
				ok.Set("ok", true)
				ok.Set("id", id)
				ok.Set("mode", "ssh")
				ok.Set("host", host)
				ok.Set("shared", true)
				ok.Set("connecting", false)
				ok.Set("connected", true)
				cb.Invoke(ok)
			}
			// Watch shared gateway; if it drops, surface exit to UI.
			go watchSharedSSH(sess)
		}()
		result.Set("ok", true)
		result.Set("id", id)
		result.Set("mode", mode)
		result.Set("shared", true)
		result.Set("connecting", !already)
		result.Set("connected", already)
		if already {
			result.Set("host", builtins.SharedSSHHost())
			termMu.Lock()
			if cur := terms[id]; cur != nil {
				cur.state = "connected"
				cur.host = builtins.SharedSSHHost()
			}
			termMu.Unlock()
		}
		return result
	case "local":
		sess.state = "connected"
		termMu.Lock()
		terms[id] = sess
		termMu.Unlock()
		cwd := wasmshell.GetCwd()
		emitTermData(id, fmt.Sprintf("\r\n\x1b[90m[goar] local wasmshell  cwd=%s\x1b[0m\r\n", cwd))
		emitTermData(id, localPrompt())
	default:
		cancel()
		result.Set("ok", false)
		result.Set("error", "mode must be ssh or local")
		return result
	}

	result.Set("ok", true)
	result.Set("id", id)
	result.Set("mode", mode)
	return result
}

func watchSharedSSH(sess *termSession) {
	ticker := time.NewTicker(2 * time.Second)
	defer ticker.Stop()
	wasLive := true
	for range ticker.C {
		termMu.Lock()
		cur := terms[sess.id]
		termMu.Unlock()
		if cur == nil {
			return
		}
		st, host, errMsg := builtins.SharedSSHState()
		switch st {
		case "connected":
			if !wasLive {
				termMu.Lock()
				if c := terms[sess.id]; c != nil {
					c.state = "connected"
					c.host = host
					c.errMsg = ""
				}
				termMu.Unlock()
				emitTermData(sess.id, fmt.Sprintf("\r\n\x1b[90m[goar] SSH session restored · %s\x1b[0m\r\n", host))
			}
			wasLive = true
		case "reconnecting", "connecting":
			wasLive = false
			termMu.Lock()
			if c := terms[sess.id]; c != nil {
				c.state = st
			}
			termMu.Unlock()
		case "failed":
			prevFailed := !wasLive && cur.state == "failed"
			wasLive = false
			// Keep UI session; surface error once — user/visibility can call reconnectSSH.
			termMu.Lock()
			if c := terms[sess.id]; c != nil {
				c.state = "failed"
				c.errMsg = errMsg
			}
			termMu.Unlock()
			if errMsg != "" && !prevFailed {
				emitTermData(sess.id, fmt.Sprintf("\r\n\x1b[91m[goar] shared SSH failed: %s\x1b[0m\r\n", errMsg))
			}
			// If gateway no longer wants live (explicit disconnect), exit UI term.
			if !builtins.SharedSSHWantLive() {
				termMu.Lock()
				if c := terms[sess.id]; c != nil {
					if c.unsub != nil {
						c.unsub()
						c.unsub = nil
					}
					delete(terms, sess.id)
				}
				termMu.Unlock()
				emitTermExit(sess.id, 1)
				return
			}
		case "closed":
			wasLive = false
			if !builtins.SharedSSHWantLive() {
				termMu.Lock()
				if c := terms[sess.id]; c != nil {
					c.state = "closed"
					if c.unsub != nil {
						c.unsub()
						c.unsub = nil
					}
					delete(terms, sess.id)
				}
				termMu.Unlock()
				emitTermExit(sess.id, 0)
				return
			}
			// Auto-reconnect in progress or pending — keep term session attached.
		}
	}
}

func jsReconnectSSH(this js.Value, args []js.Value) any {
	result := js.Global().Get("Object").New()
	cols, rows := 80, 24
	cb := js.Undefined()
	if len(args) > 0 && args[0].Type() == js.TypeObject {
		o := args[0]
		if v := o.Get("cols"); v.Type() == js.TypeNumber {
			cols = int(v.Float())
		}
		if v := o.Get("rows"); v.Type() == js.TypeNumber {
			rows = int(v.Float())
		}
		if v := o.Get("callback"); v.Type() == js.TypeFunction {
			cb = v
		}
	}
	if len(args) > 0 && args[0].Type() == js.TypeFunction {
		cb = args[0]
	}
	if !builtins.IsSSHConfigured() {
		result.Set("ok", false)
		result.Set("error", "SSH not configured")
		if cb.Type() == js.TypeFunction {
			cb.Invoke(result)
		}
		return result
	}
	result.Set("ok", true)
	result.Set("connecting", true)
	go func() {
		ctx, cancel := context.WithTimeout(context.Background(), 60*time.Second)
		defer cancel()
		sess, err := builtins.ReconnectSharedSSH(ctx, cols, rows)
		out := js.Global().Get("Object").New()
		if err != nil {
			out.Set("ok", false)
			out.Set("error", err.Error())
			out.Set("connecting", false)
			out.Set("connected", false)
		} else {
			out.Set("ok", true)
			out.Set("connected", true)
			out.Set("connecting", false)
			out.Set("host", sess.Host())
			out.Set("shared", true)
		}
		if cb.Type() == js.TypeFunction {
			cb.Invoke(out)
		}
	}()
	return result
}


func jsTermWrite(this js.Value, args []js.Value) any {
	result := js.Global().Get("Object").New()
	if len(args) < 2 {
		result.Set("ok", false)
		result.Set("error", "termWrite(id, data)")
		return result
	}
	id := args[0].String()
	data := args[1].String()
	termMu.Lock()
	sess := terms[id]
	termMu.Unlock()
	if sess == nil {
		result.Set("ok", false)
		result.Set("error", "unknown term id")
		return result
	}
	switch sess.mode {
	case "ssh":
		if !builtins.SharedSSHConnected() {
			result.Set("ok", true)
			result.Set("pending", true)
			return result
		}
		if _, err := builtins.SharedSSHWrite([]byte(data)); err != nil {
			result.Set("ok", false)
			result.Set("error", err.Error())
			return result
		}
	case "local":
		handleLocalInput(sess, data)
	}
	result.Set("ok", true)
	return result
}

func jsTermResize(this js.Value, args []js.Value) any {
	result := js.Global().Get("Object").New()
	if len(args) < 3 {
		result.Set("ok", false)
		result.Set("error", "termResize(id, cols, rows)")
		return result
	}
	id := args[0].String()
	cols := int(args[1].Float())
	rows := int(args[2].Float())
	termMu.Lock()
	sess := terms[id]
	termMu.Unlock()
	if sess == nil {
		result.Set("ok", false)
		result.Set("error", "unknown term id")
		return result
	}
	if sess.mode == "ssh" && builtins.SharedSSHConnected() {
		if err := builtins.SharedSSHResize(cols, rows); err != nil {
			result.Set("ok", false)
			result.Set("error", err.Error())
			return result
		}
	}
	result.Set("ok", true)
	return result
}

func jsCloseTerm(this js.Value, args []js.Value) any {
	result := js.Global().Get("Object").New()
	if len(args) < 1 {
		result.Set("ok", false)
		result.Set("error", "closeTerm(id)")
		return result
	}
	id := args[0].String()
	killShared := false
	if len(args) > 1 && args[1].Type() == js.TypeObject {
		if v := args[1].Get("killShared"); v.Type() == js.TypeBoolean && v.Bool() {
			killShared = true
		}
	}
	termMu.Lock()
	sess := terms[id]
	delete(terms, id)
	termMu.Unlock()
	if sess == nil {
		result.Set("ok", false)
		result.Set("error", "unknown term id")
		return result
	}
	if sess.cancel != nil {
		sess.cancel()
	}
	if sess.unsub != nil {
		sess.unsub()
		sess.unsub = nil
	}
	// Detach UI only by default so the agent can keep using the shared PTY.
	// Explicit disconnect (killShared) tears down the gateway.
	if sess.mode == "ssh" && killShared {
		_ = builtins.CloseSharedSSH()
	}
	result.Set("ok", true)
	result.Set("detached", true)
	return result
}

func handleLocalInput(sess *termSession, data string) {
	for _, r := range data {
		switch r {
		case '\r', '\n':
			line := sess.lineBuf.String()
			sess.lineBuf.Reset()
			emitTermData(sess.id, "\r\n")
			if strings.TrimSpace(line) != "" {
				runLocalLine(sess, line)
			}
			emitTermData(sess.id, localPrompt())
		case 3: // Ctrl-C
			sess.lineBuf.Reset()
			emitTermData(sess.id, "^C\r\n")
			emitTermData(sess.id, localPrompt())
		case 4: // Ctrl-D
			if sess.lineBuf.Len() == 0 {
				emitTermData(sess.id, "logout\r\n")
				termMu.Lock()
				delete(terms, sess.id)
				termMu.Unlock()
				if sess.cancel != nil {
					sess.cancel()
				}
				emitTermExit(sess.id, 0)
				return
			}
		case 127, 8: // backspace
			s := sess.lineBuf.String()
			if len(s) > 0 {
				rs := []rune(s)
				sess.lineBuf.Reset()
				sess.lineBuf.WriteString(string(rs[:len(rs)-1]))
				emitTermData(sess.id, "\b \b")
			}
		default:
			if r >= 32 {
				sess.lineBuf.WriteRune(r)
				emitTermData(sess.id, string(r))
			}
		}
	}
}

func runLocalLine(sess *termSession, line string) {
	line = strings.TrimSpace(line)
	if line == "" {
		return
	}
	lower := strings.ToLower(line)
	if lower == "exit" || lower == "logout" || lower == "quit" {
		emitTermData(sess.id, "logout\r\n")
		termMu.Lock()
		delete(terms, sess.id)
		termMu.Unlock()
		if sess.cancel != nil {
			sess.cancel()
		}
		emitTermExit(sess.id, 0)
		return
	}
	if lower == "clear" || lower == "cls" {
		emitTermData(sess.id, "\x1b[2J\x1b[H")
		return
	}
	res := wasmshell.Run(line)
	if res.Stdout != "" {
		out := strings.ReplaceAll(res.Stdout, "\n", "\r\n")
		emitTermData(sess.id, out)
		if !strings.HasSuffix(out, "\r\n") && !strings.HasSuffix(res.Stdout, "\n") {
			emitTermData(sess.id, "\r\n")
		}
	}
	if res.Stderr != "" {
		errOut := strings.ReplaceAll(res.Stderr, "\n", "\r\n")
		emitTermData(sess.id, "\x1b[91m"+errOut+"\x1b[0m")
		if !strings.HasSuffix(errOut, "\r\n") {
			emitTermData(sess.id, "\r\n")
		}
	}
	if res.ReturnCode != 0 && res.Stdout == "" && res.Stderr == "" {
		emitTermData(sess.id, fmt.Sprintf("\x1b[90m[exit %d]\x1b[0m\r\n", res.ReturnCode))
	}
}

func localPrompt() string {
	cwd := wasmshell.GetCwd()
	home := strings.TrimSpace(os.Getenv("AGENT_HOME"))
	if home != "" && (cwd == home || strings.HasPrefix(cwd, home+"/")) {
		cwd = "~" + strings.TrimPrefix(cwd, home)
		if cwd == "~" {
			cwd = "~"
		}
	}
	return fmt.Sprintf("\x1b[92mgoar\x1b[0m:\x1b[94m%s\x1b[0m$ ", cwd)
}

func emitTermData(id, data string) {
	termMu.Lock()
	cbs := append([]js.Value{}, termDataCBs...)
	termMu.Unlock()
	o := js.Global().Get("Object").New()
	o.Set("id", id)
	o.Set("data", data)
	for _, cb := range cbs {
		if cb.Type() == js.TypeFunction {
			cb.Invoke(o)
		}
	}
}

func emitTermExit(id string, code int) {
	termMu.Lock()
	cbs := append([]js.Value{}, termExitCBs...)
	termMu.Unlock()
	o := js.Global().Get("Object").New()
	o.Set("id", id)
	o.Set("code", code)
	for _, cb := range cbs {
		if cb.Type() == js.TypeFunction {
			cb.Invoke(o)
		}
	}
}

func jsTermStatus(this js.Value, args []js.Value) any {
	result := js.Global().Get("Object").New()
	if len(args) < 1 {
		result.Set("ok", false)
		result.Set("error", "termStatus(id)")
		return result
	}
	id := args[0].String()
	termMu.Lock()
	sess := terms[id]
	termMu.Unlock()
	if sess == nil {
		result.Set("ok", false)
		result.Set("error", "unknown term id")
		result.Set("state", "gone")
		return result
	}
	termMu.Lock()
	st, host, errMsg, bytesIn, mode := sess.state, sess.host, sess.errMsg, sess.bytesIn, sess.mode
	termMu.Unlock()
	sharedConnected := builtins.SharedSSHConnected()
	result.Set("ok", true)
	result.Set("id", id)
	result.Set("mode", mode)
	result.Set("state", st)
	result.Set("connecting", st == "connecting")
	result.Set("connected", st == "connected")
	result.Set("host", host)
	result.Set("error", errMsg)
	result.Set("bytesIn", bytesIn)
	result.Set("hasSSH", sharedConnected)
	result.Set("shared", mode == "ssh")
	return result
}

func jsSharedSSHStatus(this js.Value, args []js.Value) any {
	result := js.Global().Get("Object").New()
	st, host, errMsg := builtins.SharedSSHState()
	result.Set("ok", true)
	result.Set("state", st)
	result.Set("host", host)
	result.Set("error", errMsg)
	result.Set("connected", st == "connected")
	result.Set("reconnecting", st == "reconnecting" || st == "connecting")
	result.Set("wantLive", builtins.SharedSSHWantLive())
	result.Set("sshConfigured", builtins.IsSSHConfigured())
	return result
}
