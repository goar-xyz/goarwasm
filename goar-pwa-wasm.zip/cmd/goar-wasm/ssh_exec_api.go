//go:build js && wasm

package main

import (
	"context"
	"strings"
	"syscall/js"
	"time"

	"github.com/goarxyz/goar/internal/core/tools/builtins"
)

func registerSSHExecAPI(goar js.Value) {
	goar.Set("sshExec", js.FuncOf(jsSSHExec))
	goar.Set("runBash", js.FuncOf(jsRunBash))
	goar.Set("isSSHConfigured", js.FuncOf(func(this js.Value, args []js.Value) any {
		return builtins.IsSSHConfigured()
	}))
}

func finishSSHResult(ok bool, errMsg string, out any) js.Value {
	result := js.Global().Get("Object").New()
	result.Set("ok", ok)
	if errMsg != "" {
		result.Set("error", errMsg)
	}
	if m, okm := out.(map[string]any); okm {
		if s, _ := m["stdout"].(string); true {
			result.Set("stdout", s)
		}
		if s, _ := m["stderr"].(string); true {
			result.Set("stderr", s)
		}
		if s, _ := m["host"].(string); s != "" {
			result.Set("host", s)
		}
		if s, _ := m["runtime"].(string); s != "" {
			result.Set("runtime", s)
		}
		if s, _ := m["command"].(string); s != "" {
			result.Set("command", s)
		}
		if s, _ := m["pty_error"].(string); s != "" {
			result.Set("pty_error", s)
		}
		if v, ok := m["returncode"]; ok {
			switch n := v.(type) {
			case int:
				result.Set("exitcode", n)
				result.Set("returncode", n)
			case float64:
				result.Set("exitcode", int(n))
				result.Set("returncode", int(n))
			}
		} else if ok {
			result.Set("exitcode", 0)
		}
	}
	return result
}

// jsSSHExec(command, timeoutMs?, callback) — ALWAYS async when callback given.
// Sync path is rejected under WASM to avoid deadlocking the runtime on Wisp dial.
func jsSSHExec(this js.Value, args []js.Value) any {
	cmd := ""
	timeoutMs := 60000
	cb := js.Undefined()
	if len(args) > 0 {
		cmd = strings.TrimSpace(args[0].String())
	}
	if len(args) > 1 {
		if args[1].Type() == js.TypeNumber {
			timeoutMs = int(args[1].Float())
		} else if args[1].Type() == js.TypeFunction {
			cb = args[1]
		}
	}
	if len(args) > 2 && args[2].Type() == js.TypeFunction {
		cb = args[2]
	}

	if cmd == "" {
		res := finishSSHResult(false, "sshExec(command, timeoutMs?, cb)", nil)
		if cb.Type() == js.TypeFunction {
			cb.Invoke(res)
			return nil
		}
		return res
	}
	if !builtins.IsSSHConfigured() {
		res := finishSSHResult(false, "SSH not configured", nil)
		if cb.Type() == js.TypeFunction {
			cb.Invoke(res)
			return nil
		}
		return res
	}

	run := func() js.Value {
		sec := timeoutMs / 1000
		if sec < 1 {
			sec = 1
		}
		ctx, cancel := context.WithTimeout(context.Background(), time.Duration(sec)*time.Second)
		defer cancel()
		out, err := builtins.RunSSHExecForAPI(ctx, cmd, sec)
		if err != nil {
			return finishSSHResult(false, err.Error(), out)
		}
		return finishSSHResult(true, "", out)
	}

	if cb.Type() == js.TypeFunction {
		go func() {
			cb.Invoke(run())
		}()
		return nil
	}

	promiseCtor := js.Global().Get("Promise")
	if promiseCtor.Type() == js.TypeFunction {
		var exec js.Func
		exec = js.FuncOf(func(this js.Value, a []js.Value) any {
			defer exec.Release()
			resolve := a[0]
			go func() {
				resolve.Invoke(run())
			}()
			return nil
		})
		return promiseCtor.New(exec)
	}
	return finishSSHResult(false, "sshExec requires callback or Promise under WASM", nil)
}

// jsRunBash(command, timeoutMs?, callback) — agent bash path (shared SSH PTY).
func jsRunBash(this js.Value, args []js.Value) any {
	cmd := ""
	timeoutMs := 120000
	cb := js.Undefined()
	if len(args) > 0 {
		cmd = strings.TrimSpace(args[0].String())
	}
	if len(args) > 1 {
		if args[1].Type() == js.TypeNumber {
			timeoutMs = int(args[1].Float())
		} else if args[1].Type() == js.TypeFunction {
			cb = args[1]
		}
	}
	if len(args) > 2 && args[2].Type() == js.TypeFunction {
		cb = args[2]
	}

	if cmd == "" {
		res := finishSSHResult(false, "runBash(command, timeoutMs?, cb)", nil)
		if cb.Type() == js.TypeFunction {
			cb.Invoke(res)
			return nil
		}
		return res
	}
	if !builtins.IsSSHConfigured() {
		res := finishSSHResult(false, "SSH not configured — open Settings and add VPS credentials", nil)
		if cb.Type() == js.TypeFunction {
			cb.Invoke(res)
			return nil
		}
		return res
	}

	run := func() js.Value {
		sec := timeoutMs / 1000
		if sec < 1 {
			sec = 1
		}
		ctx, cancel := context.WithTimeout(context.Background(), time.Duration(sec)*time.Second)
		defer cancel()
		out, err := builtins.RunBashForAPI(ctx, cmd, sec)
		if err != nil {
			return finishSSHResult(false, err.Error(), out)
		}
		return finishSSHResult(true, "", out)
	}

	if cb.Type() == js.TypeFunction {
		go func() {
			cb.Invoke(run())
		}()
		return nil
	}

	promiseCtor := js.Global().Get("Promise")
	if promiseCtor.Type() == js.TypeFunction {
		var exec js.Func
		exec = js.FuncOf(func(this js.Value, a []js.Value) any {
			defer exec.Release()
			resolve := a[0]
			go func() {
				resolve.Invoke(run())
			}()
			return nil
		})
		return promiseCtor.New(exec)
	}
	return finishSSHResult(false, "runBash requires callback or Promise under WASM", nil)
}
