//go:build js && wasm

package main

import (
	"context"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"strings"
	"syscall/js"
	"time"

	"github.com/goarxyz/goar/internal/core/utils"
)

// registerListModels exposes goar.listModels(baseURL, apiKey, cb) — OpenAI-compatible
// GET {base}/models or {base}/v1/models via browser fetch (direct; not Wisp).
func registerListModels(goar js.Value) {
	goar.Set("listModels", js.FuncOf(func(this js.Value, args []js.Value) any {
		baseURL := ""
		apiKey := ""
		handler := js.Undefined()
		if len(args) > 0 && args[0].Type() == js.TypeString {
			baseURL = strings.TrimSpace(args[0].String())
		}
		if len(args) > 1 && args[1].Type() == js.TypeString {
			apiKey = strings.TrimSpace(args[1].String())
		}
		if len(args) > 2 {
			handler = args[2]
		}
		// Also accept object form: listModels({baseURL, apiKey}, cb)
		if len(args) > 0 && args[0].Type() == js.TypeObject {
			o := args[0]
			if v := o.Get("baseURL"); v.Type() == js.TypeString {
				baseURL = strings.TrimSpace(v.String())
			}
			if v := o.Get("apiKey"); v.Type() == js.TypeString {
				apiKey = strings.TrimSpace(v.String())
			}
			if len(args) > 1 {
				handler = args[1]
			}
		}
		go func() {
			result := js.Global().Get("Object").New()
			ids, status, err := listModelsHTTP(baseURL, apiKey)
			if err != nil {
				result.Set("ok", false)
				result.Set("error", err.Error())
				if status > 0 {
					result.Set("status", status)
				}
				invokeCB(handler, result)
				return
			}
			arr := js.Global().Get("Array").New()
			for i, id := range ids {
				arr.SetIndex(i, id)
			}
			result.Set("ok", true)
			result.Set("status", status)
			result.Set("models", arr)
			invokeCB(handler, result)
		}()
		return nil
	}))
}

func listModelsHTTP(baseURL, apiKey string) (ids []string, status int, err error) {
	baseURL = strings.TrimRight(strings.TrimSpace(baseURL), "/")
	if baseURL == "" {
		return nil, 0, fmt.Errorf("baseURL required")
	}
	candidates := modelsURLCandidates(baseURL)
	var lastErr error
	var lastStatus int
	for _, url := range candidates {
		ctx, cancel := context.WithTimeout(context.Background(), 45*time.Second)
		req, e := http.NewRequestWithContext(ctx, http.MethodGet, url, nil)
		if e != nil {
			cancel()
			lastErr = e
			continue
		}
		req.Header.Set("Accept", "application/json")
		if apiKey != "" {
			req.Header.Set("Authorization", "Bearer "+apiKey)
		}
		resp, e := utils.BuildHTTPClient(45, false).Do(req)
		if e != nil {
			cancel()
			lastErr = e
			continue
		}
		body, _ := io.ReadAll(io.LimitReader(resp.Body, 2<<20))
		_ = resp.Body.Close()
		cancel()
		lastStatus = resp.StatusCode
		if resp.StatusCode < 200 || resp.StatusCode >= 300 {
			lastErr = fmt.Errorf("models HTTP %d: %s", resp.StatusCode, truncate(string(body), 160))
			continue
		}
		parsed, e := parseModelsJSON(body)
		if e != nil {
			lastErr = e
			continue
		}
		if len(parsed) == 0 {
			lastErr = fmt.Errorf("models empty at %s", url)
			continue
		}
		return parsed, resp.StatusCode, nil
	}
	if lastErr == nil {
		lastErr = fmt.Errorf("models request failed")
	}
	return nil, lastStatus, lastErr
}

func modelsURLCandidates(base string) []string {
	b := strings.TrimRight(base, "/")
	out := []string{}
	add := func(u string) {
		for _, x := range out {
			if x == u {
				return
			}
		}
		out = append(out, u)
	}
	// Prefer /models on whatever base the user gave.
	add(b + "/models")
	if strings.HasSuffix(b, "/v1") {
		// already v1
	} else if strings.Contains(b, "/v1/") {
		// leave
	} else {
		add(b + "/v1/models")
	}
	return out
}

func parseModelsJSON(raw []byte) ([]string, error) {
	var envelope struct {
		Data []struct {
			ID   string `json:"id"`
			Name string `json:"name"`
			Type string `json:"type"`
		} `json:"data"`
		Models []struct {
			ID   string `json:"id"`
			Name string `json:"name"`
		} `json:"models"`
	}
	if err := json.Unmarshal(raw, &envelope); err != nil {
		// try plain string array
		var arr []string
		if err2 := json.Unmarshal(raw, &arr); err2 == nil {
			return uniqNonEmpty(arr), nil
		}
		return nil, fmt.Errorf("parse models: %w", err)
	}
	ids := make([]string, 0, len(envelope.Data)+len(envelope.Models))
	for _, d := range envelope.Data {
		id := d.ID
		if id == "" {
			id = d.Name
		}
		if id != "" {
			ids = append(ids, id)
		}
	}
	for _, m := range envelope.Models {
		id := m.ID
		if id == "" {
			id = m.Name
		}
		if id != "" {
			ids = append(ids, id)
		}
	}
	return uniqNonEmpty(ids), nil
}

func uniqNonEmpty(in []string) []string {
	seen := map[string]struct{}{}
	out := make([]string, 0, len(in))
	for _, s := range in {
		s = strings.TrimSpace(s)
		if s == "" {
			continue
		}
		if _, ok := seen[s]; ok {
			continue
		}
		seen[s] = struct{}{}
		out = append(out, s)
	}
	return out
}
