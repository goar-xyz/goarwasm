//go:build js && wasm

package main

import (
	"encoding/json"
	"fmt"
	"sync"
	"syscall/js"
	"time"
)

var (
	askMu       sync.Mutex
	askHandler  js.Value // optional goar.onAskUser(questionsJSON) => Promise|callback
	askWaiters  = map[string]chan string{}
)

func registerAskUserAPI(goar js.Value) {
	goar.Set("onAskUser", js.FuncOf(func(this js.Value, args []js.Value) any {
		if len(args) > 0 && args[0].Type() == js.TypeFunction {
			askMu.Lock()
			askHandler = args[0]
			askMu.Unlock()
		}
		return nil
	}))
	goar.Set("answerAskUser", js.FuncOf(func(this js.Value, args []js.Value) any {
		id := ""
		answer := ""
		if len(args) > 0 {
			id = args[0].String()
		}
		if len(args) > 1 {
			answer = args[1].String()
		}
		askMu.Lock()
		ch := askWaiters[id]
		delete(askWaiters, id)
		askMu.Unlock()
		if ch != nil {
			select {
			case ch <- answer:
			default:
			}
		}
		return nil
	}))
}

// askUserFromJS blocks until PWA answers via answerAskUser or onAskUser promise.
func askUserFromJS(prompt string) (string, error) {
	id := fmt.Sprintf("ask-%d", time.Now().UnixNano())
	ch := make(chan string, 1)
	askMu.Lock()
	askWaiters[id] = ch
	handler := askHandler
	askMu.Unlock()

	payload, _ := json.Marshal(map[string]any{
		"id":       id,
		"prompt":   prompt,
		"question": prompt,
	})

	if handler.Type() == js.TypeFunction {
		ret := handler.Invoke(string(payload))
		// If returns a Promise, attach then
		if ret.Type() == js.TypeObject && ret.Get("then").Type() == js.TypeFunction {
			then := js.FuncOf(func(this js.Value, args []js.Value) any {
				ans := ""
				if len(args) > 0 {
					ans = args[0].String()
				}
				js.Global().Get("goar").Call("answerAskUser", id, ans)
				return nil
			})
			ret.Call("then", then)
		}
	} else {
		// Dispatch DOM CustomEvent for PWA listeners
		if js.Global().Get("dispatchEvent").Truthy() {
			evInit := js.Global().Get("Object").New()
			evInit.Set("detail", string(payload))
			ev := js.Global().Get("CustomEvent").New("goar:askUser", evInit)
			js.Global().Call("dispatchEvent", ev)
		}
	}

	select {
	case ans := <-ch:
		return ans, nil
	case <-time.After(10 * time.Minute):
		askMu.Lock()
		delete(askWaiters, id)
		askMu.Unlock()
		return "", fmt.Errorf("ask_user_question timed out waiting for PWA answer")
	}
}
