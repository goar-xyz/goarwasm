// Package goar is the GOAR autonomous CLI coding agent (Go port of goar 1.1.1).
package goar

// Version mirrors goar/__init__.py __version__.
const Version = "1.1.1"
