//go:build js && wasm

// Package browsernet provides in-browser TCP networking for GOAR WASM.
//
// Dial path (product):
//  1. Wisp v1 CONNECT over WebSocket (default: Mercury wss://wisp.mercurywork.shop/)
//  2. Optional Direct Sockets when the runtime exposes TCPSocket (advanced / IWA)
//
// SOCKS5 proxies are not supported (no AGENT_SOCKS_PROXY, no socks5:// configure
// URL, no SOCKS handshake on product dial paths).
//
// Environment:
//   - AGENT_WISP_URL — optional Wisp endpoint override
package browsernet
