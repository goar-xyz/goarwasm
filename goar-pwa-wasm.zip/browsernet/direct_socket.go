//go:build js && wasm

package browsernet

import (
	"context"
	"errors"
	"fmt"
	"io"
	"net"
	"strconv"
	"sync"
	"syscall/js"
	"time"
)

// Ensure DirectSocketConn implements net.Conn.
var _ net.Conn = (*DirectSocketConn)(nil)

// DirectSocketConn is a net.Conn backed by Chromium Direct Sockets TCPSocket
// (readable.getReader / writable.getWriter streams).
type DirectSocketConn struct {
	socket js.Value
	reader js.Value
	writer js.Value

	local  net.Addr
	remote net.Addr

	mu     sync.Mutex
	buf    []byte
	closed bool
	err    error
	cond   *sync.Cond

	readDeadline  time.Time
	writeDeadline time.Time

	readLoopDone chan struct{}
}

type tcpAddr struct {
	network string
	address string
}

func (a tcpAddr) Network() string { return a.network }
func (a tcpAddr) String() string  { return a.address }

// directSocketsAvailable reports whether a TCPSocket constructor (or a
// navigator.sockets.tcp shape) is present. Presence does not guarantee open()
// will succeed — permissions / Isolated Web App policy may still reject.
func directSocketsAvailable() bool {
	if ctor := js.Global().Get("TCPSocket"); ctor.Truthy() && ctor.Type() == js.TypeFunction {
		return true
	}
	nav := js.Global().Get("navigator")
	if !nav.Truthy() {
		return false
	}
	sockets := nav.Get("sockets")
	if !sockets.Truthy() {
		return false
	}
	tcp := sockets.Get("tcp")
	return tcp.Truthy()
}

// dialDirectSocket opens a raw TCP connection via Direct Sockets TCPSocket.
func dialDirectSocket(ctx context.Context, host string, port int) (*DirectSocketConn, error) {
	if !directSocketsAvailable() {
		return nil, errors.New("browsernet: Direct Sockets / TCPSocket not available")
	}

	ctor := js.Global().Get("TCPSocket")
	if !ctor.Truthy() || ctor.Type() != js.TypeFunction {
		return nil, errors.New("browsernet: TCPSocket constructor not available")
	}

	var socket js.Value
	func() {
		defer func() {
			if r := recover(); r != nil {
				socket = js.Undefined()
			}
		}()
		socket = ctor.New(host, port)
	}()
	if socket.IsUndefined() || socket.IsNull() {
		return nil, errors.New("browsernet: TCPSocket constructor failed")
	}

	opened := socket.Get("opened")
	openInfo, err := awaitPromise(ctx, opened)
	if err != nil {
		_ = closeJSSocket(socket)
		return nil, fmt.Errorf("browsernet: TCPSocket open: %w", err)
	}

	readable := openInfo.Get("readable")
	writable := openInfo.Get("writable")
	if !readable.Truthy() || !writable.Truthy() {
		_ = closeJSSocket(socket)
		return nil, errors.New("browsernet: TCPSocket open missing readable/writable")
	}

	reader := readable.Call("getReader")
	writer := writable.Call("getWriter")
	if !reader.Truthy() || !writer.Truthy() {
		_ = closeJSSocket(socket)
		return nil, errors.New("browsernet: TCPSocket getReader/getWriter failed")
	}

	localAddr := "browser"
	if la := openInfo.Get("localAddress"); la.Truthy() && la.Type() == js.TypeString {
		lp := openInfo.Get("localPort")
		if lp.Truthy() {
			localAddr = net.JoinHostPort(la.String(), strconv.Itoa(lp.Int()))
		} else {
			localAddr = la.String()
		}
	}
	remoteAddr := net.JoinHostPort(host, strconv.Itoa(port))
	if ra := openInfo.Get("remoteAddress"); ra.Truthy() && ra.Type() == js.TypeString {
		rp := openInfo.Get("remotePort")
		if rp.Truthy() {
			remoteAddr = net.JoinHostPort(ra.String(), strconv.Itoa(rp.Int()))
		}
	}

	c := &DirectSocketConn{
		socket:       socket,
		reader:       reader,
		writer:       writer,
		local:        tcpAddr{network: "tcp", address: localAddr},
		remote:       tcpAddr{network: "tcp", address: remoteAddr},
		readLoopDone: make(chan struct{}),
	}
	c.cond = sync.NewCond(&c.mu)
	go c.readLoop()
	return c, nil
}

func closeJSSocket(socket js.Value) error {
	if socket.IsUndefined() || socket.IsNull() {
		return nil
	}
	closeFn := socket.Get("close")
	if closeFn.Truthy() && closeFn.Type() == js.TypeFunction {
		p := socket.Call("close")
		if p.Truthy() {
			_, _ = awaitPromise(context.Background(), p)
		}
	}
	return nil
}

func (c *DirectSocketConn) readLoop() {
	defer close(c.readLoopDone)
	for {
		c.mu.Lock()
		closed := c.closed
		reader := c.reader
		c.mu.Unlock()
		if closed || !reader.Truthy() {
			return
		}

		result, err := awaitPromise(context.Background(), reader.Call("read"))
		if err != nil {
			c.mu.Lock()
			if !c.closed {
				c.err = err
				c.closed = true
			}
			c.cond.Broadcast()
			c.mu.Unlock()
			return
		}

		if result.Get("done").Truthy() && result.Get("done").Bool() {
			c.mu.Lock()
			if c.err == nil {
				c.err = io.EOF
			}
			c.closed = true
			c.cond.Broadcast()
			c.mu.Unlock()
			return
		}

		value := result.Get("value")
		var b []byte
		if value.InstanceOf(js.Global().Get("Uint8Array")) {
			b = make([]byte, value.Get("byteLength").Int())
			js.CopyBytesToGo(b, value)
		} else if value.InstanceOf(js.Global().Get("ArrayBuffer")) {
			u8 := js.Global().Get("Uint8Array").New(value)
			b = make([]byte, u8.Get("byteLength").Int())
			js.CopyBytesToGo(b, u8)
		} else {
			continue
		}

		c.mu.Lock()
		if !c.closed {
			c.buf = append(c.buf, b...)
			c.cond.Broadcast()
		}
		c.mu.Unlock()
	}
}

// Read implements net.Conn.
func (c *DirectSocketConn) Read(b []byte) (int, error) {
	c.mu.Lock()
	defer c.mu.Unlock()
	for {
		if len(c.buf) > 0 {
			n := copy(b, c.buf)
			c.buf = c.buf[n:]
			return n, nil
		}
		if c.err != nil {
			return 0, c.err
		}
		if c.closed {
			return 0, io.EOF
		}
		if err := c.waitDeadlineLocked(c.readDeadline); err != nil {
			return 0, err
		}
	}
}

// Write implements net.Conn.
func (c *DirectSocketConn) Write(b []byte) (int, error) {
	c.mu.Lock()
	if c.closed {
		c.mu.Unlock()
		return 0, net.ErrClosed
	}
	deadline := c.writeDeadline
	writer := c.writer
	c.mu.Unlock()

	if err := checkDeadline(deadline); err != nil {
		return 0, err
	}

	ctx, cancel := deadlineContext(deadline)
	defer cancel()

	ready := writer.Get("ready")
	if ready.Truthy() {
		if _, err := awaitPromise(ctx, ready); err != nil {
			return 0, fmt.Errorf("browsernet: TCPSocket writer ready: %w", err)
		}
	}

	u8 := js.Global().Get("Uint8Array").New(len(b))
	js.CopyBytesToJS(u8, b)
	if _, err := awaitPromise(ctx, writer.Call("write", u8)); err != nil {
		return 0, fmt.Errorf("browsernet: TCPSocket write: %w", err)
	}
	return len(b), nil
}

// Close implements net.Conn.
func (c *DirectSocketConn) Close() error {
	c.mu.Lock()
	if c.closed {
		c.mu.Unlock()
		return nil
	}
	c.closed = true
	c.err = net.ErrClosed
	c.cond.Broadcast()
	reader := c.reader
	writer := c.writer
	socket := c.socket
	c.mu.Unlock()

	if writer.Truthy() {
		closeFn := writer.Get("close")
		if closeFn.Truthy() && closeFn.Type() == js.TypeFunction {
			p := writer.Call("close")
			if p.Truthy() {
				_, _ = awaitPromise(context.Background(), p)
			}
		} else {
			abort := writer.Get("abort")
			if abort.Truthy() && abort.Type() == js.TypeFunction {
				_ = writer.Call("abort")
			}
		}
	}
	if reader.Truthy() {
		cancel := reader.Get("cancel")
		if cancel.Truthy() && cancel.Type() == js.TypeFunction {
			p := reader.Call("cancel")
			if p.Truthy() {
				_, _ = awaitPromise(context.Background(), p)
			}
		}
	}
	_ = closeJSSocket(socket)

	select {
	case <-c.readLoopDone:
	case <-time.After(2 * time.Second):
	}
	return nil
}

// LocalAddr implements net.Conn.
func (c *DirectSocketConn) LocalAddr() net.Addr { return c.local }

// RemoteAddr implements net.Conn.
func (c *DirectSocketConn) RemoteAddr() net.Addr { return c.remote }

// SetDeadline implements net.Conn.
func (c *DirectSocketConn) SetDeadline(t time.Time) error {
	c.mu.Lock()
	defer c.mu.Unlock()
	c.readDeadline = t
	c.writeDeadline = t
	c.cond.Broadcast()
	return nil
}

// SetReadDeadline implements net.Conn.
func (c *DirectSocketConn) SetReadDeadline(t time.Time) error {
	c.mu.Lock()
	defer c.mu.Unlock()
	c.readDeadline = t
	c.cond.Broadcast()
	return nil
}

// SetWriteDeadline implements net.Conn.
func (c *DirectSocketConn) SetWriteDeadline(t time.Time) error {
	c.mu.Lock()
	defer c.mu.Unlock()
	c.writeDeadline = t
	return nil
}

func (c *DirectSocketConn) waitDeadlineLocked(d time.Time) error {
	if err := checkDeadline(d); err != nil {
		return err
	}
	if d.IsZero() {
		c.cond.Wait()
		return nil
	}
	timer := time.AfterFunc(time.Until(d), func() {
		c.mu.Lock()
		c.cond.Broadcast()
		c.mu.Unlock()
	})
	c.cond.Wait()
	timer.Stop()
	return checkDeadline(d)
}

func deadlineContext(d time.Time) (context.Context, context.CancelFunc) {
	if d.IsZero() {
		return context.WithCancel(context.Background())
	}
	return context.WithDeadline(context.Background(), d)
}

// dialDirectTo opens a Direct Sockets TCP connection to network/address (no SOCKS).
func dialDirectTo(ctx context.Context, network, address string) (net.Conn, error) {
	if network != "tcp" && network != "tcp4" && network != "tcp6" {
		return nil, fmt.Errorf("browsernet: unsupported network %q", network)
	}
	host, portStr, err := net.SplitHostPort(address)
	if err != nil {
		return nil, fmt.Errorf("browsernet: address: %w", err)
	}
	port, err := strconv.Atoi(portStr)
	if err != nil || port < 0 || port > 65535 {
		return nil, fmt.Errorf("browsernet: invalid port %q", portStr)
	}
	return dialDirectSocket(ctx, host, port)
}
