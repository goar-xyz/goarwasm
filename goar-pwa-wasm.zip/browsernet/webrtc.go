//go:build js && wasm

package browsernet

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net"
	"sync"
	"syscall/js"
	"time"
)

// WebRTC mesh remains BroadcastChannel signaling + RTCPeerConnection DataChannel
// (see ListenWebRTC / WebRTCConn). Product dialing is Wisp-only (see sdn.go).

// DefaultSTUNURL is the Google public STUN server (fixed from blueprint typo stun:://google.com).
const DefaultSTUNURL = "stun:stun.l.google.com:19302"

// Ensure WebRTC data-channel connections implement net.Conn.
var (
	_ net.Conn     = (*WebRTCConn)(nil)
	_ net.Listener = (*WebRTCListener)(nil)
)

// WebRTCConn is a net.Conn over an RTCDataChannel.
type WebRTCConn struct {
	pc     js.Value
	dc     js.Value
	local  net.Addr
	remote net.Addr

	mu     sync.Mutex
	buf    []byte
	closed bool
	err    error
	cond   *sync.Cond

	readDeadline  time.Time
	writeDeadline time.Time

	onMessage js.Func
	onClose   js.Func
	onOpen    js.Func
	opened    chan struct{}
	openOnce  sync.Once
	released  bool
}

type webrtcAddr struct {
	peerID string
}

func (a webrtcAddr) Network() string { return "webrtc" }
func (a webrtcAddr) String() string  { return a.peerID }

func newWebRTCConn(pc, dc js.Value, localID, remoteID string) *WebRTCConn {
	c := &WebRTCConn{
		pc:     pc,
		dc:     dc,
		local:  webrtcAddr{peerID: localID},
		remote: webrtcAddr{peerID: remoteID},
		opened: make(chan struct{}),
	}
	c.cond = sync.NewCond(&c.mu)

	c.onMessage = js.FuncOf(func(this js.Value, args []js.Value) any {
		if len(args) == 0 {
			return nil
		}
		data := args[0].Get("data")
		var b []byte
		if data.InstanceOf(js.Global().Get("ArrayBuffer")) {
			u8 := js.Global().Get("Uint8Array").New(data)
			b = make([]byte, u8.Get("byteLength").Int())
			js.CopyBytesToGo(b, u8)
		} else if data.InstanceOf(js.Global().Get("Uint8Array")) {
			b = make([]byte, data.Get("byteLength").Int())
			js.CopyBytesToGo(b, data)
		} else if data.Type() == js.TypeString {
			b = []byte(data.String())
		} else {
			return nil
		}
		c.mu.Lock()
		if !c.closed {
			c.buf = append(c.buf, b...)
			c.cond.Broadcast()
		}
		c.mu.Unlock()
		return nil
	})
	c.onClose = js.FuncOf(func(this js.Value, args []js.Value) any {
		c.mu.Lock()
		c.closed = true
		if c.err == nil {
			c.err = io.EOF
		}
		c.cond.Broadcast()
		c.mu.Unlock()
		return nil
	})
	c.onOpen = js.FuncOf(func(this js.Value, args []js.Value) any {
		c.openOnce.Do(func() { close(c.opened) })
		return nil
	})

	dc.Set("binaryType", "arraybuffer")
	dc.Set("onmessage", c.onMessage)
	dc.Set("onclose", c.onClose)
	dc.Set("onopen", c.onOpen)
	// Already-open channel (answerer side often sees open immediately)
	if dc.Get("readyState").String() == "open" {
		c.openOnce.Do(func() { close(c.opened) })
	}
	return c
}

func (c *WebRTCConn) waitOpen(ctx context.Context) error {
	select {
	case <-ctx.Done():
		return ctx.Err()
	case <-c.opened:
		return nil
	}
}

func (c *WebRTCConn) Read(b []byte) (int, error) {
	c.mu.Lock()
	defer c.mu.Unlock()
	for {
		if len(c.buf) > 0 {
			n := copy(b, c.buf)
			c.buf = c.buf[n:]
			return n, nil
		}
		if c.err != nil {
			return 0, c.err
		}
		if c.closed {
			return 0, io.EOF
		}
		if err := waitDeadlineCond(c.cond, &c.mu, c.readDeadline); err != nil {
			return 0, err
		}
	}
}

func (c *WebRTCConn) Write(b []byte) (int, error) {
	c.mu.Lock()
	if c.closed {
		c.mu.Unlock()
		return 0, net.ErrClosed
	}
	if err := checkDeadline(c.writeDeadline); err != nil {
		c.mu.Unlock()
		return 0, err
	}
	dc := c.dc
	c.mu.Unlock()

	u8 := js.Global().Get("Uint8Array").New(len(b))
	js.CopyBytesToJS(u8, b)
	dc.Call("send", u8)
	return len(b), nil
}

func (c *WebRTCConn) Close() error {
	c.mu.Lock()
	if c.closed {
		c.mu.Unlock()
		return nil
	}
	c.closed = true
	c.err = net.ErrClosed
	c.cond.Broadcast()
	dc, pc := c.dc, c.pc
	c.mu.Unlock()

	if !dc.IsUndefined() && !dc.IsNull() {
		dc.Call("close")
	}
	if !pc.IsUndefined() && !pc.IsNull() {
		pc.Call("close")
	}
	c.release()
	return nil
}

func (c *WebRTCConn) release() {
	c.mu.Lock()
	defer c.mu.Unlock()
	if c.released {
		return
	}
	c.released = true
	c.onMessage.Release()
	c.onClose.Release()
	c.onOpen.Release()
}

func (c *WebRTCConn) LocalAddr() net.Addr  { return c.local }
func (c *WebRTCConn) RemoteAddr() net.Addr { return c.remote }
func (c *WebRTCConn) SetDeadline(t time.Time) error {
	return setBothDeadlines(&c.mu, &c.readDeadline, &c.writeDeadline, c.cond, t)
}
func (c *WebRTCConn) SetReadDeadline(t time.Time) error {
	return setReadDeadline(&c.mu, &c.readDeadline, c.cond, t)
}
func (c *WebRTCConn) SetWriteDeadline(t time.Time) error {
	return setWriteDeadline(&c.mu, &c.writeDeadline, t)
}

func setBothDeadlines(mu *sync.Mutex, r, w *time.Time, cond *sync.Cond, t time.Time) error {
	mu.Lock()
	*r, *w = t, t
	cond.Broadcast()
	mu.Unlock()
	return nil
}
func setReadDeadline(mu *sync.Mutex, r *time.Time, cond *sync.Cond, t time.Time) error {
	mu.Lock()
	*r = t
	cond.Broadcast()
	mu.Unlock()
	return nil
}
func setWriteDeadline(mu *sync.Mutex, w *time.Time, t time.Time) error {
	mu.Lock()
	*w = t
	mu.Unlock()
	return nil
}

func waitDeadlineCond(cond *sync.Cond, mu *sync.Mutex, d time.Time) error {
	if err := checkDeadline(d); err != nil {
		return err
	}
	if d.IsZero() {
		cond.Wait()
		return nil
	}
	timer := time.AfterFunc(time.Until(d), func() {
		mu.Lock()
		cond.Broadcast()
		mu.Unlock()
	})
	cond.Wait()
	timer.Stop()
	return checkDeadline(d)
}

// WebRTCListener accepts mesh peers via BroadcastChannel signaling + RTCPeerConnection.
type WebRTCListener struct {
	channelName string
	localID     string
	stunURL     string
	bc          js.Value

	mu      sync.Mutex
	closed  bool
	pending chan net.Conn

	onMessage js.Func
	pcs       map[string]js.Value
	iceFuncs  []js.Func
	released  bool
}

// ListenWebRTC starts a BroadcastChannel-signaled WebRTC mesh listener.
// channelName is the BroadcastChannel name; localID identifies this peer.
func ListenWebRTC(channelName, localID string) (*WebRTCListener, error) {
	return ListenWebRTCSTUN(channelName, localID, DefaultSTUNURL)
}

// ListenWebRTCSTUN is ListenWebRTC with an explicit STUN URL.
func ListenWebRTCSTUN(channelName, localID, stunURL string) (*WebRTCListener, error) {
	if js.Global().Get("BroadcastChannel").IsUndefined() {
		return nil, errors.New("browsernet: BroadcastChannel not available")
	}
	if js.Global().Get("RTCPeerConnection").IsUndefined() {
		return nil, errors.New("browsernet: RTCPeerConnection not available")
	}
	if stunURL == "" {
		stunURL = DefaultSTUNURL
	}
	if localID == "" {
		localID = fmt.Sprintf("peer-%d", time.Now().UnixNano())
	}
	ln := &WebRTCListener{
		channelName: channelName,
		localID:     localID,
		stunURL:     stunURL,
		bc:          js.Global().Get("BroadcastChannel").New(channelName),
		pending:     make(chan net.Conn, 8),
		pcs:         make(map[string]js.Value),
	}
	ln.onMessage = js.FuncOf(func(this js.Value, args []js.Value) any {
		if len(args) == 0 {
			return nil
		}
		data := args[0].Get("data")
		var raw string
		if data.Type() == js.TypeString {
			raw = data.String()
		} else if !data.IsUndefined() {
			raw = js.Global().Get("JSON").Call("stringify", data).String()
		} else {
			return nil
		}
		var msg signalMsg
		if err := json.Unmarshal([]byte(raw), &msg); err != nil {
			return nil
		}
		if msg.To != "" && msg.To != ln.localID {
			return nil
		}
		if msg.From == ln.localID {
			return nil
		}
		go ln.handleSignal(msg)
		return nil
	})
	ln.bc.Set("onmessage", ln.onMessage)
	// Announce presence so peers can offer.
	ln.post(signalMsg{Type: "hello", From: ln.localID})
	return ln, nil
}

type signalMsg struct {
	Type string `json:"type"`
	From string `json:"from"`
	To   string `json:"to,omitempty"`
	SDP  string `json:"sdp,omitempty"`
	Cand string `json:"candidate,omitempty"`
}

func (ln *WebRTCListener) post(msg signalMsg) {
	b, _ := json.Marshal(msg)
	ln.bc.Call("postMessage", string(b))
}

func (ln *WebRTCListener) iceServers() js.Value {
	stun := js.Global().Get("Object").New()
	stun.Set("urls", ln.stunURL)
	arr := js.Global().Get("Array").New()
	arr.SetIndex(0, stun)
	cfg := js.Global().Get("Object").New()
	cfg.Set("iceServers", arr)
	return cfg
}

func (ln *WebRTCListener) handleSignal(msg signalMsg) {
	ln.mu.Lock()
	if ln.closed {
		ln.mu.Unlock()
		return
	}
	ln.mu.Unlock()

	switch msg.Type {
	case "hello":
		if ln.localID > msg.From {
			ctx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
			_, _ = ln.DialPeer(ctx, msg.From)
			cancel()
		}
	case "offer":
		ln.acceptOffer(msg)
	case "answer":
		ln.applyRemote(msg.From, msg.SDP, "answer")
	case "candidate":
		ln.addCandidate(msg.From, msg.Cand)
	}
}

func (ln *WebRTCListener) newPC(peerID string) js.Value {
	pc := js.Global().Get("RTCPeerConnection").New(ln.iceServers())
	ln.mu.Lock()
	ln.pcs[peerID] = pc
	ln.mu.Unlock()

	onICE := js.FuncOf(func(this js.Value, args []js.Value) any {
		if len(args) == 0 {
			return nil
		}
		ev := args[0]
		cand := ev.Get("candidate")
		if cand.IsNull() || cand.IsUndefined() {
			return nil
		}
		ln.post(signalMsg{
			Type: "candidate",
			From: ln.localID,
			To:   peerID,
			Cand: js.Global().Get("JSON").Call("stringify", cand).String(),
		})
		return nil
	})
	pc.Set("onicecandidate", onICE)
	ln.mu.Lock()
	ln.iceFuncs = append(ln.iceFuncs, onICE)
	ln.mu.Unlock()
	return pc
}

// DialPeer creates an offer toward peerID and returns a connected WebRTCConn.
func (ln *WebRTCListener) DialPeer(ctx context.Context, peerID string) (net.Conn, error) {
	pc := ln.newPC(peerID)
	dcOpts := js.Global().Get("Object").New()
	dcOpts.Set("ordered", true)
	dc := pc.Call("createDataChannel", "goar", dcOpts)
	conn := newWebRTCConn(pc, dc, ln.localID, peerID)

	offerPromise := pc.Call("createOffer")
	offer, err := awaitPromise(ctx, offerPromise)
	if err != nil {
		_ = conn.Close()
		return nil, err
	}
	setLocal := pc.Call("setLocalDescription", offer)
	if _, err := awaitPromise(ctx, setLocal); err != nil {
		_ = conn.Close()
		return nil, err
	}
	sdp := pc.Get("localDescription").Get("sdp").String()
	ln.post(signalMsg{Type: "offer", From: ln.localID, To: peerID, SDP: sdp})

	if err := conn.waitOpen(ctx); err != nil {
		_ = conn.Close()
		return nil, err
	}
	return conn, nil
}

func (ln *WebRTCListener) acceptOffer(msg signalMsg) {
	ctx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
	defer cancel()

	pc := ln.newPC(msg.From)
	pending := make(chan *WebRTCConn, 1)
	onDC := js.FuncOf(func(this js.Value, args []js.Value) any {
		if len(args) == 0 {
			return nil
		}
		dc := args[0].Get("channel")
		c := newWebRTCConn(pc, dc, ln.localID, msg.From)
		select {
		case pending <- c:
		default:
		}
		return nil
	})
	pc.Set("ondatachannel", onDC)

	offerInit := js.Global().Get("Object").New()
	offerInit.Set("type", "offer")
	offerInit.Set("sdp", msg.SDP)
	if _, err := awaitPromise(ctx, pc.Call("setRemoteDescription", offerInit)); err != nil {
		onDC.Release()
		return
	}
	answer, err := awaitPromise(ctx, pc.Call("createAnswer"))
	if err != nil {
		onDC.Release()
		return
	}
	if _, err := awaitPromise(ctx, pc.Call("setLocalDescription", answer)); err != nil {
		onDC.Release()
		return
	}
	sdp := pc.Get("localDescription").Get("sdp").String()
	ln.post(signalMsg{Type: "answer", From: ln.localID, To: msg.From, SDP: sdp})

	select {
	case c := <-pending:
		onDC.Release()
		_ = c.waitOpen(ctx)
		ln.mu.Lock()
		if !ln.closed {
			select {
			case ln.pending <- c:
			default:
				_ = c.Close()
			}
		} else {
			_ = c.Close()
		}
		ln.mu.Unlock()
	case <-ctx.Done():
		onDC.Release()
	}
}

func (ln *WebRTCListener) applyRemote(peerID, sdp, typ string) {
	ln.mu.Lock()
	pc, ok := ln.pcs[peerID]
	ln.mu.Unlock()
	if !ok {
		return
	}
	desc := js.Global().Get("Object").New()
	desc.Set("type", typ)
	desc.Set("sdp", sdp)
	ctx, cancel := context.WithTimeout(context.Background(), 15*time.Second)
	defer cancel()
	_, _ = awaitPromise(ctx, pc.Call("setRemoteDescription", desc))
}

func (ln *WebRTCListener) addCandidate(peerID, candJSON string) {
	ln.mu.Lock()
	pc, ok := ln.pcs[peerID]
	ln.mu.Unlock()
	if !ok || candJSON == "" {
		return
	}
	cand := js.Global().Get("JSON").Call("parse", candJSON)
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()
	_, _ = awaitPromise(ctx, pc.Call("addIceCandidate", cand))
}

// Accept implements net.Listener.
func (ln *WebRTCListener) Accept() (net.Conn, error) {
	c, ok := <-ln.pending
	if !ok {
		return nil, net.ErrClosed
	}
	return c, nil
}

// Close implements net.Listener.
func (ln *WebRTCListener) Close() error {
	ln.mu.Lock()
	if ln.closed {
		ln.mu.Unlock()
		return nil
	}
	ln.closed = true
	close(ln.pending)
	pcs := ln.pcs
	ln.pcs = nil
	ln.mu.Unlock()

	for _, pc := range pcs {
		pc.Call("close")
	}
	if !ln.bc.IsUndefined() {
		ln.bc.Call("close")
	}
	ln.mu.Lock()
	funcs := ln.iceFuncs
	ln.iceFuncs = nil
	if !ln.released {
		ln.released = true
		ln.onMessage.Release()
	}
	ln.mu.Unlock()
	for _, f := range funcs {
		f.Release()
	}
	return nil
}

// Addr implements net.Listener.
func (ln *WebRTCListener) Addr() net.Addr {
	return webrtcAddr{peerID: ln.localID + "@" + ln.channelName}
}

// awaitPromise waits for a JS Promise to settle.
func awaitPromise(ctx context.Context, p js.Value) (js.Value, error) {
	if p.IsUndefined() || p.IsNull() {
		return js.Undefined(), errors.New("browsernet: nil promise")
	}
	done := make(chan struct{})
	var result js.Value
	var errMsg string
	var once sync.Once

	then := js.FuncOf(func(this js.Value, args []js.Value) any {
		once.Do(func() {
			if len(args) > 0 {
				result = args[0]
			}
			close(done)
		})
		return nil
	})
	catch := js.FuncOf(func(this js.Value, args []js.Value) any {
		once.Do(func() {
			if len(args) > 0 {
				errMsg = args[0].String()
			} else {
				errMsg = "promise rejected"
			}
			close(done)
		})
		return nil
	})
	defer then.Release()
	defer catch.Release()

	p.Call("then", then).Call("catch", catch)

	select {
	case <-ctx.Done():
		return js.Undefined(), ctx.Err()
	case <-done:
		if errMsg != "" {
			return js.Undefined(), errors.New(errMsg)
		}
		return result, nil
	}
}
