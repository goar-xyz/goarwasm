//go:build js && wasm

package browsernet

import (
	"context"
	"fmt"
	"net"
	"net/http"
	"strings"
	"sync"
	"time"
)

// EnvProxyPreferred is deprecated and ignored (SOCKS removed from product surface).
// Kept as empty-name sentinel so old binaries referencing the symbol still link if vendored.
const EnvProxyPreferred = ""

// EnvProxyFallback is deprecated and ignored.
const EnvProxyFallback = ""

// Transport mode strings reported by TransportMode / goar.status().
const (
	TransportDirectSockets = "direct-sockets"
	TransportWebSocket     = "websocket"
)

// Dial is the process-wide DialContext set by SDN.Install for non-HTTP dials
// (SSH, raw TCP). Nil until Install runs. DialContextFunc is defined in sql_interceptor.go.
var Dial DialContextFunc

var (
	transportMu   sync.Mutex
	transportMode string // last successful (or preferred) dial path
)

// DialContext dials through the installed package Dial (set by Install).
// Prefer this for tools that need TCP beyond http.DefaultTransport.
func DialContext(ctx context.Context, network, address string) (net.Conn, error) {
	if Dial == nil {
		return nil, fmt.Errorf("browsernet: Dial not installed; call SDN.Install() first")
	}
	return Dial(ctx, network, address)
}

// TransportMode returns the active dial path: "direct-sockets", "wisp", or "websocket".
// Before the first successful dial it reflects capability preference.
func TransportMode() string {
	transportMu.Lock()
	defer transportMu.Unlock()
	if transportMode != "" {
		return transportMode
	}
	return TransportWisp
}

func setTransportMode(mode string) {
	transportMu.Lock()
	transportMode = mode
	transportMu.Unlock()
}

// SDN is the browsernet control plane: Wisp-first dialer + HTTP/resolver hooks.
type SDN struct {
	wispURL  string
	wispPool []string // primary + fallbacks

	mu        sync.Mutex
	installed bool
	lastMode  string
}

// SDNConfig configures Wisp endpoints (SOCKS ProxyURL is ignored if set).
type SDNConfig struct {
	// ProxyURL is ignored (kept for API compatibility; SOCKS removed from product).
	ProxyURL string
	// WispURL is an optional Wisp endpoint (wisp://, wisps://, or wss://…/wisp/).
	// When empty, DefaultWispURL is used unless SkipDefaultWisp.
	WispURL string
	// WispFallbacks appends extra Wisp URLs after WispURL (mercurywork is appended by default).
	WispFallbacks []string
	// SkipDefaultWisp disables wiring the mercurywork default when both URLs are empty.
	SkipDefaultWisp bool
}

// NewSDN prepares an SDN from a Wisp-looking URL (SOCKS URLs are rejected).
func NewSDN(proxyOrWispURL string) (*SDN, error) {
	raw := strings.TrimSpace(proxyOrWispURL)
	if raw == "" || LooksLikeWispURL(raw) {
		return NewSDNConfig(SDNConfig{WispURL: raw})
	}
	lower := strings.ToLower(raw)
	if strings.HasPrefix(lower, "socks5://") || strings.HasPrefix(lower, "socks5h://") {
		return nil, fmt.Errorf("browsernet: SOCKS proxies are not supported; set a Wisp URL (wss://… or AGENT_WISP_URL)")
	}
	return NewSDNConfig(SDNConfig{WispURL: raw})
}

// NewSDNConfig builds an SDN from Wisp settings (ProxyURL ignored).
func NewSDNConfig(cfg SDNConfig) (*SDN, error) {
	s := &SDN{}

	// ProxyURL / SOCKS intentionally ignored — product is Wisp-only.
	_ = cfg.ProxyURL
	wisp := strings.TrimSpace(cfg.WispURL)

	pool := make([]string, 0, 4)
	seen := map[string]bool{}
	push := func(raw string) {
		n, err := NormalizeWispURL(raw)
		if err != nil || n == "" || seen[n] {
			return
		}
		seen[n] = true
		pool = append(pool, n)
	}

	if wisp != "" {
		push(wisp)
	}
	for _, f := range cfg.WispFallbacks {
		push(f)
	}

	if len(pool) == 0 && !cfg.SkipDefaultWisp {
		for _, d := range DefaultWispPool() {
			push(d)
		}
	} else if len(pool) > 0 {
		// Always offer mercurywork as last-resort fallback when any wisp is set.
		push(DefaultWispURL)
	}

	if len(pool) > 0 {
		s.wispURL = pool[0]
		s.wispPool = pool
	}

	if s.wispURL == "" {
		return nil, fmt.Errorf("browsernet: need a Wisp URL (set AGENT_WISP_URL or rely on default mercurywork)")
	}
	return s, nil
}

// NewSDNFromEnv reads AGENT_WISP_URL (SOCKS env vars are ignored).
// When unset, wires the default mercurywork Wisp pool (not an error).
func NewSDNFromEnv() (*SDN, error) {
	wisp := WispURLFromEnv()
	if wisp == "" {
		return NewSDNConfig(SDNConfig{}) // default mercurywork pool
	}
	return NewSDNConfig(SDNConfig{WispURL: wisp})
}

// GatewayURL returns the active Wisp URL.
func (s *SDN) GatewayURL() string {
	if s == nil {
		return ""
	}
	return s.wispURL
}

// WispURL returns the primary Wisp endpoint, if any.
func (s *SDN) WispURL() string {
	if s == nil {
		return ""
	}
	return s.wispURL
}

// ProxyHostPort always returns "" (SOCKS removed from product).
func (s *SDN) ProxyHostPort() string { return "" }

// HasSOCKS always returns false (SOCKS removed from product).
func (s *SDN) HasSOCKS() bool { return false }

// RemoteDNS always returns false (SOCKS removed from product).
func (s *SDN) RemoteDNS() bool { return false }

// TransportMode returns this SDN's last used dial path, or the capability preference.
func (s *SDN) TransportMode() string {
	if s == nil {
		return TransportMode()
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	if s.lastMode != "" {
		return s.lastMode
	}
	if s.wispURL != "" {
		return TransportWisp
	}
	if directSocketsAvailable() {
		return TransportDirectSockets
	}
	return TransportWebSocket
}

// DialContext dials a TCP address using automatic runtime fallback:
//  1. Wisp v1 CONNECT (TCP) when a Wisp URL / pool is configured
//  2. Direct Sockets TCPSocket to the destination when available (no SOCKS)
func (s *SDN) DialContext(ctx context.Context, network, address string) (net.Conn, error) {
	if s == nil {
		return nil, fmt.Errorf("browsernet: nil SDN")
	}

	var errs []string

	if s.wispURL != "" {
		fallbacks := s.wispPool
		if len(fallbacks) > 0 && fallbacks[0] == s.wispURL {
			fallbacks = fallbacks[1:]
		}
		conn, err := dialViaWisp(ctx, s.wispURL, fallbacks, network, address)
		if err == nil {
			s.recordMode(TransportWisp)
			return conn, nil
		}
		errs = append(errs, fmt.Sprintf("wisp: %v", err))
	}

	if directSocketsAvailable() {
		conn, err := dialDirectTo(ctx, network, address)
		if err == nil {
			s.recordMode(TransportDirectSockets)
			return conn, nil
		}
		errs = append(errs, fmt.Sprintf("direct-sockets: %v", err))
	}

	if len(errs) == 0 {
		return nil, fmt.Errorf("browsernet: no dial path configured")
	}
	return nil, fmt.Errorf("browsernet: all dial paths failed: %s", strings.Join(errs, "; "))
}

func (s *SDN) recordMode(mode string) {
	s.mu.Lock()
	s.lastMode = mode
	s.mu.Unlock()
	setTransportMode(mode)
}

// Dialer is an SDN-backed dialer (net.Dialer cannot override DialContext).
type Dialer struct {
	SDN     *SDN
	Timeout time.Duration
}

// DialContext dials through the SDN gateway.
func (d *Dialer) DialContext(ctx context.Context, network, address string) (net.Conn, error) {
	if d == nil || d.SDN == nil {
		return nil, fmt.Errorf("browsernet: nil Dialer")
	}
	if d.Timeout > 0 {
		var cancel context.CancelFunc
		ctx, cancel = context.WithTimeout(ctx, d.Timeout)
		defer cancel()
	}
	return d.SDN.DialContext(ctx, network, address)
}

// Dialer returns an SDN-backed Dialer (Timeout default 30s).
func (s *SDN) Dialer() *Dialer {
	return &Dialer{SDN: s, Timeout: 30 * time.Second}
}

// DialerFunc returns a DialContext function suitable for http.Transport.
func (s *SDN) DialerFunc() func(ctx context.Context, network, address string) (net.Conn, error) {
	return s.DialContext
}

// Install hooks the process-wide HTTP transport and PreferGo DNS dialer so
// default http clients use the SDN tunnel (webfetch/git/tools), and sets
// package-level Dial for non-HTTP dials (SSH, etc.).
// LLM provider / agent API calls must use NewDirectHTTPClient / utils.BuildHTTPClient
// (browser fetch) — not this Wisp-backed DefaultClient.
// Safe to call once per SDN; subsequent calls are no-ops.
func (s *SDN) Install() error {
	if s == nil {
		return fmt.Errorf("browsernet: nil SDN")
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	if s.installed {
		return nil
	}

	var tr *http.Transport
	if existing, ok := http.DefaultTransport.(*http.Transport); ok && existing != nil {
		tr = existing.Clone()
	} else {
		tr = &http.Transport{
			Proxy:                 nil,
			ForceAttemptHTTP2:     true,
			MaxIdleConns:          100,
			IdleConnTimeout:       90 * time.Second,
			TLSHandshakeTimeout:   10 * time.Second,
			ExpectContinueTimeout: 1 * time.Second,
		}
	}
	tr.Proxy = nil
	tr.DialContext = s.DialContext
	if tlsCfg, err := TLSConfig(); err != nil {
		return fmt.Errorf("browsernet: tls roots: %w", err)
	} else {
		tr.TLSClientConfig = tlsCfg
	}
	http.DefaultTransport = tr
	if http.DefaultClient != nil {
		http.DefaultClient.Transport = tr
	} else {
		http.DefaultClient = &http.Client{Transport: tr}
	}

	net.DefaultResolver = &net.Resolver{
		PreferGo: true,
		Dial: func(ctx context.Context, network, address string) (net.Conn, error) {
			return s.DialContext(ctx, network, address)
		},
	}

	Dial = s.DialContext
	// Preferred mode until first successful dial (Wisp-first).
	if s.wispURL != "" {
		setTransportMode(TransportWisp)
	} else if directSocketsAvailable() {
		setTransportMode(TransportDirectSockets)
	} else {
		setTransportMode(TransportWebSocket)
	}
	s.installed = true
	return nil
}

// ProxyURLFromEnv always returns "" — SOCKS env configuration removed from product.
func ProxyURLFromEnv() string { return "" }

// DirectSocketsAvailable reports whether the JS runtime exposes TCPSocket
// (or navigator.sockets.tcp). Open may still fail without IWA / permissions policy.
func DirectSocketsAvailable() bool {
	return directSocketsAvailable()
}
