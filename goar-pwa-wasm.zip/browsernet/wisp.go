//go:build js && wasm

package browsernet

import (
	"context"
	"encoding/binary"
	"errors"
	"fmt"
	"io"
	"net"
	"strconv"
	"os"
	"strings"
	"sync"
	"sync/atomic"
	"syscall/js"
	"time"
)

// Default public Wisp endpoint (Mercury Workshop — reliable default).
const (
	DefaultWispURL         = "wss://wisp.mercurywork.shop/"
	DefaultWispFallbackURL = "wss://wisp.mercurywork.shop/" // same as default; no manus auto-fallback
	EnvWispURL             = "AGENT_WISP_URL"
	TransportWisp          = "wisp"
)

// DefaultWispPool is mercurywork only (reliable public Wisp).
func DefaultWispPool() []string {
	return []string{DefaultWispURL}
}

const (
	wispPacketConnect  = 0x01
	wispPacketData     = 0x02
	wispPacketContinue = 0x03
	wispPacketClose    = 0x04
	wispStreamTCP      = 0x01
)

// LooksLikeWispURL reports whether raw is a Wisp-style URL
// (wisp://, wisps://, or ws(s)://…/wisp/).
func LooksLikeWispURL(raw string) bool {
	raw = strings.TrimSpace(raw)
	if raw == "" {
		return false
	}
	lower := strings.ToLower(raw)
	switch {
	case strings.HasPrefix(lower, "wisp://"), strings.HasPrefix(lower, "wisps://"):
		return true
	case strings.HasPrefix(lower, "ws://"), strings.HasPrefix(lower, "wss://"):
		return strings.Contains(lower, "/wisp")
	default:
		return false
	}
}

// NormalizeWispURL converts wisp://→ws:// and wisps://→wss://, validates, and
// ensures a trailing slash (Wisp URL convention).
func NormalizeWispURL(raw string) (string, error) {
	u := strings.TrimSpace(raw)
	if u == "" {
		return "", errors.New("browsernet: empty wisp URL")
	}
	lower := strings.ToLower(u)
	switch {
	case strings.HasPrefix(lower, "wisps://"):
		u = "wss://" + u[len("wisps://"):]
	case strings.HasPrefix(lower, "wisp://"):
		u = "ws://" + u[len("wisp://"):]
	case strings.HasPrefix(lower, "wss://"), strings.HasPrefix(lower, "ws://"):
		// keep
	default:
		return "", fmt.Errorf("browsernet: unsupported wisp scheme: %s", raw)
	}
	lower = strings.ToLower(u)
	if !strings.HasPrefix(lower, "ws://") && !strings.HasPrefix(lower, "wss://") {
		return "", fmt.Errorf("browsernet: bad wisp URL: %s", raw)
	}
	// Ensure trailing slash when no query/fragment (Wisp convention).
	if !strings.ContainsAny(u, "?#") && !strings.HasSuffix(u, "/") {
		u += "/"
	}
	return u, nil
}

// WispURLFromEnv returns AGENT_WISP_URL or "".
func WispURLFromEnv() string {
	return strings.TrimSpace(os.Getenv(EnvWispURL))
}

// dialViaWisp opens a TCP stream to address through one or more Wisp v1 servers.
// Transient WebSocket/handshake failures retry with exponential backoff across
// the URL pool so brief drops do not leave callers stuck on a half-dead path.
func dialViaWisp(ctx context.Context, primary string, fallbacks []string, network, address string) (net.Conn, error) {
	if network != "tcp" && network != "tcp4" && network != "tcp6" {
		return nil, fmt.Errorf("browsernet: unsupported network %q", network)
	}
	host, portStr, err := net.SplitHostPort(address)
	if err != nil {
		return nil, fmt.Errorf("browsernet: address: %w", err)
	}
	port, err := strconv.Atoi(portStr)
	if err != nil || port < 0 || port > 65535 {
		return nil, fmt.Errorf("browsernet: invalid port %q", portStr)
	}

	urls := make([]string, 0, 2+len(fallbacks))
	seen := map[string]bool{}
	push := func(raw string) {
		n, err := NormalizeWispURL(raw)
		if err != nil || n == "" || seen[n] {
			return
		}
		seen[n] = true
		urls = append(urls, n)
	}
	push(primary)
	for _, f := range fallbacks {
		push(f)
	}
	if len(urls) == 0 {
		return nil, errors.New("browsernet: no wisp URLs configured")
	}

	var errs []string
	backoff := wispDialBaseBackoff
	for attempt := 1; attempt <= wispDialMaxAttempts; attempt++ {
		atomic.AddUint64(&wispDialAttempts, 1)
		for _, u := range urls {
			if ctx.Err() != nil {
				return nil, ctx.Err()
			}
			conn, err := dialWispTCP(ctx, u, host, port)
			if err == nil {
				noteWispOK()
				return conn, nil
			}
			errs = append(errs, fmt.Sprintf("%s(try%d): %v", u, attempt, err))
			atomic.AddUint64(&wispDialFails, 1)
			noteWispDrop(err)
			if ctx.Err() != nil {
				return nil, ctx.Err()
			}
		}
		if attempt >= wispDialMaxAttempts {
			break
		}
		wait := backoff
		if wait > wispDialMaxBackoff {
			wait = wispDialMaxBackoff
		}
		timer := time.NewTimer(wait)
		select {
		case <-ctx.Done():
			timer.Stop()
			return nil, ctx.Err()
		case <-timer.C:
		}
		backoff *= 2
	}
	return nil, fmt.Errorf("browsernet: wisp dial failed after retries: %s", strings.Join(errs, "; "))
}

func dialWispTCP(ctx context.Context, wispURL, host string, port int) (net.Conn, error) {
	ws, err := dialWispWebSocket(ctx, wispURL)
	if err != nil {
		return nil, err
	}

	// Wait for initial CONTINUE on stream 0 (Wisp v1 handshake).
	initBuf, err := waitInitialContinue(ctx, ws)
	if err != nil {
		_ = ws.close()
		return nil, err
	}

	streamID := uint32(1)
	connectPayload := make([]byte, 0, 1+2+len(host))
	connectPayload = append(connectPayload, wispStreamTCP)
	var portBuf [2]byte
	binary.LittleEndian.PutUint16(portBuf[:], uint16(port))
	connectPayload = append(connectPayload, portBuf[:]...)
	connectPayload = append(connectPayload, []byte(host)...)
	if err := ws.send(encodeWispPacket(wispPacketConnect, streamID, connectPayload)); err != nil {
		_ = ws.close()
		return nil, fmt.Errorf("browsernet: wisp CONNECT: %w", err)
	}

	c := &wispStreamConn{
		ws:         ws,
		streamID:   streamID,
		remote:     wsAddr{network: "tcp", address: net.JoinHostPort(host, strconv.Itoa(port))},
		local:      wsAddr{network: "wisp", address: "browser"},
		bufRemain:  initBuf,
		closed:     make(chan struct{}),
		wispURL:    wispURL,
	}
	c.cond = sync.NewCond(&c.mu)
	go c.readLoop()
	return c, nil
}

func encodeWispPacket(typ byte, streamID uint32, payload []byte) []byte {
	pkt := make([]byte, 5+len(payload))
	pkt[0] = typ
	binary.LittleEndian.PutUint32(pkt[1:5], streamID)
	copy(pkt[5:], payload)
	return pkt
}

func waitInitialContinue(ctx context.Context, ws *wispWS) (uint32, error) {
	for {
		msg, err := ws.recv(ctx)
		if err != nil {
			return 0, err
		}
		if len(msg) < 5 {
			continue
		}
		typ := msg[0]
		sid := binary.LittleEndian.Uint32(msg[1:5])
		payload := msg[5:]
		if typ == wispPacketContinue && sid == 0 {
			if len(payload) < 4 {
				return 0, errors.New("browsernet: wisp initial CONTINUE too short")
			}
			return binary.LittleEndian.Uint32(payload[:4]), nil
		}
		if typ == wispPacketClose && sid == 0 {
			reason := byte(0)
			if len(payload) > 0 {
				reason = payload[0]
			}
			return 0, fmt.Errorf("browsernet: wisp closed during handshake (reason=0x%02x)", reason)
		}
	}
}

// --- low-level WebSocket with discrete messages ---

type wispWS struct {
	ws     js.Value
	msgs   chan []byte
	errCh  chan error
	closed int32

	onOpen, onMessage, onClose, onError js.Func
	opened                              chan struct{}
	openOnce                            sync.Once
	openErr                             error
}

func dialWispWebSocket(ctx context.Context, wsURL string) (*wispWS, error) {
	if js.Global().Get("WebSocket").IsUndefined() {
		return nil, errors.New("browsernet: WebSocket not available")
	}
	w := &wispWS{
		msgs:   make(chan []byte, 64),
		errCh:  make(chan error, 1),
		opened: make(chan struct{}),
	}
	ws := js.Global().Get("WebSocket").New(wsURL)
	ws.Set("binaryType", "arraybuffer")
	w.ws = ws

	w.onOpen = js.FuncOf(func(this js.Value, args []js.Value) any {
		w.openOnce.Do(func() { close(w.opened) })
		return nil
	})
	w.onMessage = js.FuncOf(func(this js.Value, args []js.Value) any {
		if len(args) == 0 || atomic.LoadInt32(&w.closed) != 0 {
			return nil
		}
		data := args[0].Get("data")
		var b []byte
		if data.InstanceOf(js.Global().Get("ArrayBuffer")) {
			uint8 := js.Global().Get("Uint8Array").New(data)
			b = make([]byte, uint8.Get("byteLength").Int())
			js.CopyBytesToGo(b, uint8)
		} else if data.InstanceOf(js.Global().Get("Uint8Array")) {
			b = make([]byte, data.Get("byteLength").Int())
			js.CopyBytesToGo(b, data)
		} else {
			return nil
		}
		select {
		case w.msgs <- b:
		default:
			// drop if reader is too slow; stream will notice gaps via CLOSE
			select {
			case w.msgs <- b:
			default:
			}
		}
		return nil
	})
	w.onClose = js.FuncOf(func(this js.Value, args []js.Value) any {
		w.openOnce.Do(func() {
			w.openErr = errors.New("browsernet: wisp websocket closed before open")
			close(w.opened)
		})
		w.fail(io.EOF)
		return nil
	})
	w.onError = js.FuncOf(func(this js.Value, args []js.Value) any {
		err := errors.New("browsernet: wisp websocket error")
		w.openOnce.Do(func() {
			w.openErr = err
			close(w.opened)
		})
		w.fail(err)
		return nil
	})
	ws.Set("onopen", w.onOpen)
	ws.Set("onmessage", w.onMessage)
	ws.Set("onclose", w.onClose)
	ws.Set("onerror", w.onError)

	select {
	case <-ctx.Done():
		_ = w.close()
		return nil, ctx.Err()
	case <-w.opened:
		if w.openErr != nil {
			_ = w.close()
			return nil, w.openErr
		}
	}
	return w, nil
}

func (w *wispWS) fail(err error) {
	if !atomic.CompareAndSwapInt32(&w.closed, 0, 1) {
		return
	}
	if err != nil && !errors.Is(err, net.ErrClosed) {
		noteWispDrop(err)
	}
	select {
	case w.errCh <- err:
	default:
	}
	close(w.msgs)
}

func (w *wispWS) send(b []byte) error {
	if atomic.LoadInt32(&w.closed) != 0 {
		return net.ErrClosed
	}
	uint8 := js.Global().Get("Uint8Array").New(len(b))
	js.CopyBytesToJS(uint8, b)
	w.ws.Call("send", uint8)
	return nil
}

func (w *wispWS) recv(ctx context.Context) ([]byte, error) {
	select {
	case <-ctx.Done():
		return nil, ctx.Err()
	case err := <-w.errCh:
		// re-queue so later readers see it
		select {
		case w.errCh <- err:
		default:
		}
		if err == nil {
			err = io.EOF
		}
		return nil, err
	case msg, ok := <-w.msgs:
		if !ok {
			return nil, io.EOF
		}
		return msg, nil
	}
}

func (w *wispWS) close() error {
	first := atomic.CompareAndSwapInt32(&w.closed, 0, 1)
	if first {
		select {
		case w.errCh <- net.ErrClosed:
		default:
		}
	}
	if !w.ws.IsUndefined() && !w.ws.IsNull() {
		w.ws.Set("onopen", js.Undefined())
		w.ws.Set("onmessage", js.Undefined())
		w.ws.Set("onclose", js.Undefined())
		w.ws.Set("onerror", js.Undefined())
		rs := w.ws.Get("readyState").Int()
		if rs == 0 || rs == 1 {
			w.ws.Call("close")
		}
	}
	// Release JS funcs once; ignore double-release panics.
	func() {
		defer func() { _ = recover() }()
		w.onOpen.Release()
		w.onMessage.Release()
		w.onClose.Release()
		w.onError.Release()
	}()
	return nil
}

// --- stream conn ---

type wispStreamConn struct {
	ws       *wispWS
	streamID uint32
	wispURL  string

	local  net.Addr
	remote net.Addr

	mu        sync.Mutex
	buf       []byte
	bufRemain uint32
	err       error
	closedCh  bool
	cond      *sync.Cond

	closed   chan struct{}

	readDeadline  time.Time
	writeDeadline time.Time

	closeOnce sync.Once
}

func (c *wispStreamConn) readLoop() {
	defer close(c.closed)
	ctx := context.Background()
	for {
		msg, err := c.ws.recv(ctx)
		if err != nil {
			c.setErr(err)
			return
		}
		if len(msg) < 5 {
			continue
		}
		typ := msg[0]
		sid := binary.LittleEndian.Uint32(msg[1:5])
		payload := msg[5:]
		if sid != c.streamID && !(typ == wispPacketContinue && sid == 0) {
			// ignore other streams / keepalive continues on 0 after handshake
			if typ == wispPacketContinue && sid == 0 && len(payload) >= 4 {
				// ignore — per-stream continues use stream ID
			}
			continue
		}
		switch typ {
		case wispPacketData:
			if sid != c.streamID {
				continue
			}
			if len(payload) == 0 {
				continue
			}
			c.mu.Lock()
			c.buf = append(c.buf, payload...)
			c.cond.Broadcast()
			c.mu.Unlock()
		case wispPacketContinue:
			if len(payload) < 4 {
				continue
			}
			n := binary.LittleEndian.Uint32(payload[:4])
			c.mu.Lock()
			c.bufRemain = n
			c.cond.Broadcast()
			c.mu.Unlock()
		case wispPacketClose:
			reason := byte(0x01)
			if len(payload) > 0 {
				reason = payload[0]
			}
			// 0x02 = voluntary stream closure → clean EOF for readers.
			if reason == 0x02 {
				c.setErr(io.EOF)
			} else {
				c.setErr(fmt.Errorf("browsernet: wisp stream closed (reason=0x%02x)", reason))
			}
			return
		}
	}
}

func (c *wispStreamConn) setErr(err error) {
	c.mu.Lock()
	defer c.mu.Unlock()
	if c.err == nil {
		c.err = err
	}
	c.closedCh = true
	c.cond.Broadcast()
}

func (c *wispStreamConn) Read(b []byte) (int, error) {
	c.mu.Lock()
	defer c.mu.Unlock()
	for {
		if len(c.buf) > 0 {
			n := copy(b, c.buf)
			c.buf = c.buf[n:]
			return n, nil
		}
		if c.err != nil {
			return 0, c.err
		}
		if c.closedCh {
			return 0, io.EOF
		}
		if err := c.waitDeadlineLocked(c.readDeadline); err != nil {
			return 0, err
		}
	}
}

func (c *wispStreamConn) Write(b []byte) (int, error) {
	total := 0
	for len(b) > 0 {
		c.mu.Lock()
		for c.bufRemain == 0 && c.err == nil && !c.closedCh {
			if err := checkDeadline(c.writeDeadline); err != nil {
				c.mu.Unlock()
				return total, err
			}
			// Wait for CONTINUE (or use a short wait + recheck deadline).
			if c.writeDeadline.IsZero() {
				c.cond.Wait()
			} else {
				if err := c.waitDeadlineLocked(c.writeDeadline); err != nil {
					c.mu.Unlock()
					return total, err
				}
			}
		}
		if c.err != nil {
			err := c.err
			c.mu.Unlock()
			return total, err
		}
		if c.closedCh {
			c.mu.Unlock()
			return total, net.ErrClosed
		}
		if err := checkDeadline(c.writeDeadline); err != nil {
			c.mu.Unlock()
			return total, err
		}
		// Send one DATA packet; decrement buffer remaining.
		chunk := b
		// Keep packets reasonably sized for WS.
		const maxChunk = 16 * 1024
		if len(chunk) > maxChunk {
			chunk = chunk[:maxChunk]
		}
		c.bufRemain--
		c.mu.Unlock()

		pkt := encodeWispPacket(wispPacketData, c.streamID, chunk)
		if err := c.ws.send(pkt); err != nil {
			return total, err
		}
		total += len(chunk)
		b = b[len(chunk):]
	}
	return total, nil
}

func (c *wispStreamConn) Close() error {
	c.closeOnce.Do(func() {
		_ = c.ws.send(encodeWispPacket(wispPacketClose, c.streamID, []byte{0x02}))
		_ = c.ws.close()
		c.setErr(net.ErrClosed)
	})
	return nil
}

func (c *wispStreamConn) LocalAddr() net.Addr  { return c.local }
func (c *wispStreamConn) RemoteAddr() net.Addr { return c.remote }

func (c *wispStreamConn) SetDeadline(t time.Time) error {
	c.mu.Lock()
	defer c.mu.Unlock()
	c.readDeadline = t
	c.writeDeadline = t
	c.cond.Broadcast()
	return nil
}

func (c *wispStreamConn) SetReadDeadline(t time.Time) error {
	c.mu.Lock()
	defer c.mu.Unlock()
	c.readDeadline = t
	c.cond.Broadcast()
	return nil
}

func (c *wispStreamConn) SetWriteDeadline(t time.Time) error {
	c.mu.Lock()
	defer c.mu.Unlock()
	c.writeDeadline = t
	c.cond.Broadcast()
	return nil
}

func (c *wispStreamConn) waitDeadlineLocked(d time.Time) error {
	if err := checkDeadline(d); err != nil {
		return err
	}
	if d.IsZero() {
		c.cond.Wait()
		return nil
	}
	timer := time.AfterFunc(time.Until(d), func() {
		c.mu.Lock()
		c.cond.Broadcast()
		c.mu.Unlock()
	})
	c.cond.Wait()
	timer.Stop()
	return checkDeadline(d)
}

var _ net.Conn = (*wispStreamConn)(nil)
