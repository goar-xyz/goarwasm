//go:build js && wasm

package browsernet

import (
	"sync"
	"sync/atomic"
	"time"
)

// Wisp dial / drop health for UI-safe reconnect (no secrets logged).
// Each TCP stream still opens its own Wisp WebSocket (v1); resilience is
// retry-with-backoff on dial plus drop signalling so SSH can recreate.

const (
	wispDialMaxAttempts = 5
	wispDialBaseBackoff = 400 * time.Millisecond
	wispDialMaxBackoff  = 8 * time.Second
)

var (
	wispHealthMu      sync.Mutex
	wispLastDropAt    time.Time
	wispLastDropErr   string
	wispLastOKAt      time.Time
	wispDialAttempts  uint64
	wispDialFails     uint64
	wispDropListeners []func(reason string)
)

// OnWispDrop registers a listener when a Wisp WebSocket fails/closes.
// Returns an unregister function.
func OnWispDrop(fn func(reason string)) (unregister func()) {
	if fn == nil {
		return func() {}
	}
	wispHealthMu.Lock()
	wispDropListeners = append(wispDropListeners, fn)
	idx := len(wispDropListeners) - 1
	wispHealthMu.Unlock()
	return func() {
		wispHealthMu.Lock()
		if idx >= 0 && idx < len(wispDropListeners) {
			wispDropListeners[idx] = nil
		}
		wispHealthMu.Unlock()
	}
}

// WispHealth reports recent dial/drop stats for status() (no secrets).
func WispHealth() map[string]any {
	wispHealthMu.Lock()
	defer wispHealthMu.Unlock()
	out := map[string]any{
		"dialAttempts": atomic.LoadUint64(&wispDialAttempts),
		"dialFails":    atomic.LoadUint64(&wispDialFails),
	}
	if !wispLastDropAt.IsZero() {
		out["lastDropAt"] = wispLastDropAt.UTC().Format(time.RFC3339Nano)
		out["lastDropErr"] = wispLastDropErr
	}
	if !wispLastOKAt.IsZero() {
		out["lastOKAt"] = wispLastOKAt.UTC().Format(time.RFC3339Nano)
	}
	return out
}

func noteWispOK() {
	wispHealthMu.Lock()
	wispLastOKAt = time.Now()
	wispHealthMu.Unlock()
}

func noteWispDrop(err error) {
	reason := "wisp websocket closed"
	if err != nil {
		reason = err.Error()
	}
	wispHealthMu.Lock()
	wispLastDropAt = time.Now()
	wispLastDropErr = reason
	listeners := append([]func(string){}, wispDropListeners...)
	wispHealthMu.Unlock()
	for _, fn := range listeners {
		if fn != nil {
			fn(reason)
		}
	}
}
