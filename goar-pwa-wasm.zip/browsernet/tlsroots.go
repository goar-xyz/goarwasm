//go:build js && wasm

package browsernet

import (
	"crypto/tls"
	"crypto/x509"
	_ "embed"
	"fmt"
)

//go:embed cacert.pem
var cacertPEM []byte

// RootCAs returns an x509 pool from the embedded Mozilla/system CA bundle.
// Go's SystemCertPool is empty under js/wasm, which causes
// "x509: certificate signed by unknown authority" on HTTPS.
func RootCAs() (*x509.CertPool, error) {
	pool := x509.NewCertPool()
	if ok := pool.AppendCertsFromPEM(cacertPEM); !ok {
		return nil, fmt.Errorf("browsernet: failed to parse embedded CA bundle")
	}
	return pool, nil
}

// TLSConfig returns a tls.Config with embedded roots.
func TLSConfig() (*tls.Config, error) {
	roots, err := RootCAs()
	if err != nil {
		return nil, err
	}
	return &tls.Config{RootCAs: roots, MinVersion: tls.VersionTLS12}, nil
}
