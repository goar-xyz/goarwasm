//go:build js && wasm

package browsernet

import (
	"context"
	"errors"
	"io"
	"net"
	"sync"
	"syscall/js"
	"time"
)

// Ensure VirtualConn implements net.Conn.
var _ net.Conn = (*VirtualConn)(nil)

// VirtualConn is a net.Conn backed by a browser WebSocket.
type VirtualConn struct {
	ws     js.Value
	local  net.Addr
	remote net.Addr

	mu     sync.Mutex
	buf    []byte
	closed bool
	err    error
	cond   *sync.Cond

	readDeadline  time.Time
	writeDeadline time.Time

	onOpen    js.Func
	onMessage js.Func
	onClose   js.Func
	onError   js.Func

	openOnce sync.Once
	opened   chan struct{}
	openErr  error

	callbacksReleased bool
}

type wsAddr struct {
	network string
	address string
}

func (a wsAddr) Network() string { return a.network }
func (a wsAddr) String() string  { return a.address }

// dialWebSocket opens a browser WebSocket and wraps it as VirtualConn.
func dialWebSocket(ctx context.Context, wsURL string) (*VirtualConn, error) {
	if js.Global().Get("WebSocket").IsUndefined() {
		return nil, errors.New("browsernet: WebSocket not available")
	}

	c := &VirtualConn{
		local:  wsAddr{network: "ws", address: "browser"},
		remote: wsAddr{network: "ws", address: wsURL},
		opened: make(chan struct{}),
	}
	c.cond = sync.NewCond(&c.mu)

	ws := js.Global().Get("WebSocket").New(wsURL)
	ws.Set("binaryType", "arraybuffer")
	c.ws = ws

	c.onOpen = js.FuncOf(func(this js.Value, args []js.Value) any {
		c.openOnce.Do(func() { close(c.opened) })
		return nil
	})
	c.onMessage = js.FuncOf(func(this js.Value, args []js.Value) any {
		if len(args) == 0 {
			return nil
		}
		data := args[0].Get("data")
		var b []byte
		if data.InstanceOf(js.Global().Get("ArrayBuffer")) {
			uint8 := js.Global().Get("Uint8Array").New(data)
			b = make([]byte, uint8.Get("byteLength").Int())
			js.CopyBytesToGo(b, uint8)
		} else if data.InstanceOf(js.Global().Get("Uint8Array")) {
			b = make([]byte, data.Get("byteLength").Int())
			js.CopyBytesToGo(b, data)
		} else if data.Type() == js.TypeString {
			b = []byte(data.String())
		} else {
			return nil
		}
		c.mu.Lock()
		if !c.closed {
			c.buf = append(c.buf, b...)
			c.cond.Broadcast()
		}
		c.mu.Unlock()
		return nil
	})
	c.onClose = js.FuncOf(func(this js.Value, args []js.Value) any {
		c.mu.Lock()
		c.closed = true
		if c.err == nil {
			c.err = io.EOF
		}
		c.cond.Broadcast()
		c.mu.Unlock()
		c.openOnce.Do(func() {
			c.openErr = errors.New("browsernet: websocket closed before open")
			close(c.opened)
		})
		return nil
	})
	c.onError = js.FuncOf(func(this js.Value, args []js.Value) any {
		c.mu.Lock()
		c.err = errors.New("browsernet: websocket error")
		c.closed = true
		c.cond.Broadcast()
		c.mu.Unlock()
		c.openOnce.Do(func() {
			c.openErr = c.err
			close(c.opened)
		})
		return nil
	})

	ws.Set("onopen", c.onOpen)
	ws.Set("onmessage", c.onMessage)
	ws.Set("onclose", c.onClose)
	ws.Set("onerror", c.onError)

	select {
	case <-ctx.Done():
		_ = c.Close()
		return nil, ctx.Err()
	case <-c.opened:
		if c.openErr != nil {
			_ = c.Close()
			return nil, c.openErr
		}
	}
	return c, nil
}

func (c *VirtualConn) releaseCallbacks() {
	c.mu.Lock()
	defer c.mu.Unlock()
	if c.callbacksReleased {
		return
	}
	c.callbacksReleased = true
	c.onOpen.Release()
	c.onMessage.Release()
	c.onClose.Release()
	c.onError.Release()
}

// Read implements net.Conn.
func (c *VirtualConn) Read(b []byte) (int, error) {
	c.mu.Lock()
	defer c.mu.Unlock()

	for {
		if len(c.buf) > 0 {
			n := copy(b, c.buf)
			c.buf = c.buf[n:]
			return n, nil
		}
		if c.err != nil {
			return 0, c.err
		}
		if c.closed {
			return 0, io.EOF
		}
		if err := c.waitDeadlineLocked(c.readDeadline); err != nil {
			return 0, err
		}
	}
}

// Write implements net.Conn.
func (c *VirtualConn) Write(b []byte) (int, error) {
	c.mu.Lock()
	if c.closed {
		c.mu.Unlock()
		return 0, net.ErrClosed
	}
	if err := checkDeadline(c.writeDeadline); err != nil {
		c.mu.Unlock()
		return 0, err
	}
	ws := c.ws
	c.mu.Unlock()

	uint8 := js.Global().Get("Uint8Array").New(len(b))
	js.CopyBytesToJS(uint8, b)
	ws.Call("send", uint8)
	return len(b), nil
}

// Close implements net.Conn.
func (c *VirtualConn) Close() error {
	c.mu.Lock()
	if c.closed {
		c.mu.Unlock()
		return nil
	}
	c.closed = true
	c.err = net.ErrClosed
	c.cond.Broadcast()
	ws := c.ws
	c.mu.Unlock()

	if !ws.IsUndefined() && !ws.IsNull() {
		// Detach handlers BEFORE close/Release so late events cannot hit released funcs.
		ws.Set("onopen", js.Undefined())
		ws.Set("onmessage", js.Undefined())
		ws.Set("onclose", js.Undefined())
		ws.Set("onerror", js.Undefined())
		// readyState: 0 connecting, 1 open, 2 closing, 3 closed
		rs := ws.Get("readyState").Int()
		if rs == 0 || rs == 1 {
			ws.Call("close")
		}
	}
	c.releaseCallbacks()
	return nil
}

// LocalAddr implements net.Conn.
func (c *VirtualConn) LocalAddr() net.Addr { return c.local }

// RemoteAddr implements net.Conn.
func (c *VirtualConn) RemoteAddr() net.Addr { return c.remote }

// SetDeadline implements net.Conn.
func (c *VirtualConn) SetDeadline(t time.Time) error {
	c.mu.Lock()
	defer c.mu.Unlock()
	c.readDeadline = t
	c.writeDeadline = t
	c.cond.Broadcast()
	return nil
}

// SetReadDeadline implements net.Conn.
func (c *VirtualConn) SetReadDeadline(t time.Time) error {
	c.mu.Lock()
	defer c.mu.Unlock()
	c.readDeadline = t
	c.cond.Broadcast()
	return nil
}

// SetWriteDeadline implements net.Conn.
func (c *VirtualConn) SetWriteDeadline(t time.Time) error {
	c.mu.Lock()
	defer c.mu.Unlock()
	c.writeDeadline = t
	return nil
}

func checkDeadline(d time.Time) error {
	if d.IsZero() {
		return nil
	}
	if time.Now().After(d) {
		return osTimeoutError{}
	}
	return nil
}

func (c *VirtualConn) waitDeadlineLocked(d time.Time) error {
	if err := checkDeadline(d); err != nil {
		return err
	}
	if d.IsZero() {
		c.cond.Wait()
		return nil
	}
	timer := time.AfterFunc(time.Until(d), func() {
		c.mu.Lock()
		c.cond.Broadcast()
		c.mu.Unlock()
	})
	c.cond.Wait()
	timer.Stop()
	return checkDeadline(d)
}

type osTimeoutError struct{}

func (osTimeoutError) Error() string   { return "i/o timeout" }
func (osTimeoutError) Timeout() bool   { return true }
func (osTimeoutError) Temporary() bool { return true }
