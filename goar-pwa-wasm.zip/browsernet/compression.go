//go:build js && wasm

package browsernet

import (
	"encoding/binary"
	"errors"
	"io"
	"net"
	"sync"
	"syscall/js"
	"time"
)

// DefaultMTU is the max application payload per WebRTC data-channel chunk.
const DefaultMTU = 16 * 1024

// DefaultBufferedAmountLowThreshold triggers write wakeups under backpressure.
const DefaultBufferedAmountLowThreshold = 256 * 1024

// Ensure OptimizedWebRTCConn implements net.Conn.
var _ net.Conn = (*OptimizedWebRTCConn)(nil)

// OptimizedWebRTCConn wraps a WebRTCConn with MTU chunking and bufferedAmount backpressure.
// Deadlines are owned here (not on VirtualConn).
type OptimizedWebRTCConn struct {
	inner *WebRTCConn
	mtu   int

	mu            sync.Mutex
	readBuf       []byte
	closed        bool
	err           error
	cond          *sync.Cond
	readDeadline  time.Time
	writeDeadline time.Time

	onLow     js.Func
	hasOnLow  bool
	writeWait chan struct{}
	released  bool
}

// OptimizeWebRTC wraps conn for chunked writes with backpressure.
// If conn is not *WebRTCConn, returns an error.
func OptimizeWebRTC(conn net.Conn, mtu int) (*OptimizedWebRTCConn, error) {
	inner, ok := conn.(*WebRTCConn)
	if !ok {
		return nil, errors.New("browsernet: OptimizeWebRTC requires *WebRTCConn")
	}
	if mtu <= 0 {
		mtu = DefaultMTU
	}
	o := &OptimizedWebRTCConn{
		inner:     inner,
		mtu:       mtu,
		writeWait: make(chan struct{}, 1),
	}
	o.cond = sync.NewCond(&o.mu)

	dc := inner.dc
	if !dc.IsUndefined() && !dc.IsNull() {
		dc.Set("bufferedAmountLowThreshold", DefaultBufferedAmountLowThreshold)
		o.onLow = js.FuncOf(func(this js.Value, args []js.Value) any {
			select {
			case o.writeWait <- struct{}{}:
			default:
			}
			return nil
		})
		o.hasOnLow = true
		dc.Set("onbufferedamountlow", o.onLow)
	}
	return o, nil
}

// Read reassembles length-prefixed chunks from the inner data channel stream.
func (o *OptimizedWebRTCConn) Read(b []byte) (int, error) {
	o.mu.Lock()
	defer o.mu.Unlock()

	for len(o.readBuf) == 0 {
		if err := checkDeadline(o.readDeadline); err != nil {
			return 0, err
		}
		if o.closed {
			if o.err != nil {
				return 0, o.err
			}
			return 0, io.EOF
		}
		o.mu.Unlock()
		hdr := make([]byte, 4)
		_, err := io.ReadFull(o.inner, hdr)
		if err != nil {
			o.mu.Lock()
			o.err = err
			o.closed = true
			return 0, err
		}
		n := int(binary.BigEndian.Uint32(hdr))
		if n < 0 || n > o.mtu*4 {
			o.mu.Lock()
			o.err = errors.New("browsernet: invalid chunk length")
			o.closed = true
			return 0, o.err
		}
		payload := make([]byte, n)
		_, err = io.ReadFull(o.inner, payload)
		o.mu.Lock()
		if err != nil {
			o.err = err
			o.closed = true
			return 0, err
		}
		o.readBuf = append(o.readBuf, payload...)
	}
	n := copy(b, o.readBuf)
	o.readBuf = o.readBuf[n:]
	return n, nil
}

// Write splits b into MTU-sized length-prefixed chunks with backpressure.
func (o *OptimizedWebRTCConn) Write(b []byte) (int, error) {
	total := 0
	for len(b) > 0 {
		if err := o.waitWritable(); err != nil {
			return total, err
		}
		chunk := b
		if len(chunk) > o.mtu {
			chunk = b[:o.mtu]
		}
		hdr := make([]byte, 4)
		binary.BigEndian.PutUint32(hdr, uint32(len(chunk)))
		frame := append(hdr, chunk...)
		n, err := o.inner.Write(frame)
		if err != nil {
			return total, err
		}
		if n != len(frame) {
			return total, io.ErrShortWrite
		}
		total += len(chunk)
		b = b[len(chunk):]
	}
	return total, nil
}

func (o *OptimizedWebRTCConn) waitWritable() error {
	o.mu.Lock()
	if o.closed {
		o.mu.Unlock()
		return net.ErrClosed
	}
	deadline := o.writeDeadline
	dc := o.inner.dc
	o.mu.Unlock()

	if err := checkDeadline(deadline); err != nil {
		return err
	}
	if dc.IsUndefined() || dc.IsNull() {
		return nil
	}
	for dc.Get("bufferedAmount").Int() > DefaultBufferedAmountLowThreshold {
		if err := checkDeadline(deadline); err != nil {
			return err
		}
		timer := time.NewTimer(50 * time.Millisecond)
		select {
		case <-o.writeWait:
			timer.Stop()
		case <-timer.C:
		}
	}
	return nil
}

func (o *OptimizedWebRTCConn) Close() error {
	o.mu.Lock()
	o.closed = true
	o.err = net.ErrClosed
	o.cond.Broadcast()
	release := false
	if !o.released {
		o.released = true
		release = o.hasOnLow
	}
	onLow := o.onLow
	o.mu.Unlock()
	if release {
		onLow.Release()
	}
	return o.inner.Close()
}

func (o *OptimizedWebRTCConn) LocalAddr() net.Addr  { return o.inner.LocalAddr() }
func (o *OptimizedWebRTCConn) RemoteAddr() net.Addr { return o.inner.RemoteAddr() }

// SetDeadline sets both read and write deadlines on the optimized conn.
func (o *OptimizedWebRTCConn) SetDeadline(t time.Time) error {
	o.mu.Lock()
	o.readDeadline = t
	o.writeDeadline = t
	o.cond.Broadcast()
	o.mu.Unlock()
	_ = o.inner.SetDeadline(t)
	return nil
}

// SetReadDeadline sets the read deadline on OptimizedWebRTCConn.
func (o *OptimizedWebRTCConn) SetReadDeadline(t time.Time) error {
	o.mu.Lock()
	o.readDeadline = t
	o.cond.Broadcast()
	o.mu.Unlock()
	_ = o.inner.SetReadDeadline(t)
	return nil
}

// SetWriteDeadline sets the write deadline on OptimizedWebRTCConn.
func (o *OptimizedWebRTCConn) SetWriteDeadline(t time.Time) error {
	o.mu.Lock()
	o.writeDeadline = t
	o.mu.Unlock()
	_ = o.inner.SetWriteDeadline(t)
	return nil
}
