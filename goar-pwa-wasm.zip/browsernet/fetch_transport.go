//go:build js && wasm

package browsernet

import (
	"bytes"
	"fmt"
	"io"
	"net/http"
	"syscall/js"
	"time"
)

// FetchTransport implements http.RoundTripper via the browser's fetch() API.
// Traffic goes direct from the page (CORS), not through Wisp/SDN.
// Use for LLM provider / agent API calls. Keep SDN Dial for SSH/TCP tools.
type FetchTransport struct{}

// NewDirectHTTPClient returns an http.Client that uses browser fetch (no Wisp).
func NewDirectHTTPClient(timeout time.Duration) *http.Client {
	if timeout <= 0 {
		timeout = 720 * time.Second
	}
	return &http.Client{
		Timeout:   timeout,
		Transport: FetchTransport{},
	}
}

func (FetchTransport) RoundTrip(req *http.Request) (*http.Response, error) {
	if req == nil {
		return nil, fmt.Errorf("browsernet: nil request")
	}
	if js.Global().Get("fetch").Type() != js.TypeFunction {
		return nil, fmt.Errorf("browsernet: fetch() not available")
	}

	opts := js.Global().Get("Object").New()
	opts.Set("method", req.Method)
	opts.Set("mode", "cors")
	opts.Set("credentials", "omit")
	opts.Set("redirect", "follow")

	headers := js.Global().Get("Headers").New()
	for k, vals := range req.Header {
		for _, v := range vals {
			headers.Call("append", k, v)
		}
	}
	opts.Set("headers", headers)

	if req.Body != nil && req.Method != http.MethodGet && req.Method != http.MethodHead {
		body, err := io.ReadAll(req.Body)
		_ = req.Body.Close()
		if err != nil {
			return nil, err
		}
		u8 := js.Global().Get("Uint8Array").New(len(body))
		js.CopyBytesToJS(u8, body)
		opts.Set("body", u8)
	}

	// AbortSignal when context cancels
	var abort js.Value
	if req.Context() != nil {
		if ac := js.Global().Get("AbortController"); ac.Type() == js.TypeFunction {
			ctrl := ac.New()
			abort = ctrl.Get("signal")
			opts.Set("signal", abort)
			stop := make(chan struct{})
			go func() {
				select {
				case <-req.Context().Done():
					ctrl.Call("abort")
				case <-stop:
				}
			}()
			defer close(stop)
		}
	}

	ch := make(chan struct {
		resp js.Value
		err  error
	}, 1)

	promise := js.Global().Call("fetch", req.URL.String(), opts)
	var then, catch js.Func
	then = js.FuncOf(func(this js.Value, args []js.Value) any {
		then.Release()
		catch.Release()
		ch <- struct {
			resp js.Value
			err  error
		}{resp: args[0]}
		return nil
	})
	catch = js.FuncOf(func(this js.Value, args []js.Value) any {
		then.Release()
		catch.Release()
		msg := "fetch failed"
		if len(args) > 0 {
			msg = args[0].String()
		}
		ch <- struct {
			resp js.Value
			err  error
		}{err: fmt.Errorf("browsernet: %s", msg)}
		return nil
	})
	promise.Call("then", then).Call("catch", catch)

	out := <-ch
	if out.err != nil {
		return nil, out.err
	}
	return mapJSResponse(req, out.resp)
}

func mapJSResponse(req *http.Request, jsResp js.Value) (*http.Response, error) {
	status := jsResp.Get("status").Int()
	statusText := jsResp.Get("statusText").String()

	hdr := make(http.Header)
	if h := jsResp.Get("headers"); h.Truthy() {
		// headers.forEach((v,k) => ...)
		forEach := js.FuncOf(func(this js.Value, args []js.Value) any {
			if len(args) >= 2 {
				hdr.Add(args[1].String(), args[0].String())
			}
			return nil
		})
		h.Call("forEach", forEach)
		forEach.Release()
	}

	bodyJS := jsResp.Get("body")
	var body io.ReadCloser
	if bodyJS.Truthy() && bodyJS.Get("getReader").Type() == js.TypeFunction {
		body = &fetchStreamReader{reader: bodyJS.Call("getReader")}
	} else {
		// fallback: arrayBuffer
		buf, err := awaitArrayBuffer(jsResp.Call("arrayBuffer"))
		if err != nil {
			return nil, err
		}
		body = io.NopCloser(bytes.NewReader(buf))
	}

	return &http.Response{
		Status:     fmt.Sprintf("%d %s", status, statusText),
		StatusCode: status,
		Proto:      "HTTP/1.1",
		ProtoMajor: 1,
		ProtoMinor: 1,
		Header:     hdr,
		Body:       body,
		Request:    req,
	}, nil
}

type fetchStreamReader struct {
	reader js.Value
	buf    []byte
	eof    bool
	closed bool
}

func (r *fetchStreamReader) Read(p []byte) (int, error) {
	if r.closed {
		return 0, io.ErrClosedPipe
	}
	for len(r.buf) == 0 && !r.eof {
		chunk, done, err := r.readChunk()
		if err != nil {
			return 0, err
		}
		if done {
			r.eof = true
			break
		}
		r.buf = append(r.buf, chunk...)
	}
	if len(r.buf) == 0 {
		return 0, io.EOF
	}
	n := copy(p, r.buf)
	r.buf = r.buf[n:]
	return n, nil
}

func (r *fetchStreamReader) readChunk() ([]byte, bool, error) {
	ch := make(chan struct {
		b    []byte
		done bool
		err  error
	}, 1)
	var then, catch js.Func
	then = js.FuncOf(func(this js.Value, args []js.Value) any {
		then.Release()
		catch.Release()
		res := args[0]
		done := res.Get("done").Bool()
		if done {
			ch <- struct {
				b    []byte
				done bool
				err  error
			}{done: true}
			return nil
		}
		val := res.Get("value")
		n := val.Get("byteLength").Int()
		if n == 0 && val.Get("length").Truthy() {
			n = val.Get("length").Int()
		}
		b := make([]byte, n)
		js.CopyBytesToGo(b, val)
		ch <- struct {
			b    []byte
			done bool
			err  error
		}{b: b}
		return nil
	})
	catch = js.FuncOf(func(this js.Value, args []js.Value) any {
		then.Release()
		catch.Release()
		msg := "stream read failed"
		if len(args) > 0 {
			msg = args[0].String()
		}
		ch <- struct {
			b    []byte
			done bool
			err  error
		}{err: fmt.Errorf("browsernet: %s", msg)}
		return nil
	})
	r.reader.Call("read").Call("then", then).Call("catch", catch)
	out := <-ch
	return out.b, out.done, out.err
}

func (r *fetchStreamReader) Close() error {
	if r.closed {
		return nil
	}
	r.closed = true
	if r.reader.Get("cancel").Type() == js.TypeFunction {
		r.reader.Call("cancel")
	}
	return nil
}

func awaitArrayBuffer(promise js.Value) ([]byte, error) {
	ch := make(chan struct {
		b   []byte
		err error
	}, 1)
	var then, catch js.Func
	then = js.FuncOf(func(this js.Value, args []js.Value) any {
		then.Release()
		catch.Release()
		ab := args[0]
		u8 := js.Global().Get("Uint8Array").New(ab)
		n := u8.Get("byteLength").Int()
		b := make([]byte, n)
		js.CopyBytesToGo(b, u8)
		ch <- struct {
			b   []byte
			err error
		}{b: b}
		return nil
	})
	catch = js.FuncOf(func(this js.Value, args []js.Value) any {
		then.Release()
		catch.Release()
		msg := "arrayBuffer failed"
		if len(args) > 0 {
			msg = args[0].String()
		}
		ch <- struct {
			b   []byte
			err error
		}{err: fmt.Errorf("browsernet: %s", msg)}
		return nil
	})
	promise.Call("then", then).Call("catch", catch)
	out := <-ch
	return out.b, out.err
}
