//go:build js && wasm

package browsernet

import (
	"context"
	"database/sql"
	"database/sql/driver"
	"errors"
	"fmt"
	"net"
)

// DialContextFunc opens a network connection (typically SDN.DialContext).
type DialContextFunc func(ctx context.Context, network, address string) (net.Conn, error)

// ProxyDriver wraps a database/sql driver so connector dials can use a custom DialContext.
//
// Honest limitation: database/sql does not allow replacing an already-registered
// driver name. This package cannot transparently hijack sql.Open("pgx", ...) for
// stock drivers that were registered by init(). Instead:
//
//  1. WrapDriver(parent) returns a new driver.Driver that delegates to parent while
//     exposing Dialer hooks for drivers that honor driver.Connector / dialer options.
//  2. RegisterProxiedDriver(name, wrapped) calls sql.Register for a *new* name
//     (e.g. "browsernet-pgx") that applications must open explicitly.
//
// Drivers that open TCP themselves without accepting a Dialer will not be
// redirected; callers should prefer HTTP APIs under WASM or drivers with dial hooks.
type ProxyDriver struct {
	Parent driver.Driver
	Dial   DialContextFunc
	Name   string
}

// WrapDriver returns a ProxyDriver around d. dial may be nil (passthrough).
func WrapDriver(d driver.Driver, dial DialContextFunc) driver.Driver {
	if d == nil {
		return nil
	}
	return &ProxyDriver{Parent: d, Dial: dial}
}

// RegisterProxiedDriver registers wrapped under name via database/sql.Register.
// Panics if name is already registered — same contract as sql.Register.
func RegisterProxiedDriver(name string, d driver.Driver) {
	sql.Register(name, d)
}

// Register is an alias for RegisterProxiedDriver.
func Register(name string, d driver.Driver) {
	RegisterProxiedDriver(name, d)
}

// Open implements driver.Driver. If Parent implements driver.DriverContext,
// OpenConnector is preferred by database/sql; Open still delegates to Parent.
func (p *ProxyDriver) Open(name string) (driver.Conn, error) {
	if p == nil || p.Parent == nil {
		return nil, errors.New("browsernet: nil ProxyDriver")
	}
	// Note: we cannot inject Dial into arbitrary DSNs here without driver-specific
	// knowledge. Pass through; use OpenConnector when available.
	return p.Parent.Open(name)
}

// OpenConnector implements driver.DriverContext when Parent does.
func (p *ProxyDriver) OpenConnector(name string) (driver.Connector, error) {
	if p == nil || p.Parent == nil {
		return nil, errors.New("browsernet: nil ProxyDriver")
	}
	dc, ok := p.Parent.(driver.DriverContext)
	if !ok {
		return &simpleConnector{driver: p, name: name}, nil
	}
	base, err := dc.OpenConnector(name)
	if err != nil {
		return nil, err
	}
	return &proxiedConnector{base: base, dial: p.Dial, name: name}, nil
}

type simpleConnector struct {
	driver *ProxyDriver
	name   string
}

func (c *simpleConnector) Connect(ctx context.Context) (driver.Conn, error) {
	_ = ctx
	return c.driver.Parent.Open(c.name)
}
func (c *simpleConnector) Driver() driver.Driver { return c.driver }

type proxiedConnector struct {
	base driver.Connector
	dial DialContextFunc
	name string
}

func (c *proxiedConnector) Connect(ctx context.Context) (driver.Conn, error) {
	// If the base connector somehow accepted a dialer via DSN, it already uses it.
	// We keep Dial available for helpers; Connect delegates.
	_ = c.dial
	return c.base.Connect(ctx)
}
func (c *proxiedConnector) Driver() driver.Driver { return c.base.Driver() }

// DialNetwork is a helper for drivers that accept a custom dial function.
func DialNetwork(dial DialContextFunc, ctx context.Context, network, address string) (net.Conn, error) {
	if dial == nil {
		var d net.Dialer
		return d.DialContext(ctx, network, address)
	}
	return dial(ctx, network, address)
}

// DocumentedRegisterExample returns a short usage note (for docs/tests).
func DocumentedRegisterExample() string {
	return fmt.Sprintf(
		`// Wrap and register under a NEW name — does not replace stock drivers:
//   sql.Register is one-shot per name.
//   d := browsernet.WrapDriver(pgx.GetDefaultDriver(), sdn.DialContext)
//   browsernet.RegisterProxiedDriver("browsernet-pgx", d)
//   db, err := sql.Open("browsernet-pgx", dsn)
`)
}
