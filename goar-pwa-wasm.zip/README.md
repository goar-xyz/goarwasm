# GOAR PWA WASM source

Go source that builds **`goar.wasm`** — the browser binary for the full GOAR PWA agent.

## What is in `goar.wasm`

| Path | Role |
|------|------|
| `cmd/goar-wasm/` | Entry + `window.goar` JS API (configure, runAgent, runBash, reconnectSSH, …) |
| `internal/appui/` | Chat TUI + terminal UI (in WASM) |
| `internal/core/` | Agent runtime, LLM, tools, SharedSSH PTY |
| `browsernet/` | Wisp / SSH-TCP dial + TLS roots |
| `internal/cli/` | Pulled in by the build graph |
| `internal/webui/` | Embedded PWA static tree (used by CLI serve; present because of that import) |

## Build

Go 1.24+ (`go.mod`).

```bash
make wasm
# writes ./goar.wasm
```

## Note on this zip

Large non-Go binaries under `internal/webui/web/` were omitted or replaced with placeholders (`assets/gecko`, packed `vendor/goar.wasm`) so the archive stays downloadable. That embedded tree is a copy of the PWA loader assets, not the Go agent source. The agent source is the packages in the table above.

One README only (this file).
