// Package assets embeds GOAR logo assets.
package assets

import _ "embed"

//go:embed logo.svg
var LogoSVG []byte
