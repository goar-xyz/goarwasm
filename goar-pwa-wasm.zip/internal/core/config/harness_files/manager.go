package harnessfiles

import (
	"os"
	"path/filepath"
	"sync"

	"github.com/goarxyz/goar/internal/core/paths"
)

// FileSource is "user" or "project".
type FileSource string

const (
	SourceUser    FileSource = "user"
	SourceProject FileSource = "project"
)

// Manager tracks harness file locations for the process.
// Port of goar.core.config.harness_files._harness_manager.HarnessFilesManager.
type Manager struct {
	Sources        []FileSource
	Workdir        string
	AdditionalDirs []string
	UserConfigFile string
	UserEnvFile    string
	ConfigFile     string
	trustedCheck   func(string) bool
}

var (
	mu   sync.Mutex
	inst *Manager
)

// Init initializes the global harness manager.
func Init(workdir string) *Manager {
	mu.Lock()
	defer mu.Unlock()
	if workdir == "" {
		workdir, _ = os.Getwd()
	}
	m := &Manager{
		Sources:        []FileSource{SourceUser, SourceProject},
		Workdir:        workdir,
		UserConfigFile: paths.ConfigFile(),
		UserEnvFile:    paths.EnvFile(),
		trustedCheck:   func(string) bool { return true },
	}
	proj := filepath.Join(workdir, paths.ConfigDirName, paths.ConfigFileName)
	if _, err := os.Stat(proj); err == nil {
		m.ConfigFile = proj
	} else {
		m.ConfigFile = m.UserConfigFile
	}
	inst = m
	return m
}

// InitHarnessFilesManager is the Python-named alias.
func InitHarnessFilesManager(workdir string, sources ...FileSource) *Manager {
	m := Init(workdir)
	if len(sources) > 0 {
		m.Sources = append([]FileSource{}, sources...)
	}
	return m
}

// Get returns the global manager, initializing with cwd if needed.
func Get() *Manager {
	mu.Lock()
	defer mu.Unlock()
	if inst == nil {
		wd, _ := os.Getwd()
		inst = &Manager{
			Sources:        []FileSource{SourceUser, SourceProject},
			Workdir:        wd,
			UserConfigFile: paths.ConfigFile(),
			UserEnvFile:    paths.EnvFile(),
			ConfigFile:     paths.ConfigFile(),
			trustedCheck:   func(string) bool { return true },
		}
	}
	return inst
}

// GetHarnessFilesManager is the Python-named alias.
func GetHarnessFilesManager() *Manager { return Get() }

// ResetHarnessFilesManager clears the singleton (tests).
func ResetHarnessFilesManager() {
	mu.Lock()
	defer mu.Unlock()
	inst = nil
}

func (m *Manager) hasSource(s FileSource) bool {
	for _, x := range m.Sources {
		if x == s {
			return true
		}
	}
	return false
}

func (m *Manager) effectiveCwd() string {
	if m.Workdir != "" {
		return m.Workdir
	}
	wd, _ := os.Getwd()
	return wd
}

func (m *Manager) trustedWorkdir() string {
	if !m.hasSource(SourceProject) {
		return ""
	}
	cwd := m.effectiveCwd()
	if m.trustedCheck != nil && !m.trustedCheck(cwd) {
		return ""
	}
	return cwd
}

// SetTrustedCheck overrides trust evaluation (tests / trusted_folders wiring).
func (m *Manager) SetTrustedCheck(fn func(string) bool) { m.trustedCheck = fn }

// AddDir appends an --add-dir path.
func (m *Manager) AddDir(dir string) {
	if dir == "" {
		return
	}
	abs, err := filepath.Abs(dir)
	if err != nil {
		abs = dir
	}
	m.AdditionalDirs = append(m.AdditionalDirs, abs)
}

// ProjectRoots returns trusted cwd + add-dirs (deduped).
func (m *Manager) ProjectRoots() []string {
	add := dedupPaths(m.AdditionalDirs, true)
	workdir := m.trustedWorkdir()
	if workdir == "" {
		return add
	}
	w, _ := filepath.Abs(workdir)
	out := []string{w}
	for _, p := range add {
		if p == w {
			continue
		}
		if isRelativeTo(p, w) {
			continue
		}
		out = append(out, p)
	}
	return out
}

// ResolvedConfigFile returns project config if present else user config.
func (m *Manager) ResolvedConfigFile() string {
	workdir := m.trustedWorkdir()
	if workdir != "" {
		cand := filepath.Join(workdir, paths.ConfigDirName, paths.ConfigFileName)
		if st, err := os.Stat(cand); err == nil && !st.IsDir() {
			return cand
		}
	}
	if m.hasSource(SourceUser) {
		return paths.ConfigFile()
	}
	return ""
}

// HookFiles returns user + project hooks.toml paths.
func (m *Manager) HookFiles() []string {
	var files []string
	if m.hasSource(SourceUser) {
		files = append(files, filepath.Join(paths.Home(), "hooks.toml"))
	}
	for _, root := range m.ProjectRoots() {
		files = append(files, filepath.Join(root, paths.ConfigDirName, "hooks.toml"))
	}
	return files
}

// PersistAllowed is true when user source is enabled.
func (m *Manager) PersistAllowed() bool { return m.hasSource(SourceUser) }

func dirIfExists(p string) []string {
	if st, err := os.Stat(p); err == nil && st.IsDir() {
		return []string{p}
	}
	return nil
}

// UserToolsDirs returns ~/.agent/tools if present.
func (m *Manager) UserToolsDirs() []string {
	if !m.hasSource(SourceUser) {
		return nil
	}
	return dirIfExists(filepath.Join(paths.Home(), "tools"))
}

// UserSkillsDirs returns ~/.agent/skills and ~/.agent/agents/skills.
func (m *Manager) UserSkillsDirs() []string {
	if !m.hasSource(SourceUser) {
		return nil
	}
	var out []string
	out = append(out, dirIfExists(filepath.Join(paths.Home(), "skills"))...)
	out = append(out, dirIfExists(filepath.Join(paths.Home(), "agents", "skills"))...)
	return out
}

// UserAgentsDirs returns ~/.agent/agents.
func (m *Manager) UserAgentsDirs() []string {
	if !m.hasSource(SourceUser) {
		return nil
	}
	return dirIfExists(filepath.Join(paths.Home(), "agents"))
}

// UserPromptsDirs returns ~/.agent/prompts.
func (m *Manager) UserPromptsDirs() []string {
	if !m.hasSource(SourceUser) {
		return nil
	}
	return dirIfExists(filepath.Join(paths.Home(), "prompts"))
}

// ProjectToolsDirs walks project roots for tools dirs.
func (m *Manager) ProjectToolsDirs() []string {
	return m.walkProjectRoots().Tools
}

// ProjectSkillsDirs walks project roots for skills dirs.
func (m *Manager) ProjectSkillsDirs() []string {
	return m.walkProjectRoots().Skills
}

// ProjectAgentsDirs walks project roots for agents dirs.
func (m *Manager) ProjectAgentsDirs() []string {
	return m.walkProjectRoots().Agents
}

// ProjectPromptsDirs returns .agent/prompts under project roots.
func (m *Manager) ProjectPromptsDirs() []string {
	var out []string
	for _, root := range m.ProjectRoots() {
		out = append(out, dirIfExists(filepath.Join(root, paths.ConfigDirName, "prompts"))...)
	}
	return out
}

func (m *Manager) walkProjectRoots() paths.ConfigWalkResult {
	var all []paths.ConfigWalkResult
	for _, root := range m.ProjectRoots() {
		all = append(all, paths.WalkLocalConfigDirs(root)...)
	}
	return paths.AggregateWalk(all)
}

// LoadUserDoc loads ~/.agent/AGENTS.md.
func (m *Manager) LoadUserDoc() string {
	if !m.hasSource(SourceUser) {
		return ""
	}
	b, err := os.ReadFile(filepath.Join(paths.Home(), paths.AgentsMDFilename))
	if err != nil {
		return ""
	}
	return string(bytesTrimSpace(b))
}

func bytesTrimSpace(b []byte) []byte {
	return []byte(stringTrimSpace(string(b)))
}

func stringTrimSpace(s string) string {
	for len(s) > 0 && (s[0] == ' ' || s[0] == '\n' || s[0] == '\t' || s[0] == '\r') {
		s = s[1:]
	}
	for len(s) > 0 {
		c := s[len(s)-1]
		if c != ' ' && c != '\n' && c != '\t' && c != '\r' {
			break
		}
		s = s[:len(s)-1]
	}
	return s
}

func (m *Manager) collectAgentsMD(start, stop string, stopInclusive bool) []AgentsMDDoc {
	startAbs, _ := filepath.Abs(start)
	stopAbs, _ := filepath.Abs(stop)
	if !isRelativeTo(startAbs, stopAbs) && startAbs != stopAbs {
		return nil
	}
	var docs []AgentsMDDoc
	current := startAbs
	for {
		if current == stopAbs && !stopInclusive {
			break
		}
		path := filepath.Join(current, paths.AgentsMDFilename)
		if b, err := os.ReadFile(path); err == nil {
			text := stringTrimSpace(string(b))
			if text != "" {
				docs = append(docs, AgentsMDDoc{Dir: current, Content: text})
			}
		}
		if current == stopAbs {
			break
		}
		parent := filepath.Dir(current)
		if parent == current {
			break
		}
		current = parent
	}
	// reverse to outermost-first
	for i, j := 0, len(docs)-1; i < j; i, j = i+1, j-1 {
		docs[i], docs[j] = docs[j], docs[i]
	}
	return docs
}

// AgentsMDDoc is a discovered AGENTS.md.
type AgentsMDDoc struct {
	Dir     string
	Content string
}

// FindSubdirectoryAgentsMD walks parents of filePath for AGENTS.md files
// between the file's parent and the open project root (exclusive).
func (m *Manager) FindSubdirectoryAgentsMD(filePath string) []string {
	var found []string
	for _, doc := range m.findSubdirectoryAgentsMDDocs(filePath) {
		found = append(found, filepath.Join(doc.Dir, paths.AgentsMDFilename))
	}
	return found
}

func (m *Manager) findSubdirectoryAgentsMDDocs(filePath string) []AgentsMDDoc {
	dir := filepath.Dir(filePath)
	var docs []AgentsMDDoc
	for _, root := range m.ProjectRoots() {
		docs = append(docs, m.collectAgentsMD(dir, root, false)...)
	}
	return docs
}

// LoadProjectDocs collects AGENTS.md from project roots upward.
func (m *Manager) LoadProjectDocs() []AgentsMDDoc {
	var docs []AgentsMDDoc
	for _, root := range m.ProjectRoots() {
		// include root itself
		docs = append(docs, m.collectAgentsMD(root, root, true)...)
		// also walk up from root toward filesystem root a limited amount
		parent := filepath.Dir(root)
		docs = append(docs, m.collectAgentsMD(parent, filepath.VolumeName(root)+string(filepath.Separator), true)...)
	}
	return docs
}

func dedupPaths(in []string, dropNested bool) []string {
	seen := map[string]bool{}
	var out []string
	for _, p := range in {
		abs, err := filepath.Abs(p)
		if err != nil {
			abs = p
		}
		if seen[abs] {
			continue
		}
		seen[abs] = true
		out = append(out, abs)
	}
	if !dropNested {
		return out
	}
	var filtered []string
	for i, a := range out {
		nested := false
		for j, b := range out {
			if i == j {
				continue
			}
			if isRelativeTo(a, b) && a != b {
				nested = true
				break
			}
		}
		if !nested {
			filtered = append(filtered, a)
		}
	}
	return filtered
}

func isRelativeTo(path, base string) bool {
	rel, err := filepath.Rel(base, path)
	if err != nil {
		return false
	}
	return rel != ".." && !startsWithDotDot(rel)
}

func startsWithDotDot(rel string) bool {
	return rel == ".." || len(rel) >= 3 && rel[0] == '.' && rel[1] == '.' && (rel[2] == '/' || rel[2] == '\\')
}
