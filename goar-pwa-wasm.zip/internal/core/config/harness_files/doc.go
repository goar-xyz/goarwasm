// Package harnessfiles manages config/env/session harness file paths.
package harnessfiles
