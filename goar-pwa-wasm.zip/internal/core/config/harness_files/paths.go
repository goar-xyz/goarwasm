package harnessfiles

import (
	"path/filepath"

	"github.com/goarxyz/goar/internal/core/paths"
)

// UserConfigFile returns ~/.agent/config.toml
func UserConfigFile() string { return paths.ConfigFile() }

// UserEnvFile returns ~/.agent/.env
func UserEnvFile() string { return paths.EnvFile() }

// ProjectConfigFile returns .agent/config.toml under cwd-relative root.
func ProjectConfigFile(root string) string {
	return filepath.Join(root, paths.ConfigDirName, "config.toml")
}
