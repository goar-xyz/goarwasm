package layers

import (
	"os"

	"github.com/goarxyz/goar/internal/core/config"
)

// LoadEnvOverrides builds a layer from AGENT_* / OPENAI_* environment variables.
func LoadEnvOverrides() config.ConfigLayer {
	data := config.RawConfig{}
	if v := os.Getenv("OPENAI_MODEL"); v != "" {
		data["active_model"] = v
	}
	if v := os.Getenv("AGENT_THEME"); v != "" {
		data["theme"] = v
	}
	if v := os.Getenv("AGENT_DEFAULT_AGENT"); v != "" {
		data["default_agent"] = v
	}
	if v := os.Getenv("AGENT_API_TIMEOUT"); v != "" {
		data["api_timeout"] = v
	}
	if v := os.Getenv("AGENT_BYPASS_TOOL_PERMISSIONS"); v != "" {
		data["bypass_tool_permissions"] = v
	}
	if v := os.Getenv("OPENAI_BASE_URL"); v != "" {
		data["openai_base_url"] = v
	}
	return config.ConfigLayer{Name: "env", Trusted: true, Data: data}
}
