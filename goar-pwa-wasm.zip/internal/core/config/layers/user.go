package layers

import (
	"os"

	"github.com/BurntSushi/toml"
	"github.com/goarxyz/goar/internal/core/config"
	"github.com/goarxyz/goar/internal/core/paths"
)

// LoadUserLayer reads ~/.agent/config.toml into a ConfigLayer.
func LoadUserLayer() (config.ConfigLayer, error) {
	path := paths.ConfigFile()
	data := config.RawConfig{}
	if _, err := os.Stat(path); err != nil {
		return config.ConfigLayer{Name: "user", Trusted: true, Data: data}, nil
	}
	if _, err := toml.DecodeFile(path, &data); err != nil {
		return config.ConfigLayer{}, err
	}
	return config.ConfigLayer{Name: "user", Trusted: true, Data: data}, nil
}
