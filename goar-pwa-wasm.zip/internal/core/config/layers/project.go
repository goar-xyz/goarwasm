package layers

import (
	"os"
	"path/filepath"
	"sync"

	"github.com/BurntSushi/toml"
	"github.com/goarxyz/goar/internal/core"
	"github.com/goarxyz/goar/internal/core/config"
	"github.com/goarxyz/goar/internal/core/paths"
)

// ProjectConfigLayer reads a project-level TOML config file (Python ProjectConfigLayer).
//
// If no file is found in the working directory, walks up parent directories until
// a .agent/config.toml is found (stopping before AGENT_HOME's parent).
type ProjectConfigLayer struct {
	mu             sync.Mutex
	Name           string
	Root           string
	ConfigFilePath string
	isSet          bool
	trusted        *bool
}

// NewProjectConfigLayer constructs a project layer rooted at path (or cwd).
func NewProjectConfigLayer(path string) *ProjectConfigLayer {
	if path == "" {
		path, _ = os.Getwd()
	}
	return &ProjectConfigLayer{Name: "project-toml", Root: path}
}

// FindConfigFile walks upward for .agent/config.toml.
func (p *ProjectConfigLayer) FindConfigFile() string {
	p.mu.Lock()
	defer p.mu.Unlock()
	if p.isSet {
		return p.ConfigFilePath
	}
	root := p.Root
	if root == "" {
		root, _ = os.Getwd()
	}
	homeParent := filepath.Dir(paths.Home())
	for dir := root; ; dir = filepath.Dir(dir) {
		if dir == homeParent {
			break
		}
		candidate := filepath.Join(dir, paths.ConfigDirName, paths.ConfigFileName)
		if st, err := os.Stat(candidate); err == nil && !st.IsDir() {
			p.ConfigFilePath = candidate
			break
		}
		parent := filepath.Dir(dir)
		if parent == dir {
			break
		}
	}
	p.isSet = true
	return p.ConfigFilePath
}

// CheckTrust returns whether the project config directory is trusted.
func (p *ProjectConfigLayer) CheckTrust() bool {
	cfgPath := p.FindConfigFile()
	if cfgPath == "" {
		return true
	}
	mgr := core.NewTrustedFoldersManager()
	trusted, known := mgr.IsTrusted(filepath.Dir(cfgPath))
	if !known {
		return false
	}
	return trusted
}

// GrantTrust marks the project config parent as trusted.
func (p *ProjectConfigLayer) GrantTrust() error {
	cfgPath := p.FindConfigFile()
	if cfgPath == "" {
		return nil
	}
	t := true
	p.trusted = &t
	return core.NewTrustedFoldersManager().AddTrusted(filepath.Dir(cfgPath))
}

// RevokeTrust marks the project config parent as untrusted.
func (p *ProjectConfigLayer) RevokeTrust() error {
	cfgPath := p.FindConfigFile()
	if cfgPath == "" {
		return nil
	}
	t := false
	p.trusted = &t
	return core.NewTrustedFoldersManager().AddUntrusted(filepath.Dir(cfgPath))
}

// ReadConfig loads the TOML map (empty if no file).
func (p *ProjectConfigLayer) ReadConfig() (config.RawConfig, error) {
	cfgPath := p.FindConfigFile()
	data := config.RawConfig{}
	if cfgPath == "" {
		return data, nil
	}
	if _, err := toml.DecodeFile(cfgPath, &data); err != nil {
		return nil, err
	}
	return data, nil
}

// Load returns a ConfigLayer, enforcing trust.
func (p *ProjectConfigLayer) Load() (config.ConfigLayer, error) {
	return LoadProjectLayer(p.Root, p.CheckTrust())
}

// LoadProjectLayer reads .agent/config.toml from workdir (compat helper).
func LoadProjectLayer(workdir string, trusted bool) (config.ConfigLayer, error) {
	layer := NewProjectConfigLayer(workdir)
	path := layer.FindConfigFile()
	data := config.RawConfig{}
	if path == "" {
		// Also try workdir directly for backwards compat.
		direct := filepath.Join(workdir, paths.ConfigDirName, paths.ConfigFileName)
		if _, err := os.Stat(direct); err == nil {
			path = direct
		}
	}
	if path == "" {
		return config.ConfigLayer{Name: "project", Trusted: trusted, Data: data}, nil
	}
	if !trusted {
		return config.ConfigLayer{}, config.UntrustedLayerError{Path: path}
	}
	if _, err := toml.DecodeFile(path, &data); err != nil {
		return config.ConfigLayer{}, err
	}
	return config.ConfigLayer{Name: "project", Trusted: true, Data: data}, nil
}
