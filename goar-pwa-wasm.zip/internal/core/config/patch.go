package config

import "fmt"

// PatchOp is a config mutation.
type PatchOp interface {
	Apply(cfg *Config) error
}

// SetField sets a top-level string field by name.
type SetField struct {
	Key   string
	Value any
}

func (s SetField) Apply(cfg *Config) error {
	switch s.Key {
	case "active_model":
		if v, ok := s.Value.(string); ok {
			cfg.ActiveModel = v
		}
	case "theme":
		if v, ok := s.Value.(string); ok {
			cfg.Theme = v
		}
	case "default_agent":
		if v, ok := s.Value.(string); ok {
			cfg.DefaultAgent = v
		}
	default:
		return fmt.Errorf("unsupported set field: %s", s.Key)
	}
	return nil
}

// DeleteField clears a list field.
type DeleteField struct{ Key string }

func (d DeleteField) Apply(cfg *Config) error {
	switch d.Key {
	case "enabled_tools":
		cfg.EnabledTools = nil
	case "disabled_tools":
		cfg.DisabledTools = nil
	default:
		return fmt.Errorf("unsupported delete field: %s", d.Key)
	}
	return nil
}

// AppendToList appends to a string list field.
type AppendToList struct {
	Key   string
	Value string
}

func (a AppendToList) Apply(cfg *Config) error {
	switch a.Key {
	case "enabled_tools":
		cfg.EnabledTools = append(cfg.EnabledTools, a.Value)
	case "disabled_tools":
		cfg.DisabledTools = append(cfg.DisabledTools, a.Value)
	default:
		return fmt.Errorf("unsupported append field: %s", a.Key)
	}
	return nil
}

// RemoveFromList removes a value from a string list.
type RemoveFromList struct {
	Key   string
	Value string
}

func (r RemoveFromList) Apply(cfg *Config) error {
	filter := func(in []string) []string {
		out := in[:0]
		for _, v := range in {
			if v != r.Value {
				out = append(out, v)
			}
		}
		return out
	}
	switch r.Key {
	case "enabled_tools":
		cfg.EnabledTools = filter(cfg.EnabledTools)
	case "disabled_tools":
		cfg.DisabledTools = filter(cfg.DisabledTools)
	default:
		return fmt.Errorf("unsupported remove field: %s", r.Key)
	}
	return nil
}

// ConfigPatch applies a sequence of ops.
type ConfigPatch struct{ Ops []PatchOp }

func (p ConfigPatch) Apply(cfg *Config) error {
	for _, op := range p.Ops {
		if err := op.Apply(cfg); err != nil {
			return err
		}
	}
	return nil
}
