// Package config implements layered TOML/env configuration (Python: goar.core.config).
package config
