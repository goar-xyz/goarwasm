package config

// ConfigOrigin tracks which layer provided a value.
type ConfigOrigin struct {
	LayerName string
}
