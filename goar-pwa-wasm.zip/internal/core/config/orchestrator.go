package config

import (
	"os"
	"path/filepath"

	"github.com/goarxyz/goar/internal/core/paths"
)

// Orchestrator loads layered config (user + project + env).
type Orchestrator struct {
	TrustedFolders []string
}

// NewOrchestrator creates an orchestrator.
func NewOrchestrator(trusted []string) *Orchestrator {
	return &Orchestrator{TrustedFolders: trusted}
}

// LoadAll loads defaults, user TOML, trusted project TOML, then env.
func (o *Orchestrator) LoadAll(workdir string) (*Config, error) {
	b := NewBuilder()
	userFile := paths.ConfigFile()
	if st, err := os.Stat(userFile); err == nil && !st.IsDir() {
		b.AddLayer(ConfigLayer{Name: "user", Trusted: true, Data: RawConfig{"_source": userFile}})
	}
	proj := filepath.Join(workdir, paths.ConfigDirName, paths.ConfigFileName)
	if st, err := os.Stat(proj); err == nil && !st.IsDir() {
		trusted := false
		for _, t := range o.TrustedFolders {
			if t == workdir {
				trusted = true
				break
			}
		}
		b.AddLayer(ConfigLayer{Name: "project", Trusted: trusted, Data: RawConfig{"_source": proj}})
	}
	_, err := b.Build()
	if err != nil {
		return nil, err
	}
	// Prefer the full Load() path for actual values
	return Load()
}
