package config

import "fmt"

// MergeStrategy for config fields.
type MergeStrategy string

const (
	StrategyReplace  MergeStrategy = "replace"
	StrategyConcat   MergeStrategy = "concat"
	StrategyUnion    MergeStrategy = "union"
	StrategyShallow  MergeStrategy = "merge"
	StrategyConflict MergeStrategy = "conflict"
	StrategyCoalesce MergeStrategy = "coalesce"
)

// MergeFieldMetadata declares how a field merges across layers (Python MergeFieldMetadata).
type MergeFieldMetadata struct {
	Strategy MergeStrategy
	MergeKey string
}

// WithReplaceMerge marks a field as replace-on-override.
func WithReplaceMerge() MergeFieldMetadata { return MergeFieldMetadata{Strategy: StrategyReplace} }

// WithConcatMerge marks a list field as concatenate.
func WithConcatMerge() MergeFieldMetadata { return MergeFieldMetadata{Strategy: StrategyConcat} }

// WithUnionMerge marks a list field as keyed-union.
func WithUnionMerge(mergeKey string) MergeFieldMetadata {
	return MergeFieldMetadata{Strategy: StrategyUnion, MergeKey: mergeKey}
}

// WithShallowMerge marks a map field as shallow-merge.
func WithShallowMerge() MergeFieldMetadata { return MergeFieldMetadata{Strategy: StrategyShallow} }

// WithConflictMerge marks a field that errors on mismatch.
func WithConflictMerge() MergeFieldMetadata { return MergeFieldMetadata{Strategy: StrategyConflict} }

// ConfigDefinitionError is raised for invalid schema declarations.
type ConfigDefinitionError struct{ Msg string }

func (e ConfigDefinitionError) Error() string { return e.Msg }

// DuplicateMergeMetadataError is raised when multiple merge markers exist.
type DuplicateMergeMetadataError struct{ Msg string }

func (e DuplicateMergeMetadataError) Error() string { return e.Msg }

// ValidateMergeKey ensures union merges declare a key.
func ValidateMergeKey(m MergeFieldMetadata) error {
	if m.Strategy == StrategyUnion && m.MergeKey == "" {
		return fmt.Errorf("WithUnionMerge requires merge_key")
	}
	return nil
}

// FieldOrigin tracks which config layer set a field.
type FieldOrigin map[string]string

// ConfigSchema is a typed config document with origin tracking (Python ConfigSchema).
type ConfigSchema struct {
	Values  map[string]any
	Origins FieldOrigin
}

// NewConfigSchema constructs an empty schema document.
func NewConfigSchema() *ConfigSchema {
	return &ConfigSchema{Values: map[string]any{}, Origins: FieldOrigin{}}
}

// OriginOf returns the layer name that set key, if known.
func (c *ConfigSchema) OriginOf(key string) string {
	if c == nil || c.Origins == nil {
		return ""
	}
	return c.Origins[key]
}

// Set sets a value and records its origin layer.
func (c *ConfigSchema) Set(key string, value any, origin string) {
	if c.Values == nil {
		c.Values = map[string]any{}
	}
	if c.Origins == nil {
		c.Origins = FieldOrigin{}
	}
	c.Values[key] = value
	if origin != "" {
		c.Origins[key] = origin
	}
}

// Get returns a value.
func (c *ConfigSchema) Get(key string) (any, bool) {
	if c == nil || c.Values == nil {
		return nil, false
	}
	v, ok := c.Values[key]
	return v, ok
}

// ConfigFragment is a partial config overlay (Python ConfigFragment).
type ConfigFragment struct {
	Values map[string]any
	Source string
}

// MergeFieldTable maps field names to merge metadata.
type MergeFieldTable map[string]MergeFieldMetadata

// ValidateMergeTable checks all entries.
func ValidateMergeTable(t MergeFieldTable) error {
	seen := map[string]bool{}
	for k, m := range t {
		if seen[k] {
			return DuplicateMergeMetadataError{Msg: "duplicate merge metadata for " + k}
		}
		seen[k] = true
		if err := ValidateMergeKey(m); err != nil {
			return ConfigDefinitionError{Msg: err.Error()}
		}
	}
	return nil
}

// DefaultMergeTable returns common merge strategies for GOAR config fields.
func DefaultMergeTable() MergeFieldTable {
	return MergeFieldTable{
		"providers":        WithUnionMerge("name"),
		"models":           WithUnionMerge("alias"),
		"enabled_tools":    WithConcatMerge(),
		"disabled_tools":   WithConcatMerge(),
		"extra_headers":    WithShallowMerge(),
		"active_model":     WithReplaceMerge(),
		"theme":            WithReplaceMerge(),
		"system_prompt_id": WithReplaceMerge(),
	}
}
