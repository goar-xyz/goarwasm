package config

import (
	"fmt"
	"sync"

	"github.com/goarxyz/goar/internal/core/utils"
)

// layerData is a named raw layer payload used during merge.
type layerData struct {
	Name string
	Data RawConfig
}

// Builder collects layers and merges them into a Config (Python ConfigBuilder).
type Builder struct {
	mu     sync.Mutex
	layers []ConfigLayer
	table  MergeFieldTable
}

// NewBuilder creates an empty builder with the default merge table.
func NewBuilder() *Builder {
	return &Builder{table: DefaultMergeTable()}
}

// NewBuilderWithTable creates a builder with a custom merge table.
func NewBuilderWithTable(table MergeFieldTable) *Builder {
	if table == nil {
		table = DefaultMergeTable()
	}
	return &Builder{table: table}
}

// AddLayer appends a layer (higher layers override lower ones).
func (b *Builder) AddLayer(l ConfigLayer) *Builder {
	b.mu.Lock()
	defer b.mu.Unlock()
	b.layers = append(b.layers, l)
	return b
}

// AddLayers appends multiple layers.
func (b *Builder) AddLayers(layers []ConfigLayer) *Builder {
	b.mu.Lock()
	defer b.mu.Unlock()
	b.layers = append(b.layers, layers...)
	return b
}

// Layers returns a copy of registered layers.
func (b *Builder) Layers() []ConfigLayer {
	b.mu.Lock()
	defer b.mu.Unlock()
	out := make([]ConfigLayer, len(b.layers))
	copy(out, b.layers)
	return out
}

// Build merges layers onto defaults. Untrusted and empty layers are skipped.
// Pass forceLoad=true to ignore any layer caching (layers here are already materialized).
func (b *Builder) Build() (*Config, error) {
	return b.BuildForce(false)
}

// BuildForce mirrors Python build(force_load=...).
func (b *Builder) BuildForce(forceLoad bool) (*Config, error) {
	_ = forceLoad
	b.mu.Lock()
	layers := make([]ConfigLayer, len(b.layers))
	copy(layers, b.layers)
	table := b.table
	b.mu.Unlock()

	layerDicts := make([]layerData, 0, len(layers))
	for _, layer := range layers {
		if !layer.Trusted && layer.Name == "project" {
			continue
		}
		if len(layer.Data) == 0 {
			continue
		}
		layerDicts = append(layerDicts, layerData{Name: layer.Name, Data: layer.Data})
	}

	merged, origins, err := b.mergeFields(table, layerDicts)
	if err != nil {
		return nil, err
	}

	cfg := Default()
	if err := applyTOML(cfg, merged); err != nil {
		return nil, err
	}
	_ = origins
	return cfg, nil
}

func (b *Builder) mergeFields(table MergeFieldTable, layerDicts []layerData) (RawConfig, FieldOrigin, error) {
	accumulated := RawConfig{}
	origins := FieldOrigin{}

	for _, ld := range layerDicts {
		for key, value := range ld.Data {
			meta, ok := table[key]
			if !ok {
				// Unknown keys: last-write-wins replace.
				accumulated[key] = value
				origins[key] = ld.Name
				continue
			}
			strategy := utils.MergeStrategy(meta.Strategy)
			var merged any
			var err error
			if meta.Strategy == StrategyUnion && meta.MergeKey != "" {
				merged, err = applyUnion(accumulated[key], value, meta.MergeKey)
			} else {
				merged, err = strategy.Apply(accumulated[key], value)
			}
			if err != nil {
				return nil, nil, fmt.Errorf("merge field %s from layer %s: %w", key, ld.Name, err)
			}
			accumulated[key] = merged
			origins[key] = ld.Name
		}
	}
	return accumulated, origins, nil
}

func applyUnion(base, override any, mergeKey string) (any, error) {
	ba, aok := asAnySlice(base)
	oa, ook := asAnySlice(override)
	if !aok && base == nil {
		ba = nil
		aok = true
	}
	if !ook {
		return nil, fmt.Errorf("union requires list operands")
	}
	seen := map[string]bool{}
	var out []any
	add := func(item any) {
		key := fmt.Sprint(item)
		if m, ok := item.(map[string]any); ok {
			if v, ok := m[mergeKey]; ok {
				key = fmt.Sprint(v)
			}
		}
		if seen[key] {
			return
		}
		seen[key] = true
		out = append(out, item)
	}
	for _, item := range ba {
		add(item)
	}
	for _, item := range oa {
		add(item)
	}
	return out, nil
}

func asAnySlice(v any) ([]any, bool) {
	if v == nil {
		return nil, true
	}
	switch s := v.(type) {
	case []any:
		return s, true
	case []string:
		out := make([]any, len(s))
		for i, x := range s {
			out[i] = x
		}
		return out, true
	case []map[string]any:
		out := make([]any, len(s))
		for i, x := range s {
			out[i] = x
		}
		return out, true
	default:
		return nil, false
	}
}
