package config

import "fmt"

// RawConfig is an untyped layer payload.
type RawConfig map[string]any

// ConfigLayer is a named configuration layer.
type ConfigLayer struct {
	Name    string
	Trusted bool
	Data    RawConfig
}

// ConfigLayerError is a layer processing error.
type ConfigLayerError struct {
	Layer string
	Msg   string
}

func (e ConfigLayerError) Error() string {
	return fmt.Sprintf("config layer %s: %s", e.Layer, e.Msg)
}

// EmptyLayerError is raised for empty required layers.
type EmptyLayerError struct{ Layer string }

func (e EmptyLayerError) Error() string { return "empty config layer: " + e.Layer }

// UntrustedLayerError is raised when using an untrusted project layer.
type UntrustedLayerError struct{ Path string }

func (e UntrustedLayerError) Error() string { return "untrusted config layer: " + e.Path }

// TrustNotResolvedError means trust was not decided.
type TrustNotResolvedError struct{ Path string }

func (e TrustNotResolvedError) Error() string { return "trust not resolved: " + e.Path }

// TrustResolutionError is a trust decision failure.
type TrustResolutionError struct{ Msg string }

func (e TrustResolutionError) Error() string { return e.Msg }

// LayerImplementationError is an internal layer bug.
type LayerImplementationError struct{ Msg string }

func (e LayerImplementationError) Error() string { return e.Msg }

// MergeLayers merges layers low→high with replace semantics for scalars.
func MergeLayers(layers []ConfigLayer) RawConfig {
	out := RawConfig{}
	for _, layer := range layers {
		for k, v := range layer.Data {
			if existing, ok := out[k]; ok {
				em, eok := existing.(map[string]any)
				vm, vok := v.(map[string]any)
				if eok && vok {
					out[k] = mergeMaps(em, vm)
					continue
				}
			}
			out[k] = v
		}
	}
	return out
}

func mergeMaps(a, b map[string]any) map[string]any {
	out := map[string]any{}
	for k, v := range a {
		out[k] = v
	}
	for k, v := range b {
		if em, eok := out[k].(map[string]any); eok {
			if vm, vok := v.(map[string]any); vok {
				out[k] = mergeMaps(em, vm)
				continue
			}
		}
		out[k] = v
	}
	return out
}

// Layer commands (port of _GrantTrust / _RevokeTrust / _Load / etc.)
type layerCmdKind int

const (
	cmdGrantTrust layerCmdKind = iota
	cmdRevokeTrust
	cmdResolveTrust
	cmdLoad
	cmdInvalidateCache
)

type layerCmd struct {
	Kind layerCmdKind
	Path string
}

// LayerState tracks trust + cached payload for a layer.
type LayerState struct {
	Trusted       bool
	TrustResolved bool
	Cache         RawConfig
	Fingerprint   string
	Path          string
	Name          string
}

// StatefulLayer is a ConfigLayer with trust/cache operations.
type StatefulLayer struct {
	Layer         ConfigLayer
	State         LayerState
	onTrustChange func(trusted bool)
}

// NewStatefulLayer constructs a layer manager for one source.
func NewStatefulLayer(name, path string, trusted bool) *StatefulLayer {
	return &StatefulLayer{
		Layer: ConfigLayer{Name: name, Trusted: trusted},
		State: LayerState{Name: name, Path: path, Trusted: trusted, TrustResolved: trusted},
	}
}

func (s *StatefulLayer) checkTrust() error {
	if !s.State.TrustResolved {
		return TrustNotResolvedError{Path: s.State.Path}
	}
	if !s.State.Trusted {
		return UntrustedLayerError{Path: s.State.Path}
	}
	return nil
}

// GrantTrust marks the layer trusted.
func (s *StatefulLayer) GrantTrust() {
	s.State.Trusted = true
	s.State.TrustResolved = true
	s.Layer.Trusted = true
	s.notifyTrustChange()
}

// RevokeTrust marks the layer untrusted.
func (s *StatefulLayer) RevokeTrust() {
	s.State.Trusted = false
	s.State.TrustResolved = true
	s.Layer.Trusted = false
	s.InvalidateCache()
	s.notifyTrustChange()
}

// ResolveTrust sets the trust decision.
func (s *StatefulLayer) ResolveTrust(trusted bool) {
	s.State.Trusted = trusted
	s.State.TrustResolved = true
	s.Layer.Trusted = trusted
	s.notifyTrustChange()
}

// IsTrusted reports current trust.
func (s *StatefulLayer) IsTrusted() bool { return s.State.Trusted && s.State.TrustResolved }

// InvalidateCache drops cached data.
func (s *StatefulLayer) InvalidateCache() {
	s.State.Cache = nil
	s.State.Fingerprint = ""
}

// Load returns cached or provided data after trust checks.
func (s *StatefulLayer) Load(read func() (RawConfig, string, error)) (RawConfig, error) {
	if err := s.checkTrust(); err != nil {
		return nil, err
	}
	if s.State.Cache != nil {
		return s.State.Cache, nil
	}
	data, fp, err := read()
	if err != nil {
		return nil, ConfigLayerError{Layer: s.State.Name, Msg: err.Error()}
	}
	if len(data) == 0 {
		return nil, EmptyLayerError{Layer: s.State.Name}
	}
	s.State.Cache = data
	s.State.Fingerprint = fp
	s.Layer.Data = data
	return data, nil
}

// GetFingerprint returns the cache fingerprint.
func (s *StatefulLayer) GetFingerprint() string { return s.State.Fingerprint }

// Apply merges this layer into dst when trusted.
func (s *StatefulLayer) Apply(dst RawConfig) (RawConfig, error) {
	if !s.IsTrusted() {
		return dst, nil
	}
	if s.State.Cache == nil {
		return dst, nil
	}
	return MergeLayers([]ConfigLayer{{Name: s.State.Name, Trusted: true, Data: s.State.Cache}, {Name: "dst", Trusted: true, Data: dst}}), nil
}

func (s *StatefulLayer) notifyTrustChange() {
	if s.onTrustChange != nil {
		s.onTrustChange(s.State.Trusted)
	}
}

// SetTrustChangeHandler registers a trust-change callback.
func (s *StatefulLayer) SetTrustChangeHandler(fn func(bool)) { s.onTrustChange = fn }

// Dispatch handles a layer command.
func (s *StatefulLayer) Dispatch(cmd layerCmd) error {
	switch cmd.Kind {
	case cmdGrantTrust:
		s.GrantTrust()
	case cmdRevokeTrust:
		s.RevokeTrust()
	case cmdResolveTrust:
		s.ResolveTrust(true)
	case cmdInvalidateCache:
		s.InvalidateCache()
	case cmdLoad:
		_, err := s.Load(func() (RawConfig, string, error) { return s.Layer.Data, s.State.Fingerprint, nil })
		return err
	}
	return nil
}
