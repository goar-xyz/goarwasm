package config

import (
	"os"
	"path/filepath"
	"testing"
)

func TestDefaultConfigHasCatalog(t *testing.T) {
	cfg := Default()
	if len(cfg.Providers) == 0 {
		t.Fatal("expected providers from catalog")
	}
	if len(cfg.Models) == 0 {
		t.Fatal("expected models from catalog")
	}
	if cfg.ActiveModel == "" {
		t.Fatal("active model empty")
	}
}

func TestLoadSaveRoundTrip(t *testing.T) {
	dir := t.TempDir()
	t.Setenv("AGENT_HOME", dir)
	cfg := Default()
	cfg.ActiveModel = "gpt-4o"
	if err := Save(cfg); err != nil {
		t.Fatal(err)
	}
	if _, err := os.Stat(filepath.Join(dir, "config.toml")); err != nil {
		t.Fatal(err)
	}
	loaded, err := Load()
	if err != nil {
		t.Fatal(err)
	}
	if loaded.ActiveModel != "gpt-4o" {
		t.Fatalf("got %q", loaded.ActiveModel)
	}
}

func TestEnvOverride(t *testing.T) {
	dir := t.TempDir()
	t.Setenv("AGENT_HOME", dir)
	t.Setenv("OPENAI_MODEL", "o4-mini")
	cfg, err := Load()
	if err != nil {
		t.Fatal(err)
	}
	if cfg.ActiveModel != "o4-mini" {
		t.Fatalf("env override failed: %q", cfg.ActiveModel)
	}
}

func TestGetActiveModel(t *testing.T) {
	cfg := Default()
	m, err := cfg.GetActiveModel()
	if err != nil {
		t.Fatal(err)
	}
	if m.Alias != cfg.ActiveModel {
		t.Fatal(m.Alias)
	}
	p, err := cfg.GetProviderForModel(m)
	if err != nil {
		t.Fatal(err)
	}
	if p.Name != m.Provider {
		t.Fatal(p.Name)
	}
}

func TestSaveMinimalTheme(t *testing.T) {
	dir := t.TempDir()
	t.Setenv("AGENT_HOME", dir)
	t.Setenv("AGENT_THEME", "")
	pc := ProviderConfig{Name: "openai", APIBase: "https://api.openai.com/v1", APIKeyEnvVar: "OPENAI_API_KEY", APIStyle: "openai", Backend: "generic"}
	mc := ModelConfig{Name: "gpt-4.1", Provider: "openai", Alias: "gpt-4.1"}
	if err := SaveMinimal(pc, mc, "gpt-4.1", "goar-light"); err != nil {
		t.Fatal(err)
	}
	cfg, err := Load()
	if err != nil {
		t.Fatal(err)
	}
	if cfg.Theme != "goar-light" {
		t.Fatalf("theme %q", cfg.Theme)
	}
}
