// Package config loads and saves GOAR configuration (TOML + env layers).
package config

import (
	"bufio"
	"fmt"
	"os"
	"path/filepath"
	"strconv"
	"strings"

	"github.com/BurntSushi/toml"
	"github.com/goarxyz/goar/internal/core/paths"
	"github.com/goarxyz/goar/internal/core/providers"
)

const (
	DefaultAPIEnvKey   = "OPENAI_API_KEY"
	DefaultActiveModel = "gpt-4.1"
	DefaultTheme       = "goar-dark"
	DefaultAgent       = "adaptive-engineer"
)

// ProviderConfig describes an LLM API endpoint.
type ProviderConfig struct {
	Name               string            `toml:"name" json:"name"`
	APIBase            string            `toml:"api_base" json:"api_base"`
	APIKeyEnvVar       string            `toml:"api_key_env_var" json:"api_key_env_var"`
	APIStyle           string            `toml:"api_style" json:"api_style"`
	Backend            string            `toml:"backend" json:"backend"`
	ReasoningFieldName string            `toml:"reasoning_field_name" json:"reasoning_field_name"`
	ProjectID          string            `toml:"project_id" json:"project_id"`
	Region             string            `toml:"region" json:"region"`
	ExtraHeaders       map[string]string `toml:"extra_headers" json:"extra_headers"`
}

// ModelConfig describes a selectable model.
type ModelConfig struct {
	Name                 string  `toml:"name" json:"name"`
	Provider             string  `toml:"provider" json:"provider"`
	Alias                string  `toml:"alias" json:"alias"`
	Temperature          float64 `toml:"temperature" json:"temperature"`
	InputPrice           float64 `toml:"input_price" json:"input_price"`
	OutputPrice          float64 `toml:"output_price" json:"output_price"`
	Thinking             string  `toml:"thinking" json:"thinking"`
	AutoCompactThreshold int     `toml:"auto_compact_threshold" json:"auto_compact_threshold"`
}

// SessionLoggingConfig controls session persistence.
type SessionLoggingConfig struct {
	SaveDir       string `toml:"save_dir" json:"save_dir"`
	SessionPrefix string `toml:"session_prefix" json:"session_prefix"`
	Enabled       bool   `toml:"enabled" json:"enabled"`
}

// ProjectContextConfig controls git/project context injection.
type ProjectContextConfig struct {
	DefaultCommitCount int     `toml:"default_commit_count" json:"default_commit_count"`
	TimeoutSeconds     float64 `toml:"timeout_seconds" json:"timeout_seconds"`
}

// Config is the top-level GOAR configuration (mirrors GoarConfig).
type Config struct {
	ActiveModel           string  `toml:"active_model" json:"active_model"`
	Theme                 string  `toml:"theme" json:"theme"`
	SystemPromptID        string  `toml:"system_prompt_id" json:"system_prompt_id"`
	APITimeout            float64 `toml:"api_timeout" json:"api_timeout"`
	AutoCompactThreshold  int     `toml:"auto_compact_threshold" json:"auto_compact_threshold"`
	BypassToolPermissions bool    `toml:"bypass_tool_permissions" json:"bypass_tool_permissions"`
	DefaultAgent          string  `toml:"default_agent" json:"default_agent"`
	IncludeProjectContext bool    `toml:"include_project_context" json:"include_project_context"`

	Providers      []ProviderConfig     `toml:"providers" json:"providers"`
	Models         []ModelConfig        `toml:"models" json:"models"`
	SessionLogging SessionLoggingConfig `toml:"session_logging" json:"session_logging"`
	ProjectContext ProjectContextConfig `toml:"project_context" json:"project_context"`

	EnabledTools     []string `toml:"enabled_tools" json:"enabled_tools"`
	DisabledTools    []string `toml:"disabled_tools" json:"disabled_tools"`
	ContextWarnings  bool     `toml:"context_warnings" json:"context_warnings"`
	EnableConnectors bool     `toml:"enable_connectors" json:"enable_connectors"`
	CompactionPrompt string   `toml:"compaction_prompt" json:"compaction_prompt"`
}

// MissingAPIKeyError is raised when the active provider has no API key.
type MissingAPIKeyError struct {
	Provider string
	EnvVar   string
}

func (e *MissingAPIKeyError) Error() string {
	if e.EnvVar != "" {
		return "missing API key for provider " + e.Provider + " (set $" + e.EnvVar + ")"
	}
	return "missing API key for provider " + e.Provider
}

// LoadDotenvValues is an alias for LoadDotEnv (Python load_dotenv_values).
func LoadDotenvValues() { _ = LoadDotEnv() }

// Default returns a config seeded from the provider catalog.
func Default() *Config {
	cfg := &Config{
		ActiveModel:           DefaultActiveModel,
		Theme:                 DefaultTheme,
		SystemPromptID:        "cli",
		APITimeout:            720,
		AutoCompactThreshold:  200_000,
		BypassToolPermissions: true,
		DefaultAgent:          DefaultAgent,
		IncludeProjectContext: true,
		SessionLogging: SessionLoggingConfig{
			SaveDir:       paths.SessionLogDir(),
			SessionPrefix: "session",
			Enabled:       true,
		},
		ProjectContext: ProjectContextConfig{
			DefaultCommitCount: 5,
			TimeoutSeconds:     2.0,
		},
	}
	for _, p := range providers.Catalog {
		base := p.APIBase
		if base == "" {
			base = p.DefaultBaseHint
			if base == "" {
				base = "http://127.0.0.1:0/v1"
			}
		}
		style := p.APIStyle
		if style == "" {
			style = "openai"
		}
		backend := p.Backend
		if backend == "" {
			backend = "generic"
		}
		cfg.Providers = append(cfg.Providers, ProviderConfig{
			Name:               p.Key,
			APIBase:            base,
			APIKeyEnvVar:       p.APIKeyEnvVar,
			APIStyle:           style,
			Backend:            backend,
			ReasoningFieldName: "reasoning_content",
		})
		for _, m := range p.Models {
			cfg.Models = append(cfg.Models, ModelConfig{
				Name:                 m.ID,
				Provider:             p.Key,
				Alias:                m.Alias,
				Temperature:          0.2,
				Thinking:             "off",
				AutoCompactThreshold: 200_000,
			})
		}
	}
	return cfg
}

// LoadDotEnv reads ~/.agent/.env into the process environment (without overriding existing keys).
func LoadDotEnv() error {
	path := paths.EnvFile()
	f, err := os.Open(path)
	if err != nil {
		if os.IsNotExist(err) {
			return nil
		}
		return err
	}
	defer f.Close()
	sc := bufio.NewScanner(f)
	for sc.Scan() {
		line := strings.TrimSpace(sc.Text())
		if line == "" || strings.HasPrefix(line, "#") || !strings.Contains(line, "=") {
			continue
		}
		k, v, _ := strings.Cut(line, "=")
		k = strings.TrimSpace(k)
		v = strings.Trim(strings.TrimSpace(v), `"'`)
		if k == "" || v == "" {
			continue
		}
		if os.Getenv(k) == "" {
			_ = os.Setenv(k, v)
		}
	}
	return sc.Err()
}

// Load merges defaults ← TOML file ← AGENT_*/OPENAI_* env overrides.
func Load() (*Config, error) {
	_ = LoadDotEnv()
	cfg := Default()

	configPath := paths.ConfigFile()
	if _, err := os.Stat(configPath); err == nil {
		raw := map[string]any{}
		if _, err := toml.DecodeFile(configPath, &raw); err != nil {
			return nil, fmt.Errorf("invalid TOML in %s: %w", configPath, err)
		}
		if err := applyTOML(cfg, raw); err != nil {
			return nil, err
		}
		// Also decode strongly-typed overlays for nested tables
		var fileCfg Config
		if _, err := toml.DecodeFile(configPath, &fileCfg); err == nil {
			mergeFile(cfg, &fileCfg)
		}
	} else if project := filepath.Join(paths.ConfigDirName, "config.toml"); fileExists(project) {
		var fileCfg Config
		if _, err := toml.DecodeFile(project, &fileCfg); err == nil {
			mergeFile(cfg, &fileCfg)
		}
	}

	applyEnv(cfg)
	if cfg.SessionLogging.SaveDir == "" {
		cfg.SessionLogging.SaveDir = paths.SessionLogDir()
	}
	return cfg, nil
}

func fileExists(p string) bool {
	_, err := os.Stat(p)
	return err == nil
}

func mergeFile(dst, src *Config) {
	if src.ActiveModel != "" {
		dst.ActiveModel = src.ActiveModel
	}
	if src.Theme != "" {
		dst.Theme = src.Theme
	}
	if src.SystemPromptID != "" {
		dst.SystemPromptID = src.SystemPromptID
	}
	if src.DefaultAgent != "" {
		dst.DefaultAgent = src.DefaultAgent
	}
	if src.APITimeout > 0 {
		dst.APITimeout = src.APITimeout
	}
	if len(src.Providers) > 0 {
		dst.Providers = src.Providers
	}
	if len(src.Models) > 0 {
		dst.Models = src.Models
	}
	if len(src.EnabledTools) > 0 {
		dst.EnabledTools = src.EnabledTools
	}
	if len(src.DisabledTools) > 0 {
		dst.DisabledTools = src.DisabledTools
	}
	if src.SessionLogging.SessionPrefix != "" || src.SessionLogging.SaveDir != "" {
		if src.SessionLogging.SaveDir != "" {
			dst.SessionLogging.SaveDir = src.SessionLogging.SaveDir
		}
		if src.SessionLogging.SessionPrefix != "" {
			dst.SessionLogging.SessionPrefix = src.SessionLogging.SessionPrefix
		}
		dst.SessionLogging.Enabled = src.SessionLogging.Enabled
	}
}

func applyTOML(cfg *Config, raw map[string]any) error {
	if v, ok := raw["active_model"].(string); ok && v != "" {
		cfg.ActiveModel = v
	}
	if v, ok := raw["theme"].(string); ok && v != "" {
		cfg.Theme = v
	}
	if v, ok := raw["bypass_tool_permissions"].(bool); ok {
		cfg.BypassToolPermissions = v
	}
	return nil
}

func applyEnv(cfg *Config) {
	if v := firstEnv("OPENAI_MODEL"); v != "" {
		cfg.ActiveModel = v
	}
	if v := firstEnv("AGENT_THEME"); v != "" {
		cfg.Theme = v
	}
	if v := firstEnv("AGENT_DEFAULT_AGENT"); v != "" {
		cfg.DefaultAgent = v
	}
	if v := firstEnv("AGENT_API_TIMEOUT"); v != "" {
		if f, err := strconv.ParseFloat(v, 64); err == nil {
			cfg.APITimeout = f
		}
	}
	if v := firstEnv("AGENT_BYPASS_TOOL_PERMISSIONS"); v != "" {
		cfg.BypassToolPermissions = v == "1" || strings.EqualFold(v, "true")
	}
	if v := firstEnv("OPENAI_BASE_URL"); v != "" {
		for i := range cfg.Providers {
			env := cfg.Providers[i].APIKeyEnvVar
			if env == "" {
				env = DefaultAPIEnvKey
			}
			if env == DefaultAPIEnvKey || cfg.Providers[i].Name == "openai" || cfg.Providers[i].Name == "custom" {
				cfg.Providers[i].APIBase = v
			}
		}
	}
}

// firstEnv returns the first non-empty environment value among keys.
func firstEnv(keys ...string) string {
	for _, k := range keys {
		if v := os.Getenv(k); v != "" {
			return v
		}
	}
	return ""
}

// Save writes cfg to ~/.agent/config.toml.
func Save(cfg *Config) error {
	if err := paths.EnsureHome(); err != nil {
		return err
	}
	path := paths.ConfigFile()
	f, err := os.Create(path)
	if err != nil {
		return err
	}
	defer f.Close()
	enc := toml.NewEncoder(f)
	return enc.Encode(cfg)
}

// SaveMinimal writes a focused onboarding config (selected provider + model).
// theme is optional; empty keeps DefaultTheme.
func SaveMinimal(provider ProviderConfig, model ModelConfig, activeAlias string, theme ...string) error {
	th := DefaultTheme
	if len(theme) > 0 && theme[0] != "" {
		th = theme[0]
	}
	cfg := &Config{
		ActiveModel:           activeAlias,
		Theme:                 th,
		DefaultAgent:          DefaultAgent,
		SystemPromptID:        "cli",
		APITimeout:            720,
		BypassToolPermissions: true,
		Providers:             []ProviderConfig{provider},
		Models:                []ModelConfig{model},
		SessionLogging: SessionLoggingConfig{
			SaveDir:       paths.SessionLogDir(),
			SessionPrefix: "session",
			Enabled:       true,
		},
	}
	return Save(cfg)
}

// WriteEnvValue upserts KEY=value in ~/.agent/.env (mode 0600).
func WriteEnvValue(key, value string) error {
	if err := paths.EnsureHome(); err != nil {
		return err
	}
	path := paths.EnvFile()
	vals := map[string]string{}
	if f, err := os.Open(path); err == nil {
		sc := bufio.NewScanner(f)
		for sc.Scan() {
			line := strings.TrimSpace(sc.Text())
			if line == "" || strings.HasPrefix(line, "#") || !strings.Contains(line, "=") {
				continue
			}
			k, v, _ := strings.Cut(line, "=")
			vals[strings.TrimSpace(k)] = strings.Trim(strings.TrimSpace(v), `"'`)
		}
		f.Close()
	}
	vals[key] = value
	var b strings.Builder
	b.WriteString("# Agent credentials — do not commit this file\n\n")
	keys := make([]string, 0, len(vals))
	for k := range vals {
		keys = append(keys, k)
	}
	// stable-ish order
	for i := 0; i < len(keys); i++ {
		for j := i + 1; j < len(keys); j++ {
			if keys[j] < keys[i] {
				keys[i], keys[j] = keys[j], keys[i]
			}
		}
	}
	for _, k := range keys {
		b.WriteString(k)
		b.WriteByte('=')
		b.WriteString(vals[k])
		b.WriteByte('\n')
	}
	return os.WriteFile(path, []byte(b.String()), 0o600)
}

// GetActiveModel returns the model matching ActiveModel alias.
func (c *Config) GetActiveModel() (ModelConfig, error) {
	for _, m := range c.Models {
		if m.Alias == c.ActiveModel {
			return m, nil
		}
	}
	return ModelConfig{}, fmt.Errorf("active model %q not found in configuration", c.ActiveModel)
}

// GetProviderForModel returns the provider for a model.
func (c *Config) GetProviderForModel(m ModelConfig) (ProviderConfig, error) {
	for _, p := range c.Providers {
		if p.Name == m.Provider {
			return p, nil
		}
	}
	return ProviderConfig{}, fmt.Errorf("provider %q for model %q not found", m.Provider, m.Name)
}

// GetActiveProvider returns the provider for the active model.
func (c *Config) GetActiveProvider() (ProviderConfig, error) {
	m, err := c.GetActiveModel()
	if err != nil {
		return ProviderConfig{}, err
	}
	return c.GetProviderForModel(m)
}

// APIKey resolves the API key for a provider from the environment.
func (c *Config) APIKey(p ProviderConfig) string {
	env := p.APIKeyEnvVar
	if env == "" {
		env = DefaultAPIEnvKey
	}
	return os.Getenv(env)
}

// NeedsSetup reports whether user config is missing.
func NeedsSetup() bool {
	_, err := os.Stat(paths.ConfigFile())
	return os.IsNotExist(err)
}
