package config

import (
	"fmt"
	"os"
	"strings"

	"github.com/BurntSushi/toml"
)

// MCPBase is shared MCP server config.
type MCPBase struct {
	Name              string   `toml:"name" json:"name"`
	Prompt            string   `toml:"prompt" json:"prompt"`
	StartupTimeoutSec float64  `toml:"startup_timeout_sec" json:"startup_timeout_sec"`
	ToolTimeoutSec    float64  `toml:"tool_timeout_sec" json:"tool_timeout_sec"`
	SamplingEnabled   bool     `toml:"sampling_enabled" json:"sampling_enabled"`
	Disabled          bool     `toml:"disabled" json:"disabled"`
	DisabledTools     []string `toml:"disabled_tools" json:"disabled_tools"`
}

// NormalizeName lowercases and trims an MCP server name.
func (m *MCPBase) NormalizeName() {
	m.Name = strings.ToLower(strings.TrimSpace(m.Name))
}

// MCPHTTP is an HTTP / streamable-http MCP server.
type MCPHTTP struct {
	MCPBase
	Transport    string            `toml:"transport" json:"transport"`
	URL          string            `toml:"url" json:"url"`
	Headers      map[string]string `toml:"headers" json:"headers"`
	APIKeyEnv    string            `toml:"api_key_env" json:"api_key_env"`
	APIKeyHeader string            `toml:"api_key_header" json:"api_key_header"`
	APIKeyFormat string            `toml:"api_key_format" json:"api_key_format"`
}

// HTTPHeaders returns headers with API key material applied.
func (m MCPHTTP) HTTPHeaders() map[string]string {
	out := map[string]string{}
	for k, v := range m.Headers {
		out[k] = v
	}
	if m.APIKeyEnv == "" {
		return out
	}
	token := os.Getenv(m.APIKeyEnv)
	hdr := m.APIKeyHeader
	if hdr == "" {
		hdr = "Authorization"
	}
	format := m.APIKeyFormat
	if format == "" {
		format = "Bearer {token}"
	}
	out[hdr] = strings.ReplaceAll(format, "{token}", token)
	return out
}

// MCPStdio is a stdio MCP server.
type MCPStdio struct {
	MCPBase
	Transport string            `toml:"transport" json:"transport"`
	Command   string            `toml:"command" json:"command"`
	Args      []string          `toml:"args" json:"args"`
	Env       map[string]string `toml:"env" json:"env"`
	Cwd       string            `toml:"cwd" json:"cwd"`
}

// Argv returns command + args.
func (m MCPStdio) Argv() []string {
	if m.Command == "" {
		return nil
	}
	return append([]string{m.Command}, m.Args...)
}

// ConnectorConfig disables connector tools selectively.
type ConnectorConfig struct {
	Name          string   `toml:"name" json:"name"`
	Disabled      bool     `toml:"disabled" json:"disabled"`
	DisabledTools []string `toml:"disabled_tools" json:"disabled_tools"`
}

// TranscribeProviderConfig describes a speech-to-text provider.
type TranscribeProviderConfig struct {
	Name         string `toml:"name" json:"name"`
	APIBase      string `toml:"api_base" json:"api_base"`
	APIKeyEnvVar string `toml:"api_key_env_var" json:"api_key_env_var"`
	Client       string `toml:"client" json:"client"`
}

// TranscribeModelConfig describes a transcription model.
type TranscribeModelConfig struct {
	Name                   string `toml:"name" json:"name"`
	Provider               string `toml:"provider" json:"provider"`
	Alias                  string `toml:"alias" json:"alias"`
	SampleRate             int    `toml:"sample_rate" json:"sample_rate"`
	Encoding               string `toml:"encoding" json:"encoding"`
	Language               string `toml:"language" json:"language"`
	TargetStreamingDelayMS int    `toml:"target_streaming_delay_ms" json:"target_streaming_delay_ms"`
}

// TTSProviderConfig describes a text-to-speech provider.
type TTSProviderConfig struct {
	Name         string `toml:"name" json:"name"`
	APIBase      string `toml:"api_base" json:"api_base"`
	APIKeyEnvVar string `toml:"api_key_env_var" json:"api_key_env_var"`
	Client       string `toml:"client" json:"client"`
}

// TTSModelConfig describes a TTS model/voice.
type TTSModelConfig struct {
	Name           string `toml:"name" json:"name"`
	Provider       string `toml:"provider" json:"provider"`
	Alias          string `toml:"alias" json:"alias"`
	Voice          string `toml:"voice" json:"voice"`
	ResponseFormat string `toml:"response_format" json:"response_format"`
}

// ExtendedConfig holds optional settings from Python GoarConfig not on the core Config.
type ExtendedConfig struct {
	VimKeybindings                bool                       `toml:"vim_keybindings" json:"vim_keybindings"`
	DisableWelcomeBannerAnimation bool                       `toml:"disable_welcome_banner_animation" json:"disable_welcome_banner_animation"`
	AutocopyToClipboard           bool                       `toml:"autocopy_to_clipboard" json:"autocopy_to_clipboard"`
	FileWatcherForAutocomplete    bool                       `toml:"file_watcher_for_autocomplete" json:"file_watcher_for_autocomplete"`
	DisplayedWorkdir              string                     `toml:"displayed_workdir" json:"displayed_workdir"`
	ContextWarnings               bool                       `toml:"context_warnings" json:"context_warnings"`
	IncludeCommitSignature        bool                       `toml:"include_commit_signature" json:"include_commit_signature"`
	IncludeModelInfo              bool                       `toml:"include_model_info" json:"include_model_info"`
	IncludePromptDetail           bool                       `toml:"include_prompt_detail" json:"include_prompt_detail"`
	EnableNotifications           bool                       `toml:"enable_notifications" json:"enable_notifications"`
	EnableSystemTrustStore        bool                       `toml:"enable_system_trust_store" json:"enable_system_trust_store"`
	EnableExperimentalHooks       bool                       `toml:"enable_experimental_hooks" json:"enable_experimental_hooks"`
	CompactionPromptID            string                     `toml:"compaction_prompt_id" json:"compaction_prompt_id"`
	MCPServers                    []MCPHTTP                  `toml:"mcp_servers" json:"mcp_servers"`
	MCPStdioServers               []MCPStdio                 `toml:"mcp_stdio_servers" json:"mcp_stdio_servers"`
	Connectors                    []ConnectorConfig          `toml:"connectors" json:"connectors"`
	TranscribeProviders           []TranscribeProviderConfig `toml:"transcribe_providers" json:"transcribe_providers"`
	TranscribeModels              []TranscribeModelConfig    `toml:"transcribe_models" json:"transcribe_models"`
	TTSProviders                  []TTSProviderConfig        `toml:"tts_providers" json:"tts_providers"`
	TTSModels                     []TTSModelConfig           `toml:"tts_models" json:"tts_models"`
}

// DeepUpdate merges src into dst recursively (maps only).
func DeepUpdate(dst, src map[string]any) map[string]any {
	if dst == nil {
		dst = map[string]any{}
	}
	for k, v := range src {
		if v == nil {
			continue
		}
		if sm, ok := v.(map[string]any); ok {
			if dm, ok := dst[k].(map[string]any); ok {
				dst[k] = DeepUpdate(dm, sm)
				continue
			}
		}
		dst[k] = v
	}
	return dst
}

// RemoveNoneValues drops nil entries recursively.
func RemoveNoneValues(m map[string]any) map[string]any {
	out := map[string]any{}
	for k, v := range m {
		if v == nil {
			continue
		}
		if sm, ok := v.(map[string]any); ok {
			out[k] = RemoveNoneValues(sm)
			continue
		}
		out[k] = v
	}
	return out
}

// StripBashPatternWildcard removes trailing /* from bash allow/deny patterns.
func StripBashPatternWildcard(pat string) string {
	return strings.TrimSuffix(pat, "/*")
}

// SupportsBrowserSignIn reports whether a provider supports browser OAuth.
func (p ProviderConfig) SupportsBrowserSignIn() bool {
	return p.APIBase != "" && (strings.Contains(p.Name, "openai") || p.Backend == "openai_responses")
}

// ExpandSaveDir expands ~ in session save dir.
func (s SessionLoggingConfig) ExpandSaveDir() string {
	dir := s.SaveDir
	if strings.HasPrefix(dir, "~/") {
		home, _ := os.UserHomeDir()
		dir = home + dir[1:]
	}
	return dir
}

// LoadExtended reads extended settings from a TOML file.
func LoadExtended(path string) (*ExtendedConfig, error) {
	var ext ExtendedConfig
	if _, err := os.Stat(path); err != nil {
		return &ext, nil
	}
	if _, err := toml.DecodeFile(path, &ext); err != nil {
		return nil, fmt.Errorf("extended settings: %w", err)
	}
	for i := range ext.MCPServers {
		ext.MCPServers[i].NormalizeName()
		if ext.MCPServers[i].Transport == "" {
			ext.MCPServers[i].Transport = "streamable_http"
		}
	}
	for i := range ext.MCPStdioServers {
		ext.MCPStdioServers[i].NormalizeName()
		if ext.MCPStdioServers[i].Transport == "" {
			ext.MCPStdioServers[i].Transport = "stdio"
		}
	}
	return &ext, nil
}

// CatalogProviders returns provider names from config (Python _catalog_providers).
func (c *Config) CatalogProviders() []string {
	out := make([]string, 0, len(c.Providers))
	for _, p := range c.Providers {
		out = append(out, p.Name)
	}
	return out
}

// CatalogModels returns model aliases from config.
func (c *Config) CatalogModels() []string {
	out := make([]string, 0, len(c.Models))
	for _, m := range c.Models {
		if m.Alias != "" {
			out = append(out, m.Alias)
		} else {
			out = append(out, m.Name)
		}
	}
	return out
}

// DefaultAliasToName maps alias → model name.
func (c *Config) DefaultAliasToName() map[string]string {
	out := map[string]string{}
	for _, m := range c.Models {
		alias := m.Alias
		if alias == "" {
			alias = m.Name
		}
		out[alias] = m.Name
	}
	return out
}
