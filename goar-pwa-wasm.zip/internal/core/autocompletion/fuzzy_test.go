package autocompletion

import "testing"

func TestFuzzyScore(t *testing.T) {
	if Score("abc", "zzz") >= 0 {
		t.Fatal("expected no match")
	}
	if Score("rf", "read_file") < 0 {
		t.Fatal("expected match")
	}
	got := RankFilters("rf", []string{"read_file", "write_file", "grep"}, 10)
	if len(got) == 0 {
		t.Fatal("empty")
	}
}
