package autocompletion

import (
	"strings"
)

// AdaptInputForPathCompletion extracts @query from the input text (Python path_prompt_adapter).
func AdaptInputForPathCompletion(text string, cursor int) (prefix string, query string, start int, ok bool) {
	if cursor < 0 || cursor > len(text) {
		cursor = len(text)
	}
	before := text[:cursor]
	at := strings.LastIndex(before, "@")
	if at < 0 {
		return "", "", 0, false
	}
	// '@' must start a token (start of line or after whitespace)
	if at > 0 {
		prev := before[at-1]
		if prev != ' ' && prev != '\t' && prev != '\n' && prev != '(' && prev != '[' && prev != '"' && prev != '\'' {
			return "", "", 0, false
		}
	}
	query = before[at+1:]
	if strings.ContainsAny(query, " \t\n") {
		return "", "", 0, false
	}
	return before[:at], query, at, true
}

// ApplyPathCompletion replaces the @token at start with insertText.
func ApplyPathCompletion(text string, start int, query, insertText string) (string, int) {
	end := start + 1 + len(query)
	if end > len(text) {
		end = len(text)
	}
	if !strings.HasPrefix(insertText, "@") {
		insertText = "@" + insertText
	}
	newText := text[:start] + insertText + text[end:]
	return newText, start + len(insertText)
}

// IsPathCompletionTrigger reports whether ch should open path completion.
func IsPathCompletionTrigger(ch rune) bool { return ch == '@' }

// NormalizePathInsert ensures directory suggestions end with /.
func NormalizePathInsert(path string, isDir bool) string {
	if isDir && !strings.HasSuffix(path, "/") && !strings.HasSuffix(path, `\`) {
		return path + "/"
	}
	return path
}

// SplitPathQuery splits a partial path into directory prefix and base query.
func SplitPathQuery(partial string) (dir, base string) {
	partial = strings.ReplaceAll(partial, `\`, "/")
	if i := strings.LastIndex(partial, "/"); i >= 0 {
		return partial[:i+1], partial[i+1:]
	}
	return "", partial
}

// FormatPathSuggestion builds a display label for a path candidate.
func FormatPathSuggestion(path string, isDir bool) string {
	if isDir {
		return path + "/"
	}
	return path
}
