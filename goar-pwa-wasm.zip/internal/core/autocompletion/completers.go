package autocompletion

import (
	"os"
	"path/filepath"
	"sort"
	"strings"
	"unicode"

	"github.com/goarxyz/goar/internal/core/autocompletion/fileindexer"
)

// Completer produces completion candidates (Python Completer).
type Completer interface {
	GetCompletions(text string, cursorPos int) []string
	GetCompletionItems(text string, cursorPos int) []CompletionItem
	GetReplacementRange(text string, cursorPos int) (start, end int)
}

// CompletionItem is a display/insert pair.
type CompletionItem struct {
	Insert  string
	Display string
}

// prioritizeHelpConfigSlashMenu bumps /help and /config toward the front.
func prioritizeHelpConfigSlashMenu(items []CompletionItem) []CompletionItem {
	if len(items) == 0 {
		return items
	}
	priority := map[string]int{"/help": 0, "/config": 1, "/model": 2, "/setup": 3}
	sort.SliceStable(items, func(i, j int) bool {
		pi, oki := priority[strings.ToLower(items[i].Insert)]
		pj, okj := priority[strings.ToLower(items[j].Insert)]
		if oki && okj {
			return pi < pj
		}
		if oki {
			return true
		}
		if okj {
			return false
		}
		return false
	})
	return items
}

// CommandCompleter completes slash commands (Python CommandCompleter).
type CommandCompleter struct {
	Entries func() [][2]string // alias, description
}

func (c *CommandCompleter) buildLookup() (names []string, descs map[string]string) {
	descs = map[string]string{}
	if c.Entries == nil {
		return nil, descs
	}
	for _, e := range c.Entries() {
		names = append(names, e[0])
		descs[e[0]] = e[1]
	}
	return names, descs
}

func (c *CommandCompleter) headWord(text string, cursorPos int) string {
	if cursorPos < 0 || cursorPos > len(text) {
		cursorPos = len(text)
	}
	before := text[:cursorPos]
	fields := strings.Fields(before)
	if len(fields) == 0 {
		return before
	}
	// Only complete the first token for slash commands.
	if strings.Contains(strings.TrimSpace(before), " ") && !strings.HasSuffix(before, " ") {
		// still on first word if no space before cursor's word? use last field only when single token
	}
	if len(strings.Fields(strings.TrimRight(before, " \t"))) > 1 {
		return ""
	}
	return fields[0]
}

func (c *CommandCompleter) GetCompletions(text string, cursorPos int) []string {
	items := c.GetCompletionItems(text, cursorPos)
	out := make([]string, len(items))
	for i, it := range items {
		out[i] = it.Insert
	}
	return out
}

func (c *CommandCompleter) GetCompletionItems(text string, cursorPos int) []CompletionItem {
	head := c.headWord(text, cursorPos)
	if head == "" || !strings.HasPrefix(head, "/") {
		return nil
	}
	names, descs := c.buildLookup()
	prefix := strings.ToLower(head)
	var items []CompletionItem
	for _, name := range names {
		if strings.HasPrefix(strings.ToLower(name), prefix) {
			items = append(items, CompletionItem{Insert: name, Display: name + " — " + descs[name]})
		}
	}
	return prioritizeHelpConfigSlashMenu(items)
}

func (c *CommandCompleter) GetReplacementRange(text string, cursorPos int) (int, int) {
	if cursorPos < 0 || cursorPos > len(text) {
		cursorPos = len(text)
	}
	before := text[:cursorPos]
	start := strings.LastIndexAny(before, " \t\n") + 1
	return start, cursorPos
}

// Complete implements the simple Completer interface used by older callers.
func (c *CommandCompleter) Complete(prefix string) []string {
	return c.GetCompletions(prefix, len(prefix))
}

// PathCompleter completes filesystem / indexed paths (Python PathCompleter).
type PathCompleter struct {
	Indexer       *fileindexer.Indexer
	TriggerPrefix string // e.g. "@"
	MaxResults    int
	ShowHidden    bool
}

// NewPathCompleter constructs a path completer over an optional indexer.
func NewPathCompleter(idx *fileindexer.Indexer) *PathCompleter {
	return &PathCompleter{Indexer: idx, TriggerPrefix: "@", MaxResults: 50}
}

type searchContext struct {
	partial   string
	dirPrefix string
	baseQuery string
	absMode   bool
}

func (p *PathCompleter) extractPartial(beforeCursor string) string {
	if p.TriggerPrefix != "" {
		idx := strings.LastIndex(beforeCursor, p.TriggerPrefix)
		if idx < 0 {
			return ""
		}
		partial := beforeCursor[idx+len(p.TriggerPrefix):]
		if strings.ContainsAny(partial, " \t\n") {
			return ""
		}
		return partial
	}
	fields := strings.Fields(beforeCursor)
	if len(fields) == 0 {
		return ""
	}
	return fields[len(fields)-1]
}

func (p *PathCompleter) buildSearchContext(partial string) searchContext {
	ctx := searchContext{partial: partial}
	if strings.HasPrefix(partial, "/") || (len(partial) > 1 && partial[1] == ':') {
		ctx.absMode = true
	}
	if strings.Contains(partial, string(os.PathSeparator)) {
		ctx.dirPrefix = filepath.Dir(partial)
		ctx.baseQuery = filepath.Base(partial)
		if strings.HasSuffix(partial, string(os.PathSeparator)) {
			ctx.dirPrefix = strings.TrimSuffix(partial, string(os.PathSeparator))
			ctx.baseQuery = ""
		}
	} else {
		ctx.baseQuery = partial
	}
	return ctx
}

func (p *PathCompleter) buildQueryASCIIMask(pattern string) *uint32 {
	var mask uint32
	has := false
	for _, r := range strings.ToLower(pattern) {
		if r >= 'a' && r <= 'z' {
			mask |= 1 << uint(r-'a')
			has = true
		}
	}
	if !has {
		return nil
	}
	return &mask
}

func (p *PathCompleter) isImmediateChildOfPrefix(pathStr, prefix string) bool {
	if prefix == "" || prefix == "." {
		return !strings.Contains(pathStr, string(os.PathSeparator))
	}
	prefix = strings.TrimSuffix(prefix, string(os.PathSeparator))
	if !strings.HasPrefix(pathStr, prefix+string(os.PathSeparator)) {
		return false
	}
	rest := strings.TrimPrefix(pathStr, prefix+string(os.PathSeparator))
	return !strings.Contains(rest, string(os.PathSeparator))
}

func (p *PathCompleter) matchesPrefix(entry string, ctx searchContext) bool {
	if ctx.dirPrefix != "" {
		return p.isImmediateChildOfPrefix(entry, ctx.dirPrefix) || strings.HasPrefix(entry, ctx.dirPrefix)
	}
	return true
}

func (p *PathCompleter) isVisible(entry string, ctx searchContext) bool {
	_ = ctx
	base := filepath.Base(entry)
	if !p.ShowHidden && strings.HasPrefix(base, ".") {
		return false
	}
	return true
}

func (p *PathCompleter) canPossiblyFuzzyMatch(candidate string, mask *uint32) bool {
	if mask == nil {
		return true
	}
	var have uint32
	for _, r := range strings.ToLower(candidate) {
		if r >= 'a' && r <= 'z' {
			have |= 1 << uint(r-'a')
		}
	}
	return have&*mask == *mask
}

func (p *PathCompleter) formatLabel(entry string) string {
	return entry
}

type matchRank struct {
	path  string
	score int
}

func (p *PathCompleter) buildMatchRank(entry, query string) matchRank {
	score := Score(query, entry)
	base := filepath.Base(entry)
	baseScore := Score(query, base)
	if baseScore > score {
		score = baseScore + 5
	}
	if strings.HasPrefix(strings.ToLower(base), strings.ToLower(query)) {
		score += 20
	}
	return matchRank{path: entry, score: score}
}

func (p *PathCompleter) scoreMatches(candidates []string, query string, limit int) []string {
	mask := p.buildQueryASCIIMask(query)
	var ranked []matchRank
	for _, c := range candidates {
		if !p.canPossiblyFuzzyMatch(c, mask) && !p.canPossiblyFuzzyMatch(filepath.Base(c), mask) {
			continue
		}
		mr := p.buildMatchRank(c, query)
		if mr.score >= 0 {
			ranked = append(ranked, mr)
		}
	}
	sort.Slice(ranked, func(i, j int) bool {
		if ranked[i].score != ranked[j].score {
			return ranked[i].score > ranked[j].score
		}
		return ranked[i].path < ranked[j].path
	})
	if limit > 0 && len(ranked) > limit {
		ranked = ranked[:limit]
	}
	out := make([]string, len(ranked))
	for i, r := range ranked {
		out[i] = r.path
	}
	return out
}

func (p *PathCompleter) collectMatches(text string, cursorPos int) []string {
	if cursorPos < 0 || cursorPos > len(text) {
		cursorPos = len(text)
	}
	partial := p.extractPartial(text[:cursorPos])
	if partial == "" && p.TriggerPrefix != "" {
		return nil
	}
	ctx := p.buildSearchContext(partial)
	limit := p.MaxResults
	if limit <= 0 {
		limit = 50
	}
	var candidates []string
	if p.Indexer != nil && len(p.Indexer.All()) > 0 {
		for _, e := range p.Indexer.All() {
			if !p.isVisible(e, ctx) || !p.matchesPrefix(e, ctx) {
				continue
			}
			candidates = append(candidates, e)
		}
		return p.scoreMatches(candidates, ctx.baseQuery, limit)
	}
	dir := "."
	base := ctx.baseQuery
	if ctx.dirPrefix != "" {
		dir = ctx.dirPrefix
	}
	entries, err := os.ReadDir(dir)
	if err != nil {
		return nil
	}
	for _, e := range entries {
		name := e.Name()
		if !p.ShowHidden && strings.HasPrefix(name, ".") {
			continue
		}
		full := filepath.Join(dir, name)
		if e.IsDir() {
			full += string(os.PathSeparator)
		}
		candidates = append(candidates, full)
	}
	return p.scoreMatches(candidates, base, limit)
}

func (p *PathCompleter) GetCompletions(text string, cursorPos int) []string {
	return p.collectMatches(text, cursorPos)
}

func (p *PathCompleter) GetCompletionItems(text string, cursorPos int) []CompletionItem {
	matches := p.collectMatches(text, cursorPos)
	items := make([]CompletionItem, len(matches))
	for i, m := range matches {
		insert := m
		if p.TriggerPrefix != "" {
			insert = p.TriggerPrefix + m
		}
		items[i] = CompletionItem{Insert: insert, Display: p.formatLabel(m)}
	}
	return items
}

func (p *PathCompleter) GetReplacementRange(text string, cursorPos int) (int, int) {
	if cursorPos < 0 || cursorPos > len(text) {
		cursorPos = len(text)
	}
	before := text[:cursorPos]
	if p.TriggerPrefix != "" {
		idx := strings.LastIndex(before, p.TriggerPrefix)
		if idx >= 0 {
			return idx, cursorPos
		}
	}
	start := strings.LastIndexAny(before, " \t\n") + 1
	return start, cursorPos
}

// Complete implements the simple path completer used by older callers.
func (p *PathCompleter) Complete(prefix string) []string {
	return p.GetCompletions(prefix, len(prefix))
}

// SlashCommandCompleter completes /commands (compat wrapper).
type SlashCommandCompleter struct {
	Commands []string
	inner    *CommandCompleter
}

func (s SlashCommandCompleter) Complete(prefix string) []string {
	if s.inner == nil {
		entries := make([][2]string, 0, len(s.Commands))
		for _, c := range s.Commands {
			if !strings.HasPrefix(c, "/") {
				c = "/" + c
			}
			entries = append(entries, [2]string{c, ""})
		}
		cc := &CommandCompleter{Entries: func() [][2]string { return entries }}
		return cc.Complete(prefix)
	}
	return s.inner.Complete(prefix)
}

// MultiCompleter fans out to multiple completers (Python MultiCompleter).
type MultiCompleter struct {
	Completers []Completer
}

func (m *MultiCompleter) GetCompletions(text string, cursorPos int) []string {
	seen := map[string]bool{}
	var out []string
	for _, c := range m.Completers {
		for _, item := range c.GetCompletions(text, cursorPos) {
			if seen[item] {
				continue
			}
			seen[item] = true
			out = append(out, item)
		}
		if len(out) > 0 {
			return out
		}
	}
	return out
}

func (m *MultiCompleter) GetCompletionItems(text string, cursorPos int) []CompletionItem {
	for _, c := range m.Completers {
		items := c.GetCompletionItems(text, cursorPos)
		if len(items) > 0 {
			return items
		}
	}
	return nil
}

func (m *MultiCompleter) GetReplacementRange(text string, cursorPos int) (int, int) {
	for _, c := range m.Completers {
		items := c.GetCompletionItems(text, cursorPos)
		if len(items) > 0 {
			return c.GetReplacementRange(text, cursorPos)
		}
	}
	if cursorPos < 0 || cursorPos > len(text) {
		cursorPos = len(text)
	}
	return cursorPos, cursorPos
}

// isWordChar reports whether r is a completion word character.
func isWordChar(r rune) bool {
	return unicode.IsLetter(r) || unicode.IsDigit(r) || r == '_' || r == '-' || r == '/' || r == '.' || r == '@'
}
