package autocompletion

import (
	"sort"
	"strings"
	"unicode"
)

const (
	prefixMultiplier       = 2.0
	wordBoundaryMultiplier = 1.8
	consecutiveMultiplier  = 1.3
)

// MatchResult is the outcome of a fuzzy match (Python MatchResult).
type MatchResult struct {
	Matched        bool
	Score          float64
	MatchedIndices []int
}

// FuzzyMatch scores pattern against text (Python fuzzy_match).
func FuzzyMatch(pattern, text string, textLower ...string) MatchResult {
	if pattern == "" {
		return MatchResult{Matched: true, Score: 0}
	}
	tl := ""
	if len(textLower) > 0 && textLower[0] != "" {
		tl = textLower[0]
	} else {
		tl = strings.ToLower(text)
	}
	return findBestMatch(pattern, strings.ToLower(pattern), tl, text)
}

func findBestMatch(patternOriginal, patternLower, textLower, textOriginal string) MatchResult {
	if len(patternLower) > len(textLower) {
		return MatchResult{}
	}
	if strings.HasPrefix(textLower, patternLower) {
		indices := make([]int, len(patternLower))
		for i := range indices {
			indices[i] = i
		}
		score := calculateScore(patternOriginal, patternLower, textLower, indices, textOriginal)
		return MatchResult{Matched: true, Score: score * prefixMultiplier, MatchedIndices: indices}
	}
	bestScore := -1.0
	var bestIndices []int
	for _, matcher := range []func(string, string, string, string) MatchResult{
		tryWordBoundaryMatch, tryConsecutiveMatch, trySubsequenceMatch,
	} {
		m := matcher(patternOriginal, patternLower, textLower, textOriginal)
		if m.Matched && m.Score > bestScore {
			bestScore = m.Score
			bestIndices = m.MatchedIndices
		}
	}
	if bestScore >= 0 {
		return MatchResult{Matched: true, Score: bestScore, MatchedIndices: bestIndices}
	}
	return MatchResult{}
}

func tryWordBoundaryMatch(patternOriginal, pattern, textLower, textOriginal string) MatchResult {
	var indices []int
	patternIdx := 0
	runesOrig := []rune(textOriginal)
	for i, char := range textLower {
		if patternIdx >= len(pattern) {
			break
		}
		isBoundary := i == 0 || strings.ContainsRune("/-_.", rune(textLower[i-1])) ||
			(i < len(runesOrig) && unicode.IsUpper(runesOrig[i]) && (i == 0 || !unicode.IsUpper(runesOrig[i-1])))
		if patternIdx < len(pattern) && char == rune(pattern[patternIdx]) {
			if isBoundary || (len(indices) > 0 && i == indices[len(indices)-1]+1) || len(indices) == 0 {
				indices = append(indices, i)
				patternIdx++
			}
		}
	}
	if patternIdx == len(pattern) {
		score := calculateScore(patternOriginal, pattern, textLower, indices, textOriginal)
		return MatchResult{Matched: true, Score: score * wordBoundaryMultiplier, MatchedIndices: indices}
	}
	return MatchResult{}
}

func tryConsecutiveMatch(patternOriginal, pattern, textLower, textOriginal string) MatchResult {
	var indices []int
	patternIdx := 0
	for i := 0; i < len(textLower); i++ {
		if patternIdx >= len(pattern) {
			break
		}
		if textLower[i] == pattern[patternIdx] {
			indices = append(indices, i)
			patternIdx++
		} else if len(indices) > 0 {
			indices = indices[:0]
			patternIdx = 0
		}
	}
	if patternIdx == len(pattern) {
		score := calculateScore(patternOriginal, pattern, textLower, indices, textOriginal)
		return MatchResult{Matched: true, Score: score * consecutiveMultiplier, MatchedIndices: indices}
	}
	return MatchResult{}
}

func trySubsequenceMatch(patternOriginal, pattern, textLower, textOriginal string) MatchResult {
	var indices []int
	patternIdx := 0
	for i := 0; i < len(textLower); i++ {
		if patternIdx >= len(pattern) {
			break
		}
		if textLower[i] == pattern[patternIdx] {
			indices = append(indices, i)
			patternIdx++
		}
	}
	if patternIdx == len(pattern) {
		score := calculateScore(patternOriginal, pattern, textLower, indices, textOriginal)
		return MatchResult{Matched: true, Score: score, MatchedIndices: indices}
	}
	return MatchResult{}
}

func calculateScore(patternOriginal, pattern, textLower string, indices []int, textOriginal string) float64 {
	if len(indices) == 0 {
		return 0
	}
	baseScore := 100.0
	if indices[0] == 0 {
		baseScore += 50.0
	} else {
		baseScore -= float64(indices[0]) * 2
	}
	consecutiveBonus := 0.0
	for i := 0; i < len(indices)-1; i++ {
		if indices[i+1] == indices[i]+1 {
			consecutiveBonus += 10.0
		}
	}
	boundaryBonus := 0.0
	runesOrig := []rune(textOriginal)
	for _, idx := range indices {
		if idx == 0 || (idx > 0 && strings.ContainsRune("/-_.", rune(textLower[idx-1]))) {
			boundaryBonus += 5.0
		} else if idx < len(runesOrig) && unicode.IsUpper(runesOrig[idx]) && (idx == 0 || !unicode.IsUpper(runesOrig[idx-1])) {
			boundaryBonus += 3.0
		}
	}
	caseBonus := 0.0
	for i, textIdx := range indices {
		if i < len(patternOriginal) && textIdx < len(textOriginal) && patternOriginal[i] == textOriginal[textIdx] {
			caseBonus += 2.0
		}
	}
	gapPenalty := 0.0
	for i := 0; i < len(indices)-1; i++ {
		gapPenalty += float64(indices[i+1]-indices[i]-1) * 1.5
	}
	score := baseScore + consecutiveBonus + boundaryBonus + caseBonus - gapPenalty
	if score < 0 {
		return 0
	}
	return score
}

// Score returns an int fuzzy match score (higher is better); -1 if no match.
// Kept for RankFilters / PathCompleter compatibility.
func Score(pattern, candidate string) int {
	m := FuzzyMatch(pattern, candidate)
	if !m.Matched {
		return -1
	}
	return int(m.Score)
}

// RankFilters sorts candidates by fuzzy score.
func RankFilters(pattern string, candidates []string, limit int) []string {
	type item struct {
		s string
		n int
	}
	var scored []item
	for _, c := range candidates {
		n := Score(pattern, c)
		if n >= 0 {
			scored = append(scored, item{c, n})
		}
	}
	sort.Slice(scored, func(i, j int) bool {
		if scored[i].n != scored[j].n {
			return scored[i].n > scored[j].n
		}
		return scored[i].s < scored[j].s
	})
	if limit > 0 && len(scored) > limit {
		scored = scored[:limit]
	}
	out := make([]string, len(scored))
	for i, it := range scored {
		out[i] = it.s
	}
	return out
}
