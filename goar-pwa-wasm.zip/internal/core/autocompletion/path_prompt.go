package autocompletion

import "strings"

// PathPromptState tracks in-progress @path completion in the input box (Python path_prompt).
type PathPromptState struct {
	Active bool
	Start  int
	Query  string
	Items  []string
	Index  int
}

// Reset clears the prompt state.
func (p *PathPromptState) Reset() { *p = PathPromptState{} }

// Select returns the currently highlighted item.
func (p *PathPromptState) Select() string {
	if p.Index >= 0 && p.Index < len(p.Items) {
		return p.Items[p.Index]
	}
	return ""
}

// Move moves the selection by delta (wrapping).
func (p *PathPromptState) Move(delta int) {
	if len(p.Items) == 0 {
		return
	}
	p.Index = (p.Index + delta) % len(p.Items)
	if p.Index < 0 {
		p.Index += len(p.Items)
	}
}

// SetItems replaces suggestions and resets index.
func (p *PathPromptState) SetItems(items []string) {
	p.Items = append([]string{}, items...)
	p.Index = 0
	p.Active = len(items) > 0
}

// Apply replaces the @query region in text with the selected item.
func (p *PathPromptState) Apply(text string) (string, int, bool) {
	sel := p.Select()
	if sel == "" || p.Start < 0 || p.Start > len(text) {
		return text, len(text), false
	}
	// Replace from Start through Start+1+len(Query)
	end := p.Start + 1 + len(p.Query)
	if end > len(text) {
		end = len(text)
	}
	insert := sel
	if !strings.HasPrefix(insert, "@") {
		insert = "@" + insert
	}
	newText := text[:p.Start] + insert + text[end:]
	newCursor := p.Start + len(insert)
	p.Reset()
	return newText, newCursor, true
}

// UpdateFromText refreshes query from text/cursor using AdaptInputForPathCompletion.
func (p *PathPromptState) UpdateFromText(text string, cursor int) bool {
	_, query, start, ok := AdaptInputForPathCompletion(text, cursor)
	if !ok {
		p.Reset()
		return false
	}
	p.Active = true
	p.Start = start
	p.Query = query
	return true
}

// FilterItems filters candidates by current query using fuzzy ranking.
func (p *PathPromptState) FilterItems(candidates []string, limit int) {
	if limit <= 0 {
		limit = 20
	}
	p.SetItems(RankFilters(p.Query, candidates, limit))
}
