// Package autocompletion provides fuzzy path and command completion.
package autocompletion
