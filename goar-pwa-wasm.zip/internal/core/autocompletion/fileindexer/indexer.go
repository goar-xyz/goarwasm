package fileindexer

import (
	"os"
	"path/filepath"
	"sync"
)

// Indexer walks a root and stores relative paths (Python FileIndexer).
type Indexer struct {
	Root   string
	Store  Store
	Ignore IgnoreRules

	mu           sync.Mutex
	rebuilding   bool
	cancelRebuild bool
	done         chan struct{}
}

// NewIndexer constructs an indexer for root.
func NewIndexer(root string) *Indexer {
	ignore := LoadIgnoreRules(root)
	return &Indexer{Root: root, Ignore: ignore, Store: *NewStore(ignore, 200), done: make(chan struct{})}
}

// Stats returns index statistics.
func (idx *Indexer) Stats() FileIndexStats { return idx.Store.Stats() }

// Build synchronously walks and fills the store.
func (idx *Indexer) Build() error {
	return idx.Store.Rebuild(idx.Root, nil)
}

// GetIndex returns entries for root, rebuilding if needed.
func (idx *Indexer) GetIndex(root string) []IndexEntry {
	if root == "" {
		root = idx.Root
	}
	resolved, _ := filepath.Abs(root)
	if idx.Store.Root() != resolved || len(idx.Store.Snapshot()) == 0 {
		idx.StartBackgroundRebuild(resolved)
		idx.WaitForRebuild()
	}
	return idx.Store.Snapshot()
}

// Refresh triggers a background rebuild of the current root.
func (idx *Indexer) Refresh() {
	idx.StartBackgroundRebuild(idx.Root)
}

// Shutdown cancels any in-flight rebuild.
func (idx *Indexer) Shutdown() {
	idx.mu.Lock()
	idx.cancelRebuild = true
	idx.mu.Unlock()
	idx.WaitForRebuild()
}

// StartBackgroundRebuild starts an async rebuild if not already running.
func (idx *Indexer) StartBackgroundRebuild(root string) {
	idx.mu.Lock()
	if idx.rebuilding {
		idx.mu.Unlock()
		return
	}
	idx.rebuilding = true
	idx.cancelRebuild = false
	idx.done = make(chan struct{})
	idx.mu.Unlock()
	go idx.rebuildWorker(root)
}

func (idx *Indexer) rebuildWorker(root string) {
	defer func() {
		idx.mu.Lock()
		idx.rebuilding = false
		close(idx.done)
		idx.mu.Unlock()
	}()
	_ = idx.Store.Rebuild(root, func() bool {
		idx.mu.Lock()
		defer idx.mu.Unlock()
		return idx.cancelRebuild
	})
	// Also keep legacy Walk fill for Ignore-based simple list.
	if len(idx.Store.All()) == 0 {
		var paths []string
		_ = filepath.Walk(root, func(path string, info os.FileInfo, err error) error {
			if err != nil {
				return nil
			}
			rel, err := filepath.Rel(root, path)
			if err != nil || rel == "." {
				return nil
			}
			if info.IsDir() && idx.Ignore.Match(rel) {
				return filepath.SkipDir
			}
			if idx.Ignore.Match(rel) {
				return nil
			}
			if !info.IsDir() {
				paths = append(paths, rel)
			}
			return nil
		})
		idx.Store.Set(paths)
	}
}

// WaitForRebuild blocks until the background rebuild finishes.
func (idx *Indexer) WaitForRebuild() {
	idx.mu.Lock()
	done := idx.done
	rebuilding := idx.rebuilding
	idx.mu.Unlock()
	if rebuilding && done != nil {
		<-done
	}
}

// HandleWatchChanges applies watcher events.
func (idx *Indexer) HandleWatchChanges(changes []ChangeEvent) {
	idx.Store.ApplyChanges(changes)
}

// All returns relative file paths.
func (idx *Indexer) All() []string { return idx.Store.All() }
