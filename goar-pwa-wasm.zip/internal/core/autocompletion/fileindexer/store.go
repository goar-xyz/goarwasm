package fileindexer

import (
	"os"
	"path/filepath"
	"sort"
	"strings"
	"sync"
)

const asciiCodepointLimit = 128

// FileIndexStats tracks rebuild/update counts.
type FileIndexStats struct {
	Rebuilds            int
	IncrementalUpdates  int
}

// IndexEntry is one indexed path (Python IndexEntry).
type IndexEntry struct {
	Rel       string
	RelLower  string
	Name      string
	Path      string
	IsDir     bool
	ASCIIMask int
}

// ChangeKind classifies a filesystem change.
type ChangeKind int

const (
	ChangeAdded ChangeKind = iota
	ChangeModified
	ChangeDeleted
)

// ChangeEvent is a path change notification.
type ChangeEvent struct {
	Kind ChangeKind
	Path string
}

// BuildASCIIMask builds a bitset of ASCII codepoints present in value.
func BuildASCIIMask(value string) int {
	mask := 0
	for _, r := range value {
		if r >= asciiCodepointLimit {
			continue
		}
		mask |= 1 << r
	}
	return mask
}

// Store / FileIndexStore holds indexed paths (Python FileIndexStore).
type Store struct {
	mu                  sync.RWMutex
	ignore              IgnoreRules
	stats               FileIndexStats
	massChangeThreshold int
	entriesByRel        map[string]IndexEntry
	ordered             []IndexEntry
	root                string
	// legacy simple path list used by Indexer.All()
	paths []string
}

// NewStore creates an empty file index store.
func NewStore(ignore IgnoreRules, massChangeThreshold int) *Store {
	if massChangeThreshold <= 0 {
		massChangeThreshold = 200
	}
	return &Store{
		ignore: ignore, massChangeThreshold: massChangeThreshold,
		entriesByRel: map[string]IndexEntry{},
	}
}

// Root returns the indexed root directory.
func (s *Store) Root() string {
	s.mu.RLock()
	defer s.mu.RUnlock()
	return s.root
}

// Stats returns rebuild counters.
func (s *Store) Stats() FileIndexStats {
	s.mu.RLock()
	defer s.mu.RUnlock()
	return s.stats
}

// Clear empties the store.
func (s *Store) Clear() {
	s.mu.Lock()
	defer s.mu.Unlock()
	s.entriesByRel = map[string]IndexEntry{}
	s.ordered = nil
	s.root = ""
	s.paths = nil
}

// Set replaces the simple path list (compat).
func (s *Store) Set(paths []string) {
	s.mu.Lock()
	defer s.mu.Unlock()
	s.paths = append([]string{}, paths...)
}

// All returns relative file paths (compat).
func (s *Store) All() []string {
	s.mu.RLock()
	defer s.mu.RUnlock()
	if len(s.paths) > 0 {
		return append([]string{}, s.paths...)
	}
	out := make([]string, 0, len(s.entriesByRel))
	for _, e := range s.SnapshotLocked() {
		if !e.IsDir {
			out = append(out, e.Rel)
		}
	}
	return out
}

// Add appends a path to the simple list (compat).
func (s *Store) Add(path string) {
	s.mu.Lock()
	defer s.mu.Unlock()
	s.paths = append(s.paths, path)
}

// Rebuild walks root and replaces the index (Python rebuild).
func (s *Store) Rebuild(root string, shouldCancel func() bool) error {
	resolved, err := filepath.Abs(root)
	if err != nil {
		resolved = root
	}
	s.ignore = LoadIgnoreRules(resolved)
	entries := s.walkDirectory(resolved, "", shouldCancel)
	s.mu.Lock()
	defer s.mu.Unlock()
	s.entriesByRel = map[string]IndexEntry{}
	for _, e := range entries {
		s.entriesByRel[e.Rel] = e
	}
	s.ordered = entries
	s.root = resolved
	s.stats.Rebuilds++
	paths := make([]string, 0, len(entries))
	for _, e := range entries {
		if !e.IsDir {
			paths = append(paths, e.Rel)
		}
	}
	s.paths = paths
	return nil
}

// Snapshot returns ordered entries.
func (s *Store) Snapshot() []IndexEntry {
	s.mu.Lock()
	defer s.mu.Unlock()
	return s.SnapshotLocked()
}

// SnapshotLocked assumes lock held.
func (s *Store) SnapshotLocked() []IndexEntry {
	if len(s.entriesByRel) == 0 {
		return nil
	}
	if s.ordered == nil {
		s.ordered = make([]IndexEntry, 0, len(s.entriesByRel))
		for _, e := range s.entriesByRel {
			s.ordered = append(s.ordered, e)
		}
		sort.Slice(s.ordered, func(i, j int) bool { return s.ordered[i].Rel < s.ordered[j].Rel })
	}
	out := make([]IndexEntry, len(s.ordered))
	copy(out, s.ordered)
	return out
}

// ApplyChanges applies incremental filesystem changes.
func (s *Store) ApplyChanges(changes []ChangeEvent) {
	s.mu.Lock()
	defer s.mu.Unlock()
	if s.root == "" {
		return
	}
	if len(changes) > s.massChangeThreshold {
		s.mu.Unlock()
		_ = s.Rebuild(s.root, nil)
		s.mu.Lock()
		return
	}
	modified := false
	for _, ch := range changes {
		rel, err := filepath.Rel(s.root, ch.Path)
		if err != nil {
			continue
		}
		rel = filepath.ToSlash(rel)
		if rel == "" || rel == "." {
			continue
		}
		if ch.Kind == ChangeDeleted {
			if s.removeEntry(rel) {
				modified = true
			}
			continue
		}
		st, err := os.Lstat(ch.Path)
		if err != nil {
			continue
		}
		if st.IsDir() {
			if e := s.createEntry(rel, filepath.Base(ch.Path), ch.Path, true); e != nil {
				s.entriesByRel[rel] = *e
				modified = true
			}
			for _, e := range s.walkDirectory(ch.Path, rel, nil) {
				s.entriesByRel[e.Rel] = e
				modified = true
			}
		} else {
			if e := s.createEntry(rel, filepath.Base(ch.Path), ch.Path, false); e != nil {
				s.entriesByRel[e.Rel] = *e
				modified = true
			}
		}
	}
	if modified {
		s.ordered = nil
		s.stats.IncrementalUpdates++
		paths := make([]string, 0, len(s.entriesByRel))
		for _, e := range s.entriesByRel {
			if !e.IsDir {
				paths = append(paths, e.Rel)
			}
		}
		s.paths = paths
	}
}

func (s *Store) createEntry(relStr, name, path string, isDir bool) *IndexEntry {
	if s.ignore.Match(relStr) || s.ignore.Match(name) {
		return nil
	}
	relLower := strings.ToLower(relStr)
	return &IndexEntry{
		Rel: relStr, RelLower: relLower, Name: name, Path: path, IsDir: isDir,
		ASCIIMask: BuildASCIIMask(relLower),
	}
}

func (s *Store) walkDirectory(directory, relPrefix string, cancelCheck func() bool) []IndexEntry {
	var results []IndexEntry
	entries, err := os.ReadDir(directory)
	if err != nil {
		return results
	}
	for _, entry := range entries {
		if cancelCheck != nil && cancelCheck() {
			break
		}
		name := entry.Name()
		relStr := name
		if relPrefix != "" {
			relStr = relPrefix + "/" + name
		}
		path := filepath.Join(directory, name)
		isDir := entry.IsDir()
		indexEntry := s.createEntry(relStr, name, path, isDir)
		if indexEntry == nil {
			continue
		}
		results = append(results, *indexEntry)
		if isDir {
			results = append(results, s.walkDirectory(path, relStr, cancelCheck)...)
		}
	}
	return results
}

func (s *Store) removeEntry(relStr string) bool {
	entry, ok := s.entriesByRel[relStr]
	if !ok {
		return false
	}
	delete(s.entriesByRel, relStr)
	if entry.IsDir {
		prefix := relStr + "/"
		for key := range s.entriesByRel {
			if strings.HasPrefix(key, prefix) {
				delete(s.entriesByRel, key)
			}
		}
	}
	return true
}
