package fileindexer

import (
	"os"
	"path/filepath"
	"time"
)

// Watcher periodically rebuilds the index (poll-based; no external watch dep required).
type Watcher struct {
	Indexer  *Indexer
	Interval time.Duration
	stop     chan struct{}
}

func NewWatcher(idx *Indexer, interval time.Duration) *Watcher {
	if interval <= 0 {
		interval = 5 * time.Second
	}
	return &Watcher{Indexer: idx, Interval: interval, stop: make(chan struct{})}
}

func (w *Watcher) Start() {
	go func() {
		t := time.NewTicker(w.Interval)
		defer t.Stop()
		for {
			select {
			case <-w.stop:
				return
			case <-t.C:
				_ = w.Indexer.Build()
			}
		}
	}()
}

func (w *Watcher) Stop() { close(w.stop) }

// Touch updates mtime of a sentinel for tests.
func Touch(path string) error {
	f, err := os.OpenFile(path, os.O_CREATE|os.O_RDWR, 0o644)
	if err != nil {
		return err
	}
	defer f.Close()
	_, _ = f.WriteString(time.Now().String())
	return nil
}

var _ = filepath.Separator
