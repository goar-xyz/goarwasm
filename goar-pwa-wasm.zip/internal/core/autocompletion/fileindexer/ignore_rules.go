package fileindexer

import (
	"bufio"
	"os"
	"path/filepath"
	"strings"
)

// DefaultIgnores are always skipped.
var DefaultIgnores = []string{
	".git", "node_modules", ".venv", "venv", "__pycache__", "dist", "build",
	".idea", ".vscode", ".agent", ".tox", ".mypy_cache", ".pytest_cache",
	"coverage", ".next", ".nuxt", ".turbo", ".cache", "target", "vendor",
}

// DefaultIgnoreSpecs are (pattern, isDirOnly) defaults.
var DefaultIgnoreSpecs = []struct {
	Pattern string
	DirOnly bool
}{
	{".git", true}, {".svn", true}, {".hg", true},
	{"node_modules", true}, {".venv", true}, {"venv", true},
	{"__pycache__", true}, {"dist", true}, {"build", true},
	{".idea", true}, {".vscode", true}, {".agent", true},
	{"*.pyc", false}, {"*.pyo", false}, {".DS_Store", false},
}

// CompiledPattern is a compiled ignore rule.
type CompiledPattern struct {
	Raw      string
	Negate   bool
	DirOnly  bool
	Anchored bool
	Pattern  string
}

// IgnoreRules holds ignore patterns (Python IgnoreRules).
type IgnoreRules struct {
	Patterns         []string
	compiled         []CompiledPattern
	root             string
	defaultsCompiled []CompiledPattern
}

// NewIgnoreRules constructs ignore rules with optional default (pattern, dirOnly) pairs.
func NewIgnoreRules(defaults []struct {
	Pattern string
	DirOnly bool
}) IgnoreRules {
	if defaults == nil {
		defaults = DefaultIgnoreSpecs
	}
	r := IgnoreRules{}
	for _, d := range defaults {
		r.Patterns = append(r.Patterns, d.Pattern)
		r.defaultsCompiled = append(r.defaultsCompiled, CompiledPattern{
			Raw: d.Pattern, DirOnly: d.DirOnly, Pattern: d.Pattern,
		})
	}
	r.compiled = append([]CompiledPattern{}, r.defaultsCompiled...)
	return r
}

func LoadIgnoreRules(root string) IgnoreRules {
	r := NewIgnoreRules(nil)
	r.EnsureForRoot(root)
	return r
}

func (r *IgnoreRules) compileDefaultPatterns() []CompiledPattern {
	return append([]CompiledPattern{}, r.defaultsCompiled...)
}

// GetWalkSkipDirNames returns directory basenames to skip during walks.
func (r IgnoreRules) GetWalkSkipDirNames() map[string]bool {
	out := map[string]bool{}
	for _, p := range r.compiled {
		if p.DirOnly || !strings.Contains(p.Pattern, "*") {
			out[strings.TrimSuffix(p.Pattern, "/")] = true
		}
	}
	for _, d := range DefaultIgnores {
		out[d] = true
	}
	return out
}

// EnsureForRoot loads ignore files for root.
func (r *IgnoreRules) EnsureForRoot(root string) {
	resolved, _ := filepath.Abs(root)
	if r.root == resolved && len(r.compiled) > 0 {
		return
	}
	r.root = resolved
	r.compiled = r.buildPatterns(resolved)
	r.Patterns = make([]string, 0, len(r.compiled))
	for _, c := range r.compiled {
		r.Patterns = append(r.Patterns, c.Raw)
	}
}

// ShouldIgnore reports whether a relative path should be ignored.
func (r IgnoreRules) ShouldIgnore(relStr, name string, isDir bool) bool {
	if r.Match(relStr) || r.Match(name) {
		return true
	}
	ignored := false
	for _, p := range r.compiled {
		if r.matches(p, relStr, name, isDir) {
			ignored = !p.Negate
		}
	}
	return ignored
}

// Reset clears root-specific patterns back to defaults.
func (r *IgnoreRules) Reset() {
	r.root = ""
	r.compiled = append([]CompiledPattern{}, r.defaultsCompiled...)
	r.Patterns = nil
	for _, c := range r.compiled {
		r.Patterns = append(r.Patterns, c.Raw)
	}
}

func (r IgnoreRules) buildPatterns(root string) []CompiledPattern {
	out := append([]CompiledPattern{}, r.defaultsCompiled...)
	for _, name := range []string{".gitignore", ".agentignore", ".ignore", ".codeignore"} {
		f, err := os.Open(filepath.Join(root, name))
		if err != nil {
			continue
		}
		sc := bufio.NewScanner(f)
		for sc.Scan() {
			line := strings.TrimSpace(sc.Text())
			if line == "" || strings.HasPrefix(line, "#") {
				continue
			}
			neg := false
			if strings.HasPrefix(line, "!") {
				neg = true
				line = strings.TrimPrefix(line, "!")
			}
			dirOnly := strings.HasSuffix(line, "/")
			line = strings.TrimSuffix(line, "/")
			anchored := strings.HasPrefix(line, "/")
			line = strings.TrimPrefix(line, "/")
			out = append(out, CompiledPattern{
				Raw: line, Negate: neg, DirOnly: dirOnly, Anchored: anchored, Pattern: line,
			})
		}
		f.Close()
	}
	return out
}

func (r IgnoreRules) matches(p CompiledPattern, relStr, name string, isDir bool) bool {
	if p.DirOnly && !isDir {
		return false
	}
	pat := p.Pattern
	if p.Anchored {
		return matchGlob(relStr, pat) || relStr == pat
	}
	return matchGlob(name, pat) || matchGlob(relStr, pat) ||
		strings.HasPrefix(relStr, pat+"/") || strings.Contains(relStr, "/"+pat+"/")
}

// Match reports whether rel matches any simple pattern (compat).
func (r IgnoreRules) Match(rel string) bool {
	base := filepath.Base(rel)
	for _, p := range r.Patterns {
		p = strings.TrimSuffix(p, "/")
		if base == p || rel == p || strings.HasPrefix(rel, p+"/") || strings.Contains(rel, "/"+p+"/") {
			return true
		}
		if strings.Contains(p, "*") && matchGlob(base, p) {
			return true
		}
	}
	return false
}

func matchGlob(name, pattern string) bool {
	ok, err := filepath.Match(pattern, name)
	return err == nil && ok
}
