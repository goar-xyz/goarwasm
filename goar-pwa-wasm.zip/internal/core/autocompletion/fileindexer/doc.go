// Package fileindexer indexes the workspace for path autocompletion.
package fileindexer
