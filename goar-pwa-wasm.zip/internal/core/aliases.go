package core

import "github.com/goarxyz/goar/internal/core/types"

// Re-export shared types (Python: goar.core.types) for convenience.
type (
	Backend            = types.Backend
	Role               = types.Role
	StrToolChoice      = types.StrToolChoice
	ApprovalResponse   = types.ApprovalResponse
	AvailableFunction  = types.AvailableFunction
	AvailableTool      = types.AvailableTool
	FunctionCall       = types.FunctionCall
	ToolCall           = types.ToolCall
	LLMMessage         = types.LLMMessage
	LLMUsage           = types.LLMUsage
	LLMChunk           = types.LLMChunk
	AgentStats         = types.AgentStats
	ScheduledLoop      = types.ScheduledLoop
	SessionMetadata    = types.SessionMetadata
	SessionInfo        = types.SessionInfo
	OutputFormat       = types.OutputFormat
	ToolStreamEvent    = types.ToolStreamEvent
	AssistantEvent     = types.AssistantEvent
	ToolCallEvent      = types.ToolCallEvent
	ToolResultEvent    = types.ToolResultEvent
	Event              = types.Event
)

const (
	BackendGeneric     = types.BackendGeneric
	RoleSystem         = types.RoleSystem
	RoleUser           = types.RoleUser
	RoleAssistant      = types.RoleAssistant
	RoleTool           = types.RoleTool
	ToolChoiceAuto     = types.ToolChoiceAuto
	ToolChoiceNone     = types.ToolChoiceNone
	ToolChoiceAny      = types.ToolChoiceAny
	ToolChoiceRequired = types.ToolChoiceRequired
	ApprovalYes        = types.ApprovalYes
	ApprovalNo         = types.ApprovalNo
	OutputText         = types.OutputText
	OutputJSON         = types.OutputJSON
	OutputStreaming    = types.OutputStreaming
)

var (
	NewMessage = types.NewMessage
	NewEvent   = types.NewEvent
	FormatEvent = types.FormatEvent
)
