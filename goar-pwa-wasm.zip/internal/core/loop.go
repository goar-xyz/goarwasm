package core

import (
	"fmt"
	"math"
	"regexp"
	"strings"
	"time"

	"github.com/goarxyz/goar/internal/core/session"
)

const (
	MinIntervalSeconds  = 30
	MaxLoopsPerSession  = 50
)

// UsageHint is the /loop command help text (Python USAGE_HINT).
const usageHintText = `Usage:
  /loop <interval> <prompt>   Schedule a recurring prompt (e.g. /loop 5m check status)
  /loop add <interval> <prompt>
  /loop list                  List scheduled loops
  /loop cancel [id|all]       Cancel one or all loops
Interval examples: 30s, 5m, 1h, 1d (minimum 30s).`

// UsageHint returns the /loop help text.
func UsageHint() string { return usageHintText }


var intervalRE = regexp.MustCompile(`^(\d+)([smhd])$`)

// ParseInterval parses 30s/5m/2h/1d into seconds.
func ParseInterval(text string) (int, error) {
	text = strings.TrimSpace(strings.ToLower(text))
	if text == "" {
		return 0, fmt.Errorf("missing interval")
	}
	m := intervalRE.FindStringSubmatch(text)
	if m == nil {
		return 0, fmt.Errorf("invalid interval %q", text)
	}
	var n int
	fmt.Sscanf(m[1], "%d", &n)
	mult := map[string]int{"s": 1, "m": 60, "h": 3600, "d": 86400}[m[2]]
	sec := n * mult
	if sec < MinIntervalSeconds {
		return 0, fmt.Errorf("interval must be at least %ds", MinIntervalSeconds)
	}
	return sec, nil
}

// FormatDuration formats seconds as compact duration.
func FormatDuration(seconds int, short bool) string {
	parts := []string{}
	for _, u := range []struct{ suf string; sec int }{{"d", 86400}, {"h", 3600}, {"m", 60}, {"s", 1}} {
		if seconds >= u.sec {
			v := seconds / u.sec
			parts = append(parts, fmt.Sprintf("%d%s", v, u.suf))
			seconds %= u.sec
		}
	}
	if len(parts) == 0 {
		parts = []string{"0s"}
	}
	if short {
		return parts[0]
	}
	return strings.Join(parts, "")
}

// LoopManager manages scheduled loops for a session.
type LoopManager struct {
	logger *session.Logger
	loops  []ScheduledLoop
}

func NewLoopManager(logger *session.Logger) *LoopManager {
	return &LoopManager{logger: logger}
}

func (m *LoopManager) Loops() []ScheduledLoop { return append([]ScheduledLoop{}, m.loops...) }

func (m *LoopManager) Restore(loops []ScheduledLoop) { m.loops = append([]ScheduledLoop{}, loops...) }

func (m *LoopManager) NextDueIn(now float64) float64 {
	if len(m.loops) == 0 {
		return math.Inf(1)
	}
	min := m.loops[0].NextFireAt
	for _, l := range m.loops[1:] {
		if l.NextFireAt < min {
			min = l.NextFireAt
		}
	}
	d := min - now
	if d < 0 {
		return 0
	}
	return d
}

func (m *LoopManager) PopDue(now float64) *ScheduledLoop {
	var due *ScheduledLoop
	for i := range m.loops {
		if m.loops[i].NextFireAt <= now {
			if due == nil || m.loops[i].NextFireAt < due.NextFireAt {
				due = &m.loops[i]
			}
		}
	}
	if due == nil {
		return nil
	}
	due.NextFireAt = now + float64(due.IntervalSeconds)
	return due
}

func (m *LoopManager) Add(intervalText, prompt string) error {
	if len(m.loops) >= MaxLoopsPerSession {
		return fmt.Errorf("max loops per session (%d) reached", MaxLoopsPerSession)
	}
	sec, err := ParseInterval(intervalText)
	if err != nil {
		return err
	}
	now := float64(time.Now().UnixNano()) / 1e9
	id := fmt.Sprintf("loop-%d", len(m.loops)+1)
	m.loops = append(m.loops, ScheduledLoop{
		ID: id, IntervalSeconds: sec, Prompt: prompt, NextFireAt: now + float64(sec), CreatedAt: now,
	})
	return nil
}

func (m *LoopManager) Cancel(id string) int {
	if id == "all" {
		n := len(m.loops)
		m.loops = nil
		return n
	}
	out := m.loops[:0]
	n := 0
	for _, l := range m.loops {
		if l.ID == id {
			n++
			continue
		}
		out = append(out, l)
	}
	m.loops = out
	return n
}
