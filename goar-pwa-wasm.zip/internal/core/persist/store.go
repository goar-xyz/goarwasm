package persist

import (
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"sort"
	"strings"
	"sync"
	"time"

	"github.com/google/uuid"
)

// Store is durable relational memory (SQLite-shaped API, pure-Go engine).
type Store struct {
	mu   sync.RWMutex
	path string
	data *dbData
}

type dbData struct {
	Version        int                        `json:"version"`
	Meta           map[string]string          `json:"meta"`
	KV             map[string]map[string]kvRow `json:"kv"`
	Sessions       map[string]SessionRow      `json:"sessions"`
	Messages       map[string]MessageRow      `json:"messages"`
	ToolEvents     map[string]ToolEventRow    `json:"tool_events"`
	MemoryNotes    map[string]MemoryNoteRow   `json:"memory_notes"`
	KnownHostsMeta map[string]KnownHostRow    `json:"known_hosts_meta"`
}

type kvRow struct {
	Value     string `json:"value"`
	UpdatedAt string `json:"updated_at"`
}

// SessionRow is a chat/session record.
type SessionRow struct {
	ID        string `json:"id"`
	Title     string `json:"title"`
	CreatedAt string `json:"created_at"`
	UpdatedAt string `json:"updated_at"`
	MetaJSON  string `json:"meta_json"`
}

// MessageRow is a message within a session.
type MessageRow struct {
	ID        string `json:"id"`
	SessionID string `json:"session_id"`
	Role      string `json:"role"`
	Content   string `json:"content"`
	ToolName  string `json:"tool_name"`
	CreatedAt string `json:"created_at"`
	Seq       int    `json:"seq"`
}

// ToolEventRow records tool call/result history.
type ToolEventRow struct {
	ID         string `json:"id"`
	SessionID  string `json:"session_id"`
	Name       string `json:"name"`
	ArgsJSON   string `json:"args_json"`
	ResultJSON string `json:"result_json"`
	Error      string `json:"error"`
	CreatedAt  string `json:"created_at"`
}

// MemoryNoteRow is long-term agent memory.
type MemoryNoteRow struct {
	ID        string `json:"id"`
	Kind      string `json:"kind"`
	Content   string `json:"content"`
	Tags      string `json:"tags"`
	CreatedAt string `json:"created_at"`
	UpdatedAt string `json:"updated_at"`
}

// KnownHostRow mirrors SSH known_hosts metadata for queries.
type KnownHostRow struct {
	Host        string `json:"host"`
	KeyType     string `json:"key_type"`
	Fingerprint string `json:"fingerprint"`
	FirstSeen   string `json:"first_seen"`
	LastSeen    string `json:"last_seen"`
	RawLine     string `json:"raw_line"`
}

func nowRFC() string { return time.Now().UTC().Format(time.RFC3339Nano) }

func emptyData() *dbData {
	return &dbData{
		Version:        SchemaVersion,
		Meta:           map[string]string{"schema_version": fmt.Sprintf("%d", SchemaVersion)},
		KV:             map[string]map[string]kvRow{},
		Sessions:       map[string]SessionRow{},
		Messages:       map[string]MessageRow{},
		ToolEvents:     map[string]ToolEventRow{},
		MemoryNotes:    map[string]MemoryNoteRow{},
		KnownHostsMeta: map[string]KnownHostRow{},
	}
}

// Open opens or creates the store at path (absolute or under AGENT_HOME if relative).
func Open(path string) (*Store, error) {
	if path == "" {
		path = DefaultPath()
	}
	if !filepath.IsAbs(path) {
		path = filepath.Join(agentHome(), path)
	}
	_ = os.MkdirAll(filepath.Dir(path), 0o755)
	s := &Store{path: path, data: emptyData()}
	if b, err := os.ReadFile(path); err == nil && len(b) > 0 {
		var d dbData
		if err := json.Unmarshal(b, &d); err != nil {
			return nil, fmt.Errorf("persist: corrupt store: %w", err)
		}
		if d.Meta == nil {
			d.Meta = map[string]string{}
		}
		if d.KV == nil {
			d.KV = map[string]map[string]kvRow{}
		}
		if d.Sessions == nil {
			d.Sessions = map[string]SessionRow{}
		}
		if d.Messages == nil {
			d.Messages = map[string]MessageRow{}
		}
		if d.ToolEvents == nil {
			d.ToolEvents = map[string]ToolEventRow{}
		}
		if d.MemoryNotes == nil {
			d.MemoryNotes = map[string]MemoryNoteRow{}
		}
		if d.KnownHostsMeta == nil {
			d.KnownHostsMeta = map[string]KnownHostRow{}
		}
		d.Version = SchemaVersion
		s.data = &d
	}
	_ = s.Flush()
	return s, nil
}

// DefaultPath returns AGENT_HOME/persist/goar-memory.db.json.
func DefaultPath() string {
	return filepath.Join(agentHome(), DefaultRelPath)
}

func agentHome() string {
	h := strings.TrimSpace(os.Getenv("AGENT_HOME"))
	if h == "" {
		h = "/tmp/goar-agent-home"
	}
	return h
}

// Path returns the on-disk path.
func (s *Store) Path() string { return s.path }

// Flush writes the store to disk.
func (s *Store) Flush() error {
	s.mu.RLock()
	defer s.mu.RUnlock()
	return s.flushLocked()
}

func (s *Store) flushLocked() error {
	_ = os.MkdirAll(filepath.Dir(s.path), 0o755)
	b, err := json.MarshalIndent(s.data, "", "  ")
	if err != nil {
		return err
	}
	tmp := s.path + ".tmp"
	if err := os.WriteFile(tmp, b, 0o644); err != nil {
		return err
	}
	return os.Rename(tmp, s.path)
}

// ExportJSON returns the full store as JSON (for OPFS / Puter sync).
func (s *Store) ExportJSON() (string, error) {
	s.mu.RLock()
	defer s.mu.RUnlock()
	b, err := json.Marshal(s.data)
	return string(b), err
}

// ImportJSON replaces store contents from JSON.
func (s *Store) ImportJSON(raw string) error {
	var d dbData
	if err := json.Unmarshal([]byte(raw), &d); err != nil {
		return err
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	if d.Meta == nil {
		d = *emptyData()
	}
	s.data = &d
	return s.flushLocked()
}

// Engine reports the active engine name for status()/parity.
func (s *Store) Engine() string { return "pure-go-sqlite-shaped" }

// SchemaDoc returns human-readable schema (parity with SQLite DDL).
func SchemaDoc() string { return strings.TrimSpace(schemaSQL) }

// SetKV sets a namespaced key.
func (s *Store) SetKV(ns, key, value string) error {
	s.mu.Lock()
	defer s.mu.Unlock()
	if s.data.KV[ns] == nil {
		s.data.KV[ns] = map[string]kvRow{}
	}
	s.data.KV[ns][key] = kvRow{Value: value, UpdatedAt: nowRFC()}
	return s.flushLocked()
}

// GetKV returns a value.
func (s *Store) GetKV(ns, key string) (string, bool) {
	s.mu.RLock()
	defer s.mu.RUnlock()
	m := s.data.KV[ns]
	if m == nil {
		return "", false
	}
	r, ok := m[key]
	return r.Value, ok
}

// UpsertSession creates or updates a session.
func (s *Store) UpsertSession(id, title string) (SessionRow, error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	now := nowRFC()
	row, ok := s.data.Sessions[id]
	if !ok {
		row = SessionRow{ID: id, Title: title, CreatedAt: now, UpdatedAt: now, MetaJSON: "{}"}
	} else {
		if title != "" {
			row.Title = title
		}
		row.UpdatedAt = now
	}
	s.data.Sessions[id] = row
	return row, s.flushLocked()
}

// ListSessions returns sessions newest-first.
func (s *Store) ListSessions() []SessionRow {
	s.mu.RLock()
	defer s.mu.RUnlock()
	out := make([]SessionRow, 0, len(s.data.Sessions))
	for _, r := range s.data.Sessions {
		out = append(out, r)
	}
	sort.Slice(out, func(i, j int) bool { return out[i].UpdatedAt > out[j].UpdatedAt })
	return out
}

// DeleteSession removes a session and its messages/tool events.
func (s *Store) DeleteSession(id string) error {
	s.mu.Lock()
	defer s.mu.Unlock()
	delete(s.data.Sessions, id)
	for mid, m := range s.data.Messages {
		if m.SessionID == id {
			delete(s.data.Messages, mid)
		}
	}
	for tid, t := range s.data.ToolEvents {
		if t.SessionID == id {
			delete(s.data.ToolEvents, tid)
		}
	}
	return s.flushLocked()
}

// AppendMessage adds a message to a session.
func (s *Store) AppendMessage(sessionID, role, content, toolName string) (MessageRow, error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	seq := 0
	for _, m := range s.data.Messages {
		if m.SessionID == sessionID && m.Seq >= seq {
			seq = m.Seq + 1
		}
	}
	row := MessageRow{
		ID: uuid.NewString(), SessionID: sessionID, Role: role, Content: content,
		ToolName: toolName, CreatedAt: nowRFC(), Seq: seq,
	}
	s.data.Messages[row.ID] = row
	if sess, ok := s.data.Sessions[sessionID]; ok {
		sess.UpdatedAt = row.CreatedAt
		if sess.Title == "" && role == "user" {
			t := content
			if len(t) > 48 {
				t = t[:48]
			}
			sess.Title = t
		}
		s.data.Sessions[sessionID] = sess
	}
	return row, s.flushLocked()
}

// ListMessages returns messages for a session in order.
func (s *Store) ListMessages(sessionID string) []MessageRow {
	s.mu.RLock()
	defer s.mu.RUnlock()
	var out []MessageRow
	for _, m := range s.data.Messages {
		if m.SessionID == sessionID {
			out = append(out, m)
		}
	}
	sort.Slice(out, func(i, j int) bool { return out[i].Seq < out[j].Seq })
	return out
}

// AddToolEvent records a tool call/result.
func (s *Store) AddToolEvent(sessionID, name, argsJSON, resultJSON, errStr string) (ToolEventRow, error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	row := ToolEventRow{
		ID: uuid.NewString(), SessionID: sessionID, Name: name,
		ArgsJSON: argsJSON, ResultJSON: resultJSON, Error: errStr, CreatedAt: nowRFC(),
	}
	s.data.ToolEvents[row.ID] = row
	return row, s.flushLocked()
}

// AddMemoryNote stores a long-term note.
func (s *Store) AddMemoryNote(kind, content, tags string) (MemoryNoteRow, error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	now := nowRFC()
	row := MemoryNoteRow{ID: uuid.NewString(), Kind: kind, Content: content, Tags: tags, CreatedAt: now, UpdatedAt: now}
	s.data.MemoryNotes[row.ID] = row
	return row, s.flushLocked()
}

// ListMemoryNotes returns all notes newest-first.
func (s *Store) ListMemoryNotes() []MemoryNoteRow {
	s.mu.RLock()
	defer s.mu.RUnlock()
	out := make([]MemoryNoteRow, 0, len(s.data.MemoryNotes))
	for _, r := range s.data.MemoryNotes {
		out = append(out, r)
	}
	sort.Slice(out, func(i, j int) bool { return out[i].UpdatedAt > out[j].UpdatedAt })
	return out
}

// UpsertKnownHost records SSH host key metadata.
func (s *Store) UpsertKnownHost(host, keyType, fingerprint, rawLine string) error {
	s.mu.Lock()
	defer s.mu.Unlock()
	now := nowRFC()
	row, ok := s.data.KnownHostsMeta[host]
	if !ok {
		row = KnownHostRow{Host: host, FirstSeen: now}
	}
	row.KeyType = keyType
	row.Fingerprint = fingerprint
	row.RawLine = rawLine
	row.LastSeen = now
	s.data.KnownHostsMeta[host] = row
	return s.flushLocked()
}

// Stats returns simple counts for status().
func (s *Store) Stats() map[string]int {
	s.mu.RLock()
	defer s.mu.RUnlock()
	kvn := 0
	for _, m := range s.data.KV {
		kvn += len(m)
	}
	return map[string]int{
		"sessions":          len(s.data.Sessions),
		"messages":          len(s.data.Messages),
		"tool_events":       len(s.data.ToolEvents),
		"memory_notes":      len(s.data.MemoryNotes),
		"known_hosts_meta":  len(s.data.KnownHostsMeta),
		"kv":                kvn,
	}
}

// ReplaceLastMessage replaces the last message of a given role in a session, or appends.
func (s *Store) ReplaceLastMessage(sessionID, role, content, toolName string) (MessageRow, error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	var lastID string
	lastSeq := -1
	for id, m := range s.data.Messages {
		if m.SessionID == sessionID && m.Role == role && m.Seq >= lastSeq {
			lastSeq = m.Seq
			lastID = id
		}
	}
	now := nowRFC()
	if lastID != "" {
		row := s.data.Messages[lastID]
		row.Content = content
		row.ToolName = toolName
		row.CreatedAt = now
		s.data.Messages[lastID] = row
		return row, s.flushLocked()
	}
	seq := 0
	for _, m := range s.data.Messages {
		if m.SessionID == sessionID && m.Seq >= seq {
			seq = m.Seq + 1
		}
	}
	row := MessageRow{
		ID: uuid.NewString(), SessionID: sessionID, Role: role, Content: content,
		ToolName: toolName, CreatedAt: now, Seq: seq,
	}
	s.data.Messages[row.ID] = row
	return row, s.flushLocked()
}
