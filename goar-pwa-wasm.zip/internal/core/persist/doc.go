// Package persist provides durable agent memory under AGENT_HOME.
//
// Under native builds the store can use modernc.org/sqlite (see store_native.go).
// Under GOOS=js the default engine is a pure-Go relational store with the same
// schema, serialized to AGENT_HOME/persist/goar-memory.db.json and mirrored to
// OPFS (and optionally Puter FS) by the WASM app. A sql.js bridge is scaffolded
// for embedders that load sql.js; the Go API stays identical.
//
// Tables: kv, sessions, messages, tool_events, memory_notes, known_hosts_meta.
package persist
