package persist

import (
	"os"
	"path/filepath"
	"testing"
)

func TestStoreRoundTrip(t *testing.T) {
	dir := t.TempDir()
	_ = os.Setenv("AGENT_HOME", dir)
	path := filepath.Join(dir, "persist", "t.json")
	s, err := Open(path)
	if err != nil {
		t.Fatal(err)
	}
	if _, err := s.UpsertSession("s1", "hello"); err != nil {
		t.Fatal(err)
	}
	if _, err := s.AppendMessage("s1", "user", "hi", ""); err != nil {
		t.Fatal(err)
	}
	if err := s.SetKV("cfg", "k", "v"); err != nil {
		t.Fatal(err)
	}
	if _, err := s.AddMemoryNote("note", "remember this", "tag"); err != nil {
		t.Fatal(err)
	}
	_ = s.Flush()

	s2, err := Open(path)
	if err != nil {
		t.Fatal(err)
	}
	msgs := s2.ListMessages("s1")
	if len(msgs) != 1 || msgs[0].Content != "hi" {
		t.Fatalf("msgs=%v", msgs)
	}
	v, ok := s2.GetKV("cfg", "k")
	if !ok || v != "v" {
		t.Fatalf("kv=%v %v", v, ok)
	}
	st := s2.Stats()
	if st["sessions"] != 1 || st["memory_notes"] != 1 {
		t.Fatalf("stats=%v", st)
	}
}
