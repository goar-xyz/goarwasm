package core

import (
	"bufio"
	"fmt"
	"os"
	"strings"

	"github.com/goarxyz/goar/internal/core/paths"
	"github.com/goarxyz/goar/internal/core/proxy"
)

// SupportedProxyVars documents proxy-related env keys (Python SUPPORTED_PROXY_VARS).
var SupportedProxyVars = map[string]string{
	"HTTP_PROXY":    "Proxy URL for HTTP requests",
	"HTTPS_PROXY":   "Proxy URL for HTTPS requests",
	"ALL_PROXY":     "Proxy URL for all requests (fallback)",
	"NO_PROXY":      "Comma-separated list of hosts to bypass proxy",
	"SSL_CERT_FILE": "Path to custom SSL certificate file",
	"SSL_CERT_DIR":  "Path to directory containing SSL certificates",
}

// ProxySetupError is raised for invalid proxy setup commands.
type ProxySetupError struct{ Msg string }

func (e ProxySetupError) Error() string { return e.Msg }

// GetCurrentProxySettings reads proxy vars from ~/.agent/.env (Python get_current_proxy_settings).
func GetCurrentProxySettings() map[string]*string {
	out := map[string]*string{}
	for k := range SupportedProxyVars {
		out[k] = nil
	}
	path := paths.EnvFile()
	f, err := os.Open(path)
	if err != nil {
		return out
	}
	defer f.Close()
	vals := map[string]string{}
	sc := bufio.NewScanner(f)
	for sc.Scan() {
		line := strings.TrimSpace(sc.Text())
		if line == "" || strings.HasPrefix(line, "#") || !strings.Contains(line, "=") {
			continue
		}
		k, v, _ := strings.Cut(line, "=")
		k = strings.TrimSpace(k)
		v = strings.Trim(strings.TrimSpace(v), `"'`)
		vals[k] = v
	}
	for k := range SupportedProxyVars {
		if v, ok := vals[k]; ok {
			vv := v
			out[k] = &vv
		}
	}
	return out
}

// SetProxyVar writes a proxy env var into ~/.agent/.env (Python set_proxy_var).
func SetProxyVar(key, value string) error {
	key = strings.ToUpper(key)
	if _, ok := SupportedProxyVars[key]; !ok {
		keys := make([]string, 0, len(SupportedProxyVars))
		for k := range SupportedProxyVars {
			keys = append(keys, k)
		}
		return ProxySetupError{Msg: fmt.Sprintf("Unknown key '%s'. Supported: %s", key, strings.Join(keys, ", "))}
	}
	_ = paths.EnsureHome()
	return upsertEnvFile(paths.EnvFile(), key, value, false)
}

// UnsetProxyVar removes a proxy env var from ~/.agent/.env (Python unset_proxy_var).
func UnsetProxyVar(key string) error {
	key = strings.ToUpper(key)
	if _, ok := SupportedProxyVars[key]; !ok {
		keys := make([]string, 0, len(SupportedProxyVars))
		for k := range SupportedProxyVars {
			keys = append(keys, k)
		}
		return ProxySetupError{Msg: fmt.Sprintf("Unknown key '%s'. Supported: %s", key, strings.Join(keys, ", "))}
	}
	if _, err := os.Stat(paths.EnvFile()); err != nil {
		return nil
	}
	return upsertEnvFile(paths.EnvFile(), key, "", true)
}

// ParseProxyCommand parses "KEY [value]" (Python parse_proxy_command).
func ParseProxyCommand(args string) (key string, value *string, err error) {
	args = strings.TrimSpace(args)
	if args == "" {
		return "", nil, ProxySetupError{Msg: "No key provided"}
	}
	parts := strings.SplitN(args, " ", 2)
	key = strings.ToUpper(parts[0])
	if len(parts) > 1 {
		v := strings.TrimSpace(parts[1])
		value = &v
	}
	return key, value, nil
}

func upsertEnvFile(path, key, value string, unset bool) error {
	lines := []string{}
	if b, err := os.ReadFile(path); err == nil {
		lines = strings.Split(string(b), "\n")
	}
	found := false
	out := make([]string, 0, len(lines)+1)
	prefix := key + "="
	for _, line := range lines {
		trim := strings.TrimSpace(line)
		if strings.HasPrefix(trim, prefix) || strings.HasPrefix(strings.ToUpper(trim), prefix) {
			found = true
			if unset {
				continue
			}
			out = append(out, key+"="+value)
			continue
		}
		if line == "" && len(out) == 0 {
			continue
		}
		out = append(out, line)
	}
	if !found && !unset {
		out = append(out, key+"="+value)
	}
	// Trim trailing empties
	for len(out) > 0 && out[len(out)-1] == "" {
		out = out[:len(out)-1]
	}
	content := strings.Join(out, "\n")
	if content != "" {
		content += "\n"
	}
	return os.WriteFile(path, []byte(content), 0o644)
}

// SetupProxy configures process proxy from user input values (compat).
func SetupProxy(httpProxy, httpsProxy, noProxy string) *proxy.Manager {
	m := proxy.NewManager()
	m.Configure(httpProxy, httpsProxy, noProxy)
	if httpProxy != "" {
		_ = SetProxyVar("HTTP_PROXY", httpProxy)
	}
	if httpsProxy != "" {
		_ = SetProxyVar("HTTPS_PROXY", httpsProxy)
	}
	if noProxy != "" {
		_ = SetProxyVar("NO_PROXY", noProxy)
	}
	return m
}
