// Package prompts loads system and utility prompt markdown files.
package prompts
