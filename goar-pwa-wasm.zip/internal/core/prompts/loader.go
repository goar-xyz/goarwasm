package prompts

import (
	"embed"
	"fmt"
	"github.com/goarxyz/goar/internal/core/paths"
	"os"
	"path/filepath"
	"strings"
	"time"
)

//go:embed *.md
var embedded embed.FS

// MissingPromptFileError is returned when a prompt cannot be found.
type MissingPromptFileError struct{ ID string }

func (e MissingPromptFileError) Error() string { return "missing prompt file: " + e.ID }

// LoadSystemPrompt loads a system prompt by id (filename without .md).
func LoadSystemPrompt(id string) (string, error) {
	return LoadPrompt(id)
}

// LoadPrompt loads a prompt markdown file from embed or disk override.
func LoadPrompt(id string) (string, error) {
	name := id + ".md"
	// disk override in ~/.agent/prompts
	override := filepath.Join(paths.Home(), "prompts", name)
	if b, err := os.ReadFile(override); err == nil {
		return applyVars(string(b)), nil
	}
	b, err := embedded.ReadFile(name)
	if err != nil {
		return "", MissingPromptFileError{ID: id}
	}
	return applyVars(string(b)), nil
}

func applyVars(s string) string {
	s = strings.ReplaceAll(s, "$current_date", time.Now().Format("2006-01-02"))
	return s
}

// MustLoad loads or returns a fallback.
func MustLoad(id, fallback string) string {
	s, err := LoadPrompt(id)
	if err != nil {
		return fallback
	}
	return s
}

// ListEmbedded returns embedded prompt ids.
func ListEmbedded() []string {
	entries, err := embedded.ReadDir(".")
	if err != nil {
		return nil
	}
	var out []string
	for _, e := range entries {
		if strings.HasSuffix(e.Name(), ".md") {
			out = append(out, strings.TrimSuffix(e.Name(), ".md"))
		}
	}
	return out
}

// EnsureKnown checks id exists.
func EnsureKnown(id string) error {
	_, err := LoadPrompt(id)
	if err != nil {
		return fmt.Errorf("%w", err)
	}
	return nil
}
