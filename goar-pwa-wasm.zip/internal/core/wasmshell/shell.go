package wasmshell

import (
	"bytes"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"regexp"
	"sort"
	"strconv"
	"strings"
	"sync"
)

// Result is the outcome of a shell invocation.
type Result struct {
	Stdout     string
	Stderr     string
	ReturnCode int
}

var (
	cwdMu sync.Mutex
	cwd   = "/tmp/goar-agent-home"
	envMu sync.Mutex
	env   = map[string]string{}
)

func init() {
	if h := strings.TrimSpace(os.Getenv("AGENT_HOME")); h != "" {
		cwd = h
	}
	env["HOME"] = cwd
	env["PWD"] = cwd
	env["AGENT_HOME"] = cwd
	for _, e := range os.Environ() {
		if i := strings.IndexByte(e, '='); i > 0 {
			env[e[:i]] = e[i+1:]
		}
	}
}

// SetCwd updates the shell working directory.
func SetCwd(dir string) error {
	abs := resolvePath(dir)
	st, err := os.Stat(abs)
	if err != nil {
		return err
	}
	if !st.IsDir() {
		return fmt.Errorf("not a directory: %s", abs)
	}
	cwdMu.Lock()
	cwd = abs
	cwdMu.Unlock()
	envMu.Lock()
	env["PWD"] = abs
	envMu.Unlock()
	return nil
}

// GetCwd returns the current working directory.
func GetCwd() string {
	cwdMu.Lock()
	defer cwdMu.Unlock()
	return cwd
}

// UnsupportedError names a command that needs a real OS / SSH.
type UnsupportedError struct {
	Command string
}

func (e *UnsupportedError) Error() string {
	return fmt.Sprintf("command %q → solution: configure SSH (Settings / goar.configure({ssh})) so bash/ssh_exec runs it over Wisp, or use MEMFS builtins (ls/cd/cat/…). Pending packages: AGENT_HOME/pip-pending/", e.Command)
}

var remoteOnly = map[string]bool{
	"apt": true, "apt-get": true, "yum": true, "dnf": true, "apk": true,
	"gcc": true, "g++": true, "clang": true, "make": true, "cmake": true,
	"pip": true, "pip3": true, "python": true, "python3": true, "ipython": true,
	"npm": true, "npx": true, "node": true, "yarn": true, "pnpm": true,
	"docker": true, "podman": true, "kubectl": true,
	"curl": true, "wget": true, "ssh": true, "scp": true, "rsync": true,
	"sudo": true, "su": true, "systemctl": true, "service": true,
}

// NeedsRemote reports whether the command (or any segment) needs a real OS.
func NeedsRemote(command string) (bool, string) {
	for _, seg := range splitChain(command) {
		cmd := strings.TrimSpace(seg.cmd)
		if cmd == "" {
			continue
		}
		// strip redirects for base detection
		toks := tokenize(stripRedirects(cmd))
		if len(toks) == 0 {
			continue
		}
		base := filepath.Base(toks[0])
		if remoteOnly[base] {
			return true, base
		}
	}
	return false, ""
}

type chainSeg struct {
	cmd  string
	op   string // "", "&&", "||", ";"
	pipe bool
}

func splitChain(command string) []chainSeg {
	// Split on && || ; while respecting simple quotes; pipes handled inside RunSegment.
	var segs []chainSeg
	var cur strings.Builder
	inSingle, inDouble := false, false
	runes := []rune(command)
	flush := func(op string) {
		s := strings.TrimSpace(cur.String())
		cur.Reset()
		if s != "" {
			segs = append(segs, chainSeg{cmd: s, op: op})
		}
	}
	for i := 0; i < len(runes); i++ {
		c := runes[i]
		if c == '\'' && !inDouble {
			inSingle = !inSingle
			cur.WriteRune(c)
			continue
		}
		if c == '"' && !inSingle {
			inDouble = !inDouble
			cur.WriteRune(c)
			continue
		}
		if !inSingle && !inDouble {
			if c == '&' && i+1 < len(runes) && runes[i+1] == '&' {
				flush("&&")
				i++
				continue
			}
			if c == '|' && i+1 < len(runes) && runes[i+1] == '|' {
				flush("||")
				i++
				continue
			}
			if c == ';' {
				flush(";")
				continue
			}
		}
		cur.WriteRune(c)
	}
	flush("")
	return segs
}

// Run executes a shell command string against MEMFS.
func Run(command string) Result {
	command = strings.TrimSpace(command)
	if command == "" {
		return Result{}
	}
	segs := splitChain(command)
	var stdout, stderr bytes.Buffer
	rc := 0
	for i, seg := range segs {
		if i > 0 {
			prev := segs[i-1]
			switch prev.op {
			case "&&":
				if rc != 0 {
					continue
				}
			case "||":
				if rc == 0 {
					continue
				}
			}
		}
		r := runPipeline(seg.cmd)
		stdout.WriteString(r.Stdout)
		stderr.WriteString(r.Stderr)
		rc = r.ReturnCode
		if r.ReturnCode == 127 && strings.Contains(r.Stderr, "requires a real OS") {
			return r
		}
	}
	return Result{Stdout: stdout.String(), Stderr: stderr.String(), ReturnCode: rc}
}

func runPipeline(cmd string) Result {
	parts := splitPipe(cmd)
	if len(parts) == 0 {
		return Result{}
	}
	var input string
	var last Result
	for i, p := range parts {
		last = runOne(strings.TrimSpace(p), input, i == len(parts)-1)
		if last.ReturnCode != 0 && last.ReturnCode == 127 {
			return last
		}
		input = last.Stdout
		if i < len(parts)-1 {
			// intermediate: stdout becomes next stdin; clear displayed stdout
			last.Stdout = ""
		}
	}
	return last
}

func splitPipe(cmd string) []string {
	var parts []string
	var cur strings.Builder
	inSingle, inDouble := false, false
	runes := []rune(cmd)
	for i := 0; i < len(runes); i++ {
		c := runes[i]
		if c == '\'' && !inDouble {
			inSingle = !inSingle
			cur.WriteRune(c)
			continue
		}
		if c == '"' && !inSingle {
			inDouble = !inDouble
			cur.WriteRune(c)
			continue
		}
		if !inSingle && !inDouble && c == '|' {
			if i+1 < len(runes) && runes[i+1] == '|' {
				cur.WriteRune(c)
				continue
			}
			parts = append(parts, cur.String())
			cur.Reset()
			continue
		}
		cur.WriteRune(c)
	}
	parts = append(parts, cur.String())
	return parts
}

var redirRE = regexp.MustCompile(`(>>?)(\s*)(\S+)`)

func stripRedirects(cmd string) string {
	return strings.TrimSpace(redirRE.ReplaceAllString(cmd, ""))
}

func parseRedirects(cmd string) (clean string, overwrite, appendTo string) {
	clean = cmd
	for {
		m := redirRE.FindStringSubmatchIndex(clean)
		if m == nil {
			break
		}
		op := clean[m[2]:m[3]]
		path := strings.TrimSpace(clean[m[6]:m[7]])
		path = strings.Trim(path, `"'`)
		if op == ">>" {
			appendTo = path
		} else {
			overwrite = path
		}
		clean = strings.TrimSpace(clean[:m[0]] + clean[m[1]:])
	}
	return clean, overwrite, appendTo
}

func runOne(cmd, stdin string, captureOut bool) Result {
	clean, ow, ap := parseRedirects(cmd)
	toks := tokenize(clean)
	if len(toks) == 0 {
		return Result{}
	}
	base := filepath.Base(toks[0])
	if remoteOnly[base] {
		return Result{Stderr: (&UnsupportedError{Command: base}).Error() + "\n", ReturnCode: 127}
	}

	var out bytes.Buffer
	var errb bytes.Buffer
	rc := 0

	switch base {
	case "cd":
		target := homeDir()
		if len(toks) > 1 {
			target = toks[1]
		}
		if err := SetCwd(target); err != nil {
			errb.WriteString(err.Error() + "\n")
			rc = 1
		}
	case "pwd":
		out.WriteString(GetCwd() + "\n")
	case "echo":
		args := expandArgs(toks[1:])
		out.WriteString(strings.Join(args, " ") + "\n")
	case "env":
		envMu.Lock()
		keys := make([]string, 0, len(env))
		for k := range env {
			keys = append(keys, k)
		}
		sort.Strings(keys)
		for _, k := range keys {
			out.WriteString(k + "=" + env[k] + "\n")
		}
		envMu.Unlock()
	case "export":
		for _, a := range toks[1:] {
			if i := strings.IndexByte(a, '='); i > 0 {
				k, v := a[:i], a[i+1:]
				envMu.Lock()
				env[k] = expandVar(v)
				envMu.Unlock()
				_ = os.Setenv(k, expandVar(v))
			}
		}
	case "which":
		for _, a := range toks[1:] {
			if isBuiltin(a) {
				out.WriteString("builtin:" + a + "\n")
			} else if remoteOnly[a] {
				out.WriteString("remote:" + a + "\n")
			} else {
				errb.WriteString("which: " + a + ": not found\n")
				rc = 1
			}
		}
	case "ls":
		rc = cmdLS(toks[1:], &out, &errb)
	case "cat":
		if stdin != "" && len(toks) == 1 {
			out.WriteString(stdin)
		} else {
			rc = cmdCat(toks[1:], &out, &errb)
		}
	case "mkdir":
		rc = cmdMkdir(toks[1:], &errb)
	case "rm":
		rc = cmdRm(toks[1:], &errb)
	case "cp":
		rc = cmdCp(toks[1:], &errb)
	case "mv":
		rc = cmdMv(toks[1:], &errb)
	case "touch":
		rc = cmdTouch(toks[1:], &errb)
	case "head":
		rc = cmdHeadTail(toks[1:], stdin, true, &out, &errb)
	case "tail":
		rc = cmdHeadTail(toks[1:], stdin, false, &out, &errb)
	case "wc":
		rc = cmdWC(toks[1:], stdin, &out, &errb)
	case "true":
		rc = 0
	case "false":
		rc = 1
	case "test", "[":
		rc = cmdTest(toks)
	default:
		return Result{Stderr: (&UnsupportedError{Command: base}).Error() + "\n", ReturnCode: 127}
	}

	content := out.String()
	if ow != "" || ap != "" {
		path := resolvePath(firstNonEmpty(ow, ap))
		_ = os.MkdirAll(filepath.Dir(path), 0o755)
		if ap != "" {
			f, err := os.OpenFile(path, os.O_CREATE|os.O_WRONLY|os.O_APPEND, 0o644)
			if err != nil {
				errb.WriteString(err.Error() + "\n")
				rc = 1
			} else {
				_, _ = io.WriteString(f, content)
				_ = f.Close()
			}
		} else {
			if err := os.WriteFile(path, []byte(content), 0o644); err != nil {
				errb.WriteString(err.Error() + "\n")
				rc = 1
			}
		}
		if !captureOut {
			content = ""
		} else {
			// redirects consume stdout
			content = ""
		}
	}
	return Result{Stdout: content, Stderr: errb.String(), ReturnCode: rc}
}

func isBuiltin(name string) bool {
	switch name {
	case "ls", "cd", "pwd", "cat", "echo", "mkdir", "rm", "cp", "mv", "touch",
		"head", "tail", "wc", "env", "export", "which", "true", "false", "test", "[":
		return true
	}
	return false
}

func homeDir() string {
	if h := strings.TrimSpace(os.Getenv("AGENT_HOME")); h != "" {
		return h
	}
	return "/tmp/goar-agent-home"
}

func resolvePath(p string) string {
	p = expandVar(p)
	if p == "" {
		return GetCwd()
	}
	if strings.HasPrefix(p, "~/") {
		p = filepath.Join(homeDir(), p[2:])
	} else if p == "~" {
		p = homeDir()
	}
	if filepath.IsAbs(p) {
		return filepath.Clean(p)
	}
	return filepath.Clean(filepath.Join(GetCwd(), p))
}

func expandVar(s string) string {
	return os.Expand(s, func(k string) string {
		envMu.Lock()
		defer envMu.Unlock()
		if v, ok := env[k]; ok {
			return v
		}
		return os.Getenv(k)
	})
}

func expandArgs(args []string) []string {
	out := make([]string, len(args))
	for i, a := range args {
		out[i] = expandVar(a)
	}
	return out
}

func tokenize(s string) []string {
	var toks []string
	var cur strings.Builder
	inSingle, inDouble := false, false
	flush := func() {
		if cur.Len() > 0 || (len(toks) > 0 && false) {
			toks = append(toks, cur.String())
			cur.Reset()
		}
	}
	for _, c := range s {
		switch {
		case c == '\'' && !inDouble:
			inSingle = !inSingle
		case c == '"' && !inSingle:
			inDouble = !inDouble
		case (c == ' ' || c == '\t') && !inSingle && !inDouble:
			if cur.Len() > 0 {
				toks = append(toks, cur.String())
				cur.Reset()
			}
		default:
			cur.WriteRune(c)
		}
	}
	if cur.Len() > 0 {
		toks = append(toks, cur.String())
	}
	_ = flush
	return toks
}

func cmdLS(args []string, out, errb *bytes.Buffer) int {
	long := false
	var paths []string
	for _, a := range args {
		if strings.HasPrefix(a, "-") {
			if strings.Contains(a, "l") {
				long = true
			}
			continue
		}
		paths = append(paths, a)
	}
	if len(paths) == 0 {
		paths = []string{"."}
	}
	rc := 0
	for _, p := range paths {
		abs := resolvePath(p)
		st, err := os.Stat(abs)
		if err != nil {
			errb.WriteString(err.Error() + "\n")
			rc = 1
			continue
		}
		if !st.IsDir() {
			if long {
				out.WriteString(fmt.Sprintf("%s %8d %s\n", st.Mode(), st.Size(), filepath.Base(abs)))
			} else {
				out.WriteString(filepath.Base(abs) + "\n")
			}
			continue
		}
		ents, err := os.ReadDir(abs)
		if err != nil {
			errb.WriteString(err.Error() + "\n")
			rc = 1
			continue
		}
		for _, e := range ents {
			name := e.Name()
			if long {
				info, _ := e.Info()
				sz := int64(0)
				mode := os.FileMode(0)
				if info != nil {
					sz = info.Size()
					mode = info.Mode()
				}
				if e.IsDir() {
					name += "/"
				}
				out.WriteString(fmt.Sprintf("%s %8d %s\n", mode, sz, name))
			} else {
				if e.IsDir() {
					name += "/"
				}
				out.WriteString(name + "\n")
			}
		}
	}
	return rc
}

func cmdCat(args []string, out, errb *bytes.Buffer) int {
	if len(args) == 0 {
		return 0
	}
	rc := 0
	for _, a := range args {
		b, err := os.ReadFile(resolvePath(a))
		if err != nil {
			errb.WriteString(err.Error() + "\n")
			rc = 1
			continue
		}
		out.Write(b)
	}
	return rc
}

func cmdMkdir(args []string, errb *bytes.Buffer) int {
	parents := false
	var paths []string
	for _, a := range args {
		if a == "-p" {
			parents = true
			continue
		}
		paths = append(paths, a)
	}
	rc := 0
	for _, p := range paths {
		abs := resolvePath(p)
		var err error
		if parents {
			err = os.MkdirAll(abs, 0o755)
		} else {
			err = os.Mkdir(abs, 0o755)
		}
		if err != nil {
			errb.WriteString(err.Error() + "\n")
			rc = 1
		}
	}
	return rc
}

func cmdRm(args []string, errb *bytes.Buffer) int {
	recursive := false
	force := false
	var paths []string
	for _, a := range args {
		if strings.HasPrefix(a, "-") {
			if strings.Contains(a, "r") || strings.Contains(a, "R") {
				recursive = true
			}
			if strings.Contains(a, "f") {
				force = true
			}
			continue
		}
		paths = append(paths, a)
	}
	rc := 0
	for _, p := range paths {
		abs := resolvePath(p)
		var err error
		if recursive {
			err = os.RemoveAll(abs)
		} else {
			err = os.Remove(abs)
		}
		if err != nil && !force {
			errb.WriteString(err.Error() + "\n")
			rc = 1
		}
	}
	return rc
}

func cmdCp(args []string, errb *bytes.Buffer) int {
	if len(args) < 2 {
		errb.WriteString("cp: missing operand\n")
		return 1
	}
	src, dst := resolvePath(args[0]), resolvePath(args[1])
	b, err := os.ReadFile(src)
	if err != nil {
		errb.WriteString(err.Error() + "\n")
		return 1
	}
	st, err := os.Stat(dst)
	if err == nil && st.IsDir() {
		dst = filepath.Join(dst, filepath.Base(src))
	}
	_ = os.MkdirAll(filepath.Dir(dst), 0o755)
	if err := os.WriteFile(dst, b, 0o644); err != nil {
		errb.WriteString(err.Error() + "\n")
		return 1
	}
	return 0
}

func cmdMv(args []string, errb *bytes.Buffer) int {
	if len(args) < 2 {
		errb.WriteString("mv: missing operand\n")
		return 1
	}
	src, dst := resolvePath(args[0]), resolvePath(args[1])
	st, err := os.Stat(dst)
	if err == nil && st.IsDir() {
		dst = filepath.Join(dst, filepath.Base(src))
	}
	if err := os.Rename(src, dst); err != nil {
		// fallback copy+rm for cross-dir on some FS
		b, rerr := os.ReadFile(src)
		if rerr != nil {
			errb.WriteString(err.Error() + "\n")
			return 1
		}
		_ = os.MkdirAll(filepath.Dir(dst), 0o755)
		if werr := os.WriteFile(dst, b, 0o644); werr != nil {
			errb.WriteString(werr.Error() + "\n")
			return 1
		}
		_ = os.Remove(src)
	}
	return 0
}

func cmdTouch(args []string, errb *bytes.Buffer) int {
	rc := 0
	for _, a := range args {
		abs := resolvePath(a)
		_ = os.MkdirAll(filepath.Dir(abs), 0o755)
		f, err := os.OpenFile(abs, os.O_CREATE|os.O_RDWR, 0o644)
		if err != nil {
			errb.WriteString(err.Error() + "\n")
			rc = 1
			continue
		}
		_ = f.Close()
	}
	return rc
}

func cmdHeadTail(args []string, stdin string, head bool, out, errb *bytes.Buffer) int {
	n := 10
	var files []string
	for i := 0; i < len(args); i++ {
		a := args[i]
		if a == "-n" && i+1 < len(args) {
			n, _ = strconv.Atoi(args[i+1])
			i++
			continue
		}
		if strings.HasPrefix(a, "-") && len(a) > 1 {
			if v, err := strconv.Atoi(a[1:]); err == nil {
				n = v
				continue
			}
		}
		files = append(files, a)
	}
	readLines := func(content string) {
		lines := strings.Split(strings.ReplaceAll(content, "\r\n", "\n"), "\n")
		if len(lines) > 0 && lines[len(lines)-1] == "" {
			lines = lines[:len(lines)-1]
		}
		if n < 0 {
			n = 0
		}
		var sel []string
		if head {
			if n > len(lines) {
				n = len(lines)
			}
			sel = lines[:n]
		} else {
			if n > len(lines) {
				n = len(lines)
			}
			sel = lines[len(lines)-n:]
		}
		out.WriteString(strings.Join(sel, "\n"))
		if len(sel) > 0 {
			out.WriteByte('\n')
		}
	}
	if len(files) == 0 {
		readLines(stdin)
		return 0
	}
	rc := 0
	for _, f := range files {
		b, err := os.ReadFile(resolvePath(f))
		if err != nil {
			errb.WriteString(err.Error() + "\n")
			rc = 1
			continue
		}
		readLines(string(b))
	}
	return rc
}

func cmdWC(args []string, stdin string, out, errb *bytes.Buffer) int {
	var files []string
	for _, a := range args {
		if strings.HasPrefix(a, "-") {
			continue
		}
		files = append(files, a)
	}
	count := func(s string) (lines, words, bytesN int) {
		bytesN = len(s)
		lines = strings.Count(s, "\n")
		words = len(strings.Fields(s))
		return
	}
	if len(files) == 0 {
		l, w, b := count(stdin)
		out.WriteString(fmt.Sprintf("%d %d %d\n", l, w, b))
		return 0
	}
	rc := 0
	for _, f := range files {
		data, err := os.ReadFile(resolvePath(f))
		if err != nil {
			errb.WriteString(err.Error() + "\n")
			rc = 1
			continue
		}
		l, w, b := count(string(data))
		out.WriteString(fmt.Sprintf("%d %d %d %s\n", l, w, b, f))
	}
	return rc
}

func cmdTest(toks []string) int {
	// minimal: [ -e path ] / [ -d path ] / [ -f path ]
	args := toks
	if len(args) > 0 && args[0] == "[" {
		args = args[1:]
		if len(args) > 0 && args[len(args)-1] == "]" {
			args = args[:len(args)-1]
		}
	} else if len(args) > 0 && args[0] == "test" {
		args = args[1:]
	}
	if len(args) == 2 {
		op, p := args[0], resolvePath(args[1])
		st, err := os.Stat(p)
		switch op {
		case "-e":
			if err == nil {
				return 0
			}
			return 1
		case "-d":
			if err == nil && st.IsDir() {
				return 0
			}
			return 1
		case "-f":
			if err == nil && !st.IsDir() {
				return 0
			}
			return 1
		}
	}
	return 1
}

func firstNonEmpty(a, b string) string {
	if a != "" {
		return a
	}
	return b
}
