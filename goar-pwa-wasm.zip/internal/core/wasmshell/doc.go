// Package wasmshell implements a small in-process POSIX-ish shell over the Go
// filesystem (MEMFS under js/wasm). Used by bash/hooks when no local OS shell
// or SSH remote is available.
package wasmshell
