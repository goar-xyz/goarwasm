package wasmshell

import (
	"os"
	"path/filepath"
	"testing"
)

func TestBasicCommands(t *testing.T) {
	dir := t.TempDir()
	_ = os.Setenv("AGENT_HOME", dir)
	cwd = dir
	env["HOME"] = dir
	env["PWD"] = dir
	env["AGENT_HOME"] = dir

	r := Run("mkdir -p a/b && echo hello > a/b/f.txt && cat a/b/f.txt && ls a/b && pwd")
	if r.ReturnCode != 0 {
		t.Fatalf("rc=%d stderr=%s stdout=%s", r.ReturnCode, r.Stderr, r.Stdout)
	}
	if !contains(r.Stdout, "hello") {
		t.Fatalf("stdout=%q", r.Stdout)
	}
	b, err := os.ReadFile(filepath.Join(dir, "a/b/f.txt"))
	if err != nil || string(b) != "hello\n" {
		t.Fatalf("file=%q err=%v", b, err)
	}
}

func TestUnsupported(t *testing.T) {
	need, name := NeedsRemote("apt install foo")
	if !need || name != "apt" {
		t.Fatalf("need=%v name=%s", need, name)
	}
	r := Run("python3 -c 'print(1)'")
	if r.ReturnCode != 127 {
		t.Fatalf("expected 127 got %d %s", r.ReturnCode, r.Stderr)
	}
}

func contains(s, sub string) bool {
	return len(s) >= len(sub) && (s == sub || len(sub) == 0 || (len(s) > 0 && (stringIndex(s, sub) >= 0)))
}
func stringIndex(s, sub string) int {
	for i := 0; i+len(sub) <= len(s); i++ {
		if s[i:i+len(sub)] == sub {
			return i
		}
	}
	return -1
}
