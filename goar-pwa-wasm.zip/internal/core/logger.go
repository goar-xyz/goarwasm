package core

import (
	"fmt"
	"io"
	"log"
	"os"
	"path/filepath"
	"strings"
	"sync"

	"github.com/goarxyz/goar/internal/core/paths"
)

var (
	loggerOnce sync.Once
	stdLogger  *log.Logger
	logLevel   = "WARNING"
)

// Logger returns the process logger writing to $AGENT_HOME/logs/agent.log.
func Logger() *log.Logger {
	loggerOnce.Do(func() {
		_ = paths.EnsureHome()
		level := strings.ToUpper(os.Getenv("LOG_LEVEL"))
		if level != "" {
			logLevel = level
		}
		f, err := os.OpenFile(paths.LogFile(), os.O_CREATE|os.O_APPEND|os.O_WRONLY, 0o644)
		if err != nil {
			stdLogger = log.New(os.Stderr, "goar ", log.LstdFlags|log.Lmsgprefix)
			return
		}
		stdLogger = log.New(io.MultiWriter(f), "goar ", log.LstdFlags|log.Lmsgprefix)
	})
	return stdLogger
}

func levelOK(min string) bool {
	order := map[string]int{"DEBUG": 10, "INFO": 20, "WARNING": 30, "ERROR": 40, "CRITICAL": 50}
	return order[strings.ToUpper(logLevel)] <= order[min]
}

// LogDebugf logs at DEBUG.
func LogDebugf(format string, args ...any) {
	if levelOK("DEBUG") {
		Logger().Output(2, fmt.Sprintf("DEBUG "+format, args...))
	}
}

// LogInfof logs at INFO.
func LogInfof(format string, args ...any) {
	if levelOK("INFO") {
		Logger().Output(2, fmt.Sprintf("INFO "+format, args...))
	}
}

// LogWarningf logs at WARNING.
func LogWarningf(format string, args ...any) {
	if levelOK("WARNING") {
		Logger().Output(2, fmt.Sprintf("WARNING "+format, args...))
	}
}

// LogErrorf logs at ERROR.
func LogErrorf(format string, args ...any) {
	if levelOK("ERROR") {
		Logger().Output(2, fmt.Sprintf("ERROR "+format, args...))
	}
}

// EnsureLogDir creates the log directory.
func EnsureLogDir() error {
	return os.MkdirAll(filepath.Dir(paths.LogFile()), 0o755)
}
