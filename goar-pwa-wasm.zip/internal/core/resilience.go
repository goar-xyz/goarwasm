package core

import (
	"encoding/json"
	"os"
	"sync"
	"time"
)

// CircuitBreaker opens after consecutive failures.
type CircuitBreaker struct {
	mu               sync.Mutex
	FailureThreshold int
	RecoveryTimeout  time.Duration
	failures         int
	openedAt         time.Time
	open             bool
}

func NewCircuitBreaker(threshold int, recovery time.Duration) *CircuitBreaker {
	return &CircuitBreaker{FailureThreshold: threshold, RecoveryTimeout: recovery}
}

func (c *CircuitBreaker) Allow() bool {
	c.mu.Lock()
	defer c.mu.Unlock()
	if !c.open {
		return true
	}
	if time.Since(c.openedAt) >= c.RecoveryTimeout {
		c.open = false
		c.failures = 0
		return true
	}
	return false
}

func (c *CircuitBreaker) Success() {
	c.mu.Lock()
	defer c.mu.Unlock()
	c.failures = 0
	c.open = false
}

func (c *CircuitBreaker) Failure() {
	c.mu.Lock()
	defer c.mu.Unlock()
	c.failures++
	if c.failures >= c.FailureThreshold {
		c.open = true
		c.openedAt = time.Now()
	}
}

// DeadLetterQueue persists failed tool calls.
type DeadLetterQueue struct {
	mu   sync.Mutex
	Path string
	Items []map[string]any
}

func NewDeadLetterQueue(path string) *DeadLetterQueue {
	return &DeadLetterQueue{Path: path}
}

func (d *DeadLetterQueue) Add(item map[string]any) {
	d.mu.Lock()
	defer d.mu.Unlock()
	d.Items = append(d.Items, item)
	if d.Path != "" {
		b, _ := json.MarshalIndent(d.Items, "", "  ")
		_ = os.WriteFile(d.Path, b, 0o644)
	}
}

// ExponentialBackoff computes delay for attempt.
func ExponentialBackoff(attempt int, base, max time.Duration) time.Duration {
	d := base << attempt
	if d > max {
		return max
	}
	return d
}
