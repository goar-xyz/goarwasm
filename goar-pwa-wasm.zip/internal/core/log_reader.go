package core

import (
	"bufio"
	"io"
	"os"
	"strings"
	"sync"
	"time"

	"github.com/goarxyz/goar/internal/core/paths"
)

// LogEntry is a parsed log line (Python LogEntry).
type LogEntry struct {
	Raw        string
	Level      string
	LineNumber int
	Timestamp  string
	Message    string
}

// PaginatedLogs is a page of log entries (Python PaginatedLogs).
type PaginatedLogs struct {
	Entries    []LogEntry
	TotalLines int
	Offset     int
	Limit      int
	HasMore    bool
}

// LogConsumer receives newly appended log entries while watching.
type LogConsumer func(LogEntry)

// LogReader reads and optionally tails agent.log (Python LogReader).
type LogReader struct {
	mu         sync.Mutex
	path       string
	consumer   LogConsumer
	watching   bool
	stopCh     chan struct{}
	doneCh     chan struct{}
	lastOffset int64
	pollEvery  time.Duration
}

// NewLogReader constructs a reader for path (default: paths.LogFile()).
func NewLogReader(path string) *LogReader {
	if path == "" {
		path = paths.LogFile()
	}
	return &LogReader{path: path, pollEvery: 500 * time.Millisecond, stopCh: make(chan struct{}), doneCh: make(chan struct{})}
}

// LogFile returns the watched path.
func (r *LogReader) LogFile() string { return r.path }

// IsWatching reports whether the poll loop is active.
func (r *LogReader) IsWatching() bool {
	r.mu.Lock()
	defer r.mu.Unlock()
	return r.watching
}

// GetLogs returns a page of log entries (newest page via offset from end).
func (r *LogReader) GetLogs(limit, offset int) (PaginatedLogs, error) {
	if limit <= 0 {
		limit = 100
	}
	if offset < 0 {
		offset = 0
	}
	f, err := os.Open(r.path)
	if err != nil {
		return PaginatedLogs{}, err
	}
	defer f.Close()
	var lines []string
	sc := bufio.NewScanner(f)
	sc.Buffer(make([]byte, 0, 64*1024), 1024*1024)
	for sc.Scan() {
		lines = append(lines, sc.Text())
	}
	total := len(lines)
	start := total - offset - limit
	if start < 0 {
		start = 0
	}
	end := total - offset
	if end < 0 {
		end = 0
	}
	if end > total {
		end = total
	}
	page := lines[start:end]
	entries := make([]LogEntry, 0, len(page))
	for i, line := range page {
		if e := r.parseLine(line, start+i+1); e != nil {
			entries = append(entries, *e)
		}
	}
	return PaginatedLogs{
		Entries: entries, TotalLines: total, Offset: offset, Limit: limit,
		HasMore: start > 0,
	}, sc.Err()
}

// ReadLogTail returns the last n lines of agent.log (compat helper).
func ReadLogTail(n int) ([]LogLine, error) {
	r := NewLogReader("")
	page, err := r.GetLogs(n, 0)
	if err != nil {
		return nil, err
	}
	out := make([]LogLine, len(page.Entries))
	for i, e := range page.Entries {
		out[i] = LogLine{Raw: e.Raw, Level: e.Level}
	}
	return out, nil
}

// LogLine is a parsed log entry (compat).
type LogLine struct {
	Raw   string
	Level string
}

func (r *LogReader) readLinesBackward(startPosition int64) ([]string, int64, error) {
	f, err := os.Open(r.path)
	if err != nil {
		return nil, 0, err
	}
	defer f.Close()
	info, err := f.Stat()
	if err != nil {
		return nil, 0, err
	}
	size := info.Size()
	if startPosition < 0 || startPosition > size {
		startPosition = size
	}
	const chunk = 4096
	var data []byte
	pos := startPosition
	for pos > 0 && len(data) < 256*1024 {
		read := chunk
		if int64(read) > pos {
			read = int(pos)
		}
		pos -= int64(read)
		buf := make([]byte, read)
		if _, err := f.ReadAt(buf, pos); err != nil && err != io.EOF {
			return nil, startPosition, err
		}
		data = append(buf, data...)
		if pos == 0 {
			break
		}
	}
	text := string(data)
	parts := strings.Split(text, "\n")
	return parts, startPosition, nil
}

// SetConsumer sets the live-tail consumer.
func (r *LogReader) SetConsumer(c LogConsumer) {
	r.mu.Lock()
	defer r.mu.Unlock()
	r.consumer = c
}

// StartWatching begins polling for new log content.
func (r *LogReader) StartWatching() {
	r.mu.Lock()
	defer r.mu.Unlock()
	if r.watching {
		return
	}
	r.watching = true
	r.stopCh = make(chan struct{})
	r.doneCh = make(chan struct{})
	if st, err := os.Stat(r.path); err == nil {
		r.lastOffset = st.Size()
	}
	go r.pollLogLoop()
}

// StopWatching stops the poll loop.
func (r *LogReader) StopWatching() {
	r.mu.Lock()
	if !r.watching {
		r.mu.Unlock()
		return
	}
	close(r.stopCh)
	r.watching = false
	done := r.doneCh
	r.mu.Unlock()
	<-done
}

// Shutdown stops watching.
func (r *LogReader) Shutdown() { r.StopWatching() }

func (r *LogReader) pollLogLoop() {
	defer close(r.doneCh)
	ticker := time.NewTicker(r.pollEvery)
	defer ticker.Stop()
	for {
		select {
		case <-r.stopCh:
			return
		case <-ticker.C:
			r.processNewContent()
		}
	}
}

func (r *LogReader) processNewContent() {
	r.mu.Lock()
	path := r.path
	offset := r.lastOffset
	consumer := r.consumer
	r.mu.Unlock()
	f, err := os.Open(path)
	if err != nil {
		return
	}
	defer f.Close()
	st, err := f.Stat()
	if err != nil {
		return
	}
	if st.Size() < offset {
		offset = 0
	}
	if st.Size() == offset {
		return
	}
	if _, err := f.Seek(offset, io.SeekStart); err != nil {
		return
	}
	sc := bufio.NewScanner(f)
	lineNo := 0
	var newOffset int64 = offset
	for sc.Scan() {
		line := sc.Text()
		newOffset += int64(len(line) + 1)
		lineNo++
		if e := r.parseLine(line, lineNo); e != nil && consumer != nil {
			consumer(*e)
		}
	}
	r.mu.Lock()
	r.lastOffset = newOffset
	r.mu.Unlock()
}

func (r *LogReader) parseLine(line string, lineNumber int) *LogEntry {
	line = strings.TrimRight(line, "\r")
	if strings.TrimSpace(line) == "" {
		return nil
	}
	level := "INFO"
	for _, cand := range []string{"CRITICAL", "ERROR", "WARNING", "DEBUG", "INFO"} {
		if strings.Contains(line, cand) {
			level = cand
			break
		}
	}
	ts := ""
	msg := line
	// Common format: 2006-01-02 15:04:05 LEVEL message
	parts := strings.SplitN(line, " ", 4)
	if len(parts) >= 3 {
		maybe := parts[0] + " " + parts[1]
		if len(parts[0]) >= 8 && strings.Contains(parts[0], "-") {
			ts = maybe
			if len(parts) >= 4 {
				msg = parts[3]
			} else {
				msg = parts[2]
			}
		}
	}
	return &LogEntry{Raw: line, Level: level, LineNumber: lineNumber, Timestamp: ts, Message: msg}
}
