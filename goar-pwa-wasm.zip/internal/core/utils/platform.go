package utils

import (
	"os"
	"runtime"
)

// IsWindows reports Windows.
func IsWindows() bool { return runtime.GOOS == "windows" }

// IsDarwin reports macOS.
func IsDarwin() bool { return runtime.GOOS == "darwin" }

// IsLinux reports Linux.
func IsLinux() bool { return runtime.GOOS == "linux" }

// ShellExecutable returns $SHELL or a platform default.
func ShellExecutable() string {
	if IsWindows() {
		return ""
	}
	if s := os.Getenv("SHELL"); s != "" {
		return s
	}
	return "/bin/bash"
}

// HomeDir returns the user home directory.
func HomeDir() string {
	h, err := os.UserHomeDir()
	if err != nil {
		return "."
	}
	return h
}
