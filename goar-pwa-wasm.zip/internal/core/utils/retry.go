package utils

import (
	"context"
	"errors"
	"math"
	"net"
	"net/http"
	"time"
)

// RetryConfig controls exponential backoff retries.
type RetryConfig struct {
	MaxRetries     int
	BaseDelay      time.Duration
	MaxDelay       time.Duration
	Retryable      func(error) bool
	OnRetry        func(attempt int, err error, delay time.Duration)
}

// DefaultRetry is a sensible default.
func DefaultRetry() RetryConfig {
	return RetryConfig{MaxRetries: 3, BaseDelay: 500 * time.Millisecond, MaxDelay: 30 * time.Second, Retryable: IsRetryableHTTPError}
}

// IsRetryableHTTPError reports whether err looks transient.
func IsRetryableHTTPError(err error) bool {
	if err == nil {
		return false
	}
	var ne net.Error
	if errors.As(err, &ne) && (ne.Timeout() || ne.Temporary()) {
		return true
	}
	type statuser interface{ StatusCode() int }
	if s, ok := err.(statuser); ok {
		code := s.StatusCode()
		return code == http.StatusTooManyRequests || code == http.StatusBadGateway ||
			code == http.StatusServiceUnavailable || code == http.StatusGatewayTimeout
	}
	msg := err.Error()
	for _, needle := range []string{"timeout", "connection reset", "temporary", "EOF", "429", "502", "503", "504"} {
		if containsFold(msg, needle) {
			return true
		}
	}
	return false
}

func containsFold(s, sub string) bool {
	return len(sub) == 0 || (len(s) >= len(sub) && (indexFold(s, sub) >= 0))
}

func indexFold(s, sub string) int {
	ls, lsub := len(s), len(sub)
	for i := 0; i+lsub <= ls; i++ {
		if equalFoldASCII(s[i:i+lsub], sub) {
			return i
		}
	}
	return -1
}

func equalFoldASCII(a, b string) bool {
	if len(a) != len(b) {
		return false
	}
	for i := 0; i < len(a); i++ {
		ca, cb := a[i], b[i]
		if ca >= 'A' && ca <= 'Z' {
			ca += 'a' - 'A'
		}
		if cb >= 'A' && cb <= 'Z' {
			cb += 'a' - 'A'
		}
		if ca != cb {
			return false
		}
	}
	return true
}

// Do retries fn with exponential backoff until success or max retries.
func (c RetryConfig) Do(ctx context.Context, fn func(context.Context) error) error {
	var err error
	retryable := c.Retryable
	if retryable == nil {
		retryable = func(error) bool { return true }
	}
	for attempt := 0; attempt <= c.MaxRetries; attempt++ {
		if err = fn(ctx); err == nil {
			return nil
		}
		if attempt == c.MaxRetries || !retryable(err) {
			break
		}
		delay := time.Duration(float64(c.BaseDelay) * math.Pow(2, float64(attempt)))
		if delay > c.MaxDelay {
			delay = c.MaxDelay
		}
		if c.OnRetry != nil {
			c.OnRetry(attempt+1, err, delay)
		}
		select {
		case <-ctx.Done():
			return ctx.Err()
		case <-time.After(delay):
		}
	}
	return err
}

// DoValue retries a value-returning function.
func DoValue[T any](ctx context.Context, c RetryConfig, fn func(context.Context) (T, error)) (T, error) {
	var zero T
	var result T
	err := c.Do(ctx, func(ctx context.Context) error {
		var e error
		result, e = fn(ctx)
		return e
	})
	if err != nil {
		return zero, err
	}
	return result, nil
}
