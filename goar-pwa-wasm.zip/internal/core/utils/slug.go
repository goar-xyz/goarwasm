package utils

import (
	"crypto/rand"
	"fmt"
	"math/big"
)

var adjectives = []string{
	"bold",
	"brave",
	"bright",
	"calm",
	"clever",
	"cool",
	"cosmic",
	"crisp",
	"curious",
	"daring",
	"eager",
	"fair",
	"fierce",
	"gentle",
	"golden",
	"grand",
	"happy",
	"keen",
	"kind",
	"lively",
	"lucky",
	"merry",
	"mighty",
	"noble",
	"proud",
	"quick",
	"quiet",
	"rapid",
	"rustic",
	"serene",
	"sharp",
	"shiny",
	"silent",
	"smooth",
	"snowy",
	"steady",
	"swift",
	"tiny",
	"vivid",
	"warm",
	"wild",
	"wise",
	"witty",
	"zesty",
}

var nouns = []string{
	"arch",
	"bloom",
	"breeze",
	"brook",
	"cabin",
	"canyon",
	"cedar",
	"cliff",
	"cloud",
	"comet",
	"coral",
	"crane",
	"creek",
	"dawn",
	"dune",
	"ember",
	"falcon",
	"fern",
	"flame",
	"flint",
	"forest",
	"frost",
	"glen",
	"grove",
	"harbor",
	"hawk",
	"lake",
	"lark",
	"maple",
	"marsh",
	"meadow",
	"mesa",
	"mist",
	"moon",
	"oak",
	"orbit",
	"peak",
	"pine",
	"pixel",
	"pond",
	"reef",
	"ridge",
	"river",
	"rocket",
	"sage",
	"shore",
	"spark",
	"stone",
	"storm",
	"trail",
	"vale",
	"wave",
	"willow",
	"wolf",
}

func pick(list []string) string {
	if len(list) == 0 {
		return "x"
	}
	n, err := rand.Int(rand.Reader, big.NewInt(int64(len(list))))
	if err != nil {
		return list[0]
	}
	return list[n.Int64()]
}

// CreateSlug returns adjective-noun (Python create_slug).
func CreateSlug() string {
	return pick(adjectives) + "-" + pick(nouns)
}

// Slugify converts arbitrary text into a filesystem-safe slug.
func Slugify(s string) string {
	out := make([]rune, 0, len(s))
	prevDash := false
	for _, r := range stringsToLower(s) {
		if (r >= 'a' && r <= 'z') || (r >= '0' && r <= '9') {
			out = append(out, r)
			prevDash = false
			continue
		}
		if !prevDash {
			out = append(out, '-')
			prevDash = true
		}
	}
	for len(out) > 0 && out[0] == '-' {
		out = out[1:]
	}
	for len(out) > 0 && out[len(out)-1] == '-' {
		out = out[:len(out)-1]
	}
	if len(out) == 0 {
		return CreateSlug()
	}
	return string(out)
}

func stringsToLower(s string) string {
	b := make([]rune, 0, len(s))
	for _, r := range s {
		if r >= 'A' && r <= 'Z' {
			b = append(b, r+'a'-'A')
		} else {
			b = append(b, r)
		}
	}
	return string(b)
}

// MustCreateSlug is CreateSlug with a non-empty guarantee.
func MustCreateSlug() string {
	s := CreateSlug()
	if s == "-" || s == "" {
		return fmt.Sprintf("session-%d", len(adjectives)+len(nouns))
	}
	return s
}
