//go:build js && wasm

package utils

import (
	"net/http"
	"time"

	"github.com/goarxyz/goar/browsernet"
)

// BuildHTTPClient returns a browser-fetch HTTP client (direct to the API).
// Provider/model/agent calls must NOT go through Wisp — Wisp remains for SSH/TCP tools via SDN.Dial.
func BuildHTTPClient(timeoutSec float64, _ bool) *http.Client {
	if timeoutSec <= 0 {
		timeoutSec = 720
	}
	return browsernet.NewDirectHTTPClient(time.Duration(timeoutSec * float64(time.Second)))
}
