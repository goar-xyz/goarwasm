package utils

import (
	"fmt"
	"os"
	"path/filepath"
	"strings"
)

// DangerousDirectoryPatterns are paths that warrant extra caution.
var DangerousDirectoryPatterns = []string{
	"/", "/etc", "/usr", "/bin", "/sbin", "/var", "/boot", "/dev", "/proc", "/sys",
	"C:\\", "C:\\Windows", "C:\\Program Files",
}

// DangerousCommandPrefixes are shell prefixes blocked by SandboxExecutor.
var DangerousCommandPrefixes = []string{
	"rm -rf /", "mkfs", "dd if=", ":(){", "shutdown", "reboot", "poweroff",
	"diskutil erase", "format c:",
}

// IsDangerousDirectory reports whether path looks like a system root.
func IsDangerousDirectory(path string) bool {
	p := strings.TrimRight(path, `/\`)
	for _, d := range DangerousDirectoryPatterns {
		if strings.EqualFold(p, strings.TrimRight(d, `/\`)) {
			return true
		}
	}
	return false
}

// SandboxExecutor validates commands before execution (Python SandboxExecutor).
type SandboxExecutor struct {
	AllowedPaths []string
}

// NewSandboxExecutor constructs a sandbox with optional allowed path roots.
func NewSandboxExecutor(allowed []string) *SandboxExecutor {
	return &SandboxExecutor{AllowedPaths: append([]string{}, allowed...)}
}

// Validate reports whether cmd is safe to run.
func (s *SandboxExecutor) Validate(cmd string) (bool, string) {
	trimmed := strings.TrimSpace(cmd)
	if trimmed == "" {
		return false, "empty command"
	}
	lower := strings.ToLower(trimmed)
	for _, bad := range DangerousCommandPrefixes {
		if strings.Contains(lower, strings.ToLower(bad)) {
			return false, "blocked dangerous command pattern: " + bad
		}
	}
	if IsDangerousDirectory(trimmed) {
		return false, "refuses to operate on dangerous directory"
	}
	if len(s.AllowedPaths) > 0 {
		// Best-effort: if command mentions an absolute path, require it under allowed roots.
		for _, tok := range strings.Fields(trimmed) {
			if strings.HasPrefix(tok, "/") || (len(tok) > 2 && tok[1] == ':') {
				ok := false
				for _, root := range s.AllowedPaths {
					if IsWithinDir(tok, root) {
						ok = true
						break
					}
				}
				if !ok {
					return false, fmt.Sprintf("path %s is outside allowed roots", tok)
				}
			}
		}
	}
	return true, ""
}

// BuildCleanEnv returns a minimal environment for sandboxed subprocesses.
func (s *SandboxExecutor) BuildCleanEnv() map[string]string {
	keep := []string{"PATH", "HOME", "USER", "LANG", "LC_ALL", "TERM", "TMPDIR", "TMP", "TEMP"}
	out := map[string]string{}
	for _, k := range keep {
		if v := os.Getenv(k); v != "" {
			out[k] = v
		}
	}
	if out["PATH"] == "" {
		out["PATH"] = "/usr/bin:/bin:/usr/local/bin"
	}
	_ = filepath.Separator
	return out
}

// EnvList converts BuildCleanEnv to KEY=VAL slice.
func (s *SandboxExecutor) EnvList() []string {
	env := s.BuildCleanEnv()
	out := make([]string, 0, len(env))
	for k, v := range env {
		out = append(out, k+"="+v)
	}
	return out
}
