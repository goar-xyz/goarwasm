// Package utils provides shared helpers (Python: goar.core.utils).
package utils
