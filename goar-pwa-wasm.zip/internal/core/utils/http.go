package utils

import (
	"strings"
)

// ServerURLFromAPIBase strips a trailing /v1 to get the server origin.
func ServerURLFromAPIBase(apiBase string) string {
	u := strings.TrimRight(apiBase, "/")
	if strings.HasSuffix(u, "/v1") {
		return u[:len(u)-3]
	}
	return u
}

// JoinURL joins base and path without double slashes.
func JoinURL(base, path string) string {
	return strings.TrimRight(base, "/") + "/" + strings.TrimLeft(path, "/")
}

// GetUserAgent builds the Goar user-agent string for a backend name.
func GetUserAgent(backend string) string {
	if backend == "" {
		backend = "generic"
	}
	return "goar-go/1.1.1 (" + backend + ")"
}
