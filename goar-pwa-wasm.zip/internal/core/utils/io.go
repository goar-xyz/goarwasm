package utils

import (
	"bytes"
	"os"
	"unicode/utf8"
)

// ReadSafeResult is a decoded text file read.
type ReadSafeResult struct {
	Text     string
	Encoding string
	Binary   bool
}

// DecodeSafe decodes bytes as UTF-8 with replacement, detecting binary.
func DecodeSafe(b []byte) ReadSafeResult {
	if bytes.IndexByte(b, 0) >= 0 {
		return ReadSafeResult{Text: string(b), Encoding: "binary", Binary: true}
	}
	if utf8.Valid(b) {
		return ReadSafeResult{Text: string(b), Encoding: "utf-8", Binary: false}
	}
	// replace invalid sequences
	return ReadSafeResult{Text: string(bytes.ToValidUTF8(b, []byte("\uFFFD"))), Encoding: "utf-8-replace", Binary: false}
}

// ReadSafe reads a file with safe decoding.
func ReadSafe(path string) (ReadSafeResult, error) {
	b, err := os.ReadFile(path)
	if err != nil {
		return ReadSafeResult{}, err
	}
	return DecodeSafe(b), nil
}

// WriteUTF8 writes UTF-8 text, creating parent dirs if needed.
func WriteUTF8(path, content string, createParents bool) error {
	if createParents {
		dir := path[:len(path)-len(baseName(path))]
		if dir != "" && dir != "." {
			if err := os.MkdirAll(filepathDir(path), 0o755); err != nil {
				return err
			}
		}
	}
	return os.WriteFile(path, []byte(content), 0o644)
}

func baseName(p string) string {
	for i := len(p) - 1; i >= 0; i-- {
		if p[i] == '/' || p[i] == '\\' {
			return p[i+1:]
		}
	}
	return p
}

func filepathDir(p string) string {
	for i := len(p) - 1; i >= 0; i-- {
		if p[i] == '/' || p[i] == '\\' {
			if i == 0 {
				return p[:1]
			}
			return p[:i]
		}
	}
	return "."
}
