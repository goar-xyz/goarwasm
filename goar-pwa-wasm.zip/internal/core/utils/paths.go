package utils

import (
	"os"
	"path/filepath"
	"strings"
)

// ExpandUser expands a leading ~.
func ExpandUser(p string) string {
	if p == "~" || strings.HasPrefix(p, "~/") || strings.HasPrefix(p, "~"+string(os.PathSeparator)) {
		home, err := os.UserHomeDir()
		if err != nil {
			return p
		}
		if p == "~" {
			return home
		}
		return filepath.Join(home, p[2:])
	}
	return p
}

// ResolvePath expands user and makes absolute relative to cwd.
func ResolvePath(p string) (string, error) {
	p = ExpandUser(p)
	if filepath.IsAbs(p) {
		return filepath.Clean(p), nil
	}
	cwd, err := os.Getwd()
	if err != nil {
		return "", err
	}
	return filepath.Clean(filepath.Join(cwd, p)), nil
}

// IsWithinDir reports whether child is inside parent (after clean).
func IsWithinDir(child, parent string) bool {
	child = filepath.Clean(child)
	parent = filepath.Clean(parent)
	rel, err := filepath.Rel(parent, child)
	if err != nil {
		return false
	}
	return rel != ".." && !strings.HasPrefix(rel, ".."+string(os.PathSeparator))
}
