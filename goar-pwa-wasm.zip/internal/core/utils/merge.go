package utils

import "fmt"

// MergeStrategy matches Python MergeStrategy.
type MergeStrategy string

const (
	MergeReplace  MergeStrategy = "replace"
	MergeConcat   MergeStrategy = "concat"
	MergeUnion    MergeStrategy = "union"
	MergeShallow  MergeStrategy = "merge"
	MergeConflict MergeStrategy = "conflict"
	MergeCoalesce MergeStrategy = "coalesce"
)

// MergeConflictError is raised by the conflict strategy.
type MergeConflictError struct{ Field string }

func (e MergeConflictError) Error() string {
	if e.Field != "" {
		return "merge conflict on field: " + e.Field
	}
	return "merge conflict"
}

// MergeKeyError is raised when a union key is invalid.
type MergeKeyError struct {
	Key  string
	Item any
}

func (e MergeKeyError) Error() string {
	return fmt.Sprintf("merge key error for %q: %v", e.Key, e.Item)
}

// Apply merges override into base using the strategy.
func (s MergeStrategy) Apply(base, override any) (any, error) {
	switch s {
	case MergeReplace:
		return s.replace(base, override), nil
	case MergeConcat:
		return s.concat(base, override)
	case MergeUnion:
		return s.union(base, override, "")
	case MergeShallow:
		return s.merge(base, override)
	case MergeConflict:
		return s.conflict(base, override)
	case MergeCoalesce:
		ok, v := s.coalesce(base, override)
		if ok {
			return v, nil
		}
		return base, nil
	default:
		return s.replace(base, override), nil
	}
}

func (s MergeStrategy) coalesce(base, override any) (bool, any) {
	if override == nil {
		return true, base
	}
	if base == nil {
		return true, override
	}
	return false, nil
}

func (s MergeStrategy) replace(base, override any) any {
	_ = base
	return override
}

func (s MergeStrategy) concat(base, override any) (any, error) {
	ba, aok := asSlice(base)
	oa, ook := asSlice(override)
	if !aok || !ook {
		return nil, fmt.Errorf("concat requires list operands")
	}
	out := make([]any, 0, len(ba)+len(oa))
	out = append(out, ba...)
	out = append(out, oa...)
	return out, nil
}

func (s MergeStrategy) union(base, override any, keyField string) (any, error) {
	ba, aok := asSlice(base)
	oa, ook := asSlice(override)
	if !aok || !ook {
		return nil, fmt.Errorf("union requires list operands")
	}
	seen := map[string]bool{}
	var out []any
	add := func(item any) error {
		key := fmt.Sprint(item)
		if keyField != "" {
			if m, ok := item.(map[string]any); ok {
				if v, ok := m[keyField]; ok {
					key = fmt.Sprint(v)
				} else {
					return MergeKeyError{Key: keyField, Item: item}
				}
			}
		}
		if seen[key] {
			return nil
		}
		seen[key] = true
		out = append(out, item)
		return nil
	}
	for _, item := range ba {
		if err := add(item); err != nil {
			return nil, err
		}
	}
	for _, item := range oa {
		if err := add(item); err != nil {
			return nil, err
		}
	}
	return out, nil
}

func (s MergeStrategy) merge(base, override any) (any, error) {
	bm, bok := base.(map[string]any)
	om, ook := override.(map[string]any)
	if !bok || !ook {
		return s.replace(base, override), nil
	}
	return DeepUpdate(bm, om), nil
}

func (s MergeStrategy) conflict(base, override any) (any, error) {
	if fmt.Sprint(base) == fmt.Sprint(override) {
		return base, nil
	}
	return nil, MergeConflictError{}
}

func asSlice(v any) ([]any, bool) {
	switch t := v.(type) {
	case []any:
		return t, true
	case []string:
		out := make([]any, len(t))
		for i, s := range t {
			out[i] = s
		}
		return out, true
	default:
		return nil, false
	}
}

// DeepUpdate recursively merges updating into mapping (dicts only).
func DeepUpdate(mapping, updating map[string]any) map[string]any {
	out := make(map[string]any, len(mapping)+len(updating))
	for k, v := range mapping {
		out[k] = v
	}
	for k, v := range updating {
		if existing, ok := out[k]; ok {
			em, eok := existing.(map[string]any)
			vm, vok := v.(map[string]any)
			if eok && vok {
				out[k] = DeepUpdate(em, vm)
				continue
			}
		}
		out[k] = v
	}
	return out
}

// ConcatLists appends b after a.
func ConcatLists[T any](a, b []T) []T {
	out := make([]T, 0, len(a)+len(b))
	out = append(out, a...)
	out = append(out, b...)
	return out
}

// MergeMapsWithStrategy merges maps field-by-field using a per-key strategy table.
func MergeMapsWithStrategy(base, override map[string]any, strategies map[string]MergeStrategy) (map[string]any, error) {
	out := DeepUpdate(map[string]any{}, base)
	for k, v := range override {
		strat := MergeReplace
		if s, ok := strategies[k]; ok {
			strat = s
		}
		merged, err := strat.Apply(out[k], v)
		if err != nil {
			if ce, ok := err.(MergeConflictError); ok {
				ce.Field = k
				return nil, ce
			}
			return nil, err
		}
		out[k] = merged
	}
	return out, nil
}
