package utils

import (
	"path/filepath"
	"regexp"
	"strings"
)

// MatchPattern matches name against a glob, or regex if prefixed with "re:".
func MatchPattern(name, pattern string) bool {
	if strings.HasPrefix(pattern, "re:") {
		re, err := regexp.Compile(pattern[3:])
		if err != nil {
			return false
		}
		return re.MatchString(name)
	}
	ok, err := filepath.Match(pattern, name)
	if err != nil {
		return false
	}
	if ok {
		return true
	}
	// also try ** style via filepath
	ok, _ = filepath.Match(pattern, filepath.Base(name))
	return ok
}

// AnyMatch returns true if name matches any pattern.
func AnyMatch(name string, patterns []string) bool {
	for _, p := range patterns {
		if MatchPattern(name, p) {
			return true
		}
	}
	return false
}
