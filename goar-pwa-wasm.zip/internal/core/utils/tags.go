package utils

import (
	"fmt"
	"strings"
)

const (
	// GoarWarningTag wraps injected warning/context blocks for the model.
	GoarWarningTag = "goar_warning"
	// GoarSystemTag wraps system-injected notices.
	GoarSystemTag = "goar_system"
	// ToolErrorTag wraps tool failure messages.
	ToolErrorTag = "tool_error"
	// CancellationTag wraps user-cancellation notices.
	CancellationTag = "user_cancellation"
	// AgentStopEventTag wraps middleware stop reasons.
	AgentStopEventTag = "agent_stop"
)

// CancellationReason classifies why a tool/turn was cancelled.
type CancellationReason string

const (
	CancelToolSkipped     CancellationReason = "tool_skipped"
	CancelToolInterrupted CancellationReason = "tool_interrupted"
	CancelToolNoResponse  CancellationReason = "tool_no_response"
	CancelUserAbort       CancellationReason = "user_abort"
)

// WrapWarning wraps content in a goar_warning tag.
func WrapWarning(content string) string {
	return "<" + GoarWarningTag + ">\n" + content + "\n</" + GoarWarningTag + ">"
}

// WrapSystem wraps content in a goar_system tag.
func WrapSystem(content string) string {
	return "<" + GoarSystemTag + ">\n" + content + "\n</" + GoarSystemTag + ">"
}

// WrapToolError wraps content in a tool_error tag.
func WrapToolError(content string) string {
	return "<" + ToolErrorTag + ">" + content + "</" + ToolErrorTag + ">"
}

// WrapCancellation wraps content in a cancellation tag.
func WrapCancellation(content string) string {
	return "<" + CancellationTag + ">" + content + "</" + CancellationTag + ">"
}

// WrapStopEvent wraps a middleware stop reason.
func WrapStopEvent(reason string) string {
	return "<" + AgentStopEventTag + ">" + reason + "</" + AgentStopEventTag + ">"
}

// GetUserCancellationMessage builds a cancellation notice for the given reason.
func GetUserCancellationMessage(reason CancellationReason, toolName ...string) string {
	name := ""
	if len(toolName) > 0 {
		name = toolName[0]
	}
	var body string
	switch reason {
	case CancelToolSkipped:
		if name != "" {
			body = fmt.Sprintf("Tool '%s' was skipped by the user.", name)
		} else {
			body = "Tool execution was skipped by the user."
		}
	case CancelToolInterrupted:
		body = "Tool execution was interrupted by the user."
	case CancelToolNoResponse:
		body = "Tool call had no response (filled by history repair)."
	case CancelUserAbort:
		body = "User aborted the current turn."
	default:
		body = string(reason)
	}
	return WrapCancellation(body)
}

// IsUserCancellationEvent reports whether payload text contains a cancellation tag.
func IsUserCancellationEvent(text string) bool {
	return strings.Contains(text, "<"+CancellationTag+">")
}

// ContainsToolError reports whether text contains a tool_error tag.
func ContainsToolError(text string) bool {
	return strings.Contains(text, "<"+ToolErrorTag+">")
}

// KnownTags lists tags recognized by TaggedText parsing.
var KnownTags = []string{CancellationTag, ToolErrorTag, AgentStopEventTag, GoarWarningTag}

// TaggedText unwraps a single known tag wrapper (Python TaggedText).
type TaggedText struct {
	Message string
	Tag     string
}

func (t TaggedText) String() string {
	if t.Tag == "" {
		return t.Message
	}
	return "<" + t.Tag + ">" + t.Message + "</" + t.Tag + ">"
}

// TaggedTextFromString parses an optionally tagged string.
func TaggedTextFromString(text string) TaggedText {
	text = strings.TrimSpace(text)
	for _, tag := range KnownTags {
		open, close := "<"+tag+">", "</"+tag+">"
		if strings.HasPrefix(text, open) && strings.HasSuffix(text, close) {
			inner := strings.TrimSpace(strings.TrimSuffix(strings.TrimPrefix(text, open), close))
			return TaggedText{Message: inner, Tag: tag}
		}
	}
	return TaggedText{Message: text}
}
