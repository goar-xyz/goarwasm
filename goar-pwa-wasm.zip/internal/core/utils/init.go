package utils

// Re-export surface matching Python goar.core.utils.__init__
// (Go has no re-export; callers import this package directly).
