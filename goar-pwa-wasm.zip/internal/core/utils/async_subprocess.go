package utils

import (
	"bytes"
	"context"
	"os"
	"os/exec"
	"time"
)

// RunResult is subprocess output.
type RunResult struct {
	Stdout     string
	Stderr     string
	ReturnCode int
}

// RunShell runs a shell command with timeout and env overlays.
func RunShell(ctx context.Context, command string, timeout time.Duration, env map[string]string) (RunResult, error) {
	if timeout > 0 {
		var cancel context.CancelFunc
		ctx, cancel = context.WithTimeout(ctx, timeout)
		defer cancel()
	}
	var cmd *exec.Cmd
	if IsWindows() {
		cmd = exec.CommandContext(ctx, "cmd", "/C", command)
	} else {
		shell := ShellExecutable()
		cmd = exec.CommandContext(ctx, shell, "-c", command)
	}
	cmd.Env = os.Environ()
	for k, v := range env {
		cmd.Env = append(cmd.Env, k+"="+v)
	}
	var stdout, stderr bytes.Buffer
	cmd.Stdout = &stdout
	cmd.Stderr = &stderr
	err := cmd.Run()
	rc := 0
	if err != nil {
		if ee, ok := err.(*exec.ExitError); ok {
			rc = ee.ExitCode()
			err = nil
		}
	}
	return RunResult{Stdout: stdout.String(), Stderr: stderr.String(), ReturnCode: rc}, err
}

// KillProcessTree best-effort kill (process group on Unix).
func KillProcessTree(cmd *exec.Cmd) {
	if cmd == nil || cmd.Process == nil {
		return
	}
	_ = cmd.Process.Kill()
}
