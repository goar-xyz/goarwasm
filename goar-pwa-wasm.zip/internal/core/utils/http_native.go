//go:build !js

package utils

import (
	"crypto/tls"
	"net/http"
	"time"
)

// BuildHTTPClient returns an HTTP client with timeout and optional system trust.
// Native builds use the process default transport (direct to the API).
func BuildHTTPClient(timeoutSec float64, enableSystemTrust bool) *http.Client {
	tr := http.DefaultTransport.(*http.Transport).Clone()
	if !enableSystemTrust {
		_ = tls.VersionTLS12
	}
	return &http.Client{Timeout: time.Duration(timeoutSec * float64(time.Second)), Transport: tr}
}
