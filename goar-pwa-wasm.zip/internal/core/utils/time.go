package utils

import "time"

// UTCNow returns current UTC time.
func UTCNow() time.Time { return time.Now().UTC() }

// UTCNowISO returns RFC3339 UTC timestamp.
func UTCNowISO() string { return UTCNow().Format(time.RFC3339Nano) }

// UnixFloat returns seconds since epoch as float64.
func UnixFloat() float64 { return float64(time.Now().UnixNano()) / 1e9 }
