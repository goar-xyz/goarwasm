package utils

import (
	"context"
	"sync"
)

// ParallelLimit runs fns with at most limit concurrent workers.
func ParallelLimit(ctx context.Context, limit int, fns []func(context.Context) error) []error {
	if limit < 1 {
		limit = 1
	}
	sem := make(chan struct{}, limit)
	errs := make([]error, len(fns))
	var wg sync.WaitGroup
	for i, fn := range fns {
		wg.Add(1)
		go func(i int, fn func(context.Context) error) {
			defer wg.Done()
			select {
			case <-ctx.Done():
				errs[i] = ctx.Err()
				return
			case sem <- struct{}{}:
			}
			defer func() { <-sem }()
			errs[i] = fn(ctx)
		}(i, fn)
	}
	wg.Wait()
	return errs
}
