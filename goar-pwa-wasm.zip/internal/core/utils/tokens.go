package utils

import "unicode/utf8"

// EstimateTokens roughly estimates tokens as chars/4 (no tokenizer dep).
func EstimateTokens(s string) int {
	n := utf8.RuneCountInString(s)
	if n == 0 {
		return 0
	}
	return (n + 3) / 4
}

// EstimateMessagesTokens sums estimate across messages.
func EstimateMessagesTokens(contents []string) int {
	total := 0
	for _, c := range contents {
		total += EstimateTokens(c) + 4 // per-message overhead
	}
	return total
}
