package types

import (
	"encoding/json"
	"fmt"
	"time"

	"github.com/google/uuid"
)

// Backend selects an LLM backend implementation.
type Backend string

const (
	BackendGeneric Backend = "generic"
)

// Role is a chat message role.
type Role string

const (
	RoleSystem    Role = "system"
	RoleUser      Role = "user"
	RoleAssistant Role = "assistant"
	RoleTool      Role = "tool"
)

// StrToolChoice is a string tool_choice value.
type StrToolChoice string

const (
	ToolChoiceAuto     StrToolChoice = "auto"
	ToolChoiceNone     StrToolChoice = "none"
	ToolChoiceAny      StrToolChoice = "any"
	ToolChoiceRequired StrToolChoice = "required"
)

// ApprovalResponse is y/n tool approval.
type ApprovalResponse string

const (
	ApprovalYes ApprovalResponse = "y"
	ApprovalNo  ApprovalResponse = "n"
)

// AvailableFunction is an OpenAI-style function schema.
type AvailableFunction struct {
	Name        string         `json:"name"`
	Description string         `json:"description"`
	Parameters  map[string]any `json:"parameters"`
}

// AvailableTool wraps a function tool for the API.
type AvailableTool struct {
	Type     string            `json:"type"`
	Function AvailableFunction `json:"function"`
}

// FunctionCall is a tool call's function payload.
type FunctionCall struct {
	Name      string `json:"name,omitempty"`
	Arguments string `json:"arguments,omitempty"`
}

// ToolCall is an assistant tool invocation.
type ToolCall struct {
	ID       string       `json:"id,omitempty"`
	Index    *int         `json:"index,omitempty"`
	Type     string       `json:"type"`
	Function FunctionCall `json:"function"`
}

// LLMMessage is a conversation message.
type LLMMessage struct {
	Role               Role       `json:"role"`
	Content            *string    `json:"content,omitempty"`
	Injected           bool       `json:"injected,omitempty"`
	ReasoningContent   *string    `json:"reasoning_content,omitempty"`
	ReasoningState     []string   `json:"reasoning_state,omitempty"`
	ReasoningSignature *string    `json:"reasoning_signature,omitempty"`
	ReasoningMessageID *string    `json:"reasoning_message_id,omitempty"`
	ToolCalls          []ToolCall `json:"tool_calls,omitempty"`
	Name               *string    `json:"name,omitempty"`
	ToolCallID         *string    `json:"tool_call_id,omitempty"`
	MessageID          *string    `json:"message_id,omitempty"`
}

// NewMessage builds a message with a fresh message_id.
func NewMessage(role Role, content string) LLMMessage {
	id := uuid.NewString()
	c := content
	return LLMMessage{Role: role, Content: &c, MessageID: &id}
}

// ContentString returns content or empty.
func (m LLMMessage) ContentString() string {
	if m.Content == nil {
		return ""
	}
	return *m.Content
}

// LLMUsage tracks token usage.
type LLMUsage struct {
	PromptTokens     int `json:"prompt_tokens"`
	CompletionTokens int `json:"completion_tokens"`
}

// Add sums two usage structs.
func (u LLMUsage) Add(o LLMUsage) LLMUsage {
	return LLMUsage{
		PromptTokens:     u.PromptTokens + o.PromptTokens,
		CompletionTokens: u.CompletionTokens + o.CompletionTokens,
	}
}

// LLMChunk is a completion result (full or stream delta).
type LLMChunk struct {
	Message       LLMMessage `json:"message"`
	Usage         *LLMUsage  `json:"usage,omitempty"`
	CorrelationID *string    `json:"correlation_id,omitempty"`
}

// AgentStats tracks session metrics.
type AgentStats struct {
	Steps                    int     `json:"steps"`
	SessionPromptTokens      int     `json:"session_prompt_tokens"`
	SessionCompletionTokens  int     `json:"session_completion_tokens"`
	ToolCallsAgreed          int     `json:"tool_calls_agreed"`
	ToolCallsRejected        int     `json:"tool_calls_rejected"`
	ToolCallsFailed          int     `json:"tool_calls_failed"`
	ToolCallsSucceeded       int     `json:"tool_calls_succeeded"`
	ContextTokens            int     `json:"context_tokens"`
	LastTurnPromptTokens     int     `json:"last_turn_prompt_tokens"`
	LastTurnCompletionTokens int     `json:"last_turn_completion_tokens"`
	LastTurnDuration         float64 `json:"last_turn_duration"`
	TokensPerSecond          float64 `json:"tokens_per_second"`
	InputPricePerMillion     float64 `json:"input_price_per_million"`
	OutputPricePerMillion    float64 `json:"output_price_per_million"`
}

// SessionTotalLLMTokens is prompt+completion for the session.
func (s AgentStats) SessionTotalLLMTokens() int {
	return s.SessionPromptTokens + s.SessionCompletionTokens
}

// SessionCost estimates dollar cost.
func (s AgentStats) SessionCost() float64 {
	in := (float64(s.SessionPromptTokens) / 1_000_000) * s.InputPricePerMillion
	out := (float64(s.SessionCompletionTokens) / 1_000_000) * s.OutputPricePerMillion
	return in + out
}


// CreateFreshStats copies pricing from old and resets counters (Python AgentStats.create_fresh).
func CreateFreshStats(old AgentStats) AgentStats {
	return AgentStats{
		InputPricePerMillion:  old.InputPricePerMillion,
		OutputPricePerMillion: old.OutputPricePerMillion,
	}
}

// UpdatePricing sets per-million prices.
func (s *AgentStats) UpdatePricing(input, output float64) {
	s.InputPricePerMillion = input
	s.OutputPricePerMillion = output
}

// ResetContextState clears context token counters for a fresh prompt.
func (s *AgentStats) ResetContextState() {
	s.ContextTokens = 0
	s.LastTurnPromptTokens = 0
	s.LastTurnCompletionTokens = 0
	s.LastTurnDuration = 0
	s.TokensPerSecond = 0
}

// ScheduledLoop is a periodic prompt.
type ScheduledLoop struct {
	ID              string  `json:"id"`
	IntervalSeconds int     `json:"interval_seconds"`
	Prompt          string  `json:"prompt"`
	NextFireAt      float64 `json:"next_fire_at"`
	CreatedAt       float64 `json:"created_at"`
}

// SessionMetadata persists session header info.
type SessionMetadata struct {
	SessionID       string            `json:"session_id"`
	ParentSessionID *string           `json:"parent_session_id,omitempty"`
	StartTime       string            `json:"start_time"`
	EndTime         *string           `json:"end_time,omitempty"`
	GitCommit       *string           `json:"git_commit,omitempty"`
	GitBranch       *string           `json:"git_branch,omitempty"`
	Environment     map[string]string `json:"environment"`
	Username        string            `json:"username"`
	Loops           []ScheduledLoop   `json:"loops"`
	Title           *string           `json:"title,omitempty"`
	TitleSource     string            `json:"title_source"`
}

// SessionInfo is a lightweight session listing row.
type SessionInfo struct {
	SessionID    string     `json:"session_id"`
	StartTime    string     `json:"start_time"`
	MessageCount int        `json:"message_count"`
	Stats        AgentStats `json:"stats"`
	SaveDir      string     `json:"save_dir"`
}

// OutputFormat for programmatic mode.
type OutputFormat string

const (
	OutputText      OutputFormat = "text"
	OutputJSON      OutputFormat = "json"
	OutputStreaming OutputFormat = "streaming"
)

// ToolStreamEvent is a streaming tool progress event.
type ToolStreamEvent struct {
	Kind    string `json:"kind"`
	Message string `json:"message"`
}

// AssistantEvent is emitted when the assistant finishes a turn.
type AssistantEvent struct {
	Content             string  `json:"content"`
	StoppedByMiddleware bool    `json:"stopped_by_middleware"`
	MessageID           *string `json:"message_id,omitempty"`
}

// ToolCallEvent is emitted when a tool is invoked.
type ToolCallEvent struct {
	ToolCallID string `json:"tool_call_id"`
	Name       string `json:"name"`
	ArgsJSON   string `json:"args_json"`
}

// ToolResultEvent is emitted when a tool finishes.
type ToolResultEvent struct {
	ToolCallID string `json:"tool_call_id"`
	Name       string `json:"name"`
	ResultJSON string `json:"result_json"`
	Error      string `json:"error,omitempty"`
	SkipReason string `json:"skip_reason,omitempty"`
}

// Event is a runtime event union (JSON tagged).
type Event struct {
	Type      string          `json:"type"`
	Payload   json.RawMessage `json:"payload"`
	Timestamp time.Time       `json:"timestamp"`
}

// NewEvent wraps a typed payload.
func NewEvent(typ string, payload any) (Event, error) {
	b, err := json.Marshal(payload)
	if err != nil {
		return Event{}, err
	}
	return Event{Type: typ, Payload: b, Timestamp: time.Now().UTC()}, nil
}

// FormatEvent returns a human-readable line.
func FormatEvent(e Event) string {
	return fmt.Sprintf("[%s] %s %s", e.Timestamp.Format(time.RFC3339), e.Type, string(e.Payload))
}
