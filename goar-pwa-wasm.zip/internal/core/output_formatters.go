package core

import (
	"encoding/json"
	"fmt"
	"os"
)

// Formatter formats programmatic output.
type Formatter interface {
	OnEvent(Event)
	OnMessage(LLMMessage)
	Finalize() string
}

// TextFormatter prints human-readable assistant text.
type TextFormatter struct{ last string }

func (f *TextFormatter) OnEvent(e Event) {
	if e.Type == "assistant" {
		var ae AssistantEvent
		_ = json.Unmarshal(e.Payload, &ae)
		f.last = ae.Content
	}
}
func (f *TextFormatter) OnMessage(m LLMMessage) {
	if m.Role == RoleAssistant {
		f.last = m.ContentString()
	}
}
func (f *TextFormatter) Finalize() string { return f.last }

// JSONFormatter accumulates all events.
type JSONFormatter struct{ events []Event }

func (f *JSONFormatter) OnEvent(e Event) { f.events = append(f.events, e) }
func (f *JSONFormatter) OnMessage(LLMMessage) {}
func (f *JSONFormatter) Finalize() string {
	b, _ := json.MarshalIndent(f.events, "", "  ")
	return string(b)
}

// StreamingFormatter writes NDJSON per event.
type StreamingFormatter struct{}

func (f *StreamingFormatter) OnEvent(e Event) {
	b, _ := json.Marshal(e)
	fmt.Fprintln(os.Stdout, string(b))
}
func (f *StreamingFormatter) OnMessage(LLMMessage) {}
func (f *StreamingFormatter) Finalize() string     { return "" }

// CreateFormatter builds a formatter by name.
func CreateFormatter(format OutputFormat) Formatter {
	switch format {
	case OutputJSON:
		return &JSONFormatter{}
	case OutputStreaming:
		return &StreamingFormatter{}
	default:
		return &TextFormatter{}
	}
}
