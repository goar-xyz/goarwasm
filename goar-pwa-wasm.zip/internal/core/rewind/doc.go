// Package rewind implements conversation/file rewind checkpoints.
package rewind
