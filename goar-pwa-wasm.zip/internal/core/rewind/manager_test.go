package rewind_test

import (
	"os"
	"path/filepath"
	"testing"

	"github.com/goarxyz/goar/internal/core/rewind"
	"github.com/goarxyz/goar/internal/core/types"
)

func TestRewindToMessageTruncatesAndRestores(t *testing.T) {
	dir := t.TempDir()
	target := filepath.Join(dir, "scratch.txt")
	if err := os.WriteFile(target, []byte("v1"), 0o644); err != nil {
		t.Fatal(err)
	}

	sys := types.NewMessage(types.RoleSystem, "system")
	u1 := types.NewMessage(types.RoleUser, "first")
	a1 := types.NewMessage(types.RoleAssistant, "reply-first")
	u2 := types.NewMessage(types.RoleUser, "second")
	a2 := types.NewMessage(types.RoleAssistant, "reply-second")

	msgs := []types.LLMMessage{sys}
	var saved []types.LLMMessage
	var saveCalls int
	m := rewind.NewManager(&msgs, func(ms []types.LLMMessage) error {
		saveCalls++
		saved = append([]types.LLMMessage{}, ms...)
		return nil
	}, func() error { return nil })

	// Turn-start checkpoint before first user message is appended → len==1 (system only).
	m.AddCheckpoint("turn-1", nil)
	msgs = append(msgs, u1, a1)

	// Turn-start checkpoint before second user message → len==3
	m.AddCheckpoint("turn-2", nil)
	snap := rewind.SnapshotPath(target)
	m.AddCheckpoint("file-mut", []rewind.FileSnapshot{snap})
	if err := os.WriteFile(target, []byte("v2-mutated"), 0o644); err != nil {
		t.Fatal(err)
	}
	msgs = append(msgs, u2, a2)

	if len(msgs) != 5 {
		t.Fatalf("precondition messages=%d want 5", len(msgs))
	}

	// Rewind to first user message (runtime index 1) with restore — same path as /rewind confirm+restore.
	content, err := m.RewindToMessage(1, true)
	if err != nil {
		t.Fatalf("RewindToMessage: %v", err)
	}
	if content != "first" {
		t.Fatalf("content=%q", content)
	}
	if len(msgs) != 1 {
		t.Fatalf("truncated len=%d want 1 (system only)", len(msgs))
	}
	if msgs[0].Role != types.RoleSystem {
		t.Fatalf("expected system remaining, got %s", msgs[0].Role)
	}
	if saveCalls < 1 {
		t.Fatal("expected PersistMessages via save callback")
	}
	if len(saved) != 1 {
		t.Fatalf("saved len=%d", len(saved))
	}
	got, err := os.ReadFile(target)
	if err != nil {
		t.Fatal(err)
	}
	if string(got) != "v1" {
		t.Fatalf("file restore failed: %q", got)
	}
	if len(m.List()) != 1 {
		t.Fatalf("checkpoints kept=%d want 1", len(m.List()))
	}
}

func TestRewindToMessageTwoTurnsHistory(t *testing.T) {
	sys := types.NewMessage(types.RoleSystem, "system")
	u1 := types.NewMessage(types.RoleUser, "alpha")
	a1 := types.NewMessage(types.RoleAssistant, "A")
	u2 := types.NewMessage(types.RoleUser, "beta")
	a2 := types.NewMessage(types.RoleAssistant, "B")

	msgs := []types.LLMMessage{sys}
	m := rewind.NewManager(&msgs, func([]types.LLMMessage) error { return nil }, nil)
	m.AddCheckpoint("t1", nil)
	msgs = append(msgs, u1, a1)
	m.AddCheckpoint("t2", nil)
	msgs = append(msgs, u2, a2)

	// Rewind to second user message (index 3) without restore → keep sys,u1,a1
	if _, err := m.RewindToMessage(3, false); err != nil {
		t.Fatal(err)
	}
	if len(msgs) != 3 {
		t.Fatalf("len=%d want 3", len(msgs))
	}
	if msgs[1].ContentString() != "alpha" || msgs[2].ContentString() != "A" {
		t.Fatalf("unexpected history after rewind")
	}
}
