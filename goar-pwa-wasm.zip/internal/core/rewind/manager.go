package rewind

import (
	"fmt"
	"os"
	"sync"

	"github.com/goarxyz/goar/internal/core/types"
)

// FileSnapshot captures file bytes before a mutation.
type FileSnapshot struct {
	Path    string
	Content []byte // nil means file did not exist
}

// Checkpoint is a rewind point.
type Checkpoint struct {
	Index     int
	MessageID string
	Files     []FileSnapshot
	Messages  []types.LLMMessage
}

// Manager tracks checkpoints and restores them.
type Manager struct {
	mu          sync.Mutex
	checkpoints []Checkpoint
	messages    *[]types.LLMMessage
	saveMsgs    func([]types.LLMMessage) error
	reset       func() error
}

// NewManager creates a rewind manager.
func NewManager(messages *[]types.LLMMessage, save func([]types.LLMMessage) error, reset func() error) *Manager {
	return &Manager{messages: messages, saveMsgs: save, reset: reset}
}

// AddCheckpoint records a checkpoint.
func (m *Manager) AddCheckpoint(messageID string, files []FileSnapshot) Checkpoint {
	m.mu.Lock()
	defer m.mu.Unlock()
	cp := Checkpoint{Index: len(m.checkpoints), MessageID: messageID, Files: files}
	if m.messages != nil {
		cp.Messages = append([]types.LLMMessage{}, (*m.messages)...)
	}
	m.checkpoints = append(m.checkpoints, cp)
	return cp
}

// List returns checkpoints.
func (m *Manager) List() []Checkpoint {
	m.mu.Lock()
	defer m.mu.Unlock()
	out := make([]Checkpoint, len(m.checkpoints))
	copy(out, m.checkpoints)
	return out
}

// RewindTo restores files and messages to a checkpoint index.
func (m *Manager) RewindTo(index int) error {
	m.mu.Lock()
	defer m.mu.Unlock()
	if index < 0 || index >= len(m.checkpoints) {
		return os.ErrInvalid
	}
	cp := m.checkpoints[index]
	applyFiles(cp.Files)
	if m.messages != nil {
		*m.messages = append([]types.LLMMessage{}, cp.Messages...)
	}
	if m.saveMsgs != nil {
		_ = m.saveMsgs(cp.Messages)
	}
	m.checkpoints = m.checkpoints[:index+1]
	return nil
}

// RewindToMessage truncates conversation history to messages[:messageIndex]
// (same semantics as TUI /rewind confirm). When restoreFiles is true, file
// snapshots recorded at/after the matching turn checkpoint are restored to
// their pre-mutation bytes (matching /rewind confirm with restore).
//
// messageIndex is a runtime.Messages index pointing at the selected user
// message; that message and everything after it are dropped.
func (m *Manager) RewindToMessage(messageIndex int, restoreFiles bool) (string, error) {
	m.mu.Lock()
	defer m.mu.Unlock()
	if m.messages == nil {
		return "", fmt.Errorf("rewind: no message store")
	}
	msgs := *m.messages
	if messageIndex < 0 || messageIndex >= len(msgs) {
		return "", fmt.Errorf("rewind: invalid message index %d", messageIndex)
	}
	user := msgs[messageIndex]
	if user.Role != types.RoleUser {
		return "", fmt.Errorf("rewind: message at index %d is not a user message", messageIndex)
	}
	content := user.ContentString()

	if restoreFiles {
		// Prefer the turn-start checkpoint whose snapshotted length matches the
		// truncate target (AddCheckpoint runs before the user message is appended).
		cpIdx := -1
		for i, cp := range m.checkpoints {
			if len(cp.Messages) == messageIndex {
				cpIdx = i
				break
			}
		}
		if cpIdx < 0 {
			// Fallback: latest checkpoint whose snapshotted history is a prefix.
			for i, cp := range m.checkpoints {
				if len(cp.Messages) <= messageIndex {
					cpIdx = i
				}
			}
		}
		if cpIdx >= 0 {
			// Restore files from the target checkpoint and any later ones that
			// recorded mutations after this turn, using earliest snapshot wins
			// so we land on the pre-mutation bytes for each path.
			seen := map[string]bool{}
			var plan []FileSnapshot
			for i := cpIdx; i < len(m.checkpoints); i++ {
				for _, f := range m.checkpoints[i].Files {
					if seen[f.Path] {
						continue
					}
					seen[f.Path] = true
					plan = append(plan, f)
				}
			}
			applyFiles(plan)
			m.checkpoints = m.checkpoints[:cpIdx+1]
		}
	} else {
		// Drop checkpoints whose snapshotted history extends past the truncate point.
		kept := 0
		for _, cp := range m.checkpoints {
			if len(cp.Messages) <= messageIndex {
				m.checkpoints[kept] = cp
				kept++
			}
		}
		m.checkpoints = m.checkpoints[:kept]
	}

	truncated := append([]types.LLMMessage{}, msgs[:messageIndex]...)
	*m.messages = truncated
	if m.saveMsgs != nil {
		if err := m.saveMsgs(truncated); err != nil {
			return content, err
		}
	}
	return content, nil
}

func applyFiles(files []FileSnapshot) {
	for _, f := range files {
		if f.Content == nil {
			_ = os.Remove(f.Path)
			continue
		}
		_ = os.WriteFile(f.Path, f.Content, 0o644)
	}
}

// SnapshotPath reads a file snapshot.
func SnapshotPath(path string) FileSnapshot {
	b, err := os.ReadFile(path)
	if err != nil {
		return FileSnapshot{Path: path, Content: nil}
	}
	return FileSnapshot{Path: path, Content: b}
}
