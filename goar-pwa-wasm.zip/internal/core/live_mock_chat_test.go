package core_test

import (
	"context"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"strings"
	"testing"

	"github.com/goarxyz/goar/internal/core"
	"github.com/goarxyz/goar/internal/core/config"
)

const liveMarker = "GOAR_LIVE_TURN_OK"

// TestLiveMockChatTurn drives the runtime agent against an OpenAI-compatible
// mock and asserts the assistant reply contains GOAR_LIVE_TURN_OK.
func TestLiveMockChatTurn(t *testing.T) {
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch {
		case r.Method == http.MethodGet && strings.HasSuffix(r.URL.Path, "/models"):
			_ = json.NewEncoder(w).Encode(map[string]any{
				"object": "list",
				"data":   []map[string]any{{"id": "mock-goar", "object": "model"}},
			})
		case r.Method == http.MethodPost && strings.Contains(r.URL.Path, "/chat/completions"):
			body, _ := io.ReadAll(r.Body)
			var req map[string]any
			_ = json.Unmarshal(body, &req)
			last := ""
			if msgs, ok := req["messages"].([]any); ok {
				for i := len(msgs) - 1; i >= 0; i-- {
					m, _ := msgs[i].(map[string]any)
					if m["role"] == "user" {
						last, _ = m["content"].(string)
						break
					}
				}
			}
			digest := last
			if len(digest) > 60 {
				digest = digest[:57] + "..."
			}
			text := fmt.Sprintf("Mock assistant reply. %s. last_user=%q", liveMarker, digest)
			if stream, _ := req["stream"].(bool); stream {
				w.Header().Set("Content-Type", "text/event-stream")
				chunk := map[string]any{
					"id": "chatcmpl-test", "object": "chat.completion.chunk", "model": "mock-goar",
					"choices": []map[string]any{{
						"index": 0, "delta": map[string]any{"role": "assistant", "content": text}, "finish_reason": nil,
					}},
				}
				b, _ := json.Marshal(chunk)
				fmt.Fprintf(w, "data: %s\n\n", b)
				fmt.Fprintf(w, "data: [DONE]\n\n")
				return
			}
			_ = json.NewEncoder(w).Encode(map[string]any{
				"id": "chatcmpl-test", "object": "chat.completion", "model": "mock-goar",
				"choices": []map[string]any{{
					"index": 0,
					"message": map[string]any{
						"role": "assistant", "content": text,
					},
					"finish_reason": "stop",
				}},
				"usage": map[string]any{"prompt_tokens": 8, "completion_tokens": 8, "total_tokens": 16},
			})
		default:
			http.NotFound(w, r)
		}
	}))
	t.Cleanup(srv.Close)

	home := t.TempDir()
	t.Setenv("AGENT_HOME", home)
	t.Setenv("OPENAI_API_KEY", "mock")
	t.Setenv("COLORTERM", "truecolor")

	cfg := &config.Config{
		ActiveModel:           "mock-goar",
		Theme:                 "goar-dark",
		SystemPromptID:        "cli",
		APITimeout:            30,
		BypassToolPermissions: true,
		DefaultAgent:          "chat",
		IncludeProjectContext: false,
		Providers: []config.ProviderConfig{{
			Name: "mock", APIBase: srv.URL + "/v1", APIKeyEnvVar: "OPENAI_API_KEY",
			APIStyle: "openai", Backend: "generic",
		}},
		Models: []config.ModelConfig{{
			Name: "mock-goar", Provider: "mock", Alias: "mock-goar", Temperature: 0, Thinking: "off",
		}},
		SessionLogging: config.SessionLoggingConfig{
			Enabled: true, SaveDir: filepath.Join(home, "logs"), SessionPrefix: "live",
		},
	}
	_ = os.MkdirAll(filepath.Join(home, "logs"), 0o755)

	text, err := core.RunProgrammatic(context.Background(), cfg, "ping live mock turn", core.RuntimeOptions{
		AgentName: "chat", Headless: true, MaxTurns: 2,
	})
	if err != nil {
		t.Fatalf("RunProgrammatic: %v", err)
	}
	if !strings.Contains(text, liveMarker) {
		t.Fatalf("expected marker %q in assistant text, got %q", liveMarker, text)
	}
	if !strings.Contains(text, "ping live mock turn") && !strings.Contains(text, "last_user=") {
		t.Fatalf("expected user digest echo, got %q", text)
	}
}
