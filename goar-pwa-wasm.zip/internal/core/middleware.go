package core

import (
	"fmt"
	"strings"

	"github.com/goarxyz/goar/internal/core/agents"
	"github.com/goarxyz/goar/internal/core/config"
	"github.com/goarxyz/goar/internal/core/utils"
)

// MiddlewareAction is the result action of a middleware before-turn hook.
type MiddlewareAction string

const (
	MiddlewareContinue      MiddlewareAction = "continue"
	MiddlewareStop          MiddlewareAction = "stop"
	MiddlewareCompact       MiddlewareAction = "compact"
	MiddlewareInjectMessage MiddlewareAction = "inject_message"
)

// ResetReason explains why middleware state is being reset.
type ResetReason string

const (
	ResetStop    ResetReason = "stop"
	ResetCompact ResetReason = "compact"
)

// ConversationContext is passed to middleware before each turn.
type ConversationContext struct {
	Messages []LLMMessage
	Stats    *AgentStats
	Config   *config.Config
}

// MiddlewareResult is returned by before-turn middleware.
type MiddlewareResult struct {
	Action   MiddlewareAction
	Message  string
	Reason   string
	Metadata map[string]any
}

// ConversationMiddleware inspects/modifies conversation turns.
type ConversationMiddleware interface {
	Name() string
	BeforeTurn(ctx ConversationContext) MiddlewareResult
	Reset(reason ResetReason)
}

// Middleware is the legacy simple interface kept for Max* helpers.
type Middleware interface {
	Name() string
	BeforeTurn(messages []LLMMessage, stats *AgentStats) (stop bool, reason string)
	AfterTurn(messages []LLMMessage, stats *AgentStats) error
}

// MaxTurnsMiddleware stops after N assistant turns (legacy).
type MaxTurnsMiddleware struct{ Max int }

func (m MaxTurnsMiddleware) Name() string { return "max_turns" }
func (m MaxTurnsMiddleware) BeforeTurn(_ []LLMMessage, stats *AgentStats) (bool, string) {
	// Align with TurnLimitMiddleware: Steps is incremented before the first LLM
	// call (user message) and again before each LLM turn, so Steps-1 is the
	// count of completed/started LLM turns. max-turns=1 must allow exactly one.
	if m.Max > 0 && stats != nil && stats.Steps-1 >= m.Max {
		return true, fmt.Sprintf("max turns reached (%d)", m.Max)
	}
	return false, ""
}
func (m MaxTurnsMiddleware) AfterTurn([]LLMMessage, *AgentStats) error { return nil }

// MaxPriceMiddleware stops when session cost exceeds dollars (legacy).
type MaxPriceMiddleware struct{ Max float64 }

func (m MaxPriceMiddleware) Name() string { return "max_price" }
func (m MaxPriceMiddleware) BeforeTurn(_ []LLMMessage, stats *AgentStats) (bool, string) {
	if m.Max > 0 && stats.SessionCost() >= m.Max {
		return true, fmt.Sprintf("max price reached ($%.4f)", stats.SessionCost())
	}
	return false, ""
}
func (m MaxPriceMiddleware) AfterTurn([]LLMMessage, *AgentStats) error { return nil }

// MaxTokensMiddleware stops when total tokens exceed N (legacy).
type MaxTokensMiddleware struct{ Max int }

func (m MaxTokensMiddleware) Name() string { return "max_tokens" }
func (m MaxTokensMiddleware) BeforeTurn(_ []LLMMessage, stats *AgentStats) (bool, string) {
	if m.Max > 0 && stats.SessionTotalLLMTokens() >= m.Max {
		return true, fmt.Sprintf("max tokens reached (%d)", m.Max)
	}
	return false, ""
}
func (m MaxTokensMiddleware) AfterTurn([]LLMMessage, *AgentStats) error { return nil }

// TurnLimitMiddleware stops when stats.Steps-1 >= maxTurns.
type TurnLimitMiddleware struct{ MaxTurns int }

func (m *TurnLimitMiddleware) Name() string { return "turn_limit" }
func (m *TurnLimitMiddleware) BeforeTurn(ctx ConversationContext) MiddlewareResult {
	if ctx.Stats != nil && ctx.Stats.Steps-1 >= m.MaxTurns {
		return MiddlewareResult{
			Action: MiddlewareStop,
			Reason: fmt.Sprintf("Turn limit of %d reached", m.MaxTurns),
		}
	}
	return MiddlewareResult{Action: MiddlewareContinue}
}
func (m *TurnLimitMiddleware) Reset(ResetReason) {}

// PriceLimitMiddleware stops when session cost exceeds maxPrice.
type PriceLimitMiddleware struct{ MaxPrice float64 }

func (m *PriceLimitMiddleware) Name() string { return "price_limit" }
func (m *PriceLimitMiddleware) BeforeTurn(ctx ConversationContext) MiddlewareResult {
	if ctx.Stats != nil && ctx.Stats.SessionCost() > m.MaxPrice {
		return MiddlewareResult{
			Action: MiddlewareStop,
			Reason: fmt.Sprintf("Price limit exceeded: $%.4f > $%.2f", ctx.Stats.SessionCost(), m.MaxPrice),
		}
	}
	return MiddlewareResult{Action: MiddlewareContinue}
}
func (m *PriceLimitMiddleware) Reset(ResetReason) {}

// TokenLimitMiddleware stops when session LLM tokens exceed maxTokens.
type TokenLimitMiddleware struct{ MaxTokens int }

func (m *TokenLimitMiddleware) Name() string { return "token_limit" }
func (m *TokenLimitMiddleware) BeforeTurn(ctx ConversationContext) MiddlewareResult {
	if ctx.Stats != nil && ctx.Stats.SessionTotalLLMTokens() > m.MaxTokens {
		return MiddlewareResult{
			Action: MiddlewareStop,
			Reason: fmt.Sprintf("Token limit exceeded: %d > %d", ctx.Stats.SessionTotalLLMTokens(), m.MaxTokens),
		}
	}
	return MiddlewareResult{Action: MiddlewareContinue}
}
func (m *TokenLimitMiddleware) Reset(ResetReason) {}

// AutoCompactMiddleware requests compaction when context tokens hit the model threshold.
type AutoCompactMiddleware struct{}

func (m *AutoCompactMiddleware) Name() string { return "auto_compact" }
func (m *AutoCompactMiddleware) BeforeTurn(ctx ConversationContext) MiddlewareResult {
	if ctx.Config == nil || ctx.Stats == nil {
		return MiddlewareResult{Action: MiddlewareContinue}
	}
	model, err := ctx.Config.GetActiveModel()
	if err != nil {
		return MiddlewareResult{Action: MiddlewareContinue}
	}
	threshold := model.AutoCompactThreshold
	if threshold > 0 && ctx.Stats.ContextTokens >= threshold {
		return MiddlewareResult{
			Action: MiddlewareCompact,
			Metadata: map[string]any{
				"old_tokens": ctx.Stats.ContextTokens,
				"threshold":  threshold,
			},
		}
	}
	return MiddlewareResult{Action: MiddlewareContinue}
}
func (m *AutoCompactMiddleware) Reset(ResetReason) {}

// ContextWarningMiddleware injects a one-shot warning when context crosses a fraction of the threshold.
type ContextWarningMiddleware struct {
	ThresholdPercent float64
	hasWarned        bool
}

func NewContextWarningMiddleware(thresholdPercent float64) *ContextWarningMiddleware {
	if thresholdPercent <= 0 {
		thresholdPercent = 0.5
	}
	return &ContextWarningMiddleware{ThresholdPercent: thresholdPercent}
}

func (m *ContextWarningMiddleware) Name() string { return "context_warning" }
func (m *ContextWarningMiddleware) BeforeTurn(ctx ConversationContext) MiddlewareResult {
	if m.hasWarned || ctx.Config == nil || ctx.Stats == nil {
		return MiddlewareResult{Action: MiddlewareContinue}
	}
	model, err := ctx.Config.GetActiveModel()
	if err != nil {
		return MiddlewareResult{Action: MiddlewareContinue}
	}
	maxContext := model.AutoCompactThreshold
	if maxContext <= 0 {
		return MiddlewareResult{Action: MiddlewareContinue}
	}
	if ctx.Stats.ContextTokens >= int(float64(maxContext)*m.ThresholdPercent) {
		m.hasWarned = true
		pct := (float64(ctx.Stats.ContextTokens) / float64(maxContext)) * 100
		msg := fmt.Sprintf("<%s>You have used %.0f%% of your total context (%d/%d tokens)</%s>",
			utils.GoarWarningTag, pct, ctx.Stats.ContextTokens, maxContext, utils.GoarWarningTag)
		return MiddlewareResult{Action: MiddlewareInjectMessage, Message: msg}
	}
	return MiddlewareResult{Action: MiddlewareContinue}
}
func (m *ContextWarningMiddleware) Reset(ResetReason) { m.hasWarned = false }

// MakePlanAgentReminder builds the plan-mode reminder injected by ReadOnlyAgentMiddleware.
func MakePlanAgentReminder(planFilePath string, hasAskUserQuestion, hasExitPlanMode bool) string {
	instructions := []string{
		"Research the user's query using read-only tools (grep, read_file, etc.)",
	}
	if hasAskUserQuestion {
		instructions = append(instructions,
			"If you are unsure about requirements or approach, use the ask_user_question tool to clarify before finalizing your plan")
	}
	instructions = append(instructions, "Write your plan to the plan file above")
	if hasExitPlanMode {
		instructions = append(instructions,
			"When your plan is complete, call the exit_plan_mode tool to request user approval and switch to implementation mode")
	} else {
		instructions = append(instructions,
			"When your plan is complete, present it to the user and tell them to switch modes if they approve the plan")
	}
	var numbered strings.Builder
	for i, step := range instructions {
		if i > 0 {
			numbered.WriteByte('\n')
		}
		numbered.WriteString(fmt.Sprintf("%d. %s", i+1, step))
	}
	return fmt.Sprintf(`<%s>Plan mode is active. You MUST NOT make any edits (except to the plan file below, or in your scratchpad), run any non-readonly tools (including changing configs or making commits), or otherwise make any changes to the system. This supersedes any other instructions you have received.

## Plan File Info
Create or edit your plan at %s using the write_file and search_replace tools.
Build your plan incrementally by writing to or editing this file.
This is the only file you are allowed to edit. Make sure to create it early and edit as soon as you internally update your plan.

## Instructions
%s</%s>`, utils.GoarWarningTag, planFilePath, numbered.String(), utils.GoarWarningTag)
}

// PlanAgentExit is injected when leaving plan mode.
var PlanAgentExit = fmt.Sprintf("<%s>Plan mode has ended. If you have a plan ready, you can now start executing it. If not, you can now use editing tools and make changes to the system.</%s>",
	utils.GoarWarningTag, utils.GoarWarningTag)

// ChatAgentReminder is injected when entering chat mode.
var ChatAgentReminder = fmt.Sprintf(`<%s>Chat mode is active. The user wants to have a conversation -- ask questions, get explanations, or discuss code and architecture. You MUST NOT make any edits, run any non-readonly tools, or otherwise make any changes to the system. This supersedes any other instructions you have received. Instead, you should:
1. Answer the user's questions directly and comprehensively
2. Explain code, concepts, or architecture as requested
3. Use read-only tools (grep, read_file) to look up relevant code when needed
4. Focus on being informative and conversational -- your response IS the deliverable, not a precursor to action</%s>`,
	utils.GoarWarningTag, utils.GoarWarningTag)

// ChatAgentExit is injected when leaving chat mode.
var ChatAgentExit = fmt.Sprintf("<%s>Chat mode has ended. You can now use editing tools and make changes to the system.</%s>",
	utils.GoarWarningTag, utils.GoarWarningTag)

// ReadOnlyAgentMiddleware injects enter/exit reminders when an agent profile activates.
type ReadOnlyAgentMiddleware struct {
	ProfileGetter func() agents.AgentProfile
	AgentName     string
	Reminder      string
	ReminderFn    func() string
	ExitMessage   string
	wasActive     bool
}

func (m *ReadOnlyAgentMiddleware) Name() string { return "readonly_agent_" + m.AgentName }

func (m *ReadOnlyAgentMiddleware) reminder() string {
	if m.ReminderFn != nil {
		return m.ReminderFn()
	}
	return m.Reminder
}

func (m *ReadOnlyAgentMiddleware) isActive() bool {
	if m.ProfileGetter == nil {
		return false
	}
	return m.ProfileGetter().Name == m.AgentName
}

func (m *ReadOnlyAgentMiddleware) BeforeTurn(ctx ConversationContext) MiddlewareResult {
	_ = ctx
	isActive := m.isActive()
	wasActive := m.wasActive
	if wasActive && !isActive {
		m.wasActive = false
		return MiddlewareResult{Action: MiddlewareInjectMessage, Message: m.ExitMessage}
	}
	if isActive && !wasActive {
		m.wasActive = true
		return MiddlewareResult{Action: MiddlewareInjectMessage, Message: m.reminder()}
	}
	m.wasActive = isActive
	return MiddlewareResult{Action: MiddlewareContinue}
}

func (m *ReadOnlyAgentMiddleware) Reset(ResetReason) { m.wasActive = false }

// MiddlewarePipeline runs ConversationMiddleware in order.
type MiddlewarePipeline struct {
	Items   []ConversationMiddleware
	Legacy  []Middleware
}

// Add appends a ConversationMiddleware.
func (p *MiddlewarePipeline) Add(m ConversationMiddleware) *MiddlewarePipeline {
	p.Items = append(p.Items, m)
	return p
}

// AddLegacy appends a legacy Middleware (used by NewRuntime for Max* helpers).
func (p *MiddlewarePipeline) AddLegacy(m Middleware) *MiddlewarePipeline {
	p.Legacy = append(p.Legacy, m)
	return p
}

// Clear removes all middleware.
func (p *MiddlewarePipeline) Clear() {
	p.Items = nil
	p.Legacy = nil
}

// Reset resets all ConversationMiddleware state.
func (p *MiddlewarePipeline) Reset(reason ResetReason) {
	for _, mw := range p.Items {
		mw.Reset(reason)
	}
}

// BeforeTurn runs legacy middleware; returns stop for Max* helpers.
func (p *MiddlewarePipeline) BeforeTurn(messages []LLMMessage, stats *AgentStats) (stop bool, reason string) {
	for _, m := range p.Legacy {
		if stop, reason = m.BeforeTurn(messages, stats); stop {
			return true, reason
		}
	}
	return false, ""
}

// AfterTurn runs legacy AfterTurn hooks.
func (p *MiddlewarePipeline) AfterTurn(messages []LLMMessage, stats *AgentStats) error {
	for _, m := range p.Legacy {
		if err := m.AfterTurn(messages, stats); err != nil {
			return err
		}
	}
	return nil
}

// RunBeforeTurn runs ConversationMiddleware and aggregates inject/stop/compact results.
func (p *MiddlewarePipeline) RunBeforeTurn(ctx ConversationContext) MiddlewareResult {
	var inject []string
	for _, mw := range p.Items {
		result := mw.BeforeTurn(ctx)
		switch result.Action {
		case MiddlewareInjectMessage:
			if result.Message != "" {
				inject = append(inject, result.Message)
			}
		case MiddlewareStop, MiddlewareCompact:
			return result
		}
	}
	if len(inject) > 0 {
		return MiddlewareResult{
			Action:  MiddlewareInjectMessage,
			Message: strings.Join(inject, "\n\n"),
		}
	}
	return MiddlewareResult{Action: MiddlewareContinue}
}
