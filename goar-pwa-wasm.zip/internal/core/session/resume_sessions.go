package session

import (
	"fmt"

	"github.com/goarxyz/goar/internal/core/types"
)

// ResumeResult holds a resumed session.
type ResumeResult struct {
	Dir      string
	Metadata *types.SessionMetadata
	Messages []types.LLMMessage
}

// ResumeByID finds and loads a session by id (prefix match allowed).
func ResumeByID(saveDir, id string) (*ResumeResult, error) {
	sessions, err := ListSavedSessions(saveDir)
	if err != nil {
		return nil, err
	}
	for _, s := range sessions {
		if s.SessionID == id || ShortenSessionID(s.SessionID) == id || len(id) >= 4 && len(s.SessionID) >= len(id) && s.SessionID[:len(id)] == id {
			meta, err := LoadMetadata(s.SaveDir)
			if err != nil {
				return nil, err
			}
			msgs, err := LoadMessages(s.SaveDir)
			if err != nil {
				return nil, err
			}
			return &ResumeResult{Dir: s.SaveDir, Metadata: meta, Messages: msgs}, nil
		}
	}
	return nil, fmt.Errorf("session not found: %s", id)
}
