package session

import (
	"bufio"
	"encoding/json"
	"os"
	"path/filepath"
	"sort"
	"strings"
	"time"

	"github.com/goarxyz/goar/internal/core/config"
	"github.com/goarxyz/goar/internal/core/types"
)

const (
	MessagesFilename = "messages.jsonl"
	MetadataFilename = "metadata.json"
)

// SessionListEntry is a listing row for the session picker (Python SessionInfo TypedDict).
type SessionListEntry struct {
	SessionID string
	Path      string
	StartTime string
	Title     string
}

// SessionLoader discovers and loads persisted sessions (Python SessionLoader).
type SessionLoader struct {
	Cfg config.SessionLoggingConfig
}

// NewSessionLoader constructs a loader for the given logging config.
func NewSessionLoader(cfg config.SessionLoggingConfig) *SessionLoader {
	return &SessionLoader{Cfg: cfg}
}

func (l *SessionLoader) isValidSession(dir string) bool {
	metaPath := filepath.Join(dir, MetadataFilename)
	msgPath := filepath.Join(dir, MessagesFilename)
	if _, err := os.Stat(metaPath); err != nil {
		return false
	}
	if _, err := os.Stat(msgPath); err != nil {
		return false
	}
	meta, err := LoadMetadata(dir)
	if err != nil || meta == nil || meta.SessionID == "" {
		return false
	}
	return true
}

// LatestSession returns the most recent valid session directory under saveDir.
func (l *SessionLoader) LatestSession(saveDir string) (string, error) {
	if saveDir == "" {
		saveDir = l.Cfg.SaveDir
	}
	entries, err := l.ListSessions(saveDir)
	if err != nil {
		return "", err
	}
	if len(entries) == 0 {
		return "", os.ErrNotExist
	}
	return entries[0].Path, nil
}

// FindLatestSession is an alias used by resume flows.
func (l *SessionLoader) FindLatestSession() (string, error) {
	return l.LatestSession(l.Cfg.SaveDir)
}

// FindSessionByID locates a session directory by full or short id.
func (l *SessionLoader) FindSessionByID(sessionID string) (string, error) {
	sessionID = strings.TrimSpace(sessionID)
	if sessionID == "" {
		return "", os.ErrNotExist
	}
	entries, err := l.ListSessions(l.Cfg.SaveDir)
	if err != nil {
		return "", err
	}
	for _, e := range entries {
		if e.SessionID == sessionID || strings.HasPrefix(e.SessionID, sessionID) || ShortenSessionID(e.SessionID) == sessionID {
			return e.Path, nil
		}
	}
	// Also search by folder name containing the short id.
	dirs := l.findSessionDirsByShortID(sessionID)
	if len(dirs) == 1 {
		return dirs[0], nil
	}
	if len(dirs) > 1 {
		sort.Slice(dirs, func(i, j int) bool {
			ii, _ := os.Stat(dirs[i])
			jj, _ := os.Stat(dirs[j])
			if ii == nil || jj == nil {
				return dirs[i] > dirs[j]
			}
			return ii.ModTime().After(jj.ModTime())
		})
		return dirs[0], nil
	}
	return "", os.ErrNotExist
}

// DoesSessionExist reports whether a session id resolves.
func (l *SessionLoader) DoesSessionExist(sessionID string) bool {
	_, err := l.FindSessionByID(sessionID)
	return err == nil
}

func (l *SessionLoader) findSessionDirsByShortID(shortID string) []string {
	root := l.Cfg.SaveDir
	entries, err := os.ReadDir(root)
	if err != nil {
		return nil
	}
	var out []string
	for _, e := range entries {
		if !e.IsDir() {
			continue
		}
		name := e.Name()
		if strings.Contains(name, shortID) {
			path := filepath.Join(root, name)
			if l.isValidSession(path) {
				out = append(out, path)
			}
		}
	}
	return out
}

func convertToUTCISO(dateStr string) string {
	dateStr = strings.TrimSpace(dateStr)
	if dateStr == "" {
		return ""
	}
	for _, layout := range []string{time.RFC3339Nano, time.RFC3339, "2006-01-02T15:04:05", "20060102_150405"} {
		if t, err := time.Parse(layout, dateStr); err == nil {
			return t.UTC().Format(time.RFC3339Nano)
		}
	}
	return dateStr
}

// ListSessions returns valid sessions newest-first.
func (l *SessionLoader) ListSessions(saveDir string) ([]SessionListEntry, error) {
	if saveDir == "" {
		saveDir = l.Cfg.SaveDir
	}
	entries, err := os.ReadDir(saveDir)
	if err != nil {
		if os.IsNotExist(err) {
			return nil, nil
		}
		return nil, err
	}
	var out []SessionListEntry
	for _, e := range entries {
		if !e.IsDir() {
			continue
		}
		path := filepath.Join(saveDir, e.Name())
		if !l.isValidSession(path) {
			continue
		}
		meta, err := LoadMetadata(path)
		if err != nil {
			continue
		}
		title := ""
		if meta.Title != nil {
			title = *meta.Title
		}
		out = append(out, SessionListEntry{
			SessionID: meta.SessionID,
			Path:      path,
			StartTime: convertToUTCISO(meta.StartTime),
			Title:     title,
		})
	}
	sort.Slice(out, func(i, j int) bool {
		return out[i].StartTime > out[j].StartTime
	})
	return out, nil
}

// LoadMetadata reads session metadata.
func LoadMetadata(dir string) (*types.SessionMetadata, error) {
	b, err := os.ReadFile(filepath.Join(dir, MetadataFilename))
	if err != nil {
		return nil, err
	}
	var m types.SessionMetadata
	if err := json.Unmarshal(b, &m); err != nil {
		return nil, err
	}
	return &m, nil
}

// LoadMessages reads JSONL messages.
func LoadMessages(dir string) ([]types.LLMMessage, error) {
	f, err := os.Open(filepath.Join(dir, MessagesFilename))
	if err != nil {
		return nil, err
	}
	defer f.Close()
	sc := bufio.NewScanner(f)
	sc.Buffer(make([]byte, 0, 64*1024), 10*1024*1024)
	var out []types.LLMMessage
	for sc.Scan() {
		line := strings.TrimSpace(sc.Text())
		if line == "" {
			continue
		}
		var m types.LLMMessage
		if err := json.Unmarshal([]byte(line), &m); err != nil {
			continue
		}
		m.Content = cleanContentPtr(m.Content)
		out = append(out, m)
	}
	return out, sc.Err()
}

func cleanText(text string) string {
	return strings.TrimSpace(strings.ReplaceAll(text, "\x00", ""))
}

func cleanContentPtr(c *string) *string {
	if c == nil {
		return nil
	}
	s := cleanText(*c)
	return &s
}

func extractTextFromContent(content *string) string {
	if content == nil {
		return ""
	}
	return cleanText(*content)
}

// GetFirstUserMessage returns the first non-injected user message text for a session.
func GetFirstUserMessage(sessionID string, cfg config.SessionLoggingConfig) string {
	loader := NewSessionLoader(cfg)
	dir, err := loader.FindSessionByID(sessionID)
	if err != nil {
		return ""
	}
	msgs, err := LoadMessages(dir)
	if err != nil {
		return ""
	}
	for _, m := range msgs {
		if m.Role == types.RoleUser && !m.Injected {
			return extractTextFromContent(m.Content)
		}
	}
	return ""
}
