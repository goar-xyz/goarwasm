package session

import (
	"os"
	"path/filepath"
	"regexp"
	"strings"

	"github.com/goarxyz/goar/internal/core/config"
	"github.com/goarxyz/goar/internal/core/paths"
)

// PointerDirName is the directory under save_dir holding per-TTY pointers (Python POINTER_DIR_NAME).
const PointerDirName = ".last_session"

var keySanitizer = regexp.MustCompile(`[^A-Za-z0-9._-]+`)

func sanitizeKey(raw string) string {
	cleaned := strings.Trim(keySanitizer.ReplaceAllString(raw, "_"), "_")
	if cleaned == "" {
		return "unknown"
	}
	return cleaned
}

// CurrentTTYKey returns a sanitized TTY identifier for the current process, or "".
func CurrentTTYKey() string {
	for _, f := range []*os.File{os.Stdin, os.Stdout, os.Stderr} {
		if f == nil {
			continue
		}
		name, err := ttyName(f)
		if err != nil || name == "" {
			continue
		}
		return sanitizeKey(filepath.Base(name))
	}
	// Fallbacks similar to Windows path in Python.
	if wt := os.Getenv("WT_SESSION"); wt != "" {
		return sanitizeKey("wt-" + wt)
	}
	return sanitizeKey("ppid-" + itoa(os.Getppid()))
}

func itoa(n int) string {
	if n == 0 {
		return "0"
	}
	neg := n < 0
	if neg {
		n = -n
	}
	var b [20]byte
	i := len(b)
	for n > 0 {
		i--
		b[i] = byte('0' + n%10)
		n /= 10
	}
	if neg {
		i--
		b[i] = '-'
	}
	return string(b[i:])
}

func ttyName(f *os.File) (string, error) {
	// Best-effort: /proc/self/fd/N symlink on Linux.
	link := filepath.Join("/proc/self/fd", itoa(int(f.Fd())))
	target, err := os.Readlink(link)
	if err != nil {
		return "", err
	}
	if strings.HasPrefix(target, "/dev/") {
		return target, nil
	}
	return "", os.ErrNotExist
}

func pointerDir(cfg config.SessionLoggingConfig) string {
	dir := cfg.SaveDir
	if dir == "" {
		dir = paths.SessionLogDir()
	}
	return filepath.Join(dir, PointerDirName)
}

func pointerPath(cfg config.SessionLoggingConfig, ttyKey string) string {
	return filepath.Join(pointerDir(cfg), ttyKey)
}

// RecordLastSessionPointer writes the session id for the current TTY (Python record).
func RecordLastSessionPointer(cfg config.SessionLoggingConfig, sessionID string) {
	if sessionID == "" || !cfg.Enabled {
		return
	}
	ttyKey := CurrentTTYKey()
	if ttyKey == "" {
		return
	}
	path := pointerPath(cfg, ttyKey)
	_ = os.MkdirAll(filepath.Dir(path), 0o755)
	_ = os.WriteFile(path, []byte(sessionID+"\n"), 0o644)
}

// LoadLastSessionPointer reads the session id for the current TTY (Python load).
func LoadLastSessionPointer(cfg config.SessionLoggingConfig) string {
	if !cfg.Enabled {
		return ""
	}
	ttyKey := CurrentTTYKey()
	if ttyKey == "" {
		return ""
	}
	path := pointerPath(cfg, ttyKey)
	b, err := os.ReadFile(path)
	if err != nil {
		return ""
	}
	return strings.TrimSpace(string(b))
}

// LastSessionPointerFile is ~/.agent/last_session (legacy single-pointer file).
func LastSessionPointerFile() string {
	return filepath.Join(paths.Home(), "last_session")
}

// WriteLastSession stores the last session directory path (legacy API used by runtime).
func WriteLastSession(dir string) error {
	_ = paths.EnsureHome()
	return os.WriteFile(LastSessionPointerFile(), []byte(dir+"\n"), 0o644)
}

// ReadLastSession returns the last session directory (legacy API).
func ReadLastSession() (string, error) {
	b, err := os.ReadFile(LastSessionPointerFile())
	if err != nil {
		return "", err
	}
	return strings.TrimSpace(string(b)), nil
}
