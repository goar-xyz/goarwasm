package session

import (
	"os"
	"path/filepath"

	"github.com/goarxyz/goar/internal/core/config"
)

// MigrateSessionsEntrypoint performs lightweight session dir migrations.
func MigrateSessionsEntrypoint(cfg config.SessionLoggingConfig) {
	if !cfg.Enabled || cfg.SaveDir == "" {
		return
	}
	_ = os.MkdirAll(cfg.SaveDir, 0o755)
	// Migrate legacy messages.json → messages.jsonl if present
	entries, err := os.ReadDir(cfg.SaveDir)
	if err != nil {
		return
	}
	for _, e := range entries {
		if !e.IsDir() {
			continue
		}
		dir := filepath.Join(cfg.SaveDir, e.Name())
		legacy := filepath.Join(dir, "messages.json")
		target := filepath.Join(dir, MessagesFilename)
		if _, err := os.Stat(legacy); err == nil {
			if _, err := os.Stat(target); os.IsNotExist(err) {
				_ = os.Rename(legacy, target)
			}
		}
	}
}
