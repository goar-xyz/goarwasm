package session

import (
	"encoding/json"
	"os"
	"path/filepath"
	"strings"

	"github.com/goarxyz/goar/internal/core/config"
	"github.com/goarxyz/goar/internal/core/types"
)

// FindSessionByID locates a session directory by id under save_dir (optionally cwd-scoped).
func FindSessionByID(id string, cfg config.SessionLoggingConfig, workingDirectory string) string {
	if id == "" {
		return ""
	}
	root := cfg.SaveDir
	if root == "" {
		return ""
	}
	// direct match
	entries, err := os.ReadDir(root)
	if err != nil {
		return ""
	}
	for _, e := range entries {
		if !e.IsDir() {
			continue
		}
		name := e.Name()
		if name == id || strings.Contains(name, id) {
			dir := filepath.Join(root, name)
			if workingDirectory != "" && !sessionMatchesCWD(dir, workingDirectory) {
				continue
			}
			return dir
		}
	}
	return ""
}

// FindLatestSession returns the most recently modified session dir.
func FindLatestSession(cfg config.SessionLoggingConfig, workingDirectory string) string {
	root := cfg.SaveDir
	entries, err := os.ReadDir(root)
	if err != nil {
		return ""
	}
	var best string
	var bestMod int64
	for _, e := range entries {
		if !e.IsDir() {
			continue
		}
		dir := filepath.Join(root, e.Name())
		if workingDirectory != "" && !sessionMatchesCWD(dir, workingDirectory) {
			continue
		}
		info, err := e.Info()
		if err != nil {
			continue
		}
		mod := info.ModTime().UnixNano()
		if mod > bestMod {
			bestMod = mod
			best = dir
		}
	}
	return best
}

func sessionMatchesCWD(dir, cwd string) bool {
	metaPath := filepath.Join(dir, "metadata.json")
	b, err := os.ReadFile(metaPath)
	if err != nil {
		return true // don't exclude if unknown
	}
	var meta map[string]any
	if err := json.Unmarshal(b, &meta); err != nil {
		return true
	}
	wd, _ := meta["working_directory"].(string)
	if wd == "" {
		return true
	}
	return filepath.Clean(wd) == filepath.Clean(cwd)
}

// LoadSession loads messages + raw metadata map from a session directory.
func LoadSession(dir string) ([]types.LLMMessage, map[string]any, error) {
	msgs, err := LoadMessages(dir)
	if err != nil {
		return nil, nil, err
	}
	meta := map[string]any{}
	b, err := os.ReadFile(filepath.Join(dir, "metadata.json"))
	if err == nil {
		_ = json.Unmarshal(b, &meta)
	}
	return msgs, meta, nil
}
