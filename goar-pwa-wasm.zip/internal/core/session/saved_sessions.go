package session

import (
	"os"
	"path/filepath"
	"sort"

	"github.com/goarxyz/goar/internal/core/types"
)

// ListSavedSessions lists session dirs under saveDir.
func ListSavedSessions(saveDir string) ([]types.SessionInfo, error) {
	entries, err := os.ReadDir(saveDir)
	if err != nil {
		if os.IsNotExist(err) {
			return nil, nil
		}
		return nil, err
	}
	var out []types.SessionInfo
	for _, e := range entries {
		if !e.IsDir() {
			continue
		}
		dir := filepath.Join(saveDir, e.Name())
		meta, err := LoadMetadata(dir)
		if err != nil {
			continue
		}
		msgs, _ := LoadMessages(dir)
		out = append(out, types.SessionInfo{
			SessionID: meta.SessionID, StartTime: meta.StartTime,
			MessageCount: len(msgs), SaveDir: dir,
		})
	}
	sort.Slice(out, func(i, j int) bool { return out[i].StartTime > out[j].StartTime })
	return out, nil
}
