package session

import (
	"strings"
	"unicode/utf8"
)

// MaxTitleLength is the max auto title length.
const MaxTitleLength = 80

// FormatTitle cleans and truncates a title.
func FormatTitle(s string) string {
	s = strings.TrimSpace(strings.ReplaceAll(s, "\n", " "))
	for strings.Contains(s, "  ") {
		s = strings.ReplaceAll(s, "  ", " ")
	}
	if utf8.RuneCountInString(s) > MaxTitleLength {
		r := []rune(s)
		s = string(r[:MaxTitleLength-1]) + "…"
	}
	return s
}

// AutoTitleFromPrompt derives a title from the first user prompt.
func AutoTitleFromPrompt(prompt string) string {
	return FormatTitle(prompt)
}
