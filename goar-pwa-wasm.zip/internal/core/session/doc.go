// Package session handles session IDs, persistence, resume, and titles.
package session
