package session

import (
	"crypto/rand"
	"encoding/hex"
	"fmt"
	"strings"
)

// GenerateSessionID creates a new random session id.
func GenerateSessionID() string {
	return GenerateSessionIDWithSuffix("")
}

// GenerateSessionIDWithSuffix creates a session id, optionally preserving a suffix after "--".
func GenerateSessionIDWithSuffix(suffix string) string {
	b := make([]byte, 16)
	_, _ = rand.Read(b)
	id := hex.EncodeToString(b)
	suffix = strings.TrimSpace(suffix)
	if suffix != "" {
		return id + "--" + suffix
	}
	return id
}

// ExtractSuffix returns the portion after "--" in a session id, if any.
func ExtractSuffix(id string) string {
	if i := strings.Index(id, "--"); i >= 0 && i+2 < len(id) {
		return id[i+2:]
	}
	return ""
}

// ShortenSessionID returns a short display form.
func ShortenSessionID(id string) string {
	base := id
	if i := strings.Index(id, "--"); i >= 0 {
		base = id[:i]
	}
	if len(base) <= 8 {
		return base
	}
	return base[:8]
}

// FormatSessionFolder builds session_YYYYMMDD_HHMMSS_shortid.
func FormatSessionFolder(prefix, timestamp, id string) string {
	return fmt.Sprintf("%s_%s_%s", prefix, timestamp, ShortenSessionID(id))
}
