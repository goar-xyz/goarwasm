package session

import (
	"encoding/json"
	"os"
	"os/user"
	"path/filepath"
	"sync"
	"time"

	"github.com/goarxyz/goar/internal/core/types"
	"github.com/goarxyz/goar/internal/core/config"
	"github.com/goarxyz/goar/internal/core/utils"
)

// Logger persists session metadata and messages.
type Logger struct {
	mu       sync.Mutex
	Enabled  bool
	SaveDir  string
	Prefix   string
	ID       string
	Start    string
	Dir      string
	Metadata *types.SessionMetadata
}

// NewLogger creates a session logger.
func NewLogger(cfg config.SessionLoggingConfig, id string) *Logger {
	l := &Logger{Enabled: cfg.Enabled, SaveDir: cfg.SaveDir, Prefix: cfg.SessionPrefix, ID: id}
	if !l.Enabled {
		l.ID = "disabled"
		return l
	}
	if l.Prefix == "" {
		l.Prefix = "session"
	}
	l.Start = utils.UTCNowISO()
	_ = os.MkdirAll(l.SaveDir, 0o755)
	ts := time.Now().UTC().Format("20060102_150405")
	l.Dir = filepath.Join(l.SaveDir, FormatSessionFolder(l.Prefix, ts, id))
	_ = os.MkdirAll(l.Dir, 0o755)
	l.Metadata = l.initMetadata()
	_ = l.SaveMetadata()
	return l
}

func (l *Logger) initMetadata() *types.SessionMetadata {
	u := ""
	if uu, err := user.Current(); err == nil {
		u = uu.Username
	}
	return &types.SessionMetadata{
		SessionID: l.ID, StartTime: l.Start, Username: u,
		Environment: map[string]string{}, TitleSource: "auto", Loops: []types.ScheduledLoop{},
	}
}

// SaveMetadata writes metadata.json.
func (l *Logger) SaveMetadata() error {
	if !l.Enabled || l.Metadata == nil {
		return nil
	}
	l.mu.Lock()
	defer l.mu.Unlock()
	b, err := json.MarshalIndent(l.Metadata, "", "  ")
	if err != nil {
		return err
	}
	return os.WriteFile(filepath.Join(l.Dir, MetadataFilename), b, 0o644)
}

// AppendMessage appends a message as JSONL.
func (l *Logger) AppendMessage(msg types.LLMMessage) error {
	if !l.Enabled {
		return nil
	}
	l.mu.Lock()
	defer l.mu.Unlock()
	f, err := os.OpenFile(filepath.Join(l.Dir, MessagesFilename), os.O_CREATE|os.O_APPEND|os.O_WRONLY, 0o644)
	if err != nil {
		return err
	}
	defer f.Close()
	enc := json.NewEncoder(f)
	return enc.Encode(msg)
}

// SetTitle updates the session title.
func (l *Logger) SetTitle(title, source string) error {
	if l.Metadata == nil {
		return nil
	}
	t := FormatTitle(title)
	l.Metadata.Title = &t
	l.Metadata.TitleSource = source
	return l.SaveMetadata()
}

// SessionDir returns the session directory.
func (l *Logger) SessionDir() string { return l.Dir }

// SessionMetadata returns the current metadata pointer.
func (l *Logger) SessionMetadata() *types.SessionMetadata { return l.Metadata }

// ResumeExistingSession re-points the logger at an existing session directory.
func (l *Logger) ResumeExistingSession(sessionID, sessionPath string) error {
	if sessionID != "" {
		l.ID = sessionID
	}
	if sessionPath != "" {
		l.Dir = sessionPath
	}
	return nil
}

// NeedsInitialAutoTitle reports whether a title has not been set yet.
func (l *Logger) NeedsInitialAutoTitle() bool {
	return l.Metadata == nil || l.Metadata.Title == nil || *l.Metadata.Title == ""
}

// SetInitialAutoTitle derives a title from the first user prompt.
func (l *Logger) SetInitialAutoTitle(prompt string) error {
	return l.SetTitle(AutoTitleFromPrompt(prompt), "auto")
}

// PersistMessages writes the full message list (overwrite).
func (l *Logger) PersistMessages(msgs []types.LLMMessage) error {
	l.mu.Lock()
	defer l.mu.Unlock()
	if !l.Enabled {
		return nil
	}
	path := filepath.Join(l.Dir, "messages.jsonl")
	f, err := os.Create(path)
	if err != nil {
		return err
	}
	defer f.Close()
	enc := json.NewEncoder(f)
	for _, m := range msgs {
		if err := enc.Encode(m); err != nil {
			return err
		}
	}
	return nil
}

// PersistMetadata is an alias for SaveMetadata.
func (l *Logger) PersistMetadata() error { return l.SaveMetadata() }

// SaveInteraction persists a user/assistant turn pair.
func (l *Logger) SaveInteraction(user, assistant types.LLMMessage) error {
	if err := l.AppendMessage(user); err != nil {
		return err
	}
	return l.AppendMessage(assistant)
}

// FallbackTitleFromMessages picks a title from the first user message.
func FallbackTitleFromMessages(msgs []types.LLMMessage) string {
	for _, m := range msgs {
		if m.Role == types.RoleUser {
			return AutoTitleFromPrompt(m.ContentString())
		}
	}
	return "session"
}

// Username returns the current OS user for metadata.
func Username() string {
	if u, err := user.Current(); err == nil {
		return u.Username
	}
	return ""
}




// ResetSession starts a new session id under the same logging config, optionally linking a parent.
func (l *Logger) ResetSession(sessionID string, parentSessionID string) error {
	cfg := config.SessionLoggingConfig{Enabled: l.Enabled, SaveDir: l.SaveDir, SessionPrefix: l.Prefix}
	nl := NewLogger(cfg, sessionID)
	// Copy fields without copying the embedded mutex.
	l.Enabled = nl.Enabled
	l.SaveDir = nl.SaveDir
	l.Prefix = nl.Prefix
	l.ID = nl.ID
	l.Start = nl.Start
	l.Dir = nl.Dir
	l.Metadata = nl.Metadata
	if parentSessionID != "" && l.Metadata != nil {
		ps := parentSessionID
		l.Metadata.ParentSessionID = &ps
		return l.SaveMetadata()
	}
	return nil
}
