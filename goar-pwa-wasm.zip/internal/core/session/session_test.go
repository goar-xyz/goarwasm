package session

import (
	"testing"

	"github.com/goarxyz/goar/internal/core/config"
	"github.com/goarxyz/goar/internal/core/types"
)

func TestSessionLoggerRoundTrip(t *testing.T) {
	dir := t.TempDir()
	cfg := config.SessionLoggingConfig{SaveDir: dir, SessionPrefix: "session", Enabled: true}
	id := GenerateSessionID()
	l := NewLogger(cfg, id)
	msg := types.NewMessage(types.RoleUser, "hello")
	if err := l.AppendMessage(msg); err != nil {
		t.Fatal(err)
	}
	if err := l.SetTitle("hello world", "auto"); err != nil {
		t.Fatal(err)
	}
	msgs, err := LoadMessages(l.SessionDir())
	if err != nil {
		t.Fatal(err)
	}
	if len(msgs) != 1 {
		t.Fatalf("got %d", len(msgs))
	}
	meta, err := LoadMetadata(l.SessionDir())
	if err != nil {
		t.Fatal(err)
	}
	if meta.Title == nil || *meta.Title == "" {
		t.Fatal("title missing")
	}
}
