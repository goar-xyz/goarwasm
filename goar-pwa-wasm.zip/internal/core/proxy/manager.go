package proxy

import (
	"fmt"
	"math"
	"net/http"
	"net/url"
	"os"
	"strings"
	"sync"
	"time"
)

// ProxyState tracks health and usage for a single proxy endpoint.
type ProxyState struct {
	Host          string
	Failures      int
	LastFailure   float64
	LastUsed      float64
	LatencyMs     float64
	TotalRequests int
	BannedUntil   float64
}

func (s *ProxyState) IsBanned() bool {
	now := float64(time.Now().UnixNano()) / 1e9
	return now < s.BannedUntil
}

// Score returns a lower-is-better ranking score.
func (s *ProxyState) Score() float64 {
	if s.IsBanned() {
		return math.Inf(1)
	}
	now := float64(time.Now().UnixNano()) / 1e9
	failPenalty := float64(s.Failures) * 500.0
	latPenalty := s.LatencyMs * 2.0
	recencyBonus := (now - s.LastUsed) * 10.0
	return failPenalty + latPenalty - recencyBonus
}

func (s *ProxyState) RecordSuccess(latencyMs float64) {
	s.TotalRequests++
	s.LatencyMs = (s.LatencyMs * 0.7) + (latencyMs * 0.3)
	s.LastUsed = float64(time.Now().UnixNano()) / 1e9
	if s.Failures > 0 {
		s.Failures--
	}
}

func (s *ProxyState) RecordFailure() {
	s.Failures++
	s.LastFailure = float64(time.Now().UnixNano()) / 1e9
	if s.Failures >= 3 {
		exp := s.Failures - 3
		if exp > 4 {
			exp = 4
		}
		s.BannedUntil = float64(time.Now().UnixNano())/1e9 + 60.0*math.Pow(2, float64(exp))
	}
}

// Manager / ProxyManager applies proxy settings with health tracking and rotation.
type Manager struct {
	mu         sync.Mutex
	HTTPProxy  string
	HTTPSProxy string
	NoProxy    string
	user       string
	password   string
	states     []*ProxyState
	sessionMap map[string]*ProxyState
}

// NewManager creates a proxy manager from environment.
func NewManager() *Manager {
	return &Manager{
		HTTPProxy: os.Getenv("HTTP_PROXY"), HTTPSProxy: os.Getenv("HTTPS_PROXY"), NoProxy: os.Getenv("NO_PROXY"),
		sessionMap: map[string]*ProxyState{},
	}
}

// NewProxyManager constructs a rotating proxy manager from a host list.
func NewProxyManager(proxyList []string, user, password string) *Manager {
	m := &Manager{user: user, password: password, sessionMap: map[string]*ProxyState{}}
	for _, h := range proxyList {
		h = strings.TrimSpace(h)
		if h == "" {
			continue
		}
		m.states = append(m.states, &ProxyState{Host: h})
	}
	return m
}

func (m *Manager) encode(s string) string {
	return url.QueryEscape(s)
}

func (m *Manager) urlFor(state *ProxyState) string {
	if m.user != "" && m.password != "" {
		return fmt.Sprintf("http://%s:%s@%s", m.encode(m.user), m.encode(m.password), state.Host)
	}
	return "http://" + state.Host
}

// Pick selects a proxy by strategy (smart|round_robin|least_latency|least_recent).
func (m *Manager) Pick(strategy, sessionID string) *ProxyState {
	m.mu.Lock()
	defer m.mu.Unlock()
	if len(m.states) == 0 {
		return nil
	}
	if sessionID != "" {
		if s, ok := m.sessionMap[sessionID]; ok && !s.IsBanned() {
			return s
		}
	}
	available := make([]*ProxyState, 0, len(m.states))
	for _, s := range m.states {
		if !s.IsBanned() {
			available = append(available, s)
		}
	}
	if len(available) == 0 {
		available = m.states
	}
	var chosen *ProxyState
	switch strategy {
	case "round_robin":
		chosen = available[0]
		for _, s := range available[1:] {
			if s.TotalRequests < chosen.TotalRequests {
				chosen = s
			}
		}
	case "least_latency":
		chosen = available[0]
		for _, s := range available[1:] {
			cl, sl := chosen.LatencyMs, s.LatencyMs
			if cl == 0 {
				cl = 9999
			}
			if sl == 0 {
				sl = 9999
			}
			if sl < cl {
				chosen = s
			}
		}
	case "least_recent":
		chosen = available[0]
		for _, s := range available[1:] {
			if s.LastUsed < chosen.LastUsed {
				chosen = s
			}
		}
	default:
		chosen = available[0]
		for _, s := range available[1:] {
			if s.Score() < chosen.Score() {
				chosen = s
			}
		}
	}
	if sessionID != "" {
		m.sessionMap[sessionID] = chosen
	}
	return chosen
}

// CurrentURL returns the URL for the picked proxy.
func (m *Manager) CurrentURL(sessionID string) string {
	state := m.Pick("smart", sessionID)
	if state == nil {
		return ""
	}
	state.LastUsed = float64(time.Now().UnixNano()) / 1e9
	return m.urlFor(state)
}

// Rotate is an alias for CurrentURL.
func (m *Manager) Rotate(strategy, sessionID string) string {
	_ = strategy
	return m.CurrentURL(sessionID)
}

// MarkSuccess records a successful request against host.
func (m *Manager) MarkSuccess(host string, latencyMs float64) {
	m.mu.Lock()
	defer m.mu.Unlock()
	for _, s := range m.states {
		if s.Host == host {
			s.RecordSuccess(latencyMs)
			return
		}
	}
}

// MarkFailure records a failed request against host.
func (m *Manager) MarkFailure(host string) {
	m.mu.Lock()
	defer m.mu.Unlock()
	for _, s := range m.states {
		if s.Host == host {
			s.RecordFailure()
			return
		}
	}
}

// HasProxies reports whether any proxies are configured.
func (m *Manager) HasProxies() bool {
	m.mu.Lock()
	defer m.mu.Unlock()
	return len(m.states) > 0
}

// CurrentHost returns the currently preferred host or "direct".
func (m *Manager) CurrentHost() string {
	s := m.Pick("smart", "")
	if s == nil {
		return "direct"
	}
	return s.Host
}

// StatusTable renders a human-readable status table.
func (m *Manager) StatusTable() string {
	m.mu.Lock()
	defer m.mu.Unlock()
	lines := []string{"Proxy Status:", strings.Repeat("─", 50)}
	for _, s := range m.states {
		status := "OK"
		if s.IsBanned() {
			status = "BANNED"
		}
		lines = append(lines, fmt.Sprintf("  %-30s  %-6s  f=%d  lat=%.0fms  req=%d",
			s.Host, status, s.Failures, s.LatencyMs, s.TotalRequests))
	}
	return strings.Join(lines, "\n")
}

// HealthCheck probes each proxy against testURL and updates health.
func (m *Manager) HealthCheck(testURL string) map[string]map[string]any {
	if testURL == "" {
		testURL = "https://www.google.com"
	}
	m.mu.Lock()
	states := append([]*ProxyState{}, m.states...)
	m.mu.Unlock()
	results := map[string]map[string]any{}
	client := &http.Client{Timeout: 10 * time.Second}
	for _, state := range states {
		proxyURL := m.urlFor(state)
		t0 := time.Now()
		req, err := http.NewRequest(http.MethodGet, testURL, nil)
		if err != nil {
			state.RecordFailure()
			results[state.Host] = map[string]any{"status": "unhealthy", "error": err.Error()}
			continue
		}
		// Best-effort: set transport proxy when parseable.
		if u, err := url.Parse(proxyURL); err == nil {
			tr := http.DefaultTransport.(*http.Transport).Clone()
			tr.Proxy = http.ProxyURL(u)
			client = &http.Client{Timeout: 10 * time.Second, Transport: tr}
		}
		resp, err := client.Do(req)
		latency := float64(time.Since(t0).Milliseconds())
		if err != nil {
			state.RecordFailure()
			msg := err.Error()
			if len(msg) > 80 {
				msg = msg[:80]
			}
			results[state.Host] = map[string]any{"status": "unhealthy", "error": msg}
			continue
		}
		resp.Body.Close()
		state.RecordSuccess(latency)
		results[state.Host] = map[string]any{"status": "healthy", "latency_ms": math.Round(latency*10) / 10}
	}
	return results
}

// Configure sets process proxy env vars and returns a Transport (env-based manager).
func (m *Manager) Configure(httpProxy, httpsProxy, noProxy string) *http.Transport {
	m.mu.Lock()
	defer m.mu.Unlock()
	m.HTTPProxy, m.HTTPSProxy, m.NoProxy = httpProxy, httpsProxy, noProxy
	if httpProxy != "" {
		_ = os.Setenv("HTTP_PROXY", httpProxy)
		_ = os.Setenv("http_proxy", httpProxy)
	}
	if httpsProxy != "" {
		_ = os.Setenv("HTTPS_PROXY", httpsProxy)
		_ = os.Setenv("https_proxy", httpsProxy)
	}
	if noProxy != "" {
		_ = os.Setenv("NO_PROXY", noProxy)
		_ = os.Setenv("no_proxy", noProxy)
	}
	tr := http.DefaultTransport.(*http.Transport).Clone()
	tr.Proxy = m.proxyFunc()
	return tr
}

func (m *Manager) proxyFunc() func(*http.Request) (*url.URL, error) {
	return func(req *http.Request) (*url.URL, error) {
		if m.HTTPSProxy != "" && req.URL.Scheme == "https" {
			return url.Parse(m.HTTPSProxy)
		}
		if m.HTTPProxy != "" {
			return url.Parse(m.HTTPProxy)
		}
		return http.ProxyFromEnvironment(req)
	}
}

// Status returns current env proxy settings.
func (m *Manager) Status() map[string]string {
	m.mu.Lock()
	defer m.mu.Unlock()
	return map[string]string{"http_proxy": m.HTTPProxy, "https_proxy": m.HTTPSProxy, "no_proxy": m.NoProxy}
}

// BuildHTTPClient returns an HTTP client using the current proxy pick.
func (m *Manager) BuildHTTPClient(sessionID string, timeoutSec float64) *http.Client {
	if timeoutSec <= 0 {
		timeoutSec = 30
	}
	tr := http.DefaultTransport.(*http.Transport).Clone()
	if proxyURL := m.CurrentURL(sessionID); proxyURL != "" {
		if u, err := url.Parse(proxyURL); err == nil {
			tr.Proxy = http.ProxyURL(u)
		}
	} else {
		tr.Proxy = m.proxyFunc()
	}
	return &http.Client{Timeout: time.Duration(timeoutSec * float64(time.Second)), Transport: tr}
}
