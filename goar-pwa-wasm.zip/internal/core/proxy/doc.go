// Package proxy manages HTTP/HTTPS proxy configuration for LLM traffic.
package proxy
