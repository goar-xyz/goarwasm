package core

import (
	"fmt"
	"strings"

	"github.com/goarxyz/goar/internal/core/prompts"
	"github.com/goarxyz/goar/internal/core/utils"
)

// ShouldCompact reports whether context exceeds threshold.
func ShouldCompact(messages []LLMMessage, threshold int) bool {
	if threshold <= 0 {
		return false
	}
	var parts []string
	for _, m := range messages {
		parts = append(parts, m.ContentString())
	}
	return utils.EstimateMessagesTokens(parts) >= threshold
}

// CompactMessages builds a compaction summary prompt and truncated history.
func CompactMessages(messages []LLMMessage) (summaryPrompt string, kept []LLMMessage) {
	prompt, err := prompts.LoadPrompt("compact")
	if err != nil {
		prompt = "Summarize the conversation so far, preserving decisions, file paths, and TODOs."
	}
	var body strings.Builder
	for _, m := range messages {
		if m.Role == RoleSystem {
			kept = append(kept, m)
			continue
		}
		body.WriteString(fmt.Sprintf("[%s] %s\n", m.Role, utils.Truncate(m.ContentString(), 2000)))
	}
	summaryPrompt = prompt + "\n\n" + body.String()
	return summaryPrompt, kept
}
