package core

import (
	"os"
	"path/filepath"
	"sync"

	"github.com/BurntSushi/toml"
	"github.com/goarxyz/goar/internal/core/paths"
)

type trustedFile struct {
	Folders   []string `toml:"folders"`
	Untrusted []string `toml:"untrusted"`
}

// HasAgentsMDFile reports whether path contains an AGENTS.md (or agents.md).
func HasAgentsMDFile(path string) bool {
	for _, name := range []string{"AGENTS.md", "agents.md", "CLAUDE.md"} {
		if _, err := os.Stat(filepath.Join(path, name)); err == nil {
			return true
		}
	}
	return false
}

// FindTrustableFiles returns instruction files present under path.
func FindTrustableFiles(path string) []string {
	var out []string
	for _, name := range []string{"AGENTS.md", "agents.md", "CLAUDE.md", "AGENT.md", ".agent/instructions.md"} {
		p := filepath.Join(path, name)
		if _, err := os.Stat(p); err == nil {
			out = append(out, p)
		}
	}
	return out
}

// TrustedFoldersManager tracks trusted/untrusted project folders (Python TrustedFoldersManager).
type TrustedFoldersManager struct {
	mu           sync.Mutex
	trusted      map[string]bool
	untrusted    map[string]bool
	sessionTrust map[string]bool
	loaded       bool
}

// NewTrustedFoldersManager constructs a manager.
func NewTrustedFoldersManager() *TrustedFoldersManager {
	return &TrustedFoldersManager{
		trusted: map[string]bool{}, untrusted: map[string]bool{}, sessionTrust: map[string]bool{},
	}
}

func (m *TrustedFoldersManager) normalize(path string) string {
	abs, err := filepath.Abs(path)
	if err != nil {
		return filepath.Clean(path)
	}
	return abs
}

func (m *TrustedFoldersManager) load() {
	if m.loaded {
		return
	}
	m.loaded = true
	path := paths.TrustedFoldersFile()
	var f trustedFile
	if _, err := os.Stat(path); err != nil {
		return
	}
	if _, err := toml.DecodeFile(path, &f); err != nil {
		return
	}
	for _, folder := range f.Folders {
		m.trusted[m.normalize(folder)] = true
	}
	for _, folder := range f.Untrusted {
		m.untrusted[m.normalize(folder)] = true
	}
}

func (m *TrustedFoldersManager) save() error {
	_ = paths.EnsureHome()
	folders := make([]string, 0, len(m.trusted))
	for k := range m.trusted {
		folders = append(folders, k)
	}
	untrusted := make([]string, 0, len(m.untrusted))
	for k := range m.untrusted {
		untrusted = append(untrusted, k)
	}
	f, err := os.Create(paths.TrustedFoldersFile())
	if err != nil {
		return err
	}
	defer f.Close()
	return toml.NewEncoder(f).Encode(trustedFile{Folders: folders, Untrusted: untrusted})
}

// TrustForSession marks path trusted for this process only.
func (m *TrustedFoldersManager) TrustForSession(path string) {
	m.mu.Lock()
	defer m.mu.Unlock()
	m.sessionTrust[m.normalize(path)] = true
}

// IsTrusted returns true/false if decided, or nil-equivalent via (bool, bool).
func (m *TrustedFoldersManager) IsTrusted(path string) (trusted bool, known bool) {
	m.mu.Lock()
	defer m.mu.Unlock()
	m.load()
	n := m.normalize(path)
	if m.sessionTrust[n] {
		return true, true
	}
	if m.untrusted[n] {
		return false, true
	}
	if m.trusted[n] {
		return true, true
	}
	// Walk parents
	for p := n; p != "" && p != string(filepath.Separator); p = filepath.Dir(p) {
		if m.untrusted[p] {
			return false, true
		}
		if m.trusted[p] || m.sessionTrust[p] {
			return true, true
		}
		if filepath.Dir(p) == p {
			break
		}
	}
	return false, false
}

// FindTrustRoot walks upward for a trustable instruction file.
func (m *TrustedFoldersManager) FindTrustRoot(path string) string {
	n := m.normalize(path)
	for p := n; ; p = filepath.Dir(p) {
		if HasAgentsMDFile(p) {
			return p
		}
		parent := filepath.Dir(p)
		if parent == p {
			break
		}
	}
	return ""
}

// AddTrusted permanently trusts path.
func (m *TrustedFoldersManager) AddTrusted(path string) error {
	m.mu.Lock()
	defer m.mu.Unlock()
	m.load()
	n := m.normalize(path)
	m.trusted[n] = true
	delete(m.untrusted, n)
	return m.save()
}

// AddUntrusted permanently marks path untrusted.
func (m *TrustedFoldersManager) AddUntrusted(path string) error {
	m.mu.Lock()
	defer m.mu.Unlock()
	m.load()
	n := m.normalize(path)
	m.untrusted[n] = true
	delete(m.trusted, n)
	return m.save()
}

// LoadTrustedFolders reads trusted_folders.toml (compat).
func LoadTrustedFolders() ([]string, error) {
	m := NewTrustedFoldersManager()
	m.load()
	out := make([]string, 0, len(m.trusted))
	for k := range m.trusted {
		out = append(out, k)
	}
	return out, nil
}

// SaveTrustedFolders writes trusted folders (compat).
func SaveTrustedFolders(folders []string) error {
	m := NewTrustedFoldersManager()
	m.load()
	m.trusted = map[string]bool{}
	for _, f := range folders {
		m.trusted[m.normalize(f)] = true
	}
	return m.save()
}

// IsTrusted reports whether dir is in the trusted list (compat).
func IsTrusted(dir string, trusted []string) bool {
	for _, t := range trusted {
		if t == dir {
			return true
		}
	}
	return false
}
