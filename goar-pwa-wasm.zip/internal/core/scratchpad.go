package core

import (
	"os"
	"path/filepath"
	"strings"
	"sync"

	"github.com/goarxyz/goar/internal/core/session"
)

var (
	scratchMu      sync.Mutex
	activeScratch  = map[string]string{}
)

// InitScratchpad creates a session-scoped scratchpad directory (Python init_scratchpad).
// Idempotent per sessionID. Returns the directory path.
func InitScratchpad(sessionID string) (string, error) {
	scratchMu.Lock()
	defer scratchMu.Unlock()
	if dir, ok := activeScratch[sessionID]; ok {
		return dir, nil
	}
	prefix := "goar-scratchpad-" + session.ShortenSessionID(sessionID) + "-"
	dir, err := os.MkdirTemp("", prefix)
	if err != nil {
		return "", err
	}
	activeScratch[sessionID] = dir
	return dir, nil
}

// GetScratchpadDir returns the scratchpad for a session, or "".
func GetScratchpadDir(sessionID string) string {
	scratchMu.Lock()
	defer scratchMu.Unlock()
	return activeScratch[sessionID]
}

// IsScratchpadPath reports whether path is inside any active scratchpad
// (Python is_scratchpad_path). Uses Resolve to defeat traversal/symlinks.
func IsScratchpadPath(pathStr string) bool {
	scratchMu.Lock()
	dirs := make([]string, 0, len(activeScratch))
	for _, d := range activeScratch {
		dirs = append(dirs, d)
	}
	scratchMu.Unlock()
	if len(dirs) == 0 {
		return false
	}
	resolved, err := filepath.Abs(filepath.Clean(osExpand(pathStr)))
	if err != nil {
		return false
	}
	resolved, err = filepath.EvalSymlinks(resolved)
	if err != nil {
		// If the path does not exist yet, still compare cleaned abs form.
		resolved, _ = filepath.Abs(filepath.Clean(osExpand(pathStr)))
	}
	for _, sp := range dirs {
		spRes, err := filepath.EvalSymlinks(sp)
		if err != nil {
			spRes = sp
		}
		if isSubpath(resolved, spRes) {
			return true
		}
	}
	return false
}

func osExpand(p string) string {
	if strings.HasPrefix(p, "~/") {
		home, _ := os.UserHomeDir()
		return filepath.Join(home, p[2:])
	}
	return p
}

func isSubpath(path, parent string) bool {
	rel, err := filepath.Rel(parent, path)
	if err != nil {
		return false
	}
	return rel == "." || (rel != ".." && !strings.HasPrefix(rel, ".."+string(filepath.Separator)))
}

// ActiveScratchpads returns a copy of the session→dir map (test/helper).
func ActiveScratchpads() map[string]string {
	scratchMu.Lock()
	defer scratchMu.Unlock()
	out := map[string]string{}
	for k, v := range activeScratch {
		out[k] = v
	}
	return out
}
