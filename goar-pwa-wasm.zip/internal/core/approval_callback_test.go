package core

import (
	"testing"

	"github.com/goarxyz/goar/internal/core/tools"
	"github.com/goarxyz/goar/internal/core/types"
)

// TestAskApprovalCallbackPath exercises Runtime.askApproval via ApprovalCallback,
// the same hook the CLI ApprovalPanel / PWA attention path ultimately feed.
func TestAskApprovalCallbackPath(t *testing.T) {
	r := &Runtime{}
	called := false
	r.SetApprovalCallback(func(toolName string, args map[string]any, toolCallID string, required []tools.RequiredPermission) (types.ApprovalResponse, string) {
		called = true
		if toolName != "bash" {
			t.Fatalf("toolName=%q", toolName)
		}
		if toolCallID != "tc-1" {
			t.Fatalf("id=%q", toolCallID)
		}
		return types.ApprovalYes, "ok once"
	})

	dec, err := r.askApproval("bash", map[string]any{"command": "echo hi"}, "tc-1", nil)
	if err != nil {
		t.Fatalf("askApproval: %v", err)
	}
	if !called {
		t.Fatal("callback not invoked")
	}
	if dec.Verdict != ToolExecExecute {
		t.Fatalf("verdict=%v want execute", dec.Verdict)
	}
	if dec.Feedback != "ok once" {
		t.Fatalf("feedback=%q", dec.Feedback)
	}

	r2 := &Runtime{}
	dec2, err := r2.askApproval("bash", nil, "tc-2", nil)
	if err != nil {
		t.Fatalf("nil callback: %v", err)
	}
	if dec2.Verdict != ToolExecSkip {
		t.Fatalf("nil callback verdict=%v want skip", dec2.Verdict)
	}
}
