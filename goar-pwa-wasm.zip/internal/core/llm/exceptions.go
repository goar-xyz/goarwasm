package llm

import (
	"fmt"
	"net/http"
	"strings"
)

// BackendError is an LLM API failure (Python BackendError).
type BackendError struct {
	Status           int
	Message          string
	Body             string
	IsContextTooLong bool
	NonRetryable     bool
	Provider         string
	Model            string
}

func (e BackendError) Error() string {
	if e.Status != 0 {
		return fmt.Sprintf("backend error %d: %s", e.Status, e.Message)
	}
	return "backend error: " + e.Message
}

// NewBackendError builds a BackendError.
func NewBackendError(status int, msg, body string) BackendError {
	be := BackendError{Status: status, Message: msg, Body: body}
	be.IsContextTooLong = DetectContextTooLong(status, msg, body)
	return be
}

// DetectContextTooLong heuristically detects context-length failures.
func DetectContextTooLong(status int, msg, body string) bool {
	blob := strings.ToLower(msg + " " + body)
	needles := []string{
		"context_length", "context length", "maximum context", "too many tokens",
		"prompt is too long", "max_tokens", "token limit", "context window",
	}
	for _, n := range needles {
		if strings.Contains(blob, n) {
			return true
		}
	}
	return false
}

// RateLimitError is raised on HTTP 429.
type RateLimitError struct {
	Provider string
	Model    string
	Cause    error
}

func (e RateLimitError) Error() string {
	return fmt.Sprintf("rate limit from %s (model: %s)", e.Provider, e.Model)
}
func (e RateLimitError) Unwrap() error { return e.Cause }

// ContextTooLongError is raised when the prompt exceeds the model context window.
type ContextTooLongError struct {
	Provider string
	Model    string
	Cause    error
}

func (e ContextTooLongError) Error() string {
	return fmt.Sprintf("context too long for %s (model: %s)", e.Provider, e.Model)
}
func (e ContextTooLongError) Unwrap() error { return e.Cause }

// AuthenticationError is raised on 401/403.
type AuthenticationError struct {
	Provider string
	Message  string
}

func (e AuthenticationError) Error() string {
	if e.Message != "" {
		return fmt.Sprintf("authentication error for %s: %s", e.Provider, e.Message)
	}
	return "authentication error for " + e.Provider
}

// TimeoutError is raised when the backend times out.
type TimeoutError struct {
	Provider string
	Seconds  float64
}

func (e TimeoutError) Error() string {
	return fmt.Sprintf("timeout talking to %s after %.1fs", e.Provider, e.Seconds)
}

// InvalidRequestError is raised on 400-class client errors.
type InvalidRequestError struct {
	Provider string
	Message  string
	Status   int
}

func (e InvalidRequestError) Error() string {
	return fmt.Sprintf("invalid request to %s (%d): %s", e.Provider, e.Status, e.Message)
}

// ShouldRaiseRateLimitError reports whether err is a 429 BackendError.
func ShouldRaiseRateLimitError(err error) bool {
	var be BackendError
	if AsBackendError(err, &be) {
		return be.Status == http.StatusTooManyRequests
	}
	return false
}

// IsContextTooLongError walks the error chain for context-too-long signals.
func IsContextTooLongError(err error) bool {
	var be BackendError
	if AsBackendError(err, &be) && be.IsContextTooLong {
		return true
	}
	var cte ContextTooLongError
	if err != nil {
		// walk via Unwrap if present
		type unwrapper interface{ Unwrap() error }
		cur := err
		seen := map[error]bool{}
		for cur != nil && !seen[cur] {
			seen[cur] = true
			if AsBackendError(cur, &be) && be.IsContextTooLong {
				return true
			}
			if _, ok := cur.(ContextTooLongError); ok {
				return true
			}
			_ = cte
			if u, ok := cur.(unwrapper); ok {
				cur = u.Unwrap()
				continue
			}
			break
		}
	}
	return false
}

// IsNonRetryableError detects a non_retryable flag on the error chain.
func IsNonRetryableError(err error) bool {
	type nonRetryable interface{ NonRetryable() bool }
	type flagged interface{ GetNonRetryable() bool }
	type unwrapper interface{ Unwrap() error }
	cur := err
	seen := map[error]bool{}
	for cur != nil && !seen[cur] {
		seen[cur] = true
		if nr, ok := cur.(nonRetryable); ok && nr.NonRetryable() {
			return true
		}
		if f, ok := cur.(flagged); ok && f.GetNonRetryable() {
			return true
		}
		var be BackendError
		if AsBackendError(cur, &be) && be.NonRetryable {
			return true
		}
		if u, ok := cur.(unwrapper); ok {
			cur = u.Unwrap()
			continue
		}
		break
	}
	return false
}

// AsBackendError extracts a BackendError value from err if possible.
func AsBackendError(err error, dest *BackendError) bool {
	if err == nil || dest == nil {
		return false
	}
	if be, ok := err.(BackendError); ok {
		*dest = be
		return true
	}
	if be, ok := err.(*BackendError); ok && be != nil {
		*dest = *be
		return true
	}
	type unwrapper interface{ Unwrap() error }
	if u, ok := err.(unwrapper); ok {
		return AsBackendError(u.Unwrap(), dest)
	}
	return false
}

// ClassifyHTTPStatus maps an HTTP status to a typed error when possible.
func ClassifyHTTPStatus(provider, model string, status int, msg, body string) error {
	be := NewBackendError(status, msg, body)
	be.Provider = provider
	be.Model = model
	switch status {
	case http.StatusTooManyRequests:
		return RateLimitError{Provider: provider, Model: model, Cause: be}
	case http.StatusUnauthorized, http.StatusForbidden:
		return AuthenticationError{Provider: provider, Message: msg}
	case http.StatusBadRequest:
		if be.IsContextTooLong {
			return ContextTooLongError{Provider: provider, Model: model, Cause: be}
		}
		return InvalidRequestError{Provider: provider, Message: msg, Status: status}
	default:
		if be.IsContextTooLong {
			return ContextTooLongError{Provider: provider, Model: model, Cause: be}
		}
		return be
	}
}
