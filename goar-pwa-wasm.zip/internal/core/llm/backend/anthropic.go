package backend

import (
	"encoding/json"
	"fmt"

	"github.com/goarxyz/goar/internal/core/types"
	"github.com/goarxyz/goar/internal/core/llm"
)

const (
	anthropicAPIVersion = "2023-06-01"
	anthropicBeta       = "interleaved-thinking-2025-05-14,fine-grained-tool-streaming-2025-05-14,prompt-caching-2024-07-31,context-1m-2025-08-07"
	anthropicDefaultMax = 8192
	anthropicAdaptiveMax = 32768
)

// AnthropicAdapter implements Anthropic Messages API.
type AnthropicAdapter struct {
	currentIndex int
}

func (AnthropicAdapter) Endpoint() string { return "/v1/messages" }

// AnthropicMapper converts GOAR messages to Anthropic wire format.
type AnthropicMapper struct{}

func (m AnthropicMapper) PrepareMessages(messages []types.LLMMessage) (system string, out []map[string]any) {
	var pendingTools []map[string]any
	flushTools := func() {
		if len(pendingTools) == 0 {
			return
		}
		out = append(out, map[string]any{"role": "user", "content": pendingTools})
		pendingTools = nil
	}
	for _, msg := range messages {
		switch msg.Role {
		case types.RoleSystem:
			if system == "" {
				system = msg.ContentString()
			} else {
				system += "\n\n" + msg.ContentString()
			}
		case types.RoleUser:
			flushTools()
			out = append(out, map[string]any{
				"role": "user",
				"content": []map[string]any{{"type": "text", "text": msg.ContentString()}},
			})
		case types.RoleAssistant:
			flushTools()
			blocks := []map[string]any{}
			if msg.ReasoningContent != nil && *msg.ReasoningContent != "" {
				block := map[string]any{"type": "thinking", "thinking": *msg.ReasoningContent}
				if msg.ReasoningSignature != nil {
					block["signature"] = *msg.ReasoningSignature
				}
				blocks = append(blocks, block)
			}
			if msg.ContentString() != "" {
				blocks = append(blocks, map[string]any{"type": "text", "text": msg.ContentString()})
			}
			for _, tc := range msg.ToolCalls {
				var args any = map[string]any{}
				if tc.Function.Arguments != "" {
					_ = json.Unmarshal([]byte(tc.Function.Arguments), &args)
				}
				blocks = append(blocks, map[string]any{
					"type":  "tool_use",
					"id":    tc.ID,
					"name":  tc.Function.Name,
					"input": args,
				})
			}
			if len(blocks) == 0 {
				blocks = append(blocks, map[string]any{"type": "text", "text": ""})
			}
			out = append(out, map[string]any{"role": "assistant", "content": blocks})
		case types.RoleTool:
			id := ""
			if msg.ToolCallID != nil {
				id = *msg.ToolCallID
			}
			pendingTools = append(pendingTools, map[string]any{
				"type":        "tool_result",
				"tool_use_id": id,
				"content":     msg.ContentString(),
			})
		}
	}
	flushTools()
	return system, out
}

func (m AnthropicMapper) PrepareTools(tools []types.AvailableTool) []map[string]any {
	if len(tools) == 0 {
		return nil
	}
	out := make([]map[string]any, 0, len(tools))
	for _, t := range tools {
		out = append(out, map[string]any{
			"name":         t.Function.Name,
			"description":  t.Function.Description,
			"input_schema": t.Function.Parameters,
		})
	}
	return out
}

func (m AnthropicMapper) PrepareToolChoice(tc any) map[string]any {
	if tc == nil {
		return nil
	}
	switch v := tc.(type) {
	case string:
		switch v {
		case "auto":
			return map[string]any{"type": "auto"}
		case "none":
			return map[string]any{"type": "none"}
		case "any", "required":
			return map[string]any{"type": "any"}
		}
	case types.AvailableTool:
		return map[string]any{"type": "tool", "name": v.Function.Name}
	}
	return nil
}

func (m AnthropicMapper) ParseResponse(data map[string]any) (types.LLMChunk, error) {
	msg := types.LLMMessage{Role: types.RoleAssistant}
	var contentParts []string
	var toolCalls []types.ToolCall
	if blocks, ok := data["content"].([]any); ok {
		for i, b := range blocks {
			bm, _ := b.(map[string]any)
			switch bm["type"] {
			case "text":
				if t, ok := bm["text"].(string); ok {
					contentParts = append(contentParts, t)
				}
			case "thinking":
				if t, ok := bm["thinking"].(string); ok {
					msg.ReasoningContent = &t
				}
				if s, ok := bm["signature"].(string); ok {
					msg.ReasoningSignature = &s
				}
			case "tool_use":
				idx := i
				args, _ := json.Marshal(bm["input"])
				toolCalls = append(toolCalls, types.ToolCall{
					ID:    fmt.Sprint(bm["id"]),
					Index: &idx,
					Type:  "function",
					Function: types.FunctionCall{
						Name:      fmt.Sprint(bm["name"]),
						Arguments: string(args),
					},
				})
			}
		}
	}
	if len(contentParts) > 0 {
		c := ""
		for i, p := range contentParts {
			if i > 0 {
				c += "\n"
			}
			c += p
		}
		msg.Content = &c
	}
	msg.ToolCalls = toolCalls
	var usage *types.LLMUsage
	if u, ok := data["usage"].(map[string]any); ok {
		in := asInt(u["input_tokens"]) + asInt(u["cache_creation_input_tokens"]) + asInt(u["cache_read_input_tokens"])
		usage = &types.LLMUsage{PromptTokens: in, CompletionTokens: asInt(u["output_tokens"])}
	}
	return types.LLMChunk{Message: msg, Usage: usage}, nil
}

func (a AnthropicAdapter) hasThinking(messages []map[string]any) bool {
	for _, msg := range messages {
		if msg["role"] != "assistant" {
			continue
		}
		content, _ := msg["content"].([]map[string]any)
		for _, b := range content {
			if b["type"] == "thinking" {
				return true
			}
		}
	}
	return false
}

func (a AnthropicAdapter) applyThinking(payload map[string]any, messages []map[string]any, maxTokens *int, thinking string) {
	has := a.hasThinking(messages)
	if thinking == "off" && !has {
		mt := anthropicDefaultMax
		if maxTokens != nil {
			mt = *maxTokens
		}
		payload["max_tokens"] = mt
		return
	}
	eff := thinking
	if eff == "off" {
		eff = "medium"
	}
	payload["thinking"] = map[string]any{"type": "adaptive", "display": "summarized"}
	payload["output_config"] = map[string]any{"effort": eff}
	mt := anthropicAdaptiveMax
	if maxTokens != nil {
		mt = *maxTokens
	}
	payload["max_tokens"] = mt
}

func (a AnthropicAdapter) PrepareRequest(modelName string, messages []types.LLMMessage, temperature float64, tools []types.AvailableTool, maxTokens *int, toolChoice any, streaming bool, apiKey string, reasoningField string) (PreparedRequest, error) {
	_ = temperature
	_ = reasoningField
	mapper := AnthropicMapper{}
	system, converted := mapper.PrepareMessages(messages)
	payload := map[string]any{"model": modelName, "messages": converted}
	a.applyThinking(payload, converted, maxTokens, "off")
	if system != "" {
		payload["system"] = []map[string]any{{
			"type": "text", "text": system,
			"cache_control": map[string]any{"type": "ephemeral"},
		}}
	}
	if t := mapper.PrepareTools(tools); t != nil {
		payload["tools"] = t
	}
	if tc := mapper.PrepareToolChoice(toolChoice); tc != nil {
		payload["tool_choice"] = tc
	}
	if streaming {
		payload["stream"] = true
	}
	// cache control on last user message
	if len(converted) > 0 {
		last := converted[len(converted)-1]
		if last["role"] == "user" {
			if content, ok := last["content"].([]map[string]any); ok && len(content) > 0 {
				lb := content[len(content)-1]
				if lb["type"] == "text" || lb["type"] == "tool_result" {
					lb["cache_control"] = map[string]any{"type": "ephemeral"}
				}
			}
		}
	}
	body, err := json.Marshal(payload)
	if err != nil {
		return PreparedRequest{}, err
	}
	headers := map[string]string{
		"Content-Type":      "application/json",
		"anthropic-version": anthropicAPIVersion,
		"anthropic-beta":    anthropicBeta,
	}
	if apiKey != "" {
		headers["x-api-key"] = apiKey
	}
	return PreparedRequest{Endpoint: a.Endpoint(), Headers: headers, Body: body}, nil
}

func (a *AnthropicAdapter) parseResponseInner(data map[string]any, reasoningField string) (types.LLMChunk, error) {
	_ = reasoningField
	if t, _ := data["type"].(string); t != "" && isAnthropicStreamEvent(t) {
		return a.parseStreamingEvent(data)
	}
	return AnthropicMapper{}.ParseResponse(data)
}

func isAnthropicStreamEvent(t string) bool {
	switch t {
	case "message_start", "content_block_start", "content_block_delta", "content_block_stop", "message_delta", "message_stop", "ping", "error":
		return true
	}
	return false
}

func (a *AnthropicAdapter) parseStreamingEvent(data map[string]any) (types.LLMChunk, error) {
	empty := types.LLMChunk{Message: types.LLMMessage{Role: types.RoleAssistant}}
	switch data["type"] {
	case "message_start":
		a.currentIndex = 0
		msg, _ := data["message"].(map[string]any)
		if u, ok := msg["usage"].(map[string]any); ok {
			in := asInt(u["input_tokens"]) + asInt(u["cache_creation_input_tokens"]) + asInt(u["cache_read_input_tokens"])
			usage := &types.LLMUsage{PromptTokens: in, CompletionTokens: asInt(u["output_tokens"])}
			return types.LLMChunk{Message: types.LLMMessage{Role: types.RoleAssistant}, Usage: usage}, nil
		}
		return empty, nil
	case "content_block_delta":
		delta, _ := data["delta"].(map[string]any)
		msg := types.LLMMessage{Role: types.RoleAssistant}
		switch delta["type"] {
		case "text_delta":
			if t, ok := delta["text"].(string); ok {
				msg.Content = &t
			}
		case "thinking_delta":
			if t, ok := delta["thinking"].(string); ok {
				msg.ReasoningContent = &t
			}
		case "input_json_delta":
			partial, _ := delta["partial_json"].(string)
			idx := a.currentIndex
			msg.ToolCalls = []types.ToolCall{{
				Index: &idx, Type: "function",
				Function: types.FunctionCall{Arguments: partial},
			}}
		}
		return types.LLMChunk{Message: msg}, nil
	case "content_block_start":
		block, _ := data["content_block"].(map[string]any)
		if block["type"] == "tool_use" {
			idx := a.currentIndex
			return types.LLMChunk{Message: types.LLMMessage{
				Role: types.RoleAssistant,
				ToolCalls: []types.ToolCall{{
					ID: fmt.Sprint(block["id"]), Index: &idx, Type: "function",
					Function: types.FunctionCall{Name: fmt.Sprint(block["name"]), Arguments: ""},
				}},
			}}, nil
		}
		return empty, nil
	case "content_block_stop":
		a.currentIndex++
		return empty, nil
	case "message_delta":
		if u, ok := data["usage"].(map[string]any); ok {
			usage := &types.LLMUsage{CompletionTokens: asInt(u["output_tokens"])}
			return types.LLMChunk{Message: types.LLMMessage{Role: types.RoleAssistant}, Usage: usage}, nil
		}
		return empty, nil
	case "error":
		errObj, _ := data["error"].(map[string]any)
		return empty, llm.NewBackendError(0, fmt.Sprintf("Anthropic stream error (%v): %v", errObj["type"], errObj["message"]), "")
	default:
		return empty, nil
	}
}

// ParseResponse implements APIAdapter.
func (a AnthropicAdapter) ParseResponse(data map[string]any, reasoningField string) (types.LLMChunk, error) {
	p := a
	return (&p).parseResponseInner(data, reasoningField)
}
