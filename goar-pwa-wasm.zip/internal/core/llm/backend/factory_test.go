package backend

import (
	"testing"

	"github.com/goarxyz/goar/internal/core/config"
)

func TestSelectBackend(t *testing.T) {
	cfg := config.Default()
	b, err := SelectBackend(cfg)
	if err != nil {
		t.Fatal(err)
	}
	if b == nil {
		t.Fatal("nil backend")
	}
	_ = b.Close()
}

func TestAdapterForStyle(t *testing.T) {
	for _, style := range []string{"openai", "anthropic", "openai-responses", "reasoning", "vertex-anthropic"} {
		ad, err := AdapterForStyle(style)
		if err != nil {
			t.Fatalf("%s: %v", style, err)
		}
		if ad == nil {
			t.Fatal(style)
		}
	}
}
