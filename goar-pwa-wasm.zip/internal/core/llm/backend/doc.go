// Package backend implements LLM API adapters and the generic HTTP backend.
package backend
