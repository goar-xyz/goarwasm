package backend

import (
	"fmt"

	"github.com/goarxyz/goar/internal/core/config"
	"github.com/goarxyz/goar/internal/core/llm"
	"github.com/goarxyz/goar/internal/core/types"
)

// BackendFactory maps Backend enum values to constructors.
var BackendFactory = map[types.Backend]func(config.ProviderConfig, float64) llm.BackendLike{
	types.BackendGeneric: func(p config.ProviderConfig, timeout float64) llm.BackendLike {
		return NewGenericBackend(p, timeout)
	},
}

// SelectBackend creates a backend for the active provider.
func SelectBackend(cfg *config.Config) (llm.BackendLike, error) {
	provider, err := cfg.GetActiveProvider()
	if err != nil {
		return nil, err
	}
	backendName := types.Backend(provider.Backend)
	if backendName == "" {
		backendName = types.BackendGeneric
	}
	ctor, ok := BackendFactory[backendName]
	if !ok {
		return nil, fmt.Errorf("unknown backend %q", backendName)
	}
	return ctor(provider, cfg.APITimeout), nil
}

// AdapterForStyle returns an APIAdapter for the given api_style.
func AdapterForStyle(style string) (APIAdapter, error) {
	switch style {
	case "", "openai":
		return OpenAIAdapter{}, nil
	case "anthropic":
		return AnthropicAdapter{}, nil
	case "openai-responses":
		return OpenAIResponsesAdapter{}, nil
	case "reasoning":
		return ReasoningAdapter{}, nil
	case "vertex-anthropic":
		return &VertexAnthropicAdapter{}, nil
	default:
		return nil, fmt.Errorf("unknown api_style %q", style)
	}
}
