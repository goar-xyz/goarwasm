package backend

import "github.com/goarxyz/goar/internal/core/types"

// PreparedRequest is a ready-to-send HTTP request body.
type PreparedRequest struct {
	Endpoint string
	Headers  map[string]string
	Body     []byte
	BaseURL  string
}

// APIAdapter prepares and parses provider-specific chat requests.
type APIAdapter interface {
	PrepareRequest(modelName string, messages []types.LLMMessage, temperature float64, tools []types.AvailableTool, maxTokens *int, toolChoice any, streaming bool, apiKey string, reasoningField string) (PreparedRequest, error)
	ParseResponse(data map[string]any, reasoningField string) (types.LLMChunk, error)
	Endpoint() string
}
