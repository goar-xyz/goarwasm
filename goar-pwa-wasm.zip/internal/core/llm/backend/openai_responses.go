package backend

import (
	"encoding/json"
	"fmt"
	"strings"

	"github.com/goarxyz/goar/internal/core/types"
)

// OpenAIResponsesAdapter implements the OpenAI /responses API.
type OpenAIResponsesAdapter struct {
	stream OpenAIResponsesStreamParser
}

func (OpenAIResponsesAdapter) Endpoint() string { return "/responses" }

func (a OpenAIResponsesAdapter) temperatureSupported(model string) bool {
	return strings.HasPrefix(model, "gpt-4") || strings.HasPrefix(model, "gpt-3.5")
}

func (a OpenAIResponsesAdapter) mapEffort(thinking string) string {
	switch thinking {
	case "off":
		return "none"
	case "max":
		return "xhigh"
	default:
		return thinking
	}
}

func (a OpenAIResponsesAdapter) convertMessages(messages []types.LLMMessage) []map[string]any {
	var items []map[string]any
	for _, msg := range messages {
		switch msg.Role {
		case types.RoleSystem:
			items = append(items, map[string]any{"role": "system", "content": msg.ContentString()})
		case types.RoleUser:
			items = append(items, map[string]any{"role": "user", "content": msg.ContentString()})
		case types.RoleAssistant:
			for _, enc := range msg.ReasoningState {
				items = append(items, map[string]any{"type": "reasoning", "encrypted_content": enc})
			}
			items = append(items, map[string]any{
				"role": "assistant",
				"content": []map[string]any{{"type": "output_text", "text": msg.ContentString()}},
			})
			for _, tc := range msg.ToolCalls {
				items = append(items, map[string]any{
					"type": "function_call", "call_id": tc.ID,
					"name": tc.Function.Name, "arguments": tc.Function.Arguments,
				})
			}
		case types.RoleTool:
			id := ""
			if msg.ToolCallID != nil {
				id = *msg.ToolCallID
			}
			items = append(items, map[string]any{
				"type": "function_call_output", "call_id": id, "output": msg.ContentString(),
			})
		default:
			panic(fmt.Sprintf("unsupported role: %s", msg.Role))
		}
	}
	return items
}

func (a OpenAIResponsesAdapter) PrepareRequest(modelName string, messages []types.LLMMessage, temperature float64, tools []types.AvailableTool, maxTokens *int, toolChoice any, streaming bool, apiKey string, reasoningField string) (PreparedRequest, error) {
	_ = reasoningField
	input := a.convertMessages(messages)
	payload := map[string]any{"model": modelName, "input": input, "store": false}
	if a.temperatureSupported(modelName) {
		payload["temperature"] = temperature
	}
	payload["reasoning"] = map[string]any{"effort": a.mapEffort("off")}
	if len(tools) > 0 {
		tlist := make([]map[string]any, 0, len(tools))
		for _, t := range tools {
			tlist = append(tlist, map[string]any{
				"type": "function", "name": t.Function.Name,
				"description": t.Function.Description, "parameters": t.Function.Parameters,
			})
		}
		payload["tools"] = tlist
		if toolChoice != nil {
			if s, ok := toolChoice.(string); ok {
				payload["tool_choice"] = s
			} else if at, ok := toolChoice.(types.AvailableTool); ok {
				payload["tool_choice"] = map[string]any{"type": "function", "name": at.Function.Name}
			}
		}
	}
	if maxTokens != nil {
		payload["max_output_tokens"] = *maxTokens
	}
	if streaming {
		payload["stream"] = true
	}
	body, err := json.Marshal(payload)
	if err != nil {
		return PreparedRequest{}, err
	}
	headers := map[string]string{"Content-Type": "application/json"}
	if apiKey != "" {
		headers["Authorization"] = "Bearer " + apiKey
	}
	return PreparedRequest{Endpoint: a.Endpoint(), Headers: headers, Body: body}, nil
}

func (a OpenAIResponsesAdapter) ParseResponse(data map[string]any, reasoningField string) (types.LLMChunk, error) {
	_ = reasoningField
	if _, ok := data["type"]; ok {
		return a.stream.ParseEvent(data)
	}
	msg := types.LLMMessage{Role: types.RoleAssistant}
	var texts []string
	var toolCalls []types.ToolCall
	var reasoningState []string
	if output, ok := data["output"].([]any); ok {
		for i, item := range output {
			im, _ := item.(map[string]any)
			switch im["type"] {
			case "message":
				if content, ok := im["content"].([]any); ok {
					for _, c := range content {
						cm, _ := c.(map[string]any)
						if cm["type"] == "output_text" {
							if t, ok := cm["text"].(string); ok {
								texts = append(texts, t)
							}
						}
					}
				}
			case "function_call":
				idx := i
				toolCalls = append(toolCalls, types.ToolCall{
					ID: fmt.Sprint(im["call_id"]), Index: &idx, Type: "function",
					Function: types.FunctionCall{Name: fmt.Sprint(im["name"]), Arguments: fmt.Sprint(im["arguments"])},
				})
			case "reasoning":
				if enc, ok := im["encrypted_content"].(string); ok {
					reasoningState = append(reasoningState, enc)
				}
				if summary, ok := im["summary"].([]any); ok {
					var parts []string
					for _, s := range summary {
						sm, _ := s.(map[string]any)
						if t, ok := sm["text"].(string); ok {
							parts = append(parts, t)
						}
					}
					if len(parts) > 0 {
						joined := strings.Join(parts, "\n")
						msg.ReasoningContent = &joined
					}
				}
			}
		}
	}
	if len(texts) > 0 {
		c := strings.Join(texts, "\n")
		msg.Content = &c
	}
	msg.ToolCalls = toolCalls
	msg.ReasoningState = reasoningState
	var usage *types.LLMUsage
	if u, ok := data["usage"].(map[string]any); ok {
		usage = &types.LLMUsage{PromptTokens: asInt(u["input_tokens"]), CompletionTokens: asInt(u["output_tokens"])}
	}
	return types.LLMChunk{Message: msg, Usage: usage}, nil
}

// OpenAIResponsesStreamParser accumulates streaming /responses events.
type OpenAIResponsesStreamParser struct {
	text       strings.Builder
	toolArgs   map[int]*strings.Builder
	toolMeta   map[int]types.ToolCall
	usage      *types.LLMUsage
}

func (p *OpenAIResponsesStreamParser) ParseEvent(data map[string]any) (types.LLMChunk, error) {
	if p.toolArgs == nil {
		p.toolArgs = map[int]*strings.Builder{}
		p.toolMeta = map[int]types.ToolCall{}
	}
	msg := types.LLMMessage{Role: types.RoleAssistant}
	typ, _ := data["type"].(string)
	switch typ {
	case "response.output_text.delta":
		if d, ok := data["delta"].(string); ok {
			p.text.WriteString(d)
			msg.Content = &d
		}
	case "response.function_call_arguments.delta":
		idx := asInt(data["output_index"])
		if p.toolArgs[idx] == nil {
			p.toolArgs[idx] = &strings.Builder{}
		}
		if d, ok := data["delta"].(string); ok {
			p.toolArgs[idx].WriteString(d)
			msg.ToolCalls = []types.ToolCall{{Index: &idx, Type: "function", Function: types.FunctionCall{Arguments: d}}}
		}
	case "response.output_item.added":
		item, _ := data["item"].(map[string]any)
		if item["type"] == "function_call" {
			idx := asInt(data["output_index"])
			p.toolMeta[idx] = types.ToolCall{
				ID: fmt.Sprint(item["call_id"]), Index: &idx, Type: "function",
				Function: types.FunctionCall{Name: fmt.Sprint(item["name"])},
			}
		}
	case "response.completed":
		if resp, ok := data["response"].(map[string]any); ok {
			if u, ok := resp["usage"].(map[string]any); ok {
				p.usage = &types.LLMUsage{PromptTokens: asInt(u["input_tokens"]), CompletionTokens: asInt(u["output_tokens"])}
			}
		}
		c := p.text.String()
		msg.Content = &c
		for idx, meta := range p.toolMeta {
			if b := p.toolArgs[idx]; b != nil {
				meta.Function.Arguments = b.String()
			}
			msg.ToolCalls = append(msg.ToolCalls, meta)
		}
		return types.LLMChunk{Message: msg, Usage: p.usage}, nil
	}
	return types.LLMChunk{Message: msg}, nil
}

// --- Expanded Responses API types (port of _Responses* dataclasses) ---

type responsesUsageData struct {
	InputTokens  int `json:"input_tokens"`
	OutputTokens int `json:"output_tokens"`
	TotalTokens  int `json:"total_tokens"`
}

type responsesFunctionCallItem struct {
	Type      string `json:"type"`
	CallID    string `json:"call_id"`
	Name      string `json:"name"`
	Arguments string `json:"arguments"`
	ID        string `json:"id"`
	Status    string `json:"status"`
}

type responsesContentBlock struct {
	Type string `json:"type"`
	Text string `json:"text"`
}

type responsesSummaryBlock struct {
	Type string `json:"type"`
	Text string `json:"text"`
}

type responsesMessageItem struct {
	Type    string                  `json:"type"`
	Role    string                  `json:"role"`
	Content []responsesContentBlock `json:"content"`
	ID      string                  `json:"id"`
	Status  string                  `json:"status"`
}

type responsesReasoningItem struct {
	Type             string                  `json:"type"`
	Summary          []responsesSummaryBlock `json:"summary"`
	EncryptedContent string                  `json:"encrypted_content"`
	ID               string                  `json:"id"`
}

type responsesToolCallState struct {
	CallID    string
	Name      string
	Arguments strings.Builder
	Index     int
}

// IsCommentaryMessage reports whether an assistant message is commentary-only.
func (p OpenAIResponsesStreamParser) IsCommentaryMessage(role string, content string) bool {
	return role == "assistant" && strings.TrimSpace(content) == ""
}

// UsageFromResponse extracts usage from a completed response object.
func (p OpenAIResponsesStreamParser) UsageFromResponse(resp map[string]any) *types.LLMUsage {
	u, _ := resp["usage"].(map[string]any)
	if u == nil {
		return nil
	}
	return &types.LLMUsage{
		PromptTokens:     asInt(u["input_tokens"]),
		CompletionTokens: asInt(u["output_tokens"]),
	}
}

// ReasoningStateFromOutput collects encrypted reasoning blobs from output items.
func (p OpenAIResponsesStreamParser) ReasoningStateFromOutput(output []any) []string {
	var state []string
	for _, item := range output {
		m, ok := item.(map[string]any)
		if !ok || m["type"] != "reasoning" {
			continue
		}
		if enc, ok := m["encrypted_content"].(string); ok && enc != "" {
			state = append(state, enc)
		}
	}
	return state
}

// ToolCallFromItem converts a function_call output item into a ToolCall.
func (p OpenAIResponsesStreamParser) ToolCallFromItem(item map[string]any, index int) types.ToolCall {
	return types.ToolCall{
		ID:    fmt.Sprint(item["call_id"]),
		Index: &index,
		Type:  "function",
		Function: types.FunctionCall{
			Name:      fmt.Sprint(item["name"]),
			Arguments: fmt.Sprint(item["arguments"]),
		},
	}
}

// ConvertToolForResponses maps an AvailableTool into Responses API tool schema.
func (a OpenAIResponsesAdapter) ConvertToolForResponses(t types.AvailableTool) map[string]any {
	return map[string]any{
		"type":        "function",
		"name":        t.Function.Name,
		"description": t.Function.Description,
		"parameters":  t.Function.Parameters,
	}
}

// BuildPayload constructs the /responses request body.
func (a OpenAIResponsesAdapter) BuildPayload(modelName string, messages []types.LLMMessage, temperature float64, tools []types.AvailableTool, maxTokens *int, toolChoice any, streaming bool, thinking string) map[string]any {
	payload := map[string]any{
		"model": modelName,
		"input": a.convertMessages(messages),
		"store": false,
	}
	if a.temperatureSupported(modelName) {
		payload["temperature"] = temperature
	}
	effort := a.mapEffort(thinking)
	if effort == "" {
		effort = "none"
	}
	payload["reasoning"] = map[string]any{"effort": effort, "summary": "auto"}
	if len(tools) > 0 {
		tlist := make([]map[string]any, 0, len(tools))
		for _, t := range tools {
			tlist = append(tlist, a.ConvertToolForResponses(t))
		}
		payload["tools"] = tlist
	}
	if toolChoice != nil {
		payload["tool_choice"] = toolChoice
	}
	if maxTokens != nil {
		payload["max_output_tokens"] = *maxTokens
	}
	if streaming {
		payload["stream"] = true
	}
	return payload
}

// BuildHeaders returns auth + content-type headers for Responses API.
func (a OpenAIResponsesAdapter) BuildHeaders(apiKey string) map[string]string {
	return map[string]string{
		"Authorization": "Bearer " + apiKey,
		"Content-Type":  "application/json",
		"Accept":        "text/event-stream",
	}
}

// ParseOutputItems converts a completed response output array into an LLMMessage.
func (a OpenAIResponsesAdapter) ParseOutputItems(output []any) types.LLMMessage {
	var textParts []string
	var reasoning []string
	var toolCalls []types.ToolCall
	for i, item := range output {
		m, ok := item.(map[string]any)
		if !ok {
			continue
		}
		switch m["type"] {
		case "message":
			if content, ok := m["content"].([]any); ok {
				for _, c := range content {
					cm, _ := c.(map[string]any)
					if cm["type"] == "output_text" {
						textParts = append(textParts, fmt.Sprint(cm["text"]))
					}
				}
			}
		case "reasoning":
			if enc, ok := m["encrypted_content"].(string); ok {
				reasoning = append(reasoning, enc)
			}
			if summary, ok := m["summary"].([]any); ok {
				for _, s := range summary {
					sm, _ := s.(map[string]any)
					if t, ok := sm["text"].(string); ok && t != "" {
						textParts = append(textParts, t)
					}
				}
			}
		case "function_call":
			var parser OpenAIResponsesStreamParser
			toolCalls = append(toolCalls, parser.ToolCallFromItem(m, i))
		}
	}
	content := strings.Join(textParts, "")
	msg := types.LLMMessage{Role: types.RoleAssistant, Content: &content, ToolCalls: toolCalls, ReasoningState: reasoning}
	return msg
}
