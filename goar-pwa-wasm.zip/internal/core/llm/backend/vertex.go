package backend

import (
	"encoding/json"
	"fmt"
	"os"
	"os/exec"
	"strings"
	"sync"

	"github.com/goarxyz/goar/internal/core/types"
)

// BuildVertexBaseURL returns the regional Vertex AI host.
func BuildVertexBaseURL(region string) string {
	if region == "global" {
		return "https://aiplatform.googleapis.com"
	}
	return fmt.Sprintf("https://%s-aiplatform.googleapis.com", region)
}

// BuildVertexEndpoint builds the rawPredict/streamRawPredict path.
func BuildVertexEndpoint(region, projectID, model string, streaming bool) string {
	action := "rawPredict"
	if streaming {
		action = "streamRawPredict"
	}
	return fmt.Sprintf("/v1/projects/%s/locations/%s/publishers/anthropic/models/%s:%s", projectID, region, model, action)
}

// VertexCredentials obtains a GCP access token via Application Default Credentials
// using `gcloud auth print-access-token` when available, else GOOGLE_ACCESS_TOKEN.
type VertexCredentials struct {
	mu    sync.Mutex
	token string
}

// AccessToken returns a bearer token.
func (v *VertexCredentials) AccessToken() (string, error) {
	v.mu.Lock()
	defer v.mu.Unlock()
	if t := os.Getenv("GOOGLE_ACCESS_TOKEN"); t != "" {
		return t, nil
	}
	if v.token != "" {
		return v.token, nil
	}
	out, err := exec.Command("gcloud", "auth", "print-access-token").Output()
	if err != nil {
		return "", fmt.Errorf("vertex credentials: set GOOGLE_ACCESS_TOKEN or configure gcloud ADC: %w", err)
	}
	v.token = strings.TrimSpace(string(out))
	if v.token == "" {
		return "", fmt.Errorf("vertex credential refresh did not produce a token")
	}
	return v.token, nil
}

// VertexAnthropicAdapter sends Anthropic-format requests to Vertex AI.
type VertexAnthropicAdapter struct {
	AnthropicAdapter
	Credentials VertexCredentials
	ProjectID   string
	Region      string
}

func (*VertexAnthropicAdapter) Endpoint() string { return "" }

func (a *VertexAnthropicAdapter) PrepareRequest(modelName string, messages []types.LLMMessage, temperature float64, tools []types.AvailableTool, maxTokens *int, toolChoice any, streaming bool, apiKey string, reasoningField string) (PreparedRequest, error) {
	_ = temperature
	_ = apiKey
	_ = reasoningField
	if a.ProjectID == "" || a.Region == "" {
		return PreparedRequest{}, fmt.Errorf("project_id and region are required for Vertex AI")
	}
	mapper := AnthropicMapper{}
	system, converted := mapper.PrepareMessages(messages)
	payload := map[string]any{
		"anthropic_version": "vertex-2023-10-16",
		"messages":          converted,
	}
	a.applyThinking(payload, converted, maxTokens, "off")
	if system != "" {
		payload["system"] = []map[string]any{{"type": "text", "text": system, "cache_control": map[string]any{"type": "ephemeral"}}}
	}
	if t := mapper.PrepareTools(tools); t != nil {
		payload["tools"] = t
	}
	if tc := mapper.PrepareToolChoice(toolChoice); tc != nil {
		payload["tool_choice"] = tc
	}
	if streaming {
		payload["stream"] = true
	}
	body, err := json.Marshal(payload)
	if err != nil {
		return PreparedRequest{}, err
	}
	token, err := a.Credentials.AccessToken()
	if err != nil {
		return PreparedRequest{}, err
	}
	headers := map[string]string{
		"Content-Type":  "application/json",
		"Authorization": "Bearer " + token,
	}
	return PreparedRequest{
		Endpoint: BuildVertexEndpoint(a.Region, a.ProjectID, modelName, streaming),
		Headers:  headers,
		Body:     body,
		BaseURL:  BuildVertexBaseURL(a.Region),
	}, nil
}
