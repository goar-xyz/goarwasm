package backend

import (
	"encoding/json"

	"github.com/goarxyz/goar/internal/core/types"
)

// ReasoningAdapter is OpenAI-compat with structured thinking content blocks.
type ReasoningAdapter struct{}

func (ReasoningAdapter) Endpoint() string { return "/chat/completions" }

func (a ReasoningAdapter) convertMessage(msg types.LLMMessage) map[string]any {
	switch msg.Role {
	case types.RoleSystem:
		return map[string]any{"role": "system", "content": msg.ContentString()}
	case types.RoleUser:
		return map[string]any{"role": "user", "content": msg.ContentString()}
	case types.RoleTool:
		row := map[string]any{"role": "tool", "content": msg.ContentString()}
		if msg.ToolCallID != nil {
			row["tool_call_id"] = *msg.ToolCallID
		}
		if msg.Name != nil {
			row["name"] = *msg.Name
		}
		return row
	case types.RoleAssistant:
		result := map[string]any{"role": "assistant"}
		if msg.ReasoningContent != nil && *msg.ReasoningContent != "" {
			content := []map[string]any{{
				"type": "thinking",
				"thinking": []map[string]any{{"type": "text", "text": *msg.ReasoningContent}},
			}}
			if msg.ContentString() != "" {
				content = append(content, map[string]any{"type": "text", "text": msg.ContentString()})
			}
			result["content"] = content
		} else {
			result["content"] = msg.ContentString()
		}
		if len(msg.ToolCalls) > 0 {
			tcs := make([]map[string]any, 0, len(msg.ToolCalls))
			for _, tc := range msg.ToolCalls {
				row := map[string]any{
					"id": tc.ID, "type": "function",
					"function": map[string]any{"name": tc.Function.Name, "arguments": tc.Function.Arguments},
				}
				if tc.Index != nil {
					row["index"] = *tc.Index
				}
				tcs = append(tcs, row)
			}
			result["tool_calls"] = tcs
		}
		return result
	}
	return map[string]any{"role": string(msg.Role), "content": msg.ContentString()}
}

func (a ReasoningAdapter) PrepareRequest(modelName string, messages []types.LLMMessage, temperature float64, tools []types.AvailableTool, maxTokens *int, toolChoice any, streaming bool, apiKey string, reasoningField string) (PreparedRequest, error) {
	_ = reasoningField
	converted := make([]map[string]any, 0, len(messages))
	for _, m := range messages {
		converted = append(converted, a.convertMessage(m))
	}
	payload := map[string]any{"model": modelName, "messages": converted, "temperature": temperature}
	if len(tools) > 0 {
		tlist := make([]map[string]any, 0, len(tools))
		for _, t := range tools {
			tlist = append(tlist, map[string]any{
				"type": "function",
				"function": map[string]any{
					"name": t.Function.Name, "description": t.Function.Description, "parameters": t.Function.Parameters,
				},
			})
		}
		payload["tools"] = tlist
	}
	if toolChoice != nil {
		payload["tool_choice"] = toolChoice
	}
	if maxTokens != nil {
		payload["max_tokens"] = *maxTokens
	}
	if streaming {
		payload["stream"] = true
		payload["stream_options"] = map[string]any{"include_usage": true}
	}
	body, err := json.Marshal(payload)
	if err != nil {
		return PreparedRequest{}, err
	}
	headers := map[string]string{"Content-Type": "application/json"}
	if apiKey != "" {
		headers["Authorization"] = "Bearer " + apiKey
	}
	return PreparedRequest{Endpoint: a.Endpoint(), Headers: headers, Body: body}, nil
}

func (a ReasoningAdapter) ParseResponse(data map[string]any, reasoningField string) (types.LLMChunk, error) {
	// Reuse OpenAI parser semantics then lift thinking blocks
	chunk, err := (OpenAIAdapter{}).ParseResponse(data, reasoningField)
	if err != nil {
		return chunk, err
	}
	// If content is a list-like JSON from thinking providers, leave as-is; OpenAIAdapter already flattened strings.
	return chunk, nil
}
