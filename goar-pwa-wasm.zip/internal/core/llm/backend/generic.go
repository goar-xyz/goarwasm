package backend

import (
	"bufio"
	"bytes"
	"context"
	"encoding/json"
	"io"
	"net/http"
	"strings"
	"time"

	"github.com/goarxyz/goar/internal/core/types"
	"github.com/goarxyz/goar/internal/core/config"
	"github.com/goarxyz/goar/internal/core/llm"
	"github.com/goarxyz/goar/internal/core/utils"
)

// OpenAIAdapter implements OpenAI chat/completions.
type OpenAIAdapter struct{}

func (OpenAIAdapter) Endpoint() string { return "/chat/completions" }

func (a OpenAIAdapter) PrepareRequest(modelName string, messages []types.LLMMessage, temperature float64, tools []types.AvailableTool, maxTokens *int, toolChoice any, streaming bool, apiKey string, reasoningField string) (PreparedRequest, error) {
	converted := llm.MessagesToOpenAI(messages)
	if reasoningField != "" && reasoningField != "reasoning_content" {
		for _, m := range converted {
			if v, ok := m["reasoning_content"]; ok {
				m[reasoningField] = v
				delete(m, "reasoning_content")
			}
		}
	}
	payload := map[string]any{
		"model":       modelName,
		"messages":    converted,
		"temperature": temperature,
	}
	if len(tools) > 0 {
		payload["tools"] = llm.ToolsToOpenAI(tools)
	}
	if toolChoice != nil {
		payload["tool_choice"] = toolChoice
	}
	if maxTokens != nil {
		payload["max_tokens"] = *maxTokens
	}
	if streaming {
		payload["stream"] = true
		payload["stream_options"] = map[string]any{"include_usage": true}
	}
	body, err := json.Marshal(payload)
	if err != nil {
		return PreparedRequest{}, err
	}
	headers := map[string]string{"Content-Type": "application/json"}
	if apiKey != "" {
		headers["Authorization"] = "Bearer " + apiKey
	}
	return PreparedRequest{Endpoint: a.Endpoint(), Headers: headers, Body: body}, nil
}

func (a OpenAIAdapter) ParseResponse(data map[string]any, reasoningField string) (types.LLMChunk, error) {
	msg := types.LLMMessage{Role: types.RoleAssistant}
	if choices, ok := data["choices"].([]any); ok && len(choices) > 0 {
		ch, _ := choices[0].(map[string]any)
		rawMsg, _ := ch["message"].(map[string]any)
		if rawMsg == nil {
			rawMsg, _ = ch["delta"].(map[string]any)
		}
		if rawMsg != nil {
			if reasoningField != "" && reasoningField != "reasoning_content" {
				if v, ok := rawMsg[reasoningField]; ok {
					rawMsg["reasoning_content"] = v
					delete(rawMsg, reasoningField)
				}
			}
			b, _ := json.Marshal(rawMsg)
			_ = json.Unmarshal(b, &msg)
			if msg.Role == "" {
				msg.Role = types.RoleAssistant
			}
		}
	}
	var usage *types.LLMUsage
	if u, ok := data["usage"].(map[string]any); ok {
		usage = &types.LLMUsage{
			PromptTokens:     asInt(u["prompt_tokens"]),
			CompletionTokens: asInt(u["completion_tokens"]),
		}
	}
	return types.LLMChunk{Message: msg, Usage: usage}, nil
}

func asInt(v any) int {
	switch t := v.(type) {
	case float64:
		return int(t)
	case int:
		return t
	case json.Number:
		i, _ := t.Int64()
		return int(i)
	}
	return 0
}

// GenericBackend is the HTTP OpenAI-compatible backend.
type GenericBackend struct {
	Provider config.ProviderConfig
	Client   *http.Client
	Timeout  time.Duration
}

// NewGenericBackend constructs a GenericBackend.
func NewGenericBackend(provider config.ProviderConfig, timeoutSec float64) *GenericBackend {
	if timeoutSec <= 0 {
		timeoutSec = 720
	}
	return &GenericBackend{
		Provider: provider,
		Client:   utils.BuildHTTPClient(timeoutSec, false),
		Timeout:  time.Duration(timeoutSec * float64(time.Second)),
	}
}

func (b *GenericBackend) adapter() APIAdapter {
	switch b.Provider.APIStyle {
	case "anthropic":
		return AnthropicAdapter{}
	case "openai-responses":
		return OpenAIResponsesAdapter{}
	case "reasoning":
		return ReasoningAdapter{}
	case "vertex-anthropic":
		return &VertexAnthropicAdapter{ProjectID: b.Provider.ProjectID, Region: b.Provider.Region}
	default:
		return OpenAIAdapter{}
	}
}

// Complete performs a non-streaming chat completion.
func (b *GenericBackend) Complete(req llm.CompleteRequest) (types.LLMChunk, error) {
	ad := b.adapter()
	field := b.Provider.ReasoningFieldName
	if field == "" {
		field = "reasoning_content"
	}
	prep, err := ad.PrepareRequest(req.ModelName, req.Messages, req.Temperature, req.Tools, req.MaxTokens, req.ToolChoice, false, req.APIKey, field)
	if err != nil {
		return types.LLMChunk{}, err
	}
	base := prep.BaseURL
	if base == "" {
		base = req.APIBase
	}
	if base == "" {
		base = b.Provider.APIBase
	}
	url := utils.JoinURL(base, prep.Endpoint)
	ctx, cancel := context.WithTimeout(context.Background(), b.Timeout)
	defer cancel()
	httpReq, err := http.NewRequestWithContext(ctx, http.MethodPost, url, bytes.NewReader(prep.Body))
	if err != nil {
		return types.LLMChunk{}, err
	}
	for k, v := range prep.Headers {
		httpReq.Header.Set(k, v)
	}
	for k, v := range req.ExtraHeaders {
		httpReq.Header.Set(k, v)
	}
	for k, v := range b.Provider.ExtraHeaders {
		httpReq.Header.Set(k, v)
	}
	resp, err := b.Client.Do(httpReq)
	if err != nil {
		return types.LLMChunk{}, llm.NewBackendError(0, err.Error(), "")
	}
	defer resp.Body.Close()
	body, _ := io.ReadAll(resp.Body)
	if resp.StatusCode >= 300 {
		return types.LLMChunk{}, llm.NewBackendError(resp.StatusCode, http.StatusText(resp.StatusCode), string(body))
	}
	var data map[string]any
	if err := json.Unmarshal(body, &data); err != nil {
		return types.LLMChunk{}, err
	}
	return ad.ParseResponse(data, field)
}

// CompleteStreaming streams SSE chat completion chunks.
func (b *GenericBackend) CompleteStreaming(req llm.CompleteRequest, emit func(types.LLMChunk) error) error {
	ad := b.adapter()
	field := b.Provider.ReasoningFieldName
	if field == "" {
		field = "reasoning_content"
	}
	prep, err := ad.PrepareRequest(req.ModelName, req.Messages, req.Temperature, req.Tools, req.MaxTokens, req.ToolChoice, true, req.APIKey, field)
	if err != nil {
		return err
	}
	base := req.APIBase
	if base == "" {
		base = b.Provider.APIBase
	}
	url := utils.JoinURL(base, prep.Endpoint)
	ctx, cancel := context.WithTimeout(context.Background(), b.Timeout)
	defer cancel()
	httpReq, err := http.NewRequestWithContext(ctx, http.MethodPost, url, bytes.NewReader(prep.Body))
	if err != nil {
		return err
	}
	for k, v := range prep.Headers {
		httpReq.Header.Set(k, v)
	}
	resp, err := b.Client.Do(httpReq)
	if err != nil {
		return err
	}
	defer resp.Body.Close()
	if resp.StatusCode >= 300 {
		body, _ := io.ReadAll(resp.Body)
		return llm.NewBackendError(resp.StatusCode, http.StatusText(resp.StatusCode), string(body))
	}
	sc := bufio.NewScanner(resp.Body)
	for sc.Scan() {
		line := sc.Text()
		if !strings.HasPrefix(line, "data:") {
			continue
		}
		payload := strings.TrimSpace(strings.TrimPrefix(line, "data:"))
		if payload == "[DONE]" {
			break
		}
		var data map[string]any
		if err := json.Unmarshal([]byte(payload), &data); err != nil {
			continue
		}
		chunk, err := ad.ParseResponse(data, field)
		if err != nil {
			return err
		}
		if err := emit(chunk); err != nil {
			return err
		}
	}
	return sc.Err()
}

// Close implements BackendLike.
func (b *GenericBackend) Close() error { return nil }

// Ensure interface compliance.
var _ llm.BackendLike = (*GenericBackend)(nil)
