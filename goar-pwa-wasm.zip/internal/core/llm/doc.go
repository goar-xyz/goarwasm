// Package llm defines LLM types and backend protocols (Python: goar.types.llm).
package llm
