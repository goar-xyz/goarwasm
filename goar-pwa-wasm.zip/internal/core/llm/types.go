package llm

import (
	"github.com/goarxyz/goar/internal/core/config"
	"github.com/goarxyz/goar/internal/core/types"
)

// BackendLike is the injectable LLM backend protocol (Python BackendLike).
//
// Any backend used by GoarRuntime should implement Complete / CompleteStreaming
// plus Close for resource cleanup. Go does not use async context managers; callers
// should defer Close() after construction.
type BackendLike interface {
	Complete(req CompleteRequest) (types.LLMChunk, error)
	CompleteStreaming(req CompleteRequest, emit func(types.LLMChunk) error) error
	Close() error
}

// CompleteRequest is a chat completion request.
//
// Model may be provided either as ModelName (alias/name string) or as a full
// ModelConfig via Model; backends prefer Model when set.
type CompleteRequest struct {
	Model        *config.ModelConfig
	ModelName    string
	Messages     []types.LLMMessage
	Temperature  float64
	Tools        []types.AvailableTool
	MaxTokens    *int
	ToolChoice   any // StrToolChoice string, AvailableTool, or nil
	ExtraHeaders map[string]string
	Metadata     map[string]string
	APIBase      string
	APIKey       string
	APIStyle     string
	TimeoutSec   float64
	Thinking     string
}

// ResolvedModelName returns Model.Name / Alias / ModelName.
func (r CompleteRequest) ResolvedModelName() string {
	if r.Model != nil {
		if r.Model.Name != "" {
			return r.Model.Name
		}
		if r.Model.Alias != "" {
			return r.Model.Alias
		}
	}
	return r.ModelName
}

// WithModel returns a copy with Model set.
func (r CompleteRequest) WithModel(m config.ModelConfig) CompleteRequest {
	r.Model = &m
	if r.ModelName == "" {
		r.ModelName = m.Alias
		if r.ModelName == "" {
			r.ModelName = m.Name
		}
	}
	return r
}

// StrToolChoice mirrors Python StrToolChoice literals.
type StrToolChoice string

const (
	ToolChoiceAuto StrToolChoice = "auto"
	ToolChoiceNone StrToolChoice = "none"
	ToolChoiceRequired StrToolChoice = "required"
)

// NewCompleteRequest builds a request from common runtime fields.
func NewCompleteRequest(model config.ModelConfig, messages []types.LLMMessage, temperature float64) CompleteRequest {
	return CompleteRequest{
		Model:       &model,
		ModelName:   model.Alias,
		Messages:    messages,
		Temperature: temperature,
	}.WithModel(model)
}
