package llm

import (
	"encoding/json"

	"github.com/goarxyz/goar/internal/core/types"
)

// MessagesToOpenAI converts messages to OpenAI chat payload objects.
func MessagesToOpenAI(msgs []types.LLMMessage) []map[string]any {
	out := make([]map[string]any, 0, len(msgs))
	for _, m := range msgs {
		row := map[string]any{"role": string(m.Role)}
		if m.Content != nil {
			row["content"] = *m.Content
		}
		if m.Name != nil {
			row["name"] = *m.Name
		}
		if m.ToolCallID != nil {
			row["tool_call_id"] = *m.ToolCallID
		}
		if m.ReasoningContent != nil {
			row["reasoning_content"] = *m.ReasoningContent
		}
		if len(m.ToolCalls) > 0 {
			tcs := make([]map[string]any, 0, len(m.ToolCalls))
			for _, tc := range m.ToolCalls {
				tcs = append(tcs, map[string]any{
					"id":   tc.ID,
					"type": "function",
					"function": map[string]any{
						"name":      tc.Function.Name,
						"arguments": tc.Function.Arguments,
					},
				})
			}
			row["tool_calls"] = tcs
		}
		out = append(out, row)
	}
	return out
}

// ToolsToOpenAI converts tool schemas.
func ToolsToOpenAI(tools []types.AvailableTool) []map[string]any {
	out := make([]map[string]any, 0, len(tools))
	for _, t := range tools {
		typ := t.Type
		if typ == "" {
			typ = "function"
		}
		out = append(out, map[string]any{
			"type": typ,
			"function": map[string]any{
				"name":        t.Function.Name,
				"description": t.Function.Description,
				"parameters":  t.Function.Parameters,
			},
		})
	}
	return out
}

// ParseToolArguments unmarshals tool call arguments JSON.
func ParseToolArguments(args string) (map[string]any, error) {
	if args == "" {
		return map[string]any{}, nil
	}
	var m map[string]any
	if err := json.Unmarshal([]byte(args), &m); err != nil {
		return nil, err
	}
	return m, nil
}
