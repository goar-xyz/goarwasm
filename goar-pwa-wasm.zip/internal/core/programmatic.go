package core

import (
	"context"
	"encoding/json"
	"fmt"

	"github.com/goarxyz/goar/internal/core/config"
)

// ConversationLimitException is raised when middleware stops the loop.
type ConversationLimitException struct{ Msg string }

func (e ConversationLimitException) Error() string { return e.Msg }

// RunProgrammatic runs a headless prompt and returns the final assistant text.
func RunProgrammatic(ctx context.Context, cfg *config.Config, prompt string, opt RuntimeOptions) (string, error) {
	opt.Headless = true
	rt, err := NewRuntime(cfg, opt)
	if err != nil {
		return "", err
	}
	defer rt.Close()
	LogInfof("USER: %s", prompt)
	text, events, err := rt.Act(ctx, prompt)
	if err != nil {
		return text, err
	}
	for _, ev := range events {
		if ev.Type == "assistant" {
			var ae AssistantEvent
			_ = json.Unmarshal(ev.Payload, &ae)
			if ae.StoppedByMiddleware {
				return ae.Content, ConversationLimitException{Msg: ae.Content}
			}
		}
	}
	fmt.Println(text)
	return text, nil
}
