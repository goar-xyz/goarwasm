package core

import "testing"

func TestMaxTurnsMiddlewareAllowsExactlyMaxTurns(t *testing.T) {
	m := MaxTurnsMiddleware{Max: 1}

	// After user message is recorded, Steps==1; first LLM turn must be allowed.
	stop, _ := m.BeforeTurn(nil, &AgentStats{Steps: 1})
	if stop {
		t.Fatalf("max-turns=1 must allow the first LLM turn when Steps==1")
	}

	// After Steps is incremented for that LLM turn (Steps==2), further turns stop.
	stop, reason := m.BeforeTurn(nil, &AgentStats{Steps: 2})
	if !stop {
		t.Fatalf("max-turns=1 must stop when Steps==2 (one LLM turn started)")
	}
	if reason == "" {
		t.Fatalf("expected stop reason")
	}

	// Align with TurnLimitMiddleware semantics (Steps-1 >= Max).
	tl := &TurnLimitMiddleware{MaxTurns: 1}
	if r := tl.BeforeTurn(ConversationContext{Stats: &AgentStats{Steps: 1}}); r.Action != MiddlewareContinue {
		t.Fatalf("TurnLimit MaxTurns=1 should continue at Steps=1, got %v", r.Action)
	}
	if r := tl.BeforeTurn(ConversationContext{Stats: &AgentStats{Steps: 2}}); r.Action != MiddlewareStop {
		t.Fatalf("TurnLimit MaxTurns=1 should stop at Steps=2, got %v", r.Action)
	}
}

func TestMaxTurnsMiddlewareZeroDisables(t *testing.T) {
	m := MaxTurnsMiddleware{Max: 0}
	stop, _ := m.BeforeTurn(nil, &AgentStats{Steps: 100})
	if stop {
		t.Fatalf("Max=0 must not stop")
	}
}
