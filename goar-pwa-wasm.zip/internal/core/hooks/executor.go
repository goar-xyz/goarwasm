package hooks

import (
	"bytes"
	"context"
	"encoding/json"
	"io"
	"net/http"
	"os"
	"os/exec"
	"runtime"
	"strings"
	"time"

	"github.com/goarxyz/goar/internal/core/utils"
	"github.com/goarxyz/goar/internal/core/wasmshell"
)

// Execute runs a hook command with JSON event on stdin.
func Execute(ctx context.Context, h Hook, payload any) HookResult {
	cmd := strings.TrimSpace(h.Command)
	if cmd == "" {
		return HookResult{Hook: h, OK: false, Message: "empty hook command"}
	}

	// HTTP hooks: command is an absolute http(s) URL — POST JSON payload.
	if strings.HasPrefix(cmd, "http://") || strings.HasPrefix(cmd, "https://") {
		return executeHTTP(ctx, h, payload)
	}

	timeout := 30 * time.Second
	if h.Timeout > 0 {
		timeout = time.Duration(h.Timeout * float64(time.Second))
	}
	cctx, cancel := context.WithTimeout(ctx, timeout)
	defer cancel()
	body, _ := json.Marshal(payload)

	if runtime.GOOS == "js" {
		return executeWasmShell(cctx, h, body)
	}

	var execCmd *exec.Cmd
	if utils.IsWindows() {
		execCmd = exec.CommandContext(cctx, "cmd", "/C", h.Command)
	} else {
		execCmd = exec.CommandContext(cctx, utils.ShellExecutable(), "-c", h.Command)
	}
	execCmd.Env = os.Environ()
	for k, v := range h.Env {
		execCmd.Env = append(execCmd.Env, k+"="+v)
	}
	execCmd.Stdin = bytes.NewReader(body)
	var stdout, stderr bytes.Buffer
	execCmd.Stdout = &stdout
	execCmd.Stderr = &stderr
	err := execCmd.Run()
	out := stdout.String() + stderr.String()
	if err != nil {
		return HookResult{Hook: h, OK: false, Output: out, Message: err.Error()}
	}
	return parseHookOutput(h, stdout.Bytes(), out)
}

func executeWasmShell(_ context.Context, h Hook, body []byte) HookResult {
	// Apply env for wasmshell exports, then run command text through MEMFS shell.
	for k, v := range h.Env {
		_ = os.Setenv(k, v)
		wasmshell.Run("export " + k + "=" + shellSingleQuote(v))
	}
	// Expose payload via env for simple hooks; full stdin piping is not available in wasmshell.
	_ = os.Setenv("GOAR_HOOK_PAYLOAD", string(body))
	r := wasmshell.Run(h.Command)
	out := r.Stdout + r.Stderr
	if r.ReturnCode != 0 {
		msg := r.Stderr
		if msg == "" {
			msg = "hook exited " + itoa(r.ReturnCode)
		}
		if need, name := wasmshell.NeedsRemote(h.Command); need {
			msg = "hook command " + name + " needs SSH under WASM; use a MEMFS shell script or an HTTP hook URL"
		}
		return HookResult{Hook: h, OK: false, Output: out, Message: strings.TrimSpace(msg)}
	}
	return parseHookOutput(h, []byte(r.Stdout), out)
}

func executeHTTP(ctx context.Context, h Hook, payload any) HookResult {
	timeout := 30 * time.Second
	if h.Timeout > 0 {
		timeout = time.Duration(h.Timeout * float64(time.Second))
	}
	cctx, cancel := context.WithTimeout(ctx, timeout)
	defer cancel()
	body, _ := json.Marshal(payload)
	req, err := http.NewRequestWithContext(cctx, http.MethodPost, strings.TrimSpace(h.Command), bytes.NewReader(body))
	if err != nil {
		return HookResult{Hook: h, OK: false, Message: err.Error()}
	}
	req.Header.Set("Content-Type", "application/json")
	for k, v := range h.Env {
		if strings.HasPrefix(strings.ToLower(k), "header_") {
			req.Header.Set(k[7:], v)
		}
	}
	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		return HookResult{Hook: h, OK: false, Message: err.Error()}
	}
	defer resp.Body.Close()
	raw, _ := io.ReadAll(io.LimitReader(resp.Body, 1<<20))
	out := string(raw)
	if resp.StatusCode >= 400 {
		return HookResult{Hook: h, OK: false, Output: out, Message: "HTTP " + itoa(resp.StatusCode)}
	}
	return parseHookOutput(h, raw, out)
}

func parseHookOutput(h Hook, stdout []byte, out string) HookResult {
	blocked := false
	msg := ""
	var parsed map[string]any
	if json.Unmarshal(stdout, &parsed) == nil {
		if b, ok := parsed["block"].(bool); ok && b {
			blocked = true
		}
		if m, ok := parsed["message"].(string); ok {
			msg = m
		}
	}
	return HookResult{Hook: h, OK: true, Output: out, Blocked: blocked, Message: msg}
}

func shellSingleQuote(s string) string {
	return "'" + strings.ReplaceAll(s, "'", `'"'"'`) + "'"
}

func itoa(n int) string {
	if n == 0 {
		return "0"
	}
	neg := n < 0
	if neg {
		n = -n
	}
	var b [20]byte
	i := len(b)
	for n > 0 {
		i--
		b[i] = byte('0' + n%10)
		n /= 10
	}
	if neg {
		i--
		b[i] = '-'
	}
	return string(b[i:])
}
