package hooks

import (
	"github.com/goarxyz/goar/internal/core/config"
	"os"
	"path/filepath"

	"github.com/BurntSushi/toml"
	"github.com/goarxyz/goar/internal/core/paths"
)

type hooksFile struct {
	Hooks []Hook `toml:"hooks"`
}

// LoadHooks loads hooks from ~/.agent/hooks.toml and .agent/hooks.toml.
func LoadHooks(workdir string) HookConfigResult {
	res := HookConfigResult{}
	for _, p := range []string{
		filepath.Join(paths.Home(), "hooks.toml"),
		filepath.Join(workdir, paths.ConfigDirName, "hooks.toml"),
	} {
		var f hooksFile
		if _, err := os.Stat(p); err != nil {
			continue
		}
		if _, err := toml.DecodeFile(p, &f); err != nil {
			res.Issues = append(res.Issues, p+": "+err.Error())
			continue
		}
		res.Hooks = append(res.Hooks, f.Hooks...)
	}
	return res
}

// LoadHooksFromFS loads hooks using the config's working context.
func LoadHooksFromFS(cfg *config.Config) HookConfigResult {
	_ = cfg
	wd, _ := os.Getwd()
	return LoadHooks(wd)
}
