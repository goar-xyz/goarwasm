package hooks

import (
	"fmt"
	"path/filepath"
	"strings"
)

// Hook event names used by the runtime (compat + Python HookType values).
const (
	EventPreToolUse    = "PreToolUse"
	EventPostToolUse   = "PostToolUse"
	EventPreLLM        = "PreLLM"
	EventPostLLM       = "PostLLM"
	EventSessionStart  = "SessionStart"
	EventSessionEnd    = "SessionEnd"
	EventPostAgentTurn = "PostAgentTurn"
)

// HookMessageSeverity classifies hook end status (Python HookMessageSeverity).
type HookMessageSeverity string

const (
	SeverityOK      HookMessageSeverity = "ok"
	SeverityWarning HookMessageSeverity = "warning"
	SeverityError   HookMessageSeverity = "error"
)

// HookType is the declarative hook type (Python HookType).
type HookType string

const (
	HookTypePostAgentTurn HookType = "post_agent_turn"
)

// Hook is a configured hook action executed by Manager.
type Hook struct {
	Name        string            `json:"name" toml:"name"`
	Event       string            `json:"event" toml:"event"`
	Type        HookType          `json:"type" toml:"type"`
	Command     string            `json:"command" toml:"command"`
	Matcher     string            `json:"matcher" toml:"matcher"`
	Env         map[string]string `json:"env" toml:"env"`
	Timeout     float64           `json:"timeout" toml:"timeout"`
	Description string            `json:"description" toml:"description"`
}

// Validate checks required hook fields.
func (h Hook) Validate() error {
	if strings.TrimSpace(h.Command) == "" {
		return fmt.Errorf("command must not be empty")
	}
	return nil
}

// NormalizeEvent maps HookType to Event* string when Event is empty and defaults timeout.
func (h *Hook) NormalizeEvent() {
	if h.Event == "" {
		switch h.Type {
		case HookTypePostAgentTurn:
			h.Event = EventPostAgentTurn
		}
	}
	if h.Timeout <= 0 {
		h.Timeout = 30
	}
}

// HookConfigIssue records a load problem for a hooks file.
type HookConfigIssue struct {
	File    string `json:"file"`
	Message string `json:"message"`
}

// HookConfigResult is loaded hooks plus issues (Python HookConfigResult).
// Issues stays []string for runtime/config callers; TypedIssues holds structured form.
type HookConfigResult struct {
	Hooks       []Hook            `json:"hooks"`
	Issues      []string          `json:"issues"`
	TypedIssues []HookConfigIssue `json:"typed_issues,omitempty"`
}

// AddIssue records both string and typed issue forms.
func (r *HookConfigResult) AddIssue(file, message string) {
	r.Issues = append(r.Issues, file+": "+message)
	r.TypedIssues = append(r.TypedIssues, HookConfigIssue{File: file, Message: message})
}

// HookInvocation is the JSON payload passed to a hook subprocess (Python HookInvocation).
type HookInvocation struct {
	SessionID      string `json:"session_id"`
	TranscriptPath string `json:"transcript_path"`
	Cwd            string `json:"cwd"`
	HookEventName  string `json:"hook_event_name"`
}

// HookExecutionResult is a subprocess outcome (Python HookExecutionResult).
type HookExecutionResult struct {
	HookName string `json:"hook_name"`
	ExitCode *int   `json:"exit_code"`
	Stdout   string `json:"stdout"`
	Stderr   string `json:"stderr"`
	TimedOut bool   `json:"timed_out"`
}

// HookUserMessage is injected user content from hook stdout (Python HookUserMessage).
type HookUserMessage struct {
	Content string `json:"content"`
}

// HookResult is an execution result used by Manager.RunEvent.
type HookResult struct {
	Hook    Hook
	OK      bool
	Output  string
	Blocked bool
	Message string
}

// HookStartEvent marks a single hook beginning.
type HookStartEvent struct {
	HookName string `json:"hook_name"`
}

// HookEndEvent marks a single hook finishing.
type HookEndEvent struct {
	HookName string              `json:"hook_name"`
	Status   HookMessageSeverity `json:"status"`
	Content  string              `json:"content,omitempty"`
}

// HookFileName returns the conventional hooks.toml basename.
func HookFileName() string { return "hooks.toml" }

// ResolveHookPath joins a directory with hooks.toml.
func ResolveHookPath(dir string) string {
	return filepath.Join(dir, HookFileName())
}
