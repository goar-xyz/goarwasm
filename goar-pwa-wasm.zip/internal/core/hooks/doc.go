// Package hooks implements lifecycle hooks for tool/LLM events.
package hooks
