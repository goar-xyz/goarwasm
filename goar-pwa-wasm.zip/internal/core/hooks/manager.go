package hooks

import (
	"context"
	"path/filepath"

	"github.com/goarxyz/goar/internal/core/paths"
	"sync"

	"github.com/goarxyz/goar/internal/core/utils"
)

// Manager runs matching hooks for events.
type Manager struct {
	mu    sync.RWMutex
	hooks []Hook
}

// NewManager creates a hooks manager.
func NewManager(hooks []Hook) *Manager {
	return &Manager{hooks: append([]Hook{}, hooks...)}
}

// RunEvent executes all hooks for an event name, optionally filtered by tool name.
func (m *Manager) RunEvent(ctx context.Context, event, toolName string, payload any) []HookResult {
	m.mu.RLock()
	defer m.mu.RUnlock()
	var results []HookResult
	for _, h := range m.hooks {
		if h.Event != event {
			continue
		}
		if h.Matcher != "" && toolName != "" && !utils.MatchPattern(toolName, h.Matcher) {
			continue
		}
		results = append(results, Execute(ctx, h, payload))
	}
	return results
}

// AnyBlocked reports if any result blocked.
func AnyBlocked(results []HookResult) (bool, string) {
	for _, r := range results {
		if r.Blocked {
			return true, r.Message
		}
	}
	return false, ""
}

// HooksFilePath helper.
func HooksFilePath(home bool) string {
	if home {
		return filepath.Join("hooks.toml")
	}
	return filepath.Join(paths.ConfigDirName, "hooks.toml")
}
