// Package providers holds the first-run / config catalog of LLM providers.
package providers

// ModelPair is a (model_id, alias) default shipped for a provider.
type ModelPair struct {
	ID    string
	Alias string
}

// Preset is a catalog entry for a hosted or local LLM provider.
type Preset struct {
	Key                string
	DisplayName        string
	Description        string
	APIBase            string
	APIKeyEnvVar       string
	APIStyle           string // "openai" or "anthropic"
	Backend            string // "generic"
	Models             []ModelPair
	RequiresCustomBase bool
	DefaultBaseHint    string
	Notes              string
}

// Catalog mirrors goar/core/providers/catalog.py PROVIDER_CATALOG.
var Catalog = []Preset{
	{
		Key: "openai", DisplayName: "OpenAI",
		Description: "Official OpenAI API (GPT-4.1, GPT-4o, o-series)",
		APIBase:     "https://api.openai.com/v1", APIKeyEnvVar: "OPENAI_API_KEY",
		APIStyle: "openai", Backend: "generic",
		Models: []ModelPair{{"gpt-4.1", "gpt-4.1"}, {"gpt-4o", "gpt-4o"}, {"o4-mini", "o4-mini"}},
	},
	{
		Key: "anthropic", DisplayName: "Anthropic / Claude",
		Description: "Official Anthropic Messages API (Claude Sonnet, Opus, Haiku)",
		APIBase:     "https://api.anthropic.com", APIKeyEnvVar: "ANTHROPIC_API_KEY",
		APIStyle: "anthropic", Backend: "generic",
		Models: []ModelPair{{"claude-sonnet-4-5", "claude-sonnet"}, {"claude-opus-4-1", "claude-opus"}, {"claude-haiku-4-5", "claude-haiku"}},
		Notes:  "Uses Anthropic's native Messages API, not OpenAI-compat.",
	},
	{
		Key: "openrouter", DisplayName: "OpenRouter",
		Description: "One key for Claude, GPT, Gemini, Llama, and others",
		APIBase:     "https://openrouter.ai/api/v1", APIKeyEnvVar: "OPENROUTER_API_KEY",
		APIStyle: "openai", Backend: "generic",
		Models: []ModelPair{{"anthropic/claude-sonnet-4.5", "or-claude-sonnet"}, {"openai/gpt-4.1", "or-gpt-4.1"}, {"google/gemini-2.5-pro", "or-gemini"}},
	},
	{
		Key: "groq", DisplayName: "Groq",
		Description: "High-speed OpenAI-compatible inference",
		APIBase:     "https://api.groq.com/openai/v1", APIKeyEnvVar: "GROQ_API_KEY",
		APIStyle: "openai", Backend: "generic",
		Models: []ModelPair{{"llama-3.3-70b-versatile", "groq-llama"}},
	},
	{
		Key: "together", DisplayName: "Together AI",
		Description: "OpenAI-compatible hosted open models",
		APIBase:     "https://api.together.xyz/v1", APIKeyEnvVar: "TOGETHER_API_KEY",
		APIStyle: "openai", Backend: "generic",
		Models: []ModelPair{{"meta-llama/Meta-Llama-3.1-70B-Instruct-Turbo", "together-llama"}},
	},
	{
		Key: "fireworks", DisplayName: "Fireworks AI",
		Description: "OpenAI-compatible hosted inference",
		APIBase:     "https://api.fireworks.ai/inference/v1", APIKeyEnvVar: "FIREWORKS_API_KEY",
		APIStyle: "openai", Backend: "generic",
		Models: []ModelPair{{"accounts/fireworks/models/llama-v3p3-70b-instruct", "fireworks-llama"}},
	},
	{
		Key: "nvidia", DisplayName: "NVIDIA NIM",
		Description: "NVIDIA integrate API (OpenAI-compatible preset)",
		APIBase:     "https://integrate.api.nvidia.com/v1", APIKeyEnvVar: "NVIDIA_API_KEY",
		APIStyle: "openai", Backend: "generic",
		Models: []ModelPair{{"nvidia/llama-3.3-nemotron-super-49b-v1", "nemotron-super"}, {"meta/llama-3.1-405b-instruct", "llama-405b"}},
	},
	{
		Key: "azure", DisplayName: "Azure OpenAI",
		Description: "Azure OpenAI-compatible deployment endpoint",
		APIBase:     "", APIKeyEnvVar: "AZURE_OPENAI_API_KEY",
		APIStyle: "openai", Backend: "generic",
		RequiresCustomBase: true,
		DefaultBaseHint:    "https://YOUR-RESOURCE.openai.azure.com/openai/v1",
		Models:             []ModelPair{{"gpt-4o", "azure-gpt-4o"}},
		Notes:              "Paste the Azure resource endpoint. Deployment name becomes the model id.",
	},
	{
		Key: "cursor", DisplayName: "Cursor (OpenAI-compatible)",
		Description: "Any Cursor-compatible or Cursor-proxied OpenAI endpoint",
		APIBase:     "", APIKeyEnvVar: "CURSOR_API_KEY",
		APIStyle: "openai", Backend: "generic",
		RequiresCustomBase: true,
		DefaultBaseHint:    "https://your-cursor-compatible-host/v1",
		Models:             []ModelPair{{"gpt-4o", "cursor-gpt"}, {"claude-sonnet-4-5", "cursor-claude"}},
		Notes:              "Enter the OpenAI-compatible base URL and key you already use with Cursor.",
	},
	{
		Key: "ollama", DisplayName: "Ollama (local)",
		Description: "Local OpenAI-compatible server at localhost:11434",
		APIBase:     "http://127.0.0.1:11434/v1", APIKeyEnvVar: "",
		APIStyle: "openai", Backend: "generic",
		Models: []ModelPair{{"llama3.1", "local-ollama"}},
		Notes:  "No API key required. Start Ollama first.",
	},
	{
		Key: "llamacpp", DisplayName: "llama.cpp / local server",
		Description: "Local OpenAI-compatible server at localhost:8080",
		APIBase:     "http://127.0.0.1:8080/v1", APIKeyEnvVar: "",
		APIStyle: "openai", Backend: "generic",
		Models: []ModelPair{{"local-model", "local"}},
		Notes:  "No API key required. Point at llama.cpp, vLLM, LM Studio, etc.",
	},
	{
		Key: "custom", DisplayName: "Custom OpenAI-compatible",
		Description: "Any OpenAI-compatible gateway, proxy, or self-hosted server",
		APIBase:     "", APIKeyEnvVar: "OPENAI_API_KEY",
		APIStyle: "openai", Backend: "generic",
		RequiresCustomBase: true,
		DefaultBaseHint:    "https://your-host/v1",
		Models:             []ModelPair{{"custom-model", "custom"}},
	},
}

// Find returns a preset by key (case-insensitive), or nil.
func Find(key string) *Preset {
	needle := normalize(key)
	for i := range Catalog {
		if Catalog[i].Key == needle {
			return &Catalog[i]
		}
	}
	return nil
}

func normalize(s string) string {
	b := make([]byte, 0, len(s))
	for i := 0; i < len(s); i++ {
		c := s[i]
		if c >= 'A' && c <= 'Z' {
			c += 'a' - 'A'
		}
		if c == ' ' || c == '\t' {
			continue
		}
		b = append(b, c)
	}
	return string(b)
}
