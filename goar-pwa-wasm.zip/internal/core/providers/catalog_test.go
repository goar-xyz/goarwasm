package providers

import "testing"

func TestCatalogFind(t *testing.T) {
	if Find("openai") == nil {
		t.Fatal("openai missing")
	}
	if Find("NVIDIA") == nil { // case / normalize
		// our normalize lowercases - "nvidia"
	}
	if Find("nvidia") == nil {
		t.Fatal("nvidia missing")
	}
	if Find("nope") != nil {
		t.Fatal("expected nil")
	}
	if len(Catalog) < 10 {
		t.Fatalf("catalog too small: %d", len(Catalog))
	}
}
