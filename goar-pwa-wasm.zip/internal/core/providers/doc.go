// Package providers holds the LLM provider catalog (Python: goar.core.providers).
package providers
