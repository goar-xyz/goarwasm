// Package core contains the GOAR runtime, types, middleware, compaction,
// programmatic mode, logging, and related engine surfaces (Python: goar.core).
package core
