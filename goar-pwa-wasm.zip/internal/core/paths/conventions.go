package paths

// AgentsMDFilename is the project instructions file name.
const AgentsMDFilename = "AGENTS.md"

// AgentMDFilename is the optional project instruction file (AGENT.md).
const AgentMDFilename = "AGENT.md"

// ConfigDirName is the project-local config directory.
const ConfigDirName = ".agent"

// ConfigFileName is the TOML config file name.
const ConfigFileName = "config.toml"

// IgnoreFileName is the project ignore file.
const IgnoreFileName = ".agentignore"
