package paths

import (
	"os"
	"path/filepath"
)

// WalkMaxDepth limits upward config discovery.
const WalkMaxDepth = 32

// ConfigWalkResult aggregates discovered local harness directories.
// Port of goar.core.paths._local_config_walk.ConfigWalkResult.
type ConfigWalkResult struct {
	Dir        string
	ConfigFile string
	AgentsMD   string
	Tools      []string
	Skills     []string
	Agents     []string
	Prompts    []string
}

// Merge combines another walk result into this one.
func (r ConfigWalkResult) Merge(o ConfigWalkResult) ConfigWalkResult {
	r.Tools = append(r.Tools, o.Tools...)
	r.Skills = append(r.Skills, o.Skills...)
	r.Agents = append(r.Agents, o.Agents...)
	r.Prompts = append(r.Prompts, o.Prompts...)
	if o.ConfigFile != "" && r.ConfigFile == "" {
		r.ConfigFile = o.ConfigFile
	}
	if o.AgentsMD != "" && r.AgentsMD == "" {
		r.AgentsMD = o.AgentsMD
	}
	return r
}

// OrMerge is the |= operator from Python ConfigWalkResult.
func (r *ConfigWalkResult) OrMerge(o ConfigWalkResult) {
	*r = r.Merge(o)
}

// DedupPaths removes duplicate paths preserving order.
func DedupPaths(in []string) []string {
	seen := map[string]struct{}{}
	out := make([]string, 0, len(in))
	for _, p := range in {
		if _, ok := seen[p]; ok {
			continue
		}
		seen[p] = struct{}{}
		out = append(out, p)
	}
	return out
}

func dirIfExists(p string) string {
	if st, err := os.Stat(p); err == nil && st.IsDir() {
		return p
	}
	return ""
}

// WalkLocalConfigDirs walks from start up looking for .agent dirs / AGENTS.md
// and nested tools/skills/agents/prompts directories.
func WalkLocalConfigDirs(start string) []ConfigWalkResult {
	var results []ConfigWalkResult
	dir := start
	for i := 0; i < WalkMaxDepth; i++ {
		cfgDir := filepath.Join(dir, ConfigDirName)
		agentsMD := filepath.Join(dir, AgentsMDFilename)
		res := ConfigWalkResult{Dir: dir}
		if st, err := os.Stat(cfgDir); err == nil && st.IsDir() {
			res.ConfigFile = filepath.Join(cfgDir, ConfigFileName)
			if d := dirIfExists(filepath.Join(cfgDir, "tools")); d != "" {
				res.Tools = append(res.Tools, d)
			}
			if d := dirIfExists(filepath.Join(cfgDir, "skills")); d != "" {
				res.Skills = append(res.Skills, d)
			}
			if d := dirIfExists(filepath.Join(cfgDir, "agents")); d != "" {
				res.Agents = append(res.Agents, d)
			}
			if d := dirIfExists(filepath.Join(cfgDir, "prompts")); d != "" {
				res.Prompts = append(res.Prompts, d)
			}
		}
		if _, err := os.Stat(agentsMD); err == nil {
			res.AgentsMD = agentsMD
		}
		if res.ConfigFile != "" || res.AgentsMD != "" || len(res.Tools)+len(res.Skills)+len(res.Agents)+len(res.Prompts) > 0 {
			results = append(results, res)
		}
		parent := filepath.Dir(dir)
		if parent == dir {
			break
		}
		dir = parent
	}
	return results
}

// AggregateWalk merges a list of walk results into one.
func AggregateWalk(results []ConfigWalkResult) ConfigWalkResult {
	var out ConfigWalkResult
	for _, r := range results {
		out = out.Merge(r)
	}
	out.Tools = DedupPaths(out.Tools)
	out.Skills = DedupPaths(out.Skills)
	out.Agents = DedupPaths(out.Agents)
	out.Prompts = DedupPaths(out.Prompts)
	return out
}
