package paths

import "path/filepath"

// AgentsHome is ~/.agent/agents
func AgentsHome() string { return filepath.Join(Home(), "agents") }
