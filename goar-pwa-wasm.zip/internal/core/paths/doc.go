// Package paths resolves agent home and related filesystem locations (Python: goar.core.paths).
package paths
