// Package paths resolves agent home and related filesystem locations.
package paths

import (
	"os"
	"path/filepath"
)

// Home returns $AGENT_HOME or ~/.agent.
func Home() string {
	if v := os.Getenv("AGENT_HOME"); v != "" {
		return expand(v)
	}
	home, err := os.UserHomeDir()
	if err != nil {
		return ".agent"
	}
	return filepath.Join(home, ".agent")
}

// ConfigFile is ~/.agent/config.toml
func ConfigFile() string { return filepath.Join(Home(), "config.toml") }

// EnvFile is ~/.agent/.env
func EnvFile() string { return filepath.Join(Home(), ".env") }

// SessionLogDir is ~/.agent/logs/session
func SessionLogDir() string { return filepath.Join(Home(), "logs", "session") }

// LogDir is ~/.agent/logs
func LogDir() string { return filepath.Join(Home(), "logs") }

// LogFile is ~/.agent/logs/agent.log
func LogFile() string { return filepath.Join(Home(), "logs", "agent.log") }

// TrustedFoldersFile is ~/.agent/trusted_folders.toml
func TrustedFoldersFile() string { return filepath.Join(Home(), "trusted_folders.toml") }

// CacheFile is ~/.agent/cache.toml
func CacheFile() string { return filepath.Join(Home(), "cache.toml") }

// HistoryFile is ~/.agent/history
func HistoryFile() string { return filepath.Join(Home(), "history") }

// PlansDir is ~/.agent/plans
func PlansDir() string { return filepath.Join(Home(), "plans") }

// SkillsDir is ~/.agent/skills
func SkillsDir() string { return filepath.Join(Home(), "skills") }

// AgentsDir is ~/.agent/agents
func AgentsDir() string { return filepath.Join(Home(), "agents") }

// PluginsDir is ~/.agent/plugins
func PluginsDir() string { return filepath.Join(Home(), "plugins") }

// EnsureHome creates the home directory tree if missing.
func EnsureHome() error {
	dirs := []string{Home(), LogDir(), SessionLogDir(), SkillsDir(), AgentsDir(), PlansDir(), PluginsDir()}
	for _, d := range dirs {
		if err := os.MkdirAll(d, 0o755); err != nil {
			return err
		}
	}
	return nil
}

func expand(p string) string {
	if len(p) > 0 && p[0] == '~' {
		home, err := os.UserHomeDir()
		if err == nil {
			p = filepath.Join(home, p[1:])
		}
	}
	abs, err := filepath.Abs(p)
	if err != nil {
		return p
	}
	return abs
}
