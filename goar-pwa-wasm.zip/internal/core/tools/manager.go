package tools

import (
	"context"
	"fmt"
	"sync"

	"github.com/goarxyz/goar/internal/core/utils"

	"sort"
	"strings")

// Manager owns the registered tool set.
type Manager struct {
	mu    sync.RWMutex
	tools map[string]Tool
	order []string
}

// NewManager creates an empty manager.
func NewManager() *Manager {
	return &Manager{tools: map[string]Tool{}}
}

// Register adds a tool.
func (m *Manager) Register(t Tool) {
	m.mu.Lock()
	defer m.mu.Unlock()
	if _, ok := m.tools[t.Name()]; !ok {
		m.order = append(m.order, t.Name())
	}
	m.tools[t.Name()] = t
}

// Get returns a tool by name.
func (m *Manager) Get(name string) (Tool, bool) {
	m.mu.RLock()
	defer m.mu.RUnlock()
	t, ok := m.tools[name]
	return t, ok
}

// List returns tools in registration order.
func (m *Manager) List() []Tool {
	m.mu.RLock()
	defer m.mu.RUnlock()
	out := make([]Tool, 0, len(m.order))
	for _, n := range m.order {
		out = append(out, m.tools[n])
	}
	return out
}

// AvailableTools returns OpenAI-style tool schemas, filtered by enabled/disabled.
func (m *Manager) AvailableTools(enabled, disabled []string) []map[string]any {
	var out []map[string]any
	for _, t := range m.List() {
		name := t.Name()
		if len(enabled) > 0 && !utils.AnyMatch(name, enabled) {
			continue
		}
		if len(enabled) == 0 && utils.AnyMatch(name, disabled) {
			continue
		}
		out = append(out, map[string]any{
			"type": "function",
			"function": map[string]any{
				"name": name, "description": t.Description(), "parameters": t.Parameters(),
			},
		})
	}
	return out
}

// Invoke runs a tool by name with JSON-like args.
func (m *Manager) Invoke(ctx context.Context, name string, args map[string]any, inv *InvokeContext) (any, error) {
	t, ok := m.Get(name)
	if !ok {
		return nil, fmt.Errorf("unknown tool: %s", name)
	}
	return t.Run(ctx, args, inv)
}

// IntegrateAll is a no-op placeholder hook for MCP/connector discovery completion.
func (m *Manager) IntegrateAll() error { return nil }

// NoSuchToolError is returned when a tool name is unknown.
type NoSuchToolError struct{ Name string }

func (e NoSuchToolError) Error() string { return "no such tool: " + e.Name }

// RegisteredTools returns all registered tool names.
func (m *Manager) RegisteredTools() []string {
	m.mu.RLock()
	defer m.mu.RUnlock()
	out := make([]string, 0, len(m.tools))
	for name := range m.tools {
		out = append(out, name)
	}
	sort.Strings(out)
	return out
}

// IsToolAvailable applies enabled/disabled filters.
func (m *Manager) IsToolAvailable(name string, enabled, disabled []string) bool {
	if len(disabled) > 0 {
		for _, d := range disabled {
			if d == name || d == "*" {
				return false
			}
		}
	}
	if len(enabled) > 0 {
		ok := false
		for _, e := range enabled {
			if e == name || e == "*" {
				ok = true
				break
			}
		}
		if !ok {
			return false
		}
	}
	_, exists := m.Get(name)
	return exists
}

// DiscoverToolDefaults returns name→permission defaults for registered tools.
func (m *Manager) DiscoverToolDefaults() map[string]ToolPermission {
	out := map[string]ToolPermission{}
	for _, t := range m.List() {
		out[t.Name()] = t.Permission()
	}
	return out
}

// SourceDisableIndex tracks per-source (mcp/connector) disabled tools.
type SourceDisableIndex struct {
	Sources map[string]bool
	Tools   map[string]bool // "source.tool"
}

// BuildSourceDisableIndex constructs the index from config-like maps.
func BuildSourceDisableIndex(disabledSources []string, disabledTools map[string][]string) SourceDisableIndex {
	idx := SourceDisableIndex{Sources: map[string]bool{}, Tools: map[string]bool{}}
	for _, s := range disabledSources {
		idx.Sources[s] = true
	}
	for src, tools := range disabledTools {
		for _, t := range tools {
			idx.Tools[src+"."+t] = true
		}
	}
	return idx
}

func (idx SourceDisableIndex) IsSourceDisabled(name string) bool { return idx.Sources[name] }

func (idx SourceDisableIndex) IsToolDisabled(source, tool string) bool {
	return idx.Sources[source] || idx.Tools[source+"."+tool]
}

// ApplyPerSourceFiltering removes tools belonging to disabled sources.
func (m *Manager) ApplyPerSourceFiltering(idx SourceDisableIndex, sourceOf func(toolName string) string) {
	m.mu.Lock()
	defer m.mu.Unlock()
	for name := range m.tools {
		src := sourceOf(name)
		if src == "" {
			continue
		}
		tool := name
		if i := strings.LastIndex(name, "_"); i >= 0 {
			tool = name[i+1:]
		}
		if idx.IsToolDisabled(src, tool) {
			delete(m.tools, name)
		}
	}
}

// PurgeByPrefix removes tools whose names start with prefix.
func (m *Manager) PurgeByPrefix(prefix string) int {
	m.mu.Lock()
	defer m.mu.Unlock()
	n := 0
	for name := range m.tools {
		if strings.HasPrefix(name, prefix) {
			delete(m.tools, name)
			n++
		}
	}
	return n
}

// IntegrateMCP is a hook for MCP registry integration.
func (m *Manager) IntegrateMCP(register func(*Manager)) {
	if register != nil {
		register(m)
	}
}

// IntegrateConnectors is a hook for connector registry integration.
func (m *Manager) IntegrateConnectors(register func(*Manager)) {
	if register != nil {
		register(m)
	}
}

// RefreshRemoteTools re-runs remote registrations.
func (m *Manager) RefreshRemoteTools(mcpReg, connReg func(*Manager)) {
	m.IntegrateMCP(mcpReg)
	m.IntegrateConnectors(connReg)
}
