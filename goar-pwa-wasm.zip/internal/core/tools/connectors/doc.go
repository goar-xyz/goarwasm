// Package connectors implements optional OAuth-backed connector tools.
package connectors
