package connectors

import (
	"context"
	"fmt"
	"sync"

	"github.com/goarxyz/goar/internal/core/tools"
)

// ConnectorConfig is per-connector settings.
type ConnectorConfig struct {
	Name          string   `json:"name" toml:"name"`
	Disabled      bool     `json:"disabled" toml:"disabled"`
	DisabledTools []string `json:"disabled_tools" toml:"disabled_tools"`
	AuthType      string   `json:"auth_type" toml:"auth_type"` // oauth|api_key|none
	APIBase       string   `json:"api_base" toml:"api_base"`
}

// Connector is a discoverable external tool provider.
type Connector interface {
	Name() string
	Tools() []tools.Tool
	Authenticate(ctx context.Context) error
	IsAuthenticated() bool
}

// Registry manages connectors.
type Registry struct {
	mu         sync.RWMutex
	connectors map[string]Connector
	configs    map[string]ConnectorConfig
	enabled    bool
}

// NewRegistry creates a connector registry.
func NewRegistry(enabled bool) *Registry {
	return &Registry{connectors: map[string]Connector{}, configs: map[string]ConnectorConfig{}, enabled: enabled}
}

// SetConfig stores per-connector config.
func (r *Registry) SetConfig(cfg ConnectorConfig) {
	r.mu.Lock()
	defer r.mu.Unlock()
	r.configs[cfg.Name] = cfg
}

// Register adds a connector.
func (r *Registry) Register(c Connector) {
	r.mu.Lock()
	defer r.mu.Unlock()
	r.connectors[c.Name()] = c
}

// DiscoverTools returns tools from enabled authenticated connectors.
func (r *Registry) DiscoverTools() []tools.Tool {
	r.mu.RLock()
	defer r.mu.RUnlock()
	if !r.enabled {
		return nil
	}
	var out []tools.Tool
	for name, c := range r.connectors {
		cfg := r.configs[name]
		if cfg.Disabled {
			continue
		}
		disabled := map[string]bool{}
		for _, d := range cfg.DisabledTools {
			disabled[d] = true
		}
		for _, t := range c.Tools() {
			if disabled[t.Name()] {
				continue
			}
			out = append(out, t)
		}
	}
	return out
}

// AuthURL builds an OAuth authorization URL placeholder for a connector.
func (r *Registry) AuthURL(name, redirectURI string) (string, error) {
	r.mu.RLock()
	defer r.mu.RUnlock()
	cfg, ok := r.configs[name]
	if !ok {
		return "", fmt.Errorf("unknown connector: %s", name)
	}
	if cfg.AuthType != "oauth" {
		return "", fmt.Errorf("connector %s does not use oauth", name)
	}
	base := cfg.APIBase
	if base == "" {
		base = "https://example.invalid"
	}
	return fmt.Sprintf("%s/oauth/authorize?redirect_uri=%s&connector=%s", base, redirectURI, name), nil
}

// CompleteOAuth stores tokens from an OAuth callback.
func (r *Registry) CompleteOAuth(name, code string) error {
	r.mu.Lock()
	defer r.mu.Unlock()
	c, ok := r.connectors[name]
	if !ok {
		return fmt.Errorf("unknown connector: %s", name)
	}
	_ = code
	return c.Authenticate(context.Background())
}

// ConnectorAuthAction describes a required auth step for a connector.
type ConnectorAuthAction struct {
	ConnectorName string
	AuthURL       string
	Kind          string // oauth|api_key|device_code
	Message       string
}

// ConnectorAuthActionFromPayload hydrates an auth action from a bootstrap payload.
func ConnectorAuthActionFromPayload(name string, payload map[string]any) ConnectorAuthAction {
	a := ConnectorAuthAction{ConnectorName: name, Kind: "oauth"}
	if u, ok := payload["auth_url"].(string); ok {
		a.AuthURL = u
	}
	if k, ok := payload["kind"].(string); ok {
		a.Kind = k
	}
	if m, ok := payload["message"].(string); ok {
		a.Message = m
	}
	return a
}

// GetAuthAction returns auth requirements for a connector if not authenticated.
func (r *Registry) GetAuthAction(name string) (ConnectorAuthAction, bool) {
	r.mu.RLock()
	defer r.mu.RUnlock()
	c, ok := r.connectors[name]
	if !ok {
		return ConnectorAuthAction{}, false
	}
	if c.IsAuthenticated() {
		return ConnectorAuthAction{}, false
	}
	cfg := r.configs[name]
	kind := cfg.AuthType
	if kind == "" {
		kind = "oauth"
	}
	base := cfg.APIBase
	if base == "" {
		base = "https://example.invalid"
	}
	url := fmt.Sprintf("%s/oauth/authorize?connector=%s", base, name)
	return ConnectorAuthAction{ConnectorName: name, AuthURL: url, Kind: kind}, true
}

// GetAuthURL returns the auth URL for a connector.
func (r *Registry) GetAuthURL(name string) string {
	u, err := r.AuthURL(name, "http://127.0.0.1/callback")
	if err != nil {
		return ""
	}
	return u
}

// IsConnected reports whether a connector is authenticated.
func (r *Registry) IsConnected(name string) bool {
	r.mu.RLock()
	defer r.mu.RUnlock()
	c, ok := r.connectors[name]
	return ok && c.IsAuthenticated()
}

// GetConnectorNames returns registered connector names.
func (r *Registry) GetConnectorNames() []string {
	r.mu.RLock()
	defer r.mu.RUnlock()
	out := make([]string, 0, len(r.connectors))
	for n := range r.connectors {
		out = append(out, n)
	}
	return out
}

// ConnectorCount returns the number of connectors.
func (r *Registry) ConnectorCount() int {
	r.mu.RLock()
	defer r.mu.RUnlock()
	return len(r.connectors)
}

// DropConnector removes a connector.
func (r *Registry) DropConnector(name string) {
	r.mu.Lock()
	defer r.mu.Unlock()
	delete(r.connectors, name)
	delete(r.configs, name)
}

// Clear removes all connectors and configs.
func (r *Registry) Clear() {
	r.mu.Lock()
	defer r.mu.Unlock()
	r.connectors = map[string]Connector{}
	r.configs = map[string]ConnectorConfig{}
}

// GetConnectorID returns the connector name if registered.
func (r *Registry) GetConnectorID(name string) (string, bool) {
	r.mu.RLock()
	defer r.mu.RUnlock()
	_, ok := r.connectors[name]
	return name, ok
}

// RefreshConnectorAsync re-authenticates a connector.
func (r *Registry) RefreshConnectorAsync(ctx context.Context, name string) error {
	r.mu.RLock()
	c, ok := r.connectors[name]
	r.mu.RUnlock()
	if !ok {
		return fmt.Errorf("unknown connector: %s", name)
	}
	return c.Authenticate(ctx)
}

func normalizeConnectorName(name string) string {
	b := make([]byte, 0, len(name))
	for i := 0; i < len(name); i++ {
		c := name[i]
		if c >= 'A' && c <= 'Z' {
			c = c + ('a' - 'A')
		}
		if c == ' ' || c == '\t' {
			continue
		}
		b = append(b, c)
	}
	return string(b)
}

func deduplicateConnectorConfigs(in []ConnectorConfig) []ConnectorConfig {
	seen := map[string]bool{}
	var out []ConnectorConfig
	for _, c := range in {
		n := normalizeConnectorName(c.Name)
		if n == "" || seen[n] {
			continue
		}
		seen[n] = true
		c.Name = n
		out = append(out, c)
	}
	return out
}
