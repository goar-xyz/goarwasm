package tools

import (
	"encoding/json"
	"fmt"
	"strings"

	"github.com/goarxyz/goar/internal/core/types"
)

// ToolCallDisplay is UI summary for a tool invocation (Python ToolCallDisplay).
type ToolCallDisplay struct {
	Summary string `json:"summary"`
	Content string `json:"content,omitempty"`
}

// ToolResultDisplay is UI summary for a tool result (Python ToolResultDisplay).
type ToolResultDisplay struct {
	Success  bool     `json:"success"`
	Message  string   `json:"message"`
	Warnings []string `json:"warnings,omitempty"`
}

// ToolUI provides display helpers for a tool.
type ToolUI interface {
	DisplayName() string
	FormatCallDisplay(args map[string]any) ToolCallDisplay
	FormatResultDisplay(result any) ToolResultDisplay
	StatusText() string
}

// DefaultCallDisplay returns a generic call display.
func DefaultCallDisplay(name string) ToolCallDisplay {
	return ToolCallDisplay{Summary: name}
}

// InvalidArgsDisplay returns a call display for invalid args.
func InvalidArgsDisplay(name string) ToolCallDisplay {
	return ToolCallDisplay{Summary: name + " (invalid args)"}
}

// GetCallDisplay builds a call display from a tool-call event + optional formatter.
func GetCallDisplay(event types.ToolCallEvent, ui ToolUI) ToolCallDisplay {
	if ui == nil {
		return ToolCallDisplay{Summary: event.Name, Content: event.ArgsJSON}
	}
	args, err := parseArgsMap(event.ArgsJSON)
	if err != nil {
		d := ui.FormatCallDisplay(nil)
		if d.Summary == "" {
			d = InvalidArgsDisplay(ui.DisplayName())
		}
		return d
	}
	if len(args) == 0 {
		d := ui.FormatCallDisplay(nil)
		if d.Summary == "" {
			return DefaultCallDisplay(ui.DisplayName())
		}
		return d
	}
	return ui.FormatCallDisplay(args)
}

// GetResultDisplay builds a result display from a tool-result event + optional formatter.
func GetResultDisplay(event types.ToolResultEvent, ui ToolUI) ToolResultDisplay {
	if event.Error != "" {
		return ToolResultDisplay{Success: false, Message: event.Error}
	}
	if event.SkipReason != "" {
		return ToolResultDisplay{Success: false, Message: event.SkipReason}
	}
	if ui == nil {
		return ToolResultDisplay{Success: true, Message: truncate(event.ResultJSON, 200)}
	}
	var result any
	if event.ResultJSON != "" {
		_ = json.Unmarshal([]byte(event.ResultJSON), &result)
	}
	d := ui.FormatResultDisplay(result)
	if d.Message == "" {
		d.Message = truncate(event.ResultJSON, 200)
		d.Success = true
	}
	return d
}

// ToolUIDataAdapter adapts a Tool to ToolUI with defaults (Python ToolUIDataAdapter).
type ToolUIDataAdapter struct {
	Tool Tool
}

func (a ToolUIDataAdapter) DisplayName() string {
	if a.Tool == nil {
		return "tool"
	}
	return a.Tool.Name()
}

func (a ToolUIDataAdapter) FormatCallDisplay(args map[string]any) ToolCallDisplay {
	name := a.DisplayName()
	if len(args) == 0 {
		return DefaultCallDisplay(name)
	}
	b, _ := json.Marshal(args)
	return ToolCallDisplay{Summary: name, Content: truncate(string(b), 120)}
}

func (a ToolUIDataAdapter) FormatResultDisplay(result any) ToolResultDisplay {
	if result == nil {
		return ToolResultDisplay{Success: true, Message: "done"}
	}
	return ToolResultDisplay{Success: true, Message: truncate(fmt.Sprint(result), 200)}
}

func (a ToolUIDataAdapter) StatusText() string {
	return "Running " + a.DisplayName() + "…"
}

// GetStatusText returns spinner text for a tool UI.
func GetStatusText(ui ToolUI) string {
	if ui == nil {
		return "Working…"
	}
	return ui.StatusText()
}

func parseArgsMap(raw string) (map[string]any, error) {
	if strings.TrimSpace(raw) == "" {
		return map[string]any{}, nil
	}
	var m map[string]any
	err := json.Unmarshal([]byte(raw), &m)
	return m, err
}

func truncate(s string, n int) string {
	r := []rune(s)
	if len(r) <= n {
		return s
	}
	return string(r[:n]) + "…"
}
