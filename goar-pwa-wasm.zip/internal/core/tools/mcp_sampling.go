package tools

import (
	"context"
	"fmt"

	"github.com/goarxyz/goar/internal/core/llm"
	"github.com/goarxyz/goar/internal/core/types"
)

// MCPSamplingHandler fulfills MCP sampling/createMessage requests via the active backend
// (Python mcp_sampling.MCPSamplingHandler).
type MCPSamplingHandler struct {
	Backend      func() llm.BackendLike
	APIKey       func() string
	APIBase      func() string
	Model        func() string
	Temperature  float64
	ExtraHeaders func() map[string]string
	TimeoutSec   float64
}

// NewMCPSamplingHandler constructs a handler with required getters.
func NewMCPSamplingHandler(backend func() llm.BackendLike, model func() string) *MCPSamplingHandler {
	return &MCPSamplingHandler{Backend: backend, Model: model, Temperature: 0.2}
}

// CreateMessage handles a sampling request.
func (h *MCPSamplingHandler) CreateMessage(ctx context.Context, messages []types.LLMMessage, maxTokens int) (types.LLMChunk, error) {
	_ = ctx
	if h == nil || h.Backend == nil {
		return types.LLMChunk{}, BackendUnavailableError{}
	}
	b := h.Backend()
	if b == nil {
		return types.LLMChunk{}, BackendUnavailableError{}
	}
	modelName := ""
	if h.Model != nil {
		modelName = h.Model()
	}
	apiKey, apiBase := "", ""
	if h.APIKey != nil {
		apiKey = h.APIKey()
	}
	if h.APIBase != nil {
		apiBase = h.APIBase()
	}
	temp := h.Temperature
	if temp == 0 {
		temp = 0.2
	}
	mt := maxTokens
	req := llm.CompleteRequest{
		ModelName: modelName, Messages: messages, Temperature: temp,
		MaxTokens: &mt, APIKey: apiKey, APIBase: apiBase, TimeoutSec: h.TimeoutSec,
	}
	if h.ExtraHeaders != nil {
		req.ExtraHeaders = h.ExtraHeaders()
	}
	chunk, err := b.Complete(req)
	if err != nil {
		return types.LLMChunk{}, fmt.Errorf("MCP sampling failed: %w", err)
	}
	return chunk, nil
}

// CreateMessageText is a convenience that returns assistant text only.
func (h *MCPSamplingHandler) CreateMessageText(ctx context.Context, prompt string, maxTokens int) (string, error) {
	msgs := []types.LLMMessage{types.NewMessage(types.RoleUser, prompt)}
	chunk, err := h.CreateMessage(ctx, msgs, maxTokens)
	if err != nil {
		return "", err
	}
	return chunk.Message.ContentString(), nil
}

// BackendUnavailableError indicates no backend.
type BackendUnavailableError struct{}

func (BackendUnavailableError) Error() string { return "no LLM backend available for MCP sampling" }

// SamplingUnavailable reports whether the handler can serve requests.
func (h *MCPSamplingHandler) SamplingUnavailable() bool {
	return h == nil || h.Backend == nil || h.Backend() == nil
}
