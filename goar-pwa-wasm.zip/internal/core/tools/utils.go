package tools

import (
	"os"
	"path/filepath"
	"strings"

	"github.com/goarxyz/goar/internal/core/utils"
)

// ResolvePath is a tools-package helper.
func ResolvePath(p string) (string, error) { return utils.ResolvePath(p) }

// EnsureParentDir creates parent directories.
func EnsureParentDir(path string) error {
	return os.MkdirAll(filepath.Dir(path), 0o755)
}

// MakeAbsolute expands ~ and resolves to an absolute path.
func MakeAbsolute(pathStr string) (string, error) {
	pathStr = utils.ExpandUser(pathStr)
	if filepath.IsAbs(pathStr) {
		return filepath.Clean(pathStr), nil
	}
	cwd, err := os.Getwd()
	if err != nil {
		return "", err
	}
	return filepath.Clean(filepath.Join(cwd, pathStr)), nil
}

// ResolvePathPermission returns ALWAYS if under workdir, else ASK with outside_directory scope.
func ResolvePathPermission(pathStr, toolName string) *PermissionContext {
	abs, err := MakeAbsolute(pathStr)
	if err != nil {
		return &PermissionContext{Permission: PermissionAsk, Reason: err.Error()}
	}
	if IsPathWithinWorkdir(abs) {
		return &PermissionContext{Permission: PermissionAlways}
	}
	return &PermissionContext{
		Permission: PermissionAsk,
		RequiredPermissions: []RequiredPermission{{
			Scope: ScopeOutsideDirectory, InvocationPattern: abs, SessionPattern: abs,
			Label: toolName + " outside workdir",
		}},
	}
}

// IsPathWithinWorkdirString is an alias used by Python ports.
func IsPathWithinWorkdirString(pathStr string) bool {
	return IsPathWithinWorkdir(pathStr)
}

// ResolveFileToolPermissionFromConfig applies allow/deny/sensitive using BaseToolConfig.
func ResolveFileToolPermissionFromConfig(path, toolName string, cfg BaseToolConfig) *PermissionContext {
	return ResolveFileToolPermission(path, toolName, cfg.Allowlist, cfg.Denylist, cfg.SensitivePatterns, cfg.Permission)
}

// SplitCommandTokens loosely tokenizes a shell command for arity/pattern use.
func SplitCommandTokens(command string) []string {
	command = strings.TrimSpace(command)
	if command == "" {
		return nil
	}
	return strings.Fields(command)
}

// JoinPathSlash joins path elements with forward slashes.
func JoinPathSlash(parts ...string) string {
	return strings.ReplaceAll(filepath.Join(parts...), string(filepath.Separator), "/")
}
