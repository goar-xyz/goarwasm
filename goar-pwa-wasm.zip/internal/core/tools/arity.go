package tools

import "strings"

// ARITY maps command prefixes to how many leading tokens form the session pattern.
var ARITY = map[string]int{
	"aws": 3,
	"az": 3,
	"bun run": 3,
	"bun x": 3,
	"cargo add": 3,
	"cargo run": 3,
	"consul kv": 3,
	"deno task": 3,
	"docker builder": 3,
	"docker compose": 3,
	"docker container": 3,
	"docker image": 3,
	"docker network": 3,
	"docker volume": 3,
	"doctl": 3,
	"eksctl create": 3,
	"gcloud": 3,
	"gh": 3,
	"git config": 3,
	"git remote": 3,
	"git stash": 3,
	"ip addr": 3,
	"ip link": 3,
	"ip netns": 3,
	"ip route": 3,
	"kind create": 3,
	"kubectl kustomize": 3,
	"kubectl rollout": 3,
	"mc admin": 3,
	"npm exec": 3,
	"npm init": 3,
	"npm run": 3,
	"npm view": 3,
	"openssl req": 3,
	"openssl x509": 3,
	"pnpm dlx": 3,
	"pnpm exec": 3,
	"pnpm run": 3,
	"podman container": 3,
	"podman image": 3,
	"pulumi stack": 3,
	"sfdx": 3,
	"terraform workspace": 3,
	"uv run": 3,
	"vault auth": 3,
	"vault kv": 3,
	"yarn dlx": 3,
	"yarn run": 3,
	"bazel": 2,
	"brew": 2,
	"bun": 2,
	"cargo": 2,
	"cdk": 2,
	"cf": 2,
	"cmake": 2,
	"composer": 2,
	"consul": 2,
	"crictl": 2,
	"deno": 2,
	"docker": 2,
	"eksctl": 2,
	"firebase": 2,
	"flyctl": 2,
	"git": 2,
	"go": 2,
	"gradle": 2,
	"helm": 2,
	"heroku": 2,
	"hugo": 2,
	"ip": 2,
	"kind": 2,
	"kubectl": 2,
	"kustomize": 2,
	"make": 2,
	"mc": 2,
	"minikube": 2,
	"mongosh": 2,
	"mvn": 2,
	"mysql": 2,
	"ng": 2,
	"npm": 2,
	"nvm": 2,
	"nx": 2,
	"openssl": 2,
	"pip": 2,
	"pipenv": 2,
	"pnpm": 2,
	"podman": 2,
	"poetry": 2,
	"psql": 2,
	"pulumi": 2,
	"pyenv": 2,
	"python": 2,
	"rake": 2,
	"rbenv": 2,
	"redis-cli": 2,
	"rustup": 2,
	"serverless": 2,
	"skaffold": 2,
	"sls": 2,
	"sst": 2,
	"swift": 2,
	"systemctl": 2,
	"terraform": 2,
	"tmux": 2,
	"turbo": 2,
	"ufw": 2,
	"uv": 2,
	"vault": 2,
	"vercel": 2,
	"volta": 2,
	"wp": 2,
	"yarn": 2,
	"cat": 1,
	"cd": 1,
	"chmod": 1,
	"chown": 1,
	"cp": 1,
	"echo": 1,
	"env": 1,
	"export": 1,
	"grep": 1,
	"kill": 1,
	"killall": 1,
	"ln": 1,
	"ls": 1,
	"mkdir": 1,
	"mv": 1,
	"ps": 1,
	"pwd": 1,
	"rm": 1,
	"rmdir": 1,
	"sleep": 1,
	"source": 1,
	"tail": 1,
	"touch": 1,
	"unset": 1,
	"which": 1,
}

// CommandArity returns the arity for a command token sequence.
func CommandArity(tokens []string) int {
	if len(tokens) == 0 {
		return 0
	}
	// Try longest multi-word keys first (up to 3 tokens).
	for n := 3; n >= 1; n-- {
		if len(tokens) < n {
			continue
		}
		key := strings.Join(tokens[:n], " ")
		if a, ok := ARITY[key]; ok {
			return a
		}
	}
	if a, ok := ARITY[tokens[0]]; ok {
		return a
	}
	return 1
}

// BuildSessionPattern builds a stable approval pattern from command tokens (Python build_session_pattern).
func BuildSessionPattern(tokens []string) string {
	if len(tokens) == 0 {
		return ""
	}
	arity := CommandArity(tokens)
	if arity <= 0 {
		arity = 1
	}
	if arity > len(tokens) {
		arity = len(tokens)
	}
	parts := make([]string, 0, arity)
	for i := 0; i < arity && i < len(tokens); i++ {
		parts = append(parts, tokens[i])
	}
	// If arity exhausted but next tokens are flags, skip them and take one more positional if present.
	if arity < len(tokens) {
		for i := arity; i < len(tokens); i++ {
			if strings.HasPrefix(tokens[i], "-") {
				continue
			}
			// already have arity tokens; pattern is just the arity prefix
			break
		}
	}
	return strings.Join(parts, " ") + " *"
}

// TokenizeCommand splits a shell-ish command into rough tokens (whitespace).
func TokenizeCommand(command string) []string {
	return strings.Fields(strings.TrimSpace(command))
}

// SessionPatternForCommand builds a session approval pattern for a full command string.
func SessionPatternForCommand(command string) string {
	return BuildSessionPattern(TokenizeCommand(command))
}
