package tools

import (
	"path/filepath"
	"strings"
	"sync"

	"github.com/goarxyz/goar/internal/core/utils"
)

// PermissionScope classifies a required permission.
type PermissionScope string

const (
	ScopeCommandPattern   PermissionScope = "command_pattern"
	ScopeOutsideDirectory PermissionScope = "outside_directory"
	ScopeFilePattern      PermissionScope = "file_pattern"
)

// RequiredPermission is a granular approval ask.
type RequiredPermission struct {
	Scope             PermissionScope `json:"scope"`
	InvocationPattern string          `json:"invocation_pattern"`
	SessionPattern    string          `json:"session_pattern"`
	Label             string          `json:"label"`
}


// ApprovedRule is a remembered session approval rule (Python ApprovedRule).
type ApprovedRule struct {
	ToolName       string          `json:"tool_name"`
	Scope          PermissionScope `json:"scope"`
	SessionPattern string          `json:"session_pattern"`
}

// PermissionContext is a per-invocation permission decision.
type PermissionContext struct {
	Permission          ToolPermission       `json:"permission"`
	Reason              string               `json:"reason,omitempty"`
	RequiredPermissions []RequiredPermission `json:"required_permissions,omitempty"`
}

// PermissionStore remembers session approvals.
type PermissionStore struct {
	mu    sync.Mutex
	tools map[string]ToolPermission
	pats  map[string]bool
	rules []ApprovedRule
}

// NewPermissionStore creates an empty store.
func NewPermissionStore() *PermissionStore {
	return &PermissionStore{tools: map[string]ToolPermission{}, pats: map[string]bool{}, rules: nil}
}

// GetToolPermission returns a remembered tool-level permission.
func (s *PermissionStore) GetToolPermission(name string) (ToolPermission, bool) {
	s.mu.Lock()
	defer s.mu.Unlock()
	p, ok := s.tools[name]
	return p, ok
}

// SetToolPermission remembers a tool-level permission.
func (s *PermissionStore) SetToolPermission(name string, p ToolPermission) {
	s.mu.Lock()
	defer s.mu.Unlock()
	s.tools[name] = p
}

// AllowPattern remembers a session pattern approval.
func (s *PermissionStore) AllowPattern(pat string) {
	s.mu.Lock()
	defer s.mu.Unlock()
	s.pats[pat] = true
}

// IsPatternAllowed reports whether a session pattern was approved.
func (s *PermissionStore) IsPatternAllowed(pat string) bool {
	s.mu.Lock()
	defer s.mu.Unlock()
	return s.pats[pat]
}


// AddRule remembers a granular session approval rule.
func (s *PermissionStore) AddRule(rule ApprovedRule) {
	s.mu.Lock()
	defer s.mu.Unlock()
	s.rules = append(s.rules, rule)
	if rule.SessionPattern != "" {
		s.pats[rule.SessionPattern] = true
	}
}

// Covers reports whether an approved rule covers the required permission.
func (s *PermissionStore) Covers(toolName string, rp RequiredPermission) bool {
	s.mu.Lock()
	defer s.mu.Unlock()
	if s.pats[rp.SessionPattern] {
		return true
	}
	for _, r := range s.rules {
		if r.ToolName == toolName && r.Scope == rp.Scope && r.SessionPattern == rp.SessionPattern {
			return true
		}
	}
	return false
}

// Rules returns a copy of approved rules.
func (s *PermissionStore) Rules() []ApprovedRule {
	s.mu.Lock()
	defer s.mu.Unlock()
	out := make([]ApprovedRule, len(s.rules))
	copy(out, s.rules)
	return out
}

// Lock exposes the store mutex for callers that need atomic check+act (Python async with lock).
func (s *PermissionStore) Lock() { s.mu.Lock() }

// Unlock releases the store mutex.
func (s *PermissionStore) Unlock() { s.mu.Unlock() }

// ResolveFileToolPermission applies allow/deny/sensitive globs to a path.
func ResolveFileToolPermission(path, toolName string, allow, deny, sensitive []string, cfgPerm ToolPermission) *PermissionContext {
	base := filepath.Base(path)
	for _, d := range deny {
		if utils.MatchPattern(path, d) || utils.MatchPattern(base, d) {
			return &PermissionContext{Permission: PermissionNever, Reason: "path matches denylist: " + d}
		}
	}
	for _, s := range sensitive {
		if utils.MatchPattern(path, s) || utils.MatchPattern(base, s) {
			return &PermissionContext{
				Permission: PermissionAsk,
				RequiredPermissions: []RequiredPermission{{
					Scope: ScopeFilePattern, InvocationPattern: path, SessionPattern: s, Label: toolName + ":" + s,
				}},
			}
		}
	}
	for _, a := range allow {
		if utils.MatchPattern(path, a) || utils.MatchPattern(base, a) {
			return &PermissionContext{Permission: PermissionAlways}
		}
	}
	if cfgPerm == PermissionAlways {
		return &PermissionContext{Permission: PermissionAlways}
	}
	return nil
}

// IsPathWithinWorkdir reports whether path is under cwd.
func IsPathWithinWorkdir(path string) bool {
	resolved, err := utils.ResolvePath(path)
	if err != nil {
		return false
	}
	cwd, err := filepath.Abs(".")
	if err != nil {
		return false
	}
	return utils.IsWithinDir(resolved, cwd)
}

// MatchCommandPrefix reports command == pattern or command starts with pattern+" ".
func MatchCommandPrefix(command, pattern string) bool {
	return command == pattern || strings.HasPrefix(command, pattern+" ")
}
