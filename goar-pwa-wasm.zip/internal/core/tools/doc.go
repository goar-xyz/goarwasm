// Package tools implements the tool registry, permissions, MCP, and connectors.
package tools
