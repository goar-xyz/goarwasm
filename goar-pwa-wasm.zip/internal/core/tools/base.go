package tools

import (
	"context"
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"regexp"
	"strings"

	"github.com/goarxyz/goar/internal/core/rewind"
)

// ToolPermission is ALWAYS / NEVER / ASK.
type ToolPermission string

const (
	PermissionAlways ToolPermission = "always"
	PermissionNever  ToolPermission = "never"
	PermissionAsk    ToolPermission = "ask"
)

// PermissionByName parses a permission string (Python ToolPermission.by_name).
func PermissionByName(name string) (ToolPermission, error) {
	switch strings.ToLower(name) {
	case "always":
		return PermissionAlways, nil
	case "never":
		return PermissionNever, nil
	case "ask":
		return PermissionAsk, nil
	default:
		return "", &ToolPermissionError{Msg: fmt.Sprintf("Invalid tool permission: %s. Must be one of [always never ask]", name)}
	}
}

// ToolError is an unrecoverable tool failure.
type ToolError struct{ Msg string }

func (e ToolError) Error() string { return e.Msg }

// NewToolError builds a ToolError.
func NewToolError(format string, args ...any) ToolError {
	return ToolError{Msg: fmt.Sprintf(format, args...)}
}

// ToolPermissionError is raised when a tool permission is not allowed.
type ToolPermissionError struct{ Msg string }

func (e *ToolPermissionError) Error() string { return e.Msg }

// ToolInfo describes a tool for listing/UI.
type ToolInfo struct {
	Name        string         `json:"name"`
	Description string         `json:"description"`
	Parameters  map[string]any `json:"parameters"`
}

// BaseToolConfig is shared tool configuration (Python BaseToolConfig).
type BaseToolConfig struct {
	Permission        ToolPermission `json:"permission"`
	Allowlist         []string       `json:"allowlist"`
	Denylist          []string       `json:"denylist"`
	SensitivePatterns []string       `json:"sensitive_patterns"`
	Extra             map[string]any `json:"extra,omitempty"`
}

// DefaultBaseToolConfig returns ASK with empty lists.
func DefaultBaseToolConfig() BaseToolConfig {
	return BaseToolConfig{Permission: PermissionAsk}
}

// BaseToolState is mutable per-tool state (Python BaseToolState).
type BaseToolState struct {
	Data map[string]any `json:"data,omitempty"`
}

// InvokeContext is passed to tools during invocation (Python InvokeContext).
type InvokeContext struct {
	ToolCallID       string
	SessionDir       string
	PlanFilePath     string
	ScratchpadDir    string
	UserInput        func(prompt string) (string, error)
	Approval         func(summary string) (bool, error)
	ApprovalCallback func(toolName string, args map[string]any, toolCallID string, required []RequiredPermission) (string, string)
	UserInputCallback func(prompt string) (string, error)
	SwitchAgent      func(agentName string) error
	Sampling         any
	SkillManager     any
	AgentManager     any
	PermissionStore  *PermissionStore
	Config           any
}

// Tool is the interface every builtin/MCP/connector tool implements.
type Tool interface {
	Name() string
	Description() string
	Parameters() map[string]any
	Run(ctx context.Context, args map[string]any, inv *InvokeContext) (any, error)
	Permission() ToolPermission
}

// SnapshotableTool can capture a file snapshot before mutation.
type SnapshotableTool interface {
	Tool
	GetFileSnapshot(args map[string]any) *rewind.FileSnapshot
}

// PermissionResolvableTool can override permission per invocation.
type PermissionResolvableTool interface {
	Tool
	ResolvePermission(args map[string]any) *PermissionContext
}

// ResultExtraTool can append extra LLM context to results.
type ResultExtraTool interface {
	Tool
	GetResultExtra(result any) string
}

// ResettableTool can reset per-session state.
type ResettableTool interface {
	Tool
	Reset()
}

// AvailableChecker reports whether a tool is available under the given config.
type AvailableChecker interface {
	IsAvailable(cfg any) bool
}

// ResultJSON marshals a tool result.
func ResultJSON(v any) string {
	b, err := json.Marshal(v)
	if err != nil {
		return fmt.Sprintf(`{"error":%q}`, err.Error())
	}
	return string(b)
}

// ResultText flattens a map/struct-like result into "k: v" lines for the LLM.
func ResultText(v any) string {
	switch t := v.(type) {
	case string:
		return t
	case map[string]any:
		parts := make([]string, 0, len(t))
		for k, val := range t {
			parts = append(parts, fmt.Sprintf("%s: %v", k, val))
		}
		return strings.Join(parts, "\n")
	default:
		return ResultJSON(v)
	}
}

var camelBoundary = regexp.MustCompile(`([a-z0-9])([A-Z])`)

// ToSnakeCase converts CamelCase / PascalCase to snake_case (Python get_name).
func ToSnakeCase(name string) string {
	s := camelBoundary.ReplaceAllString(name, `${1}_${2}`)
	return strings.ToLower(s)
}

// GetFileSnapshotForPath captures bytes (or nil if missing) for rewind (Python get_file_snapshot_for_path).
func GetFileSnapshotForPath(path string) rewind.FileSnapshot {
	expanded := path
	if strings.HasPrefix(expanded, "~") {
		if home, err := os.UserHomeDir(); err == nil {
			expanded = filepath.Join(home, strings.TrimPrefix(expanded, "~"))
		}
	}
	if !filepath.IsAbs(expanded) {
		cwd, _ := os.Getwd()
		expanded = filepath.Join(cwd, expanded)
	}
	resolved, err := filepath.Abs(expanded)
	if err != nil {
		resolved = expanded
	}
	content, err := os.ReadFile(resolved)
	if err != nil {
		return rewind.FileSnapshot{Path: resolved, Content: nil}
	}
	return rewind.FileSnapshot{Path: resolved, Content: content}
}

// SimpleTool is a convenience Tool backed by a function.
type SimpleTool struct {
	ToolName        string
	ToolDescription string
	ToolParams      map[string]any
	ToolPerm        ToolPermission
	Fn              func(ctx context.Context, args map[string]any, inv *InvokeContext) (any, error)
	ResolvePermFn   func(args map[string]any) *PermissionContext
	SnapshotFn      func(args map[string]any) *rewind.FileSnapshot
	ExtraFn         func(result any) string
	AvailableFn     func(cfg any) bool
}

func (t *SimpleTool) Name() string                    { return t.ToolName }
func (t *SimpleTool) Description() string             { return t.ToolDescription }
func (t *SimpleTool) Parameters() map[string]any      { return t.ToolParams }
func (t *SimpleTool) Permission() ToolPermission {
	if t.ToolPerm == "" {
		return PermissionAsk
	}
	return t.ToolPerm
}
func (t *SimpleTool) Run(ctx context.Context, args map[string]any, inv *InvokeContext) (any, error) {
	if t.Fn == nil {
		return nil, NewToolError("tool %s has no implementation", t.ToolName)
	}
	return t.Fn(ctx, args, inv)
}
func (t *SimpleTool) ResolvePermission(args map[string]any) *PermissionContext {
	if t.ResolvePermFn != nil {
		return t.ResolvePermFn(args)
	}
	return nil
}
func (t *SimpleTool) GetFileSnapshot(args map[string]any) *rewind.FileSnapshot {
	if t.SnapshotFn != nil {
		return t.SnapshotFn(args)
	}
	return nil
}
func (t *SimpleTool) GetResultExtra(result any) string {
	if t.ExtraFn != nil {
		return t.ExtraFn(result)
	}
	return ""
}
func (t *SimpleTool) IsAvailable(cfg any) bool {
	if t.AvailableFn != nil {
		return t.AvailableFn(cfg)
	}
	return true
}

// Info returns ToolInfo for listing.
func Info(t Tool) ToolInfo {
	return ToolInfo{Name: t.Name(), Description: t.Description(), Parameters: t.Parameters()}
}

// CreateConfigWithPermission builds a BaseToolConfig with the given permission.
func CreateConfigWithPermission(permission ToolPermission) BaseToolConfig {
	return BaseToolConfig{Permission: permission}
}

// ValidateArgsJSON ensures args is valid JSON object text.
func ValidateArgsJSON(raw string) (map[string]any, error) {
	if strings.TrimSpace(raw) == "" {
		return map[string]any{}, nil
	}
	var out map[string]any
	if err := json.Unmarshal([]byte(raw), &out); err != nil {
		return nil, NewToolError("Validation error: %v", err)
	}
	return out, nil
}

// RequireString extracts a required string arg.
func RequireString(args map[string]any, key string) (string, error) {
	v, ok := args[key]
	if !ok {
		return "", NewToolError("missing required argument: %s", key)
	}
	s, ok := v.(string)
	if !ok {
		return "", NewToolError("argument %s must be a string", key)
	}
	return s, nil
}

// OptionalString extracts an optional string arg with default.
func OptionalString(args map[string]any, key, def string) string {
	v, ok := args[key]
	if !ok || v == nil {
		return def
	}
	if s, ok := v.(string); ok {
		return s
	}
	return def
}

// OptionalBool extracts an optional bool arg with default.
func OptionalBool(args map[string]any, key string, def bool) bool {
	v, ok := args[key]
	if !ok || v == nil {
		return def
	}
	if b, ok := v.(bool); ok {
		return b
	}
	return def
}

// OptionalInt extracts an optional int arg with default.
func OptionalInt(args map[string]any, key string, def int) int {
	v, ok := args[key]
	if !ok || v == nil {
		return def
	}
	switch n := v.(type) {
	case int:
		return n
	case int64:
		return int(n)
	case float64:
		return int(n)
	default:
		return def
	}
}
