package tools

import (
	"os"

	"github.com/BurntSushi/toml"
	"github.com/goarxyz/goar/internal/core/config"
	"github.com/goarxyz/goar/internal/core/paths"
)

// MCPSettings holds global MCP toggles (compat).
type MCPSettings struct {
	Enabled           bool
	DefaultTimeoutSec float64
}

// DefaultMCPSettings returns defaults.
func DefaultMCPSettings() MCPSettings {
	return MCPSettings{Enabled: true, DefaultTimeoutSec: 60}
}

// UpdatedToolList returns a new disabled_tools list with name added or removed (unique).
// Python: updated_tool_list.
func UpdatedToolList(tools []string, name string, disabled bool) []string {
	if disabled {
		seen := map[string]bool{}
		out := make([]string, 0, len(tools)+1)
		for _, t := range tools {
			if seen[t] {
				continue
			}
			seen[t] = true
			out = append(out, t)
		}
		if !seen[name] {
			out = append(out, name)
		}
		return out
	}
	out := make([]string, 0, len(tools))
	for _, t := range tools {
		if t != name {
			out = append(out, t)
		}
	}
	return out
}

type persistedMCPFile struct {
	MCPServers  []map[string]any `toml:"mcp_servers"`
	Connectors  []map[string]any `toml:"connectors"`
}

func loadPersistedMCP() persistedMCPFile {
	var f persistedMCPFile
	path := paths.ConfigFile()
	if _, err := os.Stat(path); err != nil {
		return f
	}
	_, _ = toml.DecodeFile(path, &f)
	return f
}

func savePersistedMCP(f persistedMCPFile) error {
	_ = paths.EnsureHome()
	path := paths.ConfigFile()
	// Merge into existing raw TOML map to avoid wiping unrelated keys.
	raw := map[string]any{}
	if _, err := os.Stat(path); err == nil {
		_, _ = toml.DecodeFile(path, &raw)
	}
	raw["mcp_servers"] = f.MCPServers
	raw["connectors"] = f.Connectors
	out, err := os.Create(path)
	if err != nil {
		return err
	}
	defer out.Close()
	return toml.NewEncoder(out).Encode(raw)
}

// PersistMCPToggle saves an MCP server/connector or individual tool toggle (Python persist_mcp_toggle).
func PersistMCPToggle(name string, isConnector bool, disabled bool, toolName string) error {
	if isConnector {
		return persistConnectorToggle(name, disabled, toolName)
	}
	return persistServerToggle(name, disabled, toolName)
}

func persistServerToggle(name string, disabled bool, toolName string) error {
	f := loadPersistedMCP()
	found := false
	for i := range f.MCPServers {
		n, _ := f.MCPServers[i]["name"].(string)
		if n != name {
			continue
		}
		found = true
		if toolName != "" {
			existing, _ := f.MCPServers[i]["disabled_tools"].([]string)
			if existing == nil {
				if anyList, ok := f.MCPServers[i]["disabled_tools"].([]any); ok {
					for _, a := range anyList {
						existing = append(existing, toString(a))
					}
				}
			}
			f.MCPServers[i]["disabled_tools"] = UpdatedToolList(existing, toolName, disabled)
		} else {
			f.MCPServers[i]["disabled"] = disabled
		}
		break
	}
	if !found {
		// Server not in base config (profile-only) — nothing to persist.
		return nil
	}
	return savePersistedMCP(f)
}

func persistConnectorToggle(name string, disabled bool, toolName string) error {
	f := loadPersistedMCP()
	found := false
	for i := range f.Connectors {
		n, _ := f.Connectors[i]["name"].(string)
		if n != name {
			continue
		}
		found = true
		if toolName != "" {
			existing, _ := f.Connectors[i]["disabled_tools"].([]string)
			if existing == nil {
				if anyList, ok := f.Connectors[i]["disabled_tools"].([]any); ok {
					for _, a := range anyList {
						existing = append(existing, toString(a))
					}
				}
			}
			f.Connectors[i]["disabled_tools"] = UpdatedToolList(existing, toolName, disabled)
		} else {
			f.Connectors[i]["disabled"] = disabled
		}
		break
	}
	if !found {
		entry := map[string]any{"name": name}
		if toolName != "" {
			if disabled {
				entry["disabled_tools"] = []string{toolName}
			} else {
				entry["disabled_tools"] = []string{}
			}
		} else {
			entry["disabled"] = disabled
		}
		f.Connectors = append(f.Connectors, entry)
	}
	return savePersistedMCP(f)
}

func toString(v any) string {
	if s, ok := v.(string); ok {
		return s
	}
	return ""
}

// ApplyMCPSettings overlays MCPSettings onto a config (compat helper).
func ApplyMCPSettings(cfg *config.Config, s MCPSettings) {
	if cfg == nil {
		return
	}
	_ = s
}
