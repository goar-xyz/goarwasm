package builtins

import (
	"context"
	"fmt"
	"os"
	"path/filepath"
	"strings"
	"time"

	"github.com/go-git/go-git/v5"
	"github.com/go-git/go-git/v5/plumbing"
	"github.com/go-git/go-git/v5/plumbing/object"
	"github.com/go-git/go-git/v5/plumbing/transport/http"

	"github.com/goarxyz/goar/internal/core/tools"
)

type gitTool struct{}

// NewGit returns a pure-Go git tool operating on MEMFS / workspace via go-git.
func NewGit() tools.Tool { return &gitTool{} }

func (t *gitTool) Name() string { return "git" }
func (t *gitTool) Description() string {
	return "Pure-Go git (status/log/diff/clone/branch) on AGENT_HOME / workspace via go-git. HTTP(S) via browsernet; git@/ssh:// remotes rewrite to HTTPS or tunnel via SSH exec when configured."
}
func (t *gitTool) Permission() tools.ToolPermission { return tools.PermissionAsk }
func (t *gitTool) Parameters() map[string]any {
	return map[string]any{
		"type": "object",
		"properties": map[string]any{
			"action": map[string]any{
				"type":        "string",
				"description": "status|log|diff|clone|branch|show",
			},
			"path":     map[string]any{"type": "string", "description": "Repo path (default: cwd or AGENT_HOME)"},
			"url":      map[string]any{"type": "string", "description": "Clone URL (http/https)"},
			"ref":      map[string]any{"type": "string", "description": "Optional ref for show/log"},
			"maxCount": map[string]any{"type": "integer", "description": "Max commits for log (default 10)"},
		},
		"required": []string{"action"},
	}
}

func (t *gitTool) Run(ctx context.Context, args map[string]any, inv *tools.InvokeContext) (any, error) {
	_ = inv
	action := strings.ToLower(strings.TrimSpace(strArg(args, "action")))
	path := strings.TrimSpace(strArg(args, "path"))
	if path == "" {
		path = defaultGitPath()
	}
	switch action {
	case "status":
		return gitStatus(path)
	case "log":
		n := 10
		if v, ok := args["maxCount"]; ok && v != nil {
			if i := asIntArg(v); i > 0 {
				n = i
			}
		}
		return gitLog(path, n)
	case "diff":
		return gitDiff(path)
	case "branch":
		return gitBranch(path)
	case "show":
		return gitShow(path, strArg(args, "ref"))
	case "clone":
		url := strArg(args, "url")
		if url == "" {
			return nil, tools.NewToolError("git clone requires url")
		}
		dest := path
		if dest == "" || dest == defaultGitPath() {
			base := filepath.Base(strings.TrimSuffix(url, ".git"))
			dest = filepath.Join(defaultGitPath(), base)
		}
		return gitClone(ctx, url, dest)
	default:
		return nil, tools.NewToolError("unknown git action %q (status|log|diff|clone|branch|show)", action)
	}
}

func defaultGitPath() string {
	if wd, err := os.Getwd(); err == nil && wd != "" {
		if _, err := os.Stat(filepath.Join(wd, ".git")); err == nil {
			return wd
		}
	}
	home := strings.TrimSpace(os.Getenv("AGENT_HOME"))
	if home == "" {
		home = "/tmp/goar-agent-home"
	}
	ws := filepath.Join(home, "workspace")
	if _, err := os.Stat(filepath.Join(ws, ".git")); err == nil {
		return ws
	}
	if _, err := os.Stat(filepath.Join(home, ".git")); err == nil {
		return home
	}
	return ws
}

func openRepo(path string) (*git.Repository, error) {
	repo, err := git.PlainOpenWithOptions(path, &git.PlainOpenOptions{DetectDotGit: true})
	if err != nil {
		return nil, fmt.Errorf("open repo at %s: %w", path, err)
	}
	return repo, nil
}

func gitStatus(path string) (any, error) {
	repo, err := openRepo(path)
	if err != nil {
		return nil, tools.NewToolError("%v", err)
	}
	wt, err := repo.Worktree()
	if err != nil {
		return nil, tools.NewToolError("%v", err)
	}
	st, err := wt.Status()
	if err != nil {
		return nil, tools.NewToolError("%v", err)
	}
	head, _ := repo.Head()
	branch := ""
	if head != nil {
		branch = head.Name().Short()
	}
	var lines []string
	for f, s := range st {
		lines = append(lines, fmt.Sprintf("%s%s %s", string(s.Staging), string(s.Worktree), f))
	}
	summary := "## " + branch + "\n"
	if len(lines) == 0 {
		summary += "nothing to commit, working tree clean\n"
	} else {
		summary += strings.Join(lines, "\n") + "\n"
	}
	return map[string]any{"path": path, "branch": branch, "status": summary, "clean": st.IsClean()}, nil
}

func gitLog(path string, n int) (any, error) {
	repo, err := openRepo(path)
	if err != nil {
		return nil, tools.NewToolError("%v", err)
	}
	iter, err := repo.Log(&git.LogOptions{})
	if err != nil {
		return nil, tools.NewToolError("%v", err)
	}
	defer iter.Close()
	var commits []map[string]any
	var lines []string
	_ = iter.ForEach(func(c *object.Commit) error {
		if len(commits) >= n {
			return fmt.Errorf("done")
		}
		entry := map[string]any{
			"hash":    c.Hash.String()[:7],
			"message": strings.Split(c.Message, "\n")[0],
			"author":  c.Author.Name,
			"date":    c.Author.When.Format(time.RFC3339),
		}
		commits = append(commits, entry)
		lines = append(lines, fmt.Sprintf("%s %s", entry["hash"], entry["message"]))
		return nil
	})
	return map[string]any{"path": path, "commits": commits, "log": strings.Join(lines, "\n")}, nil
}

func gitDiff(path string) (any, error) {
	repo, err := openRepo(path)
	if err != nil {
		return nil, tools.NewToolError("%v", err)
	}
	wt, err := repo.Worktree()
	if err != nil {
		return nil, tools.NewToolError("%v", err)
	}
	st, err := wt.Status()
	if err != nil {
		return nil, tools.NewToolError("%v", err)
	}
	var b strings.Builder
	for f, s := range st {
		if s.Worktree == git.Unmodified && s.Staging == git.Unmodified {
			continue
		}
		b.WriteString(fmt.Sprintf("*** %s (staging=%c worktree=%c)\n", f, s.Staging, s.Worktree))
		// Best-effort content diff vs HEAD for modified files
		if s.Worktree == git.Modified || s.Staging == git.Modified {
			data, err := os.ReadFile(filepath.Join(path, f))
			if err == nil {
				lines := strings.Split(string(data), "\n")
				max := 40
				if len(lines) < max {
					max = len(lines)
				}
				for i := 0; i < max; i++ {
					b.WriteString("+ " + lines[i] + "\n")
				}
				if len(lines) > max {
					b.WriteString(fmt.Sprintf("… (%d more lines)\n", len(lines)-max))
				}
			}
		}
	}
	out := b.String()
	if out == "" {
		out = "(no local changes)\n"
	}
	return map[string]any{"path": path, "diff": out}, nil
}

func gitBranch(path string) (any, error) {
	repo, err := openRepo(path)
	if err != nil {
		return nil, tools.NewToolError("%v", err)
	}
	iter, err := repo.Branches()
	if err != nil {
		return nil, tools.NewToolError("%v", err)
	}
	head, _ := repo.Head()
	current := ""
	if head != nil {
		current = head.Name().Short()
	}
	var names []string
	_ = iter.ForEach(func(ref *plumbing.Reference) error {
		n := ref.Name().Short()
		if n == current {
			names = append(names, "* "+n)
		} else {
			names = append(names, "  "+n)
		}
		return nil
	})
	return map[string]any{"path": path, "current": current, "branches": names, "text": strings.Join(names, "\n")}, nil
}

func gitShow(path, ref string) (any, error) {
	repo, err := openRepo(path)
	if err != nil {
		return nil, tools.NewToolError("%v", err)
	}
	var hash plumbing.Hash
	if ref == "" {
		head, err := repo.Head()
		if err != nil {
			return nil, tools.NewToolError("%v", err)
		}
		hash = head.Hash()
	} else {
		h, err := repo.ResolveRevision(plumbing.Revision(ref))
		if err != nil {
			return nil, tools.NewToolError("%v", err)
		}
		hash = *h
	}
	c, err := repo.CommitObject(hash)
	if err != nil {
		return nil, tools.NewToolError("%v", err)
	}
	return map[string]any{
		"hash":    c.Hash.String(),
		"message": c.Message,
		"author":  c.Author.String(),
		"text":    c.String(),
	}, nil
}

func gitClone(ctx context.Context, url, dest string) (any, error) {
	orig := url
	pathHint := ""
	if isSSHGitURL(url) {
		if httpsURL, ok := rewriteSSHGitToHTTPS(url); ok {
			url = httpsURL
			pathHint = "rewrote " + orig + " → " + url
		} else if sshConfigured() {
			return gitCloneViaSSHExec(ctx, orig, dest)
		} else {
			return nil, tools.NewToolError(
				"git clone: SSH remote %q — configure SSH (goar.configure({ssh})) to tunnel via Wisp ssh_exec, or use an https:// URL (browsernet). Tip: git@host:path often maps to https://host/path.git",
				orig,
			)
		}
	}
	InstallGitHTTPTransport()
	_ = os.MkdirAll(filepath.Dir(dest), 0o755)
	opts := &git.CloneOptions{
		URL:      url,
		Progress: nil,
	}
	if tok := strings.TrimSpace(os.Getenv("GIT_HTTP_TOKEN")); tok != "" {
		opts.Auth = &http.BasicAuth{Username: "git", Password: tok}
	} else if tok := strings.TrimSpace(os.Getenv("GITHUB_TOKEN")); tok != "" {
		opts.Auth = &http.BasicAuth{Username: "git", Password: tok}
	}
	_, err := git.PlainClone(dest, false, opts)
	if err != nil {
		// If HTTPS rewrite failed auth and SSH is available, fall back to remote git.
		if sshConfigured() && orig != url {
			return gitCloneViaSSHExec(ctx, orig, dest)
		}
		return nil, tools.NewToolError("git clone: %v", err)
	}
	out := map[string]any{"path": dest, "url": url, "ok": true}
	if pathHint != "" {
		out["note"] = pathHint
	}
	return out, nil
}

func (t *gitTool) FormatCallDisplay(args map[string]any) string {
	return "git " + strArg(args, "action")
}
func (t *gitTool) GetResultDisplay(result any) string {
	m, ok := result.(map[string]any)
	if !ok {
		return fmt.Sprint(result)
	}
	for _, k := range []string{"status", "log", "diff", "text"} {
		if s, ok := m[k].(string); ok && s != "" {
			if len(s) > 400 {
				return s[:397] + "…"
			}
			return s
		}
	}
	return fmt.Sprint(result)
}
func (t *gitTool) GetStatusText() string { return "Running git (go-git)" }
