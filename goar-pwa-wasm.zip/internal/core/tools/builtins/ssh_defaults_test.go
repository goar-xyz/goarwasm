package builtins

import (
	"os"
	"testing"
)

func TestResolveSSHConfigKaliDefaults(t *testing.T) {
	t.Setenv("AGENT_SSH_HOST", "")
	t.Setenv("AGENT_SSH_USER", "")
	t.Setenv("AGENT_SSH_PASSWORD", "")
	t.Setenv("AGENT_SSH_PRIVATE_KEY", "")
	t.Setenv("AGENT_SSH_PORT", "")
	t.Setenv("AGENT_SSH_PORTS", "")
	t.Setenv("AGENT_SSH_RECONNECT_HOST", "")
	cfg, err := resolveSSHConfig(map[string]any{})
	if err != nil {
		t.Fatal(err)
	}
	if cfg.Host != defaultSSHHost || cfg.User != defaultSSHUser || cfg.Password != defaultSSHPass {
		t.Fatalf("got %+v", cfg)
	}
	if cfg.Port != 443 {
		t.Fatalf("port %d", cfg.Port)
	}
	ports := sshDialPorts(cfg)
	if len(ports) < 2 || ports[0] != 443 || ports[1] != 22 {
		t.Fatalf("ports %v", ports)
	}
}

func TestSSHDialPortsFromEnv(t *testing.T) {
	t.Setenv(envSSHPorts, "443,22")
	cfg := sshConfig{Host: "segfault.net", Port: 443}
	ports := sshDialPorts(cfg)
	if len(ports) != 2 || ports[0] != 443 || ports[1] != 22 {
		t.Fatalf("%v", ports)
	}
}

func TestCustomHostNoDefaultPassword(t *testing.T) {
	for _, k := range []string{envSSHHost, envSSHUser, envSSHPassword, envSSHPrivateKey, envSSHPort, envSSHPorts, envSSHReconnectHost} {
		_ = os.Unsetenv(k)
	}
	_, err := resolveSSHConfig(map[string]any{"host": "example.com", "user": "ubuntu"})
	if err == nil {
		t.Fatal("expected error without password for non-kali host")
	}
}
