package builtins

import (
	"encoding/base64"
	"fmt"
	"net"
	"os"
	"path/filepath"
	"strings"
	"sync"

	"golang.org/x/crypto/ssh"
)

const (
	envSSHTrustOnFirstUse = "AGENT_SSH_TRUST_ON_FIRST_USE"
	envSSHKnownHostsPin   = "AGENT_SSH_KNOWN_HOSTS" // optional inline known_hosts content
)

var (
	knownHostsMu   sync.Mutex
	knownHostsMem  string // always-available TOFU store (js/wasm has no real os.OpenFile)
)

func knownHostsPath() string {
	home := strings.TrimSpace(os.Getenv("AGENT_HOME"))
	if home == "" {
		home = "/tmp/goar-agent-home"
	}
	return filepath.Join(home, "known_hosts")
}

func trustOnFirstUseEnabled() bool {
	v := strings.TrimSpace(os.Getenv(envSSHTrustOnFirstUse))
	if v == "" {
		return true // default true for PWA
	}
	switch strings.ToLower(v) {
	case "0", "false", "no", "off":
		return false
	default:
		return true
	}
}

func loadKnownHostsFile() string {
	path := knownHostsPath()
	data, err := os.ReadFile(path)
	if err != nil {
		return knownHostsMem
	}
	s := string(data)
	if knownHostsMem != "" && !strings.Contains(s, knownHostsMem) {
		// Merge mem entries not yet on disk
		return strings.TrimRight(s, "\n") + "\n" + knownHostsMem
	}
	if s != "" {
		knownHostsMem = s
	}
	return s
}

func persistKnownHosts(content string) error {
	knownHostsMem = content
	path := knownHostsPath()
	_ = os.MkdirAll(filepath.Dir(path), 0o755)
	if err := os.WriteFile(path, []byte(content), 0o644); err != nil {
		// js/wasm: filesystem write often returns "not implemented on js".
		// Memory store is authoritative for the session; OPFS hydrate/sync may pick it up later.
		if strings.Contains(err.Error(), "not implemented") || strings.Contains(err.Error(), "js") {
			return nil
		}
		return err
	}
	return nil
}

// hostKeyCallback verifies or records host keys via AGENT_HOME/known_hosts (memory+file; OPFS under WASM).
func hostKeyCallback() ssh.HostKeyCallback {
	return func(hostname string, remote net.Addr, key ssh.PublicKey) error {
		knownHostsMu.Lock()
		defer knownHostsMu.Unlock()

		host := stripPort(hostname)
		if host == "" && remote != nil {
			host = stripPort(remote.String())
		}
		keyLine := formatKnownHostsLine(host, key)

		// Pinned known_hosts from env / configure
		if pin := strings.TrimSpace(os.Getenv(envSSHKnownHostsPin)); pin != "" {
			if matchKnownHosts(pin, host, key) {
				return nil
			}
			return fmt.Errorf("ssh: host key for %s does not match AGENT_SSH_KNOWN_HOSTS / configure ssh.knownHosts (fail closed)", host)
		}

		content := loadKnownHostsFile()
		if matchKnownHosts(content, host, key) {
			return nil
		}
		// Mismatch if host already recorded with different key
		if hostPresent(content, host) {
			return fmt.Errorf("ssh: HOST KEY MISMATCH for %s — remote key %s %s does not match known_hosts (fail closed)",
				host, key.Type(), ssh.FingerprintSHA256(key))
		}
		if !trustOnFirstUseEnabled() {
			return fmt.Errorf("ssh: unknown host key for %s (%s %s); set AGENT_SSH_TRUST_ON_FIRST_USE=1 or configure({ssh:{trustOnFirstUse:true}}) or pin ssh.knownHosts",
				host, key.Type(), ssh.FingerprintSHA256(key))
		}
		// Trust on first use: append (memory always; file best-effort)
		if content != "" && !strings.HasSuffix(content, "\n") {
			content += "\n"
		}
		content += keyLine + "\n"
		if err := persistKnownHosts(content); err != nil {
			return fmt.Errorf("ssh: cannot persist known_hosts: %w", err)
		}
		return nil
	}
}

func stripPort(hostport string) string {
	h := hostport
	if strings.HasPrefix(h, "[") {
		if i := strings.Index(h, "]"); i >= 0 {
			return h[1:i]
		}
	}
	if i := strings.LastIndex(h, ":"); i > 0 {
		maybePort := h[i+1:]
		allDigit := true
		for _, c := range maybePort {
			if c < '0' || c > '9' {
				allDigit = false
				break
			}
		}
		if allDigit {
			return h[:i]
		}
	}
	return h
}

func formatKnownHostsLine(host string, key ssh.PublicKey) string {
	return host + " " + key.Type() + " " + base64.StdEncoding.EncodeToString(key.Marshal())
}

func hostPresent(content, host string) bool {
	for _, line := range strings.Split(content, "\n") {
		line = strings.TrimSpace(line)
		if line == "" || strings.HasPrefix(line, "#") {
			continue
		}
		fields := strings.Fields(line)
		if len(fields) < 3 {
			continue
		}
		for _, h := range strings.Split(fields[0], ",") {
			if h == host || h == "["+host+"]" {
				return true
			}
		}
	}
	return false
}

func matchKnownHosts(content, host string, key ssh.PublicKey) bool {
	want := base64.StdEncoding.EncodeToString(key.Marshal())
	for _, line := range strings.Split(content, "\n") {
		line = strings.TrimSpace(line)
		if line == "" || strings.HasPrefix(line, "#") {
			continue
		}
		fields := strings.Fields(line)
		if len(fields) < 3 {
			continue
		}
		hosts := strings.Split(fields[0], ",")
		okHost := false
		for _, h := range hosts {
			if h == host || h == "["+host+"]" {
				okHost = true
				break
			}
		}
		if !okHost {
			continue
		}
		if fields[1] == key.Type() && fields[2] == want {
			return true
		}
	}
	return false
}
