package builtins

import "github.com/goarxyz/goar/internal/core/tools"

// RegisterAll registers every builtin tool on the manager.
func RegisterAll(m *tools.Manager) {
	m.Register(NewReadFile())
	m.Register(NewWriteFile())
	m.Register(NewSearchReplace())
	m.Register(NewGrep())
	m.Register(NewBash())
	m.Register(NewSSHExec())
	m.Register(NewWebSearch())
	m.Register(NewWebFetch())
	m.Register(NewTodo())
	m.Register(NewAskUserQuestion())
	m.Register(NewSkill())
	m.Register(NewTask())
	m.Register(NewExitPlanMode())
	m.Register(NewPipInstall())
	m.Register(NewGit())
}
