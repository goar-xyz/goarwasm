package builtins

import (
	"context"
	"os"
	"strings"

	"github.com/goarxyz/goar/internal/core/tools"
	"github.com/goarxyz/goar/internal/core/utils"
)

type writeFile struct {
	maxBytes         int
	createParentDirs bool
}

func NewWriteFile() tools.Tool {
	return &writeFile{maxBytes: 64000, createParentDirs: true}
}
func (t *writeFile) Name() string { return "write_file" }
func (t *writeFile) Description() string {
	return "Create or overwrite a UTF-8 file. Fails if file exists unless 'overwrite=True'. Under WASM this is browser MEMFS (AGENT_HOME), not the VPS — use bash (tee/heredoc) on the shared SSH PTY for remote files."
}
func (t *writeFile) Permission() tools.ToolPermission { return tools.PermissionAsk }
func (t *writeFile) Parameters() map[string]any {
	return map[string]any{
		"type": "object",
		"properties": map[string]any{
			"path":      map[string]any{"type": "string"},
			"content":   map[string]any{"type": "string"},
			"overwrite": map[string]any{"type": "boolean", "description": "Must be true to overwrite an existing file."},
		},
		"required": []string{"path", "content"},
	}
}

func (t *writeFile) Run(ctx context.Context, args map[string]any, inv *tools.InvokeContext) (any, error) {
	_ = ctx; _ = inv
	path, _ := args["path"].(string)
	content, _ := args["content"].(string)
	overwrite, _ := args["overwrite"].(bool)
	if strings.TrimSpace(path) == "" {
		return nil, tools.NewToolError("Path cannot be empty")
	}
	b := []byte(content)
	if len(b) > t.maxBytes {
		return nil, tools.NewToolError("Content exceeds %d bytes limit", t.maxBytes)
	}
	resolved, err := utils.ResolvePath(path)
	if err != nil {
		return nil, tools.NewToolError("%v", err)
	}
	_, err = os.Stat(resolved)
	existed := err == nil
	if existed && !overwrite {
		return nil, tools.NewToolError("File '%s' exists. Set overwrite=True to replace.", resolved)
	}
	if t.createParentDirs {
		if err := tools.EnsureParentDir(resolved); err != nil {
			return nil, tools.NewToolError("%v", err)
		}
	}
	if err := os.WriteFile(resolved, b, 0o644); err != nil {
		return nil, tools.NewToolError("Error writing %s: %v", resolved, err)
	}
	return map[string]any{
		"path": resolved, "bytes_written": len(b), "file_existed": existed, "content": content,
	}, nil
}
