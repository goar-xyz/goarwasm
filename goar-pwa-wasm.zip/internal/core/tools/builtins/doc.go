// Package builtins implements GOAR built-in tools.
package builtins
