// Package prompts — port of goar/core/tools/builtins/prompts/__init__.py
package prompts
