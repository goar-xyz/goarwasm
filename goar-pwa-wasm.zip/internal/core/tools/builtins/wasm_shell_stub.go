//go:build !(js && wasm)

package builtins

import (
	"context"

	"github.com/goarxyz/goar/internal/core/tools"
)

func runWasmShell(_ context.Context, command string) (any, error) {
	return nil, tools.NewToolError("wasm_shell is only available under js/wasm")
}
