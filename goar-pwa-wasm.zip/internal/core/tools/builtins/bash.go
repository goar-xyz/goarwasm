package builtins

import (
	"bytes"
	"context"
	"fmt"
	"os"
	"os/exec"
	"regexp"
	"runtime"
	"strings"
	"time"

	"github.com/goarxyz/goar/internal/core/tools"
	"github.com/goarxyz/goar/internal/core/utils"
)

type bashTool struct {
	maxOutput      int
	defaultTimeout int
	allowlist      []string
	denylist       []string
	denylistAlone  []string
	sensitive      []string
}

func NewBash() tools.Tool {
	commonAllow := []string{"cd", "echo", "git diff", "git log", "git status", "tree", "whoami", "cat", "file", "find", "head", "ls", "pwd", "stat", "tail", "uname", "wc", "which"}
	return &bashTool{
		maxOutput: 16000, defaultTimeout: 300,
		allowlist:     commonAllow,
		denylist:      []string{"gdb", "pdb", "passwd", "nano", "vim", "vi", "emacs", "bash -i", "sh -i", "zsh -i", "screen", "tmux"},
		denylistAlone: []string{"python", "python3", "ipython", "bash", "sh", "nohup", "su"},
		sensitive:     []string{"sudo"},
	}
}
func (t *bashTool) Name() string { return "bash" }
func (t *bashTool) Description() string {
	return "Run a bash command and capture its output. Under WASM with SSH configured: runs on the shared SSH PTY (same session as the top-right terminal) so the human sees agent work; falls back to ssh_exec only if the PTY cannot be opened. Without SSH: asks the user to open Settings — not a silent local wasmshell substitute for VPS work."
}
func (t *bashTool) Permission() tools.ToolPermission { return tools.PermissionAsk }
func (t *bashTool) Parameters() map[string]any {
	return map[string]any{
		"type": "object",
		"properties": map[string]any{
			"command": map[string]any{"type": "string"},
			"timeout": map[string]any{"type": "integer", "description": "Override default timeout seconds."},
		},
		"required": []string{"command"},
	}
}

var cmdSplitRE = regexp.MustCompile(`\s*(?:&&|\|\||;)\s*`)

func extractCommands(command string) []string {
	parts := cmdSplitRE.Split(command, -1)
	out := make([]string, 0, len(parts))
	for _, p := range parts {
		p = strings.TrimSpace(p)
		if p != "" {
			out = append(out, p)
		}
	}
	return out
}

func (t *bashTool) Run(ctx context.Context, args map[string]any, inv *tools.InvokeContext) (any, error) {
	_ = inv
	command, _ := args["command"].(string)
	timeout := t.defaultTimeout
	if v, ok := args["timeout"]; ok && v != nil {
		timeout = asIntArg(v)
	}
	// WASM: shared SSH PTY (same as terminal panel) when configured; else tell user to open Settings.
	if runtime.GOOS == "js" {
		if sshConfigured() {
			return runCommandViaSharedPTY(ctx, command, timeout)
		}
		return nil, tools.NewToolError(
			"SSH is not configured. Open Settings (top-left icon) and add your VPS host, user, and password or private key. " +
				"Agent shell work drives that shared SSH terminal — local browser MEMFS is not a VPS substitute. " +
				"After saving SSH, open the terminal (top-right) or send another message.",
		)
	}
	for _, part := range extractCommands(command) {
		for _, d := range t.denylist {
			if tools.MatchCommandPrefix(part, d) {
				return nil, tools.NewToolError("Command denied: '%s' matches denylist pattern '%s'", part, d)
			}
		}
		toks := strings.Fields(part)
		if len(toks) == 1 {
			base := toks[0]
			for _, d := range t.denylistAlone {
				if base == d || strings.HasSuffix(base, "/"+d) {
					return nil, tools.NewToolError("Command denied: '%s' is not allowed as a standalone command", part)
				}
			}
		}
	}
	cctx, cancel := context.WithTimeout(ctx, time.Duration(timeout)*time.Second)
	defer cancel()
	var cmd *exec.Cmd
	if utils.IsWindows() {
		cmd = exec.CommandContext(cctx, "cmd", "/C", command)
	} else {
		shell := utils.ShellExecutable()
		cmd = exec.CommandContext(cctx, shell, "-c", command)
		cmd.Env = append(os.Environ(), "CI=true", "NONINTERACTIVE=1", "NO_TTY=1", "TERM=dumb", "PAGER=cat", "GIT_PAGER=cat")
	}
	var stdout, stderr bytes.Buffer
	cmd.Stdout = &stdout
	cmd.Stderr = &stderr
	err := cmd.Run()
	out := stdout.String()
	errOut := stderr.String()
	if len(out) > t.maxOutput {
		out = out[:t.maxOutput]
	}
	if len(errOut) > t.maxOutput {
		errOut = errOut[:t.maxOutput]
	}
	rc := 0
	if err != nil {
		if ee, ok := err.(*exec.ExitError); ok {
			rc = ee.ExitCode()
		} else if cctx.Err() != nil {
			return nil, tools.NewToolError("Command timed out after %ds: %q", timeout, command)
		} else {
			return nil, tools.NewToolError("Error running command %q: %v", command, err)
		}
	}
	if rc != 0 {
		msg := "Command failed: " + command + "\nReturn code: " + itoa(rc)
		if errOut != "" {
			msg += "\nStderr: " + errOut
		}
		if out != "" {
			msg += "\nStdout: " + out
		}
		return nil, tools.NewToolError("%s", msg)
	}
	return map[string]any{"command": command, "stdout": out, "stderr": errOut, "returncode": rc}, nil
}

func itoa(n int) string {
	if n == 0 {
		return "0"
	}
	neg := n < 0
	if neg {
		n = -n
	}
	var b [20]byte
	i := len(b)
	for n > 0 {
		i--
		b[i] = byte('0' + n%10)
		n /= 10
	}
	if neg {
		i--
		b[i] = '-'
	}
	return string(b[i:])
}

// BashToolConfig mirrors Python BashToolConfig.
type BashToolConfig struct {
	MaxOutputBytes     int
	DefaultTimeoutSec  int
	Allowlist          []string
	Denylist           []string
	DenylistStandalone []string
	Sensitive          []string
}

// DefaultBashConfig returns production defaults.
func DefaultBashConfig() BashToolConfig {
	return BashToolConfig{
		MaxOutputBytes:    16000,
		DefaultTimeoutSec: 300,
		Allowlist: []string{
			"cd", "echo", "git diff", "git log", "git status", "git show", "git branch",
			"tree", "whoami", "cat", "file", "find", "head", "ls", "pwd", "stat", "tail",
			"uname", "wc", "which", "rg", "grep", "sed", "awk", "sort", "uniq", "cut",
			"tr", "basename", "dirname", "realpath", "readlink", "test", "[", "true", "false",
		},
		Denylist: []string{
			"gdb", "pdb", "passwd", "nano", "vim", "vi", "emacs",
			"bash -i", "sh -i", "zsh -i", "screen", "tmux", "ftp", "telnet",
		},
		DenylistStandalone: []string{"python", "python3", "ipython", "bash", "sh", "nohup", "su", "zsh"},
		Sensitive:          []string{"sudo", "doas", "pkexec"},
	}
}

func (t *bashTool) FormatCallDisplay(args map[string]any) string {
	cmd, _ := args["command"].(string)
	if len(cmd) > 120 {
		cmd = cmd[:117] + "…"
	}
	return "$ " + cmd
}

func (t *bashTool) GetResultDisplay(result any) string {
	m, ok := result.(map[string]any)
	if !ok {
		return fmt.Sprint(result)
	}
	out, _ := m["stdout"].(string)
	if out == "" {
		return "(no output)"
	}
	if len(out) > 400 {
		return out[:397] + "…"
	}
	return out
}

func (t *bashTool) GetStatusText() string { return "Running bash command" }

func (t *bashTool) isAllowlisted(part string) bool {
	for _, a := range t.allowlist {
		if tools.MatchCommandPrefix(part, a) {
			return true
		}
	}
	return false
}

func (t *bashTool) isSensitive(part string) bool {
	for _, s := range t.sensitive {
		if tools.MatchCommandPrefix(part, s) {
			return true
		}
	}
	return false
}

func (t *bashTool) findDenylistMatch(part string) string {
	for _, d := range t.denylist {
		if tools.MatchCommandPrefix(part, d) {
			return d
		}
	}
	return ""
}

func (t *bashTool) isStandaloneDenylisted(part string) bool {
	toks := strings.Fields(part)
	if len(toks) != 1 {
		return false
	}
	base := toks[0]
	for _, d := range t.denylistAlone {
		if base == d || strings.HasSuffix(base, "/"+d) {
			return true
		}
	}
	return false
}

func (t *bashTool) hasFindExecutionPredicate(part string) bool {
	low := strings.ToLower(part)
	return strings.Contains(low, "find ") && (strings.Contains(low, "-exec") || strings.Contains(low, "-ok") || strings.Contains(low, "-delete"))
}

func collectOutsideDirs(command, workdir string) []string {
	// Heuristic: absolute paths that don't sit under workdir
	re := regexp.MustCompile(`(?:^|[\s="'])(/[^\s"']+)`)
	ms := re.FindAllStringSubmatch(command, -1)
	var out []string
	seen := map[string]bool{}
	for _, m := range ms {
		p := m[1]
		if workdir != "" && strings.HasPrefix(p, workdir) {
			continue
		}
		if !seen[p] {
			seen[p] = true
			out = append(out, p)
		}
	}
	return out
}

func matchesPattern(command, pattern string) bool {
	return tools.MatchCommandPrefix(command, pattern)
}

// ResolvePermission decides ALWAYS/ASK/NEVER for a bash invocation.
func (t *bashTool) ResolvePermission(args map[string]any, workdir string) tools.PermissionContext {
	command, _ := args["command"].(string)
	var required []tools.RequiredPermission
	parts := extractCommands(command)
	allAllowed := len(parts) > 0
	for _, part := range parts {
		if t.findDenylistMatch(part) != "" || t.isStandaloneDenylisted(part) {
			return tools.PermissionContext{Permission: tools.PermissionNever, Reason: "denylisted command"}
		}
		if t.hasFindExecutionPredicate(part) {
			required = append(required, tools.RequiredPermission{
				Scope: tools.ScopeCommandPattern, InvocationPattern: part, Label: "find -exec",
			})
			allAllowed = false
		}
		if t.isSensitive(part) {
			required = append(required, tools.RequiredPermission{
				Scope: tools.ScopeCommandPattern, InvocationPattern: part, Label: "sensitive",
			})
			allAllowed = false
		}
		if !t.isAllowlisted(part) {
			allAllowed = false
			required = append(required, tools.RequiredPermission{
				Scope: tools.ScopeCommandPattern, InvocationPattern: part, Label: "bash:" + part,
			})
		}
	}
	for _, dir := range collectOutsideDirs(command, workdir) {
		required = append(required, tools.RequiredPermission{
			Scope: tools.ScopeOutsideDirectory, InvocationPattern: dir, Label: "outside:" + dir,
		})
		allAllowed = false
	}
	if allAllowed && len(required) == 0 {
		return tools.PermissionContext{Permission: tools.PermissionAlways, Reason: "allowlisted"}
	}
	return tools.PermissionContext{Permission: tools.PermissionAsk, RequiredPermissions: required}
}

func getBaseEnv() []string {
	env := os.Environ()
	return append(env, "CI=true", "NONINTERACTIVE=1", "NO_TTY=1", "TERM=dumb", "PAGER=cat", "GIT_PAGER=cat", "GIT_TERMINAL_PROMPT=0")
}

func getShellExecutable() string { return utils.ShellExecutable() }
