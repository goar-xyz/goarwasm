package builtins

import (
	"context"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"os"
	"strings"
	"time"

	"github.com/goarxyz/goar/internal/core/tools"
)

type webSearch struct {
	timeout int
}

func NewWebSearch() tools.Tool { return &webSearch{timeout: 120} }
func (t *webSearch) Name() string { return "websearch" }
func (t *webSearch) Description() string { return "Search the web for current information." }
func (t *webSearch) Permission() tools.ToolPermission { return tools.PermissionAsk }
func (t *webSearch) Parameters() map[string]any {
	return map[string]any{
		"type": "object",
		"properties": map[string]any{"query": map[string]any{"type": "string", "minLength": 1}},
		"required": []string{"query"},
	}
}

func (t *webSearch) Run(ctx context.Context, args map[string]any, inv *tools.InvokeContext) (any, error) {
	_ = inv
	query, _ := args["query"].(string)
	if strings.TrimSpace(query) == "" {
		return nil, tools.NewToolError("query is required")
	}
	// Prefer Brave / Serper / Tavily if configured; else DuckDuckGo Instant Answer HTML-free API.
	if key := os.Getenv("BRAVE_API_KEY"); key != "" {
		return t.brave(ctx, query, key)
	}
	if key := os.Getenv("SERPER_API_KEY"); key != "" {
		return t.serper(ctx, query, key)
	}
	if key := os.Getenv("TAVILY_API_KEY"); key != "" {
		return t.tavily(ctx, query, key)
	}
	return t.duckduckgo(ctx, query)
}

func (t *webSearch) client() *http.Client {
	return &http.Client{
		Timeout:   time.Duration(t.timeout) * time.Second,
		Transport: http.DefaultTransport, // browsernet under WASM after SDN.Install
	}
}

func (t *webSearch) duckduckgo(ctx context.Context, query string) (any, error) {
	u := "https://api.duckduckgo.com/?q=" + url.QueryEscape(query) + "&format=json&no_html=1&skip_disambig=1"
	req, err := http.NewRequestWithContext(ctx, http.MethodGet, u, nil)
	if err != nil {
		return nil, tools.NewToolError("%v", err)
	}
	req.Header.Set("User-Agent", "goar-cli")
	resp, err := t.client().Do(req)
	if err != nil {
		return nil, tools.NewToolError("%v", err)
	}
	defer resp.Body.Close()
	body, _ := io.ReadAll(resp.Body)
	var data map[string]any
	_ = json.Unmarshal(body, &data)
	answer, _ := data["AbstractText"].(string)
	sources := []map[string]any{}
	if answer == "" {
		if rt, ok := data["RelatedTopics"].([]any); ok {
			for _, item := range rt {
				im, _ := item.(map[string]any)
				if text, ok := im["Text"].(string); ok && text != "" {
					if answer == "" {
						answer = text
					}
					sources = append(sources, map[string]any{"title": text, "url": fmt.Sprint(im["FirstURL"])})
				}
				if len(sources) >= 5 {
					break
				}
			}
		}
	} else if au, ok := data["AbstractURL"].(string); ok && au != "" {
		sources = append(sources, map[string]any{"title": fmt.Sprint(data["Heading"]), "url": au})
	}
	if answer == "" {
		answer = "No instant answer; try configuring BRAVE_API_KEY, SERPER_API_KEY, or TAVILY_API_KEY for richer results."
	}
	return map[string]any{"answer": answer, "sources": sources}, nil
}

func (t *webSearch) brave(ctx context.Context, query, key string) (any, error) {
	u := "https://api.search.brave.com/res/v1/web/search?q=" + url.QueryEscape(query)
	req, _ := http.NewRequestWithContext(ctx, http.MethodGet, u, nil)
	req.Header.Set("X-Subscription-Token", key)
	req.Header.Set("Accept", "application/json")
	resp, err := t.client().Do(req)
	if err != nil {
		return nil, tools.NewToolError("%v", err)
	}
	defer resp.Body.Close()
	body, _ := io.ReadAll(resp.Body)
	var data map[string]any
	_ = json.Unmarshal(body, &data)
	web, _ := data["web"].(map[string]any)
	results, _ := web["results"].([]any)
	sources := []map[string]any{}
	var parts []string
	for _, r := range results {
		rm, _ := r.(map[string]any)
		title := fmt.Sprint(rm["title"])
		urlS := fmt.Sprint(rm["url"])
		desc := fmt.Sprint(rm["description"])
		sources = append(sources, map[string]any{"title": title, "url": urlS})
		parts = append(parts, title+": "+desc)
		if len(sources) >= 8 {
			break
		}
	}
	return map[string]any{"answer": strings.Join(parts, "\n"), "sources": sources}, nil
}

func (t *webSearch) serper(ctx context.Context, query, key string) (any, error) {
	payload := strings.NewReader(`{"q":` + mustJSON(query) + `}`)
	req, _ := http.NewRequestWithContext(ctx, http.MethodPost, "https://google.serper.dev/search", payload)
	req.Header.Set("X-API-KEY", key)
	req.Header.Set("Content-Type", "application/json")
	resp, err := t.client().Do(req)
	if err != nil {
		return nil, tools.NewToolError("%v", err)
	}
	defer resp.Body.Close()
	body, _ := io.ReadAll(resp.Body)
	var data map[string]any
	_ = json.Unmarshal(body, &data)
	organic, _ := data["organic"].([]any)
	sources := []map[string]any{}
	var parts []string
	for _, r := range organic {
		rm, _ := r.(map[string]any)
		sources = append(sources, map[string]any{"title": fmt.Sprint(rm["title"]), "url": fmt.Sprint(rm["link"])})
		parts = append(parts, fmt.Sprint(rm["title"])+": "+fmt.Sprint(rm["snippet"]))
		if len(sources) >= 8 {
			break
		}
	}
	return map[string]any{"answer": strings.Join(parts, "\n"), "sources": sources}, nil
}

func (t *webSearch) tavily(ctx context.Context, query, key string) (any, error) {
	payload := strings.NewReader(`{"api_key":` + mustJSON(key) + `,"query":` + mustJSON(query) + `}`)
	req, _ := http.NewRequestWithContext(ctx, http.MethodPost, "https://api.tavily.com/search", payload)
	req.Header.Set("Content-Type", "application/json")
	resp, err := t.client().Do(req)
	if err != nil {
		return nil, tools.NewToolError("%v", err)
	}
	defer resp.Body.Close()
	body, _ := io.ReadAll(resp.Body)
	var data map[string]any
	_ = json.Unmarshal(body, &data)
	answer, _ := data["answer"].(string)
	results, _ := data["results"].([]any)
	sources := []map[string]any{}
	for _, r := range results {
		rm, _ := r.(map[string]any)
		sources = append(sources, map[string]any{"title": fmt.Sprint(rm["title"]), "url": fmt.Sprint(rm["url"])})
	}
	return map[string]any{"answer": answer, "sources": sources}, nil
}

func mustJSON(s string) string {
	b, _ := json.Marshal(s)
	return string(b)
}
