package builtins

import (
	"context"
	"os"
	"path/filepath"
	"testing"
)

func TestReadFile(t *testing.T) {
	dir := t.TempDir()
	path := filepath.Join(dir, "sample.txt")
	content := "line1\nline2\nline3\n"
	if err := os.WriteFile(path, []byte(content), 0o644); err != nil {
		t.Fatal(err)
	}
	tool := NewReadFile()
	res, err := tool.Run(context.Background(), map[string]any{"path": path, "offset": 1, "limit": 1}, nil)
	if err != nil {
		t.Fatal(err)
	}
	m := res.(map[string]any)
	if m["lines_read"].(int) != 1 {
		t.Fatalf("lines_read=%v", m["lines_read"])
	}
	if m["content"].(string) != "line2\n" {
		t.Fatalf("content=%q", m["content"])
	}
}

func TestWriteFile(t *testing.T) {
	dir := t.TempDir()
	path := filepath.Join(dir, "out.txt")
	tool := NewWriteFile()
	_, err := tool.Run(context.Background(), map[string]any{"path": path, "content": "hi", "overwrite": false}, nil)
	if err != nil {
		t.Fatal(err)
	}
	b, _ := os.ReadFile(path)
	if string(b) != "hi" {
		t.Fatal(string(b))
	}
	_, err = tool.Run(context.Background(), map[string]any{"path": path, "content": "no", "overwrite": false}, nil)
	if err == nil {
		t.Fatal("expected overwrite error")
	}
}
