package builtins

import (
	"bytes"
	"context"
	"os"
	"os/exec"
	"path/filepath"
	"runtime"
	"strings"
	"time"

	"github.com/goarxyz/goar/internal/core/tools"
)

type pipInstall struct{}

func NewPipInstall() tools.Tool { return &pipInstall{} }
func (t *pipInstall) Name() string { return "pip_install" }
func (t *pipInstall) Description() string {
	return "Install Python packages with pip for the current environment. Under WASM, forwards to ssh_exec when SSH is configured."
}
func (t *pipInstall) Permission() tools.ToolPermission { return tools.PermissionAsk }
func (t *pipInstall) Parameters() map[string]any {
	return map[string]any{
		"type": "object",
		"properties": map[string]any{
			"packages": map[string]any{"type": "array", "items": map[string]any{"type": "string"}},
			"upgrade":  map[string]any{"type": "boolean"},
		},
		"required": []string{"packages"},
	}
}
func (t *pipInstall) Run(ctx context.Context, args map[string]any, inv *tools.InvokeContext) (any, error) {
	_ = inv
	raw, _ := args["packages"].([]any)
	pkgs := make([]string, 0, len(raw))
	for _, r := range raw {
		if s, ok := r.(string); ok {
			pkgs = append(pkgs, strings.TrimSpace(s))
		}
	}
	if len(pkgs) == 0 {
		return nil, tools.NewToolError("packages required")
	}
	upgrade, _ := args["upgrade"].(bool)
	if runtime.GOOS == "js" {
		if sshConfigured() {
			cmd := "python3 -m pip install"
			if upgrade {
				cmd += " -U"
			}
			for _, p := range pkgs {
				cmd += " " + shellQuote(p)
			}
			return runCommandViaSSHExec(ctx, cmd, 600)
		}
		notePath := writePipRequirementsNote(pkgs, upgrade)
		return map[string]any{
			"ok": false,
			"pending": true,
			"packages": pkgs,
			"requirementsPath": notePath,
			"solution": "Open Settings → configure SSH, then retry pip_install (runs on remote via Wisp). " +
				"Or Terminal (SSH mode): python3 -m pip install -r " + notePath,
		}, nil
	}
	cctx, cancel := context.WithTimeout(ctx, 10*time.Minute)
	defer cancel()
	argv := []string{"-m", "pip", "install"}
	if upgrade {
		argv = append(argv, "-U")
	}
	argv = append(argv, pkgs...)
	cmd := exec.CommandContext(cctx, "python3", argv...)
	var stdout, stderr bytes.Buffer
	cmd.Stdout = &stdout
	cmd.Stderr = &stderr
	err := cmd.Run()
	rc := 0
	if err != nil {
		if ee, ok := err.(*exec.ExitError); ok {
			rc = ee.ExitCode()
		} else {
			return nil, tools.NewToolError("%v", err)
		}
	}
	return map[string]any{"packages": pkgs, "stdout": stdout.String(), "stderr": stderr.String(), "returncode": rc}, nil
}


func writePipRequirementsNote(pkgs []string, upgrade bool) string {
	home := strings.TrimSpace(os.Getenv("AGENT_HOME"))
	if home == "" {
		home = "/tmp/goar-agent-home"
	}
	dir := filepath.Join(home, "pip-pending")
	_ = os.MkdirAll(dir, 0o755)
	path := filepath.Join(dir, "requirements-pending.txt")
	var b strings.Builder
	b.WriteString("# pending pip install (WASM local — needs SSH)\n")
	if upgrade {
		b.WriteString("# upgrade requested\n")
	}
	for _, pkg := range pkgs {
		b.WriteString(pkg)
		b.WriteByte('\n')
	}
	_ = os.WriteFile(path, []byte(b.String()), 0o644)
	return path
}

func shellQuote(s string) string {
	if s == "" {
		return "''"
	}
	return "'" + strings.ReplaceAll(s, "'", `'"'"'`) + "'"
}
