package builtins

import (
	"context"
	"fmt"
	"os"
	"regexp"
	"strings"

	"github.com/goarxyz/goar/internal/core/tools"
	"github.com/goarxyz/goar/internal/core/utils"
)

var (
	searchReplaceBlockRE = regexp.MustCompile(`(?s)<{5,} SEARCH\r?\n(.*?)\r?\n?={5,}\r?\n(.*?)\r?\n?>{5,} REPLACE`)
)

type searchReplace struct {
	maxContent int
	fuzzyThresh float64
}

func NewSearchReplace() tools.Tool {
	return &searchReplace{maxContent: 100000, fuzzyThresh: 0.9}
}
func (t *searchReplace) Name() string { return "search_replace" }
func (t *searchReplace) Description() string {
	return "Replace sections of files using SEARCH/REPLACE blocks. Supports fuzzy matching and detailed error reporting. Format: <<<<<<< SEARCH\\n[text]\\n=======\\n[replacement]\\n>>>>>>> REPLACE"
}
func (t *searchReplace) Permission() tools.ToolPermission { return tools.PermissionAsk }
func (t *searchReplace) Parameters() map[string]any {
	return map[string]any{
		"type": "object",
		"properties": map[string]any{
			"file_path": map[string]any{"type": "string"},
			"content":   map[string]any{"type": "string"},
		},
		"required": []string{"file_path", "content"},
	}
}

type srBlock struct{ search, replace string }

func parseSRBlocks(content string) []srBlock {
	ms := searchReplaceBlockRE.FindAllStringSubmatch(content, -1)
	out := make([]srBlock, 0, len(ms))
	for _, m := range ms {
		out = append(out, srBlock{search: m[1], replace: m[2]})
	}
	return out
}

func (t *searchReplace) Run(ctx context.Context, args map[string]any, inv *tools.InvokeContext) (any, error) {
	_ = ctx; _ = inv
	filePath, _ := args["file_path"].(string)
	content, _ := args["content"].(string)
	if strings.TrimSpace(filePath) == "" {
		return nil, tools.NewToolError("file_path cannot be empty")
	}
	if len(content) > t.maxContent {
		return nil, tools.NewToolError("content exceeds max size")
	}
	blocks := parseSRBlocks(content)
	if len(blocks) == 0 {
		return nil, tools.NewToolError("No SEARCH/REPLACE blocks found")
	}
	resolved, err := utils.ResolvePath(filePath)
	if err != nil {
		return nil, tools.NewToolError("%v", err)
	}
	raw, err := os.ReadFile(resolved)
	if err != nil {
		return nil, tools.NewToolError("Cannot read %s: %v", resolved, err)
	}
	text := string(raw)
	applied := 0
	var warnings []string
	origLines := len(strings.Split(text, "\n"))
	for _, b := range blocks {
		if strings.Contains(text, b.search) {
			text = strings.Replace(text, b.search, b.replace, 1)
			applied++
			continue
		}
		// fuzzy: try trimmed match
		trimmed := strings.TrimSpace(b.search)
		if trimmed != "" && strings.Contains(text, trimmed) {
			text = strings.Replace(text, trimmed, b.replace, 1)
			applied++
			warnings = append(warnings, "used trimmed match for a block")
			continue
		}
		return nil, tools.NewToolError("SEARCH block not found in %s", resolved)
	}
	if err := os.WriteFile(resolved, []byte(text), 0o644); err != nil {
		return nil, tools.NewToolError("%v", err)
	}
	newLines := len(strings.Split(text, "\n"))
	changed := newLines - origLines
	if changed < 0 {
		changed = -changed
	}
	return map[string]any{
		"file": resolved, "blocks_applied": applied, "lines_changed": changed,
		"content": text, "warnings": warnings,
	}, nil
}

// SearchReplaceBlock is one SEARCH/REPLACE pair.
type SearchReplaceBlock struct {
	Search  string
	Replace string
}

// FuzzyMatch describes a near match for a failed SEARCH block.
type FuzzyMatch struct {
	Score   float64
	Start   int
	End     int
	Snippet string
}

// BlockApplyResult is the outcome of applying one block.
type BlockApplyResult struct {
	Applied bool
	Fuzzy   bool
	Warning string
}

func (t *searchReplace) FormatCallDisplay(args map[string]any) string {
	fp, _ := args["file_path"].(string)
	return "edit " + fp
}

func (t *searchReplace) GetResultDisplay(result any) string {
	m, ok := result.(map[string]any)
	if !ok {
		return fmt.Sprint(result)
	}
	return fmt.Sprintf("%s: %v blocks, ~%v lines changed", m["file"], m["blocks_applied"], m["lines_changed"])
}

func (t *searchReplace) GetStatusText() string { return "Applying search/replace" }

func (t *searchReplace) GetFileSnapshot(args map[string]any) (string, error) {
	fp, _ := args["file_path"].(string)
	resolved, err := utils.ResolvePath(fp)
	if err != nil {
		return "", err
	}
	b, err := os.ReadFile(resolved)
	if err != nil {
		return "", err
	}
	return string(b), nil
}

func (t *searchReplace) ResolvePermission(args map[string]any) tools.PermissionContext {
	fp, _ := args["file_path"].(string)
	return tools.PermissionContext{
		Permission: tools.PermissionAsk,
		RequiredPermissions: []tools.RequiredPermission{{
			Scope: tools.ScopeFilePattern, InvocationPattern: fp, Label: "search_replace:" + fp,
		}},
	}
}

func similarityRatio(a, b string) float64 {
	if a == b {
		return 1
	}
	if a == "" || b == "" {
		return 0
	}
	// Simple token Jaccard as lightweight fuzzy score
	at := strings.Fields(a)
	bt := strings.Fields(b)
	if len(at) == 0 || len(bt) == 0 {
		// fallback: rune overlap
		as := map[rune]bool{}
		for _, r := range a {
			as[r] = true
		}
		inter := 0
		for _, r := range b {
			if as[r] {
				inter++
			}
		}
		union := len(as)
		for _, r := range b {
			if !as[r] {
				union++
			}
		}
		if union == 0 {
			return 0
		}
		return float64(inter) / float64(union)
	}
	aset := map[string]bool{}
	for _, x := range at {
		aset[x] = true
	}
	inter := 0
	bset := map[string]bool{}
	for _, x := range bt {
		bset[x] = true
		if aset[x] {
			inter++
		}
	}
	union := len(aset) + len(bset) - inter
	if union == 0 {
		return 0
	}
	return float64(inter) / float64(union)
}

func (t *searchReplace) findBestFuzzyMatch(haystack, needle string) FuzzyMatch {
	best := FuzzyMatch{Score: 0}
	if needle == "" {
		return best
	}
	lines := strings.Split(haystack, "\n")
	nLines := strings.Split(needle, "\n")
	window := len(nLines)
	if window < 1 {
		window = 1
	}
	if window > len(lines) {
		window = len(lines)
	}
	for i := 0; i+window <= len(lines); i++ {
		snippet := strings.Join(lines[i:i+window], "\n")
		score := similarityRatio(snippet, needle)
		if score > best.Score {
			best = FuzzyMatch{Score: score, Start: i, End: i + window, Snippet: snippet}
		}
	}
	return best
}

func (t *searchReplace) findFuzzyMatchContext(haystack, needle string) string {
	m := t.findBestFuzzyMatch(haystack, needle)
	if m.Score < t.fuzzyThresh*0.5 {
		return ""
	}
	return fmt.Sprintf("closest match (score=%.2f) around lines %d-%d:\n%s", m.Score, m.Start+1, m.End, m.Snippet)
}

func createUnifiedDiff(path, before, after string) string {
	bl := strings.Split(before, "\n")
	al := strings.Split(after, "\n")
	var b strings.Builder
	b.WriteString("--- a/" + path + "\n+++ b/" + path + "\n")
	// Naive line diff: show removed then added for differing regions
	max := len(bl)
	if len(al) > max {
		max = len(al)
	}
	for i := 0; i < max; i++ {
		var left, right string
		if i < len(bl) {
			left = bl[i]
		}
		if i < len(al) {
			right = al[i]
		}
		if left == right {
			continue
		}
		if left != "" {
			b.WriteString("-" + left + "\n")
		}
		if right != "" {
			b.WriteString("+" + right + "\n")
		}
	}
	return b.String()
}

func (t *searchReplace) applyBlocks(text string, blocks []srBlock) (string, []BlockApplyResult, error) {
	results := make([]BlockApplyResult, 0, len(blocks))
	for _, b := range blocks {
		if strings.Contains(text, b.search) {
			text = strings.Replace(text, b.search, b.replace, 1)
			results = append(results, BlockApplyResult{Applied: true})
			continue
		}
		trimmed := strings.TrimSpace(b.search)
		if trimmed != "" && strings.Contains(text, trimmed) {
			text = strings.Replace(text, trimmed, b.replace, 1)
			results = append(results, BlockApplyResult{Applied: true, Fuzzy: true, Warning: "trimmed match"})
			continue
		}
		fm := t.findBestFuzzyMatch(text, b.search)
		if fm.Score >= t.fuzzyThresh {
			text = strings.Replace(text, fm.Snippet, b.replace, 1)
			results = append(results, BlockApplyResult{Applied: true, Fuzzy: true, Warning: fmt.Sprintf("fuzzy score=%.2f", fm.Score)})
			continue
		}
		ctx := t.findFuzzyMatchContext(text, b.search)
		msg := "SEARCH block not found"
		if ctx != "" {
			msg += "\n" + ctx
		}
		return text, results, tools.NewToolError("%s", msg)
	}
	return text, results, nil
}

func (t *searchReplace) backupFile(path string) error {
	raw, err := os.ReadFile(path)
	if err != nil {
		return err
	}
	return os.WriteFile(path+".bak", raw, 0o644)
}
