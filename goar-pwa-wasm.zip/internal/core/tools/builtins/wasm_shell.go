//go:build js && wasm

package builtins

import (
	"context"

	"github.com/goarxyz/goar/internal/core/tools"
	"github.com/goarxyz/goar/internal/core/wasmshell"
)

// runWasmShell executes command against MEMFS via wasmshell.
func runWasmShell(_ context.Context, command string) (any, error) {
	if need, name := wasmshell.NeedsRemote(command); need {
		return nil, tools.NewToolError("%s", (&wasmshell.UnsupportedError{Command: name}).Error())
	}
	r := wasmshell.Run(command)
	if r.ReturnCode != 0 {
		msg := "Command failed: " + command + "\nReturn code: " + itoa(r.ReturnCode)
		if r.Stderr != "" {
			msg += "\nStderr: " + r.Stderr
		}
		if r.Stdout != "" {
			msg += "\nStdout: " + r.Stdout
		}
		return nil, tools.NewToolError("%s", msg)
	}
	return map[string]any{
		"command":    command,
		"stdout":     r.Stdout,
		"stderr":     r.Stderr,
		"returncode": r.ReturnCode,
		"runtime":    "wasm_shell",
	}, nil
}
