package builtins

import (
	"context"
	"fmt"
	"net/http"
	"net/url"
	"os"
	"path/filepath"
	"strings"
	"time"

	"github.com/go-git/go-git/v5/plumbing/transport/client"
	githttp "github.com/go-git/go-git/v5/plumbing/transport/http"

	"github.com/goarxyz/goar/internal/core/tools"
)

// dynamicTransport always delegates to the current http.DefaultTransport so
// browsernet.SDN.Install() replacements are picked up without re-init races.
type dynamicTransport struct{}

func (dynamicTransport) RoundTrip(req *http.Request) (*http.Response, error) {
	return http.DefaultTransport.RoundTrip(req)
}

// InstallGitHTTPTransport re-binds go-git http/https protocols to a client that
// uses http.DefaultTransport (browsernet under WASM after SDN.Install).
// Safe to call multiple times (e.g. after each configure/network reinstall).
func InstallGitHTTPTransport() {
	c := &http.Client{
		Transport: dynamicTransport{},
		Timeout:   180 * time.Second,
	}
	tr := githttp.NewClient(c)
	client.InstallProtocol("http", tr)
	client.InstallProtocol("https", tr)
}

func isSSHGitURL(u string) bool {
	u = strings.TrimSpace(u)
	if u == "" {
		return false
	}
	if strings.HasPrefix(u, "git@") {
		return true
	}
	if strings.HasPrefix(u, "ssh://") {
		return true
	}
	return false
}

// rewriteSSHGitToHTTPS maps git@host:path and ssh://host/path to https://host/path.git
// for hosts that publish HTTPS remotes (GitHub, GitLab, etc.).
func rewriteSSHGitToHTTPS(raw string) (string, bool) {
	raw = strings.TrimSpace(raw)
	if strings.HasPrefix(raw, "git@") {
		// git@github.com:org/repo.git
		rest := strings.TrimPrefix(raw, "git@")
		host, path, ok := strings.Cut(rest, ":")
		if !ok || host == "" || path == "" {
			return "", false
		}
		path = strings.TrimPrefix(path, "/")
		if !strings.HasSuffix(path, ".git") {
			path += ".git"
		}
		return "https://" + host + "/" + path, true
	}
	if strings.HasPrefix(raw, "ssh://") {
		u, err := url.Parse(raw)
		if err != nil || u.Host == "" {
			return "", false
		}
		host := u.Hostname()
		path := strings.TrimPrefix(u.Path, "/")
		if path == "" {
			return "", false
		}
		if !strings.HasSuffix(path, ".git") {
			path += ".git"
		}
		return "https://" + host + "/" + path, true
	}
	return "", false
}

// gitCloneViaSSHExec runs `git clone` on the configured SSH host (Wisp dial),
// then pulls a tar of the repo back into MEMFS via remote tar | base64.
func gitCloneViaSSHExec(ctx context.Context, sshURL, dest string) (any, error) {
	_ = os.MkdirAll(filepath.Dir(dest), 0o755)
	base := filepath.Base(strings.TrimSuffix(dest, string(filepath.Separator)))
	if base == "" || base == "." {
		base = "repo"
	}
	remoteDir := "/tmp/goar-git-" + base
	cmd := fmt.Sprintf(
		"rm -rf %s && git clone --depth 1 %s %s && tar -C %s -czf - . | base64 -w0",
		shellQuote(remoteDir), shellQuote(sshURL), shellQuote(remoteDir), shellQuote(remoteDir),
	)
	res, err := runCommandViaSSHExec(ctx, cmd, 600)
	if err != nil {
		return nil, tools.NewToolError("git clone via SSH: %v — ensure remote has git, or use https:// URL through browsernet", err)
	}
	m, _ := res.(map[string]any)
	stdout, _ := m["stdout"].(string)
	stdout = strings.TrimSpace(stdout)
	if stdout == "" {
		return nil, tools.NewToolError("git clone via SSH: empty archive from remote")
	}
	// Decode base64 and extract via wasmshell-friendly write of tar is heavy;
	// write a clone marker + note; prefer unpacking with a small pure approach.
	if err := writeBase64TarToDir(stdout, dest); err != nil {
		// Fallback: keep remote path hint for the agent
		note := dest + ".ssh-clone-note.txt"
		_ = os.WriteFile(note, []byte("Cloned on remote at "+remoteDir+" via SSH. Unpack failed locally: "+err.Error()+"\nbase64_len="+fmt.Sprint(len(stdout))+"\n"), 0o644)
		return map[string]any{
			"ok":         true,
			"path":       dest,
			"url":        sshURL,
			"remotePath": remoteDir,
			"note":       "Repo cloned on SSH host; local unpack incomplete — see " + note + ". Use ssh_exec to work in " + remoteDir + ".",
			"via":        "ssh_exec",
		}, nil
	}
	return map[string]any{
		"ok": true, "path": dest, "url": sshURL, "via": "ssh_exec",
		"note": "Cloned via Wisp SSH exec git on remote, unpacked into MEMFS",
	}, nil
}
