package builtins

import (
	"bytes"
	"context"
	"fmt"
	"io"
	"net"
	"os"
	"regexp"
	"strconv"
	"strings"
	"time"

	"golang.org/x/crypto/ssh"

	"github.com/goarxyz/goar/internal/core/tools"
)

const (
	envSSHHost          = "AGENT_SSH_HOST"
	envSSHPort          = "AGENT_SSH_PORT"
	envSSHPorts         = "AGENT_SSH_PORTS"
	envSSHUser          = "AGENT_SSH_USER"
	envSSHPassword      = "AGENT_SSH_PASSWORD"
	envSSHPrivateKey    = "AGENT_SSH_PRIVATE_KEY"
	envSSHSecret        = "AGENT_SSH_SECRET"
	envSSHReconnectHost = "AGENT_SSH_RECONNECT_HOST"
)

type sshExecTool struct {
	maxOutput      int
	defaultTimeout int
}

// NewSSHExec returns the ssh_exec builtin (TCP via dialSSHConn — browsernet under WASM).
func NewSSHExec() tools.Tool {
	return &sshExecTool{maxOutput: 64000, defaultTimeout: 120}
}

func (t *sshExecTool) Name() string { return "ssh_exec" }
func (t *sshExecTool) Description() string {
	return "Run a command on the configured remote SSH host (password and/or private key). " +
		"Under WASM, dials through browsernet (Wisp). " +
		"Optional SECRET session env for segfault-style hosts. Defaults from AGENT_SSH_* / configure({ssh})."
}
func (t *sshExecTool) Permission() tools.ToolPermission { return tools.PermissionAsk }
func (t *sshExecTool) Parameters() map[string]any {
	return map[string]any{
		"type": "object",
		"properties": map[string]any{
			"command":    map[string]any{"type": "string", "description": "Remote command to run"},
			"host":       map[string]any{"type": "string", "description": "Override AGENT_SSH_HOST"},
			"port":       map[string]any{"type": "integer", "description": "Override AGENT_SSH_PORT (default 22)"},
			"user":       map[string]any{"type": "string", "description": "Override AGENT_SSH_USER"},
			"password":   map[string]any{"type": "string", "description": "Override AGENT_SSH_PASSWORD"},
			"privateKey": map[string]any{"type": "string", "description": "Override AGENT_SSH_PRIVATE_KEY (PEM)"},
			"secret":     map[string]any{"type": "string", "description": "Optional SECRET via session Setenv (segfault)"},
			"timeout":    map[string]any{"type": "integer", "description": "Timeout seconds (default 120)"},
		},
		"required": []string{"command"},
	}
}

func (t *sshExecTool) Run(ctx context.Context, args map[string]any, inv *tools.InvokeContext) (any, error) {
	_ = inv
	command, _ := args["command"].(string)
	command = strings.TrimSpace(command)
	if command == "" {
		return nil, tools.NewToolError("ssh_exec: command is required")
	}
	cfg, err := resolveSSHConfig(args)
	if err != nil {
		return nil, err
	}
	timeout := t.defaultTimeout
	if v, ok := args["timeout"]; ok && v != nil {
		if n := asIntArg(v); n > 0 {
			timeout = n
		}
	}
	cctx, cancel := context.WithTimeout(ctx, time.Duration(timeout)*time.Second)
	defer cancel()

	stdout, stderr, err := runSSHCommand(cctx, cfg, command)
	if len(stdout) > t.maxOutput {
		stdout = stdout[:t.maxOutput]
	}
	if len(stderr) > t.maxOutput {
		stderr = stderr[:t.maxOutput]
	}
	if err != nil {
		msg := fmt.Sprintf("ssh_exec failed: %v", err)
		if stderr != "" {
			msg += "\nStderr: " + stderr
		}
		if stdout != "" {
			msg += "\nStdout: " + stdout
		}
		return nil, tools.NewToolError("%s", msg)
	}
	return map[string]any{
		"host":     cfg.Host,
		"port":     cfg.Port,
		"user":     cfg.User,
		"command":  command,
		"stdout":   stdout,
		"stderr":   stderr,
		"exitcode": 0,
	}, nil
}

func (t *sshExecTool) FormatCallDisplay(args map[string]any) string {
	cmd, _ := args["command"].(string)
	if len(cmd) > 100 {
		cmd = cmd[:97] + "…"
	}
	host := strings.TrimSpace(os.Getenv(envSSHHost))
	if v, _ := args["host"].(string); strings.TrimSpace(v) != "" {
		host = strings.TrimSpace(v)
	}
	if host == "" {
		host = "ssh"
	}
	return "ssh " + host + ": " + cmd
}

func (t *sshExecTool) GetResultDisplay(result any) string {
	m, ok := result.(map[string]any)
	if !ok {
		return fmt.Sprint(result)
	}
	out, _ := m["stdout"].(string)
	if out == "" {
		errOut, _ := m["stderr"].(string)
		if errOut != "" {
			return errOut
		}
		return "(no output)"
	}
	if len(out) > 400 {
		return out[:397] + "…"
	}
	return out
}

func (t *sshExecTool) GetStatusText() string { return "Running remote SSH command" }

type sshConfig struct {
	Host       string
	Port       int
	User       string
	Password   string
	PrivateKey string
	Secret     string
}

func resolveSSHConfig(args map[string]any) (sshConfig, error) {
	cfg := sshConfig{
		Host:       firstNonEmpty(strArg(args, "host"), os.Getenv(envSSHReconnectHost), os.Getenv(envSSHHost), defaultSSHHost),
		User:       firstNonEmpty(strArg(args, "user"), os.Getenv(envSSHUser), defaultSSHUser),
		Password:   firstNonEmpty(strArg(args, "password"), os.Getenv(envSSHPassword)),
		PrivateKey: firstNonEmpty(strArg(args, "privateKey"), os.Getenv(envSSHPrivateKey)),
		Secret:     firstNonEmpty(strArg(args, "secret"), os.Getenv(envSSHSecret)),
		Port:       0,
	}
	if v, ok := args["port"]; ok && v != nil {
		if n := asIntArg(v); n > 0 {
			cfg.Port = n
		}
	} else if p := strings.TrimSpace(os.Getenv(envSSHPort)); p != "" {
		if n, err := strconv.Atoi(p); err == nil && n > 0 {
			cfg.Port = n
		}
	}
	if cfg.Port <= 0 {
		cfg.Port = defaultSSHPorts[0]
	}
	if cfg.Password == "" && cfg.PrivateKey == "" && isSegfaultSSHHost(cfg.Host) {
		cfg.Password = defaultSSHPass
	}
	if cfg.Host == "" {
		return cfg, tools.NewToolError("ssh_exec: no host (set AGENT_SSH_HOST or pass host)")
	}
	if cfg.User == "" {
		return cfg, tools.NewToolError("ssh_exec: no user (set AGENT_SSH_USER or pass user)")
	}
	if cfg.Password == "" && cfg.PrivateKey == "" {
		return cfg, tools.NewToolError("ssh_exec: need password and/or privateKey")
	}
	return cfg, nil
}

func strArg(args map[string]any, key string) string {
	v, _ := args[key].(string)
	return strings.TrimSpace(v)
}

func firstNonEmpty(vals ...string) string {
	for _, v := range vals {
		if strings.TrimSpace(v) != "" {
			return strings.TrimSpace(v)
		}
	}
	return ""
}

func runSSHCommand(ctx context.Context, cfg sshConfig, command string) (stdout, stderr string, err error) {
	ports := sshDialPorts(cfg)
	var rawConn net.Conn
	var addr string
	var dialErr error
	for _, port := range ports {
		addr = net.JoinHostPort(cfg.Host, strconv.Itoa(port))
		rawConn, dialErr = dialSSHConn(ctx, addr)
		if dialErr == nil {
			cfg.Port = port
			break
		}
	}
	if rawConn == nil {
		return "", "", fmt.Errorf("dial %s ports %v: %w", cfg.Host, ports, dialErr)
	}

	sshCfg, err := buildSSHClientConfig(cfg)
	if err != nil {
		_ = rawConn.Close()
		return "", "", err
	}

	clientConn, chans, reqs, err := ssh.NewClientConn(rawConn, addr, sshCfg)
	if err != nil {
		_ = rawConn.Close()
		return "", "", fmt.Errorf("ssh handshake: %w", err)
	}
	client := ssh.NewClient(clientConn, chans, reqs)
	defer client.Close()

	// Segfault-style / SECRET / banner hosts: interactive shell path (Press ENTER best-effort).
	if cfg.Secret != "" || isSegfaultSSHHost(cfg.Host) {
		return runSSHViaShell(ctx, client, cfg, command)
	}

	session, err := client.NewSession()
	if err != nil {
		return "", "", fmt.Errorf("ssh session: %w", err)
	}
	defer session.Close()

	var outBuf, errBuf bytes.Buffer
	session.Stdout = &outBuf
	session.Stderr = &errBuf

	done := make(chan error, 1)
	go func() {
		done <- session.Run(command)
	}()

	select {
	case <-ctx.Done():
		_ = session.Close()
		return outBuf.String(), errBuf.String(), ctx.Err()
	case err := <-done:
		if err == nil {
			return outBuf.String(), errBuf.String(), nil
		}
		if strings.Contains(outBuf.String(), "Press ENTER") || strings.Contains(errBuf.String(), "Press ENTER") {
			return runSSHViaShell(ctx, client, cfg, command)
		}
		if ee, ok := err.(*ssh.ExitError); ok {
			return outBuf.String(), errBuf.String(), fmt.Errorf("exit status %d", ee.ExitStatus())
		}
		return outBuf.String(), errBuf.String(), err
	}
}


const (
	defaultSSHHost = "segfault.net"
	defaultSSHUser = "root"
	defaultSSHPass = "segfault"
)

var defaultSSHPorts = []int{443, 22}

func sshDialPorts(cfg sshConfig) []int {
	// Prefer explicit AGENT_SSH_PORTS (from configure ports:[443,22]).
	if raw := strings.TrimSpace(os.Getenv(envSSHPorts)); raw != "" {
		var out []int
		seen := map[int]bool{}
		for _, part := range strings.Split(raw, ",") {
			part = strings.TrimSpace(part)
			if n, err := strconv.Atoi(part); err == nil && n > 0 && !seen[n] {
				out = append(out, n)
				seen[n] = true
			}
		}
		if len(out) > 0 {
			return out
		}
	}
	// Modular connectOnce: Kali → DEFAULT_PORTS; else single port or 22.
	if isSegfaultSSHHost(cfg.Host) {
		out := make([]int, 0, len(defaultSSHPorts)+1)
		seen := map[int]bool{}
		if cfg.Port > 0 {
			out = append(out, cfg.Port)
			seen[cfg.Port] = true
		}
		for _, p := range defaultSSHPorts {
			if !seen[p] {
				out = append(out, p)
				seen[p] = true
			}
		}
		return out
	}
	if cfg.Port > 0 {
		return []int{cfg.Port}
	}
	return []int{22}
}

func isSegfaultSSHHost(host string) bool {
	h := strings.ToLower(strings.TrimSpace(host))
	if h == "" {
		return false
	}
	if h == "segfault.net" || strings.HasSuffix(h, ".segfault.net") {
		return true
	}
	if strings.HasSuffix(h, ".segfault.gsocket") || h == "segfault.gsocket" {
		return true
	}
	return strings.Contains(h, "segfault")
}

func runSSHViaShell(ctx context.Context, client *ssh.Client, cfg sshConfig, command string) (string, string, error) {
	session, err := client.NewSession()
	if err != nil {
		return "", "", err
	}
	defer session.Close()
	if cfg.Secret != "" {
		_ = session.Setenv("SECRET", cfg.Secret)
	}
	_ = session.RequestPty("dumb", 40, 120, ssh.TerminalModes{
		ssh.ECHO:          0,
		ssh.TTY_OP_ISPEED: 14400,
		ssh.TTY_OP_OSPEED: 14400,
	})
	stdin, err := session.StdinPipe()
	if err != nil {
		return "", "", err
	}
	var combined bytes.Buffer
	session.Stdout = &combined
	session.Stderr = &combined
	if err := session.Shell(); err != nil {
		return "", "", fmt.Errorf("shell: %w", err)
	}

	// Segfault free-tier: ~30s MOTD + "Press any key" before a usable prompt.
	deadline := time.Now().Add(55 * time.Second)
	if dl, ok := ctx.Deadline(); ok && dl.Before(deadline) {
		deadline = dl
	}
	for time.Now().Before(deadline) {
		if ctx.Err() != nil {
			return combined.String(), "", ctx.Err()
		}
		time.Sleep(200 * time.Millisecond)
		cur := combined.String()
		low := strings.ToLower(cur)
		tail := low
		if len(tail) > 400 {
			tail = tail[len(tail)-400:]
		}
		if strings.Contains(tail, "press enter") || strings.Contains(tail, "press any key") || strings.Contains(tail, "you have 10 seconds") {
			_, _ = io.WriteString(stdin, " \n")
			time.Sleep(300 * time.Millisecond)
			continue
		}
		if shellLooksReady(cur) {
			break
		}
	}

	marker := "__GOAR_SSH_DONE__"
	// stty -echo prevents the marker from appearing in the capture via local echo.
	inner := command + "; printf '\\n" + marker + " %s\\n' \"$?\""
	wrapped := "stty -echo 2>/dev/null\n" +
		"bash --noprofile --norc -c " + strconv.Quote(inner) + "\n" +
		"stty echo 2>/dev/null\n"
	if _, err := io.WriteString(stdin, wrapped); err != nil {
		return combined.String(), "", err
	}

	markerDone := regexp.MustCompile(regexp.QuoteMeta(marker) + `\s+(\d+)`)
	waitUntil := time.Now().Add(60 * time.Second)
	if dl, ok := ctx.Deadline(); ok && dl.Before(waitUntil) {
		waitUntil = dl
	}
	for time.Now().Before(waitUntil) {
		if ctx.Err() != nil {
			_, _ = io.WriteString(stdin, "exit\n")
			return combined.String(), "", ctx.Err()
		}
		// Need marker + exit digits — not the echoed "echo MARKER $?" line.
		if markerDone.MatchString(combined.String()) {
			break
		}
		time.Sleep(200 * time.Millisecond)
	}
	_, _ = io.WriteString(stdin, "exit\n")
	_ = session.Wait()

	raw := combined.String()
	loc := markerDone.FindStringIndex(raw)
	if loc == nil {
		return raw, "", fmt.Errorf("remote command timed out or marker missing")
	}
	before := raw[:loc[0]]
	stdout := stripSSHExecEcho(before)
	return stdout, "", nil
}

func stripSSHExecEcho(s string) string {
	lines := strings.Split(s, "\n")
	out := make([]string, 0, len(lines))
	for _, line := range lines {
		trim := strings.TrimSpace(strings.ReplaceAll(line, "\r", ""))
		// Drop ANSI for classification only
		plain := ansiRE.ReplaceAllString(trim, "")
		plain = strings.TrimSpace(plain)
		if plain == "" {
			continue
		}
		if strings.Contains(plain, "/bin/bash --noprofile --norc -c") {
			continue
		}
		if strings.Contains(plain, "__GOAR_SSH_DONE__") {
			continue
		}
		out = append(out, strings.TrimRight(line, "\r"))
	}
	return strings.TrimSpace(strings.Join(out, "\n"))
}

func buildSSHClientConfig(cfg sshConfig) (*ssh.ClientConfig, error) {
	var auths []ssh.AuthMethod
	if cfg.PrivateKey != "" {
		signer, err := parsePrivateKey(cfg.PrivateKey)
		if err != nil {
			return nil, fmt.Errorf("private key: %w", err)
		}
		auths = append(auths, ssh.PublicKeys(signer))
	}
	if cfg.Password != "" {
		auths = append(auths, ssh.Password(cfg.Password))
	}
	return &ssh.ClientConfig{
		User:            cfg.User,
		Auth:            auths,
		HostKeyCallback: hostKeyCallback(),
		Timeout:         45 * time.Second,
	}, nil
}

func parsePrivateKey(pem string) (ssh.Signer, error) {
	key := []byte(strings.TrimSpace(pem))
	signer, err := ssh.ParsePrivateKey(key)
	if err == nil {
		return signer, nil
	}
	// Retry without passphrase variants already covered; return original error.
	return nil, err
}

// sshConfigured reports whether AGENT_SSH_* (or reconnect host) is present.
func sshConfigured() bool {
	host := firstNonEmpty(os.Getenv(envSSHReconnectHost), os.Getenv(envSSHHost))
	user := strings.TrimSpace(os.Getenv(envSSHUser))
	pass := strings.TrimSpace(os.Getenv(envSSHPassword))
	key := strings.TrimSpace(os.Getenv(envSSHPrivateKey))
	return host != "" && user != "" && (pass != "" || key != "")
}

// runCommandViaSSHExec runs a command using stored SSH env (used by bash under WASM).
func runCommandViaSSHExec(ctx context.Context, command string, timeoutSec int) (any, error) {
	t := NewSSHExec().(*sshExecTool)
	args := map[string]any{"command": command}
	if timeoutSec > 0 {
		args["timeout"] = timeoutSec
	}
	return t.Run(ctx, args, nil)
}

// RunSSHExecForAPI exposes ssh_exec for the WASM JS bridge (Desktop / probes).
func RunSSHExecForAPI(ctx context.Context, command string, timeoutSec int) (any, error) {
	return runCommandViaSSHExec(ctx, command, timeoutSec)
}
