package builtins

import (
	"context"
	"fmt"
	"io"
	"regexp"
	"strconv"
	"strings"
	"sync"
	"time"

	"github.com/goarxyz/goar/internal/core/tools"
)

// Shared SSH PTY gateway: one interactive session used by both the human
// terminal UI (openTerm) and agent bash. Bytes from the remote are fanned out
// to UI listeners and optionally captured for tool results.

type sharedSSHGateway struct {
	mu sync.Mutex

	sess   *SSHTermSession
	cols   int
	rows   int
	host   string
	state  string // connecting|connected|failed|closed|reconnecting
	errMsg string

	listeners    map[int]func(string)
	nextListenID int

	// active agent capture (at most one; serialized by cmdMu)
	capture *ptyCapture

	pumpCancel context.CancelFunc
	pumpGen    uint64

	// Auto-reconnect supervisor (transport / Wisp drops).
	wantLive       bool // true after a successful Ensure until CloseSharedSSH
	reconnecting   bool
	reconnectGen   uint64
	maxAutoRetry   int
	autoRetryCount int
}

type ptyCapture struct {
	marker string
	buf    strings.Builder
	done   chan struct{}
	once   sync.Once
}

var (
	sharedSSH = &sharedSSHGateway{
		listeners:    map[int]func(string){},
		state:        "closed",
		maxAutoRetry: 8,
	}
	sharedSSHCmdMu    sync.Mutex // serialize agent commands on the PTY
	sharedSSHEnsureMu sync.Mutex // serialize Ensure/Reconnect dials
)

// OnSharedSSHData registers a listener for remote PTY output (e.g. xterm UI).
// Returns an unregister function.
func OnSharedSSHData(fn func(string)) (unregister func()) {
	if fn == nil {
		return func() {}
	}
	sharedSSH.mu.Lock()
	id := sharedSSH.nextListenID
	sharedSSH.nextListenID++
	sharedSSH.listeners[id] = fn
	sharedSSH.mu.Unlock()
	return func() {
		sharedSSH.mu.Lock()
		delete(sharedSSH.listeners, id)
		sharedSSH.mu.Unlock()
	}
}

// SharedSSHConnected reports whether the shared PTY is live.
func SharedSSHConnected() bool {
	sharedSSH.mu.Lock()
	defer sharedSSH.mu.Unlock()
	return sharedSSH.sess != nil && sharedSSH.state == "connected"
}

// SharedSSHHost returns user@host:port when connected.
func SharedSSHHost() string {
	sharedSSH.mu.Lock()
	defer sharedSSH.mu.Unlock()
	return sharedSSH.host
}

// SharedSSHState returns connecting|connected|reconnecting|failed|closed and any error.
func SharedSSHState() (state, host, errMsg string) {
	sharedSSH.mu.Lock()
	defer sharedSSH.mu.Unlock()
	return sharedSSH.state, sharedSSH.host, sharedSSH.errMsg
}


// shellLooksReady reports whether remote output ends at an interactive shell prompt
// (after segfault MOTD / "Press any key" / Kali zsh banner).
func shellLooksReady(buf string) bool {
	plain := stripBasicANSI(buf)
	plain = strings.ReplaceAll(plain, "\r", "\n")
	lines := strings.Split(plain, "\n")
	var last string
	for i := len(lines) - 1; i >= 0; i-- {
		s := strings.TrimSpace(lines[i])
		if s != "" {
			last = s
			break
		}
	}
	if last == "" {
		return false
	}
	// Still in free-tier MOTD / gate
	low := strings.ToLower(last)
	if strings.Contains(low, "continuing in") || strings.Contains(low, "press any key") ||
		strings.Contains(low, "press enter") || strings.Contains(low, "creating server") {
		return false
	}
	// Reject MOTD hash banners (################) and disclaimer #### lines.
	if strings.Count(last, "#") > 2 && strings.Trim(last, "#") == "" {
		return false
	}
	if strings.HasPrefix(last, "####") {
		return false
	}
	// Kali zsh: "└─#" / "─#"
	if strings.Contains(last, "└─#") || strings.HasSuffix(last, "─#") {
		return true
	}
	// Generic prompts: single trailing prompt char, not a wall of hashes.
	if (strings.HasSuffix(last, "#") || strings.HasSuffix(last, "$") || strings.HasSuffix(last, "%") || strings.HasSuffix(last, ">")) &&
		strings.Count(last, "#") <= 2 {
		return true
	}
	return false
}

func needsLoginNudge(buf string) bool {
	low := strings.ToLower(stripBasicANSI(buf))
	// Only the *tail* matters so we do not re-nudge forever after the prompt is up.
	if len(low) > 400 {
		low = low[len(low)-400:]
	}
	return strings.Contains(low, "press any key") || strings.Contains(low, "press enter") ||
		strings.Contains(low, "you have 10 seconds")
}

// EnsureSharedSSHTerm creates or reuses the shared interactive SSH PTY.
func EnsureSharedSSHTerm(ctx context.Context, cols, rows int) (*SSHTermSession, error) {
	if cols <= 0 {
		cols = 80
	}
	if rows <= 0 {
		rows = 24
	}
	if !sshConfigured() {
		return nil, fmt.Errorf("SSH not configured: open Settings (top-left) and add host/user/password or key")
	}

	sharedSSHEnsureMu.Lock()
	defer sharedSSHEnsureMu.Unlock()

	sharedSSH.mu.Lock()
	if sharedSSH.sess != nil && sharedSSH.state == "connected" {
		sess := sharedSSH.sess
		if cols != sharedSSH.cols || rows != sharedSSH.rows {
			sharedSSH.cols, sharedSSH.rows = cols, rows
			_ = sess.Resize(cols, rows)
		}
		sharedSSH.mu.Unlock()
		return sess, nil
	}
	old := sharedSSH.sess
	if sharedSSH.pumpCancel != nil {
		sharedSSH.pumpCancel()
		sharedSSH.pumpCancel = nil
	}
	sharedSSH.sess = nil
	sharedSSH.state = "connecting"
	sharedSSH.errMsg = ""
	sharedSSH.cols, sharedSSH.rows = cols, rows
	sharedSSH.mu.Unlock()
	if old != nil {
		_ = old.Close()
	}

	sess, err := OpenSSHTerm(ctx, cols, rows)
	if err != nil {
		sharedSSH.mu.Lock()
		sharedSSH.state = "failed"
		sharedSSH.errMsg = err.Error()
		sharedSSH.mu.Unlock()
		return nil, err
	}

	pctx, cancel := context.WithCancel(context.Background())
	sharedSSH.mu.Lock()
	sharedSSH.sess = sess
	sharedSSH.host = sess.Host()
	sharedSSH.state = "connected"
	sharedSSH.errMsg = ""
	sharedSSH.wantLive = true
	sharedSSH.reconnecting = false
	sharedSSH.autoRetryCount = 0
	sharedSSH.pumpCancel = cancel
	sharedSSH.pumpGen++
	gen := sharedSSH.pumpGen
	sharedSSH.mu.Unlock()

	go sharedSSH.pump(pctx, sess, gen)
	go sharedSSH.keepalive(pctx, sess, gen)

	sharedSSH.fanout(fmt.Sprintf("\r\n\x1b[90m[goar] shared SSH PTY %s (agent + terminal)\x1b[0m\r\n", sess.Host()))
	if err := waitSharedShellReady(ctx, 55*time.Second); err != nil {
		sharedSSH.fanout(fmt.Sprintf("\r\n\x1b[90m[goar] shell ready wait: %v (continuing)\x1b[0m\r\n", err))
	}
	return sess, nil
}

// waitSharedShellReady nudges segfault login gates and waits for a prompt.
func waitSharedShellReady(ctx context.Context, maxWait time.Duration) error {
	if maxWait <= 0 {
		maxWait = 55 * time.Second
	}
	var buf strings.Builder
	done := make(chan struct{})
	var once sync.Once
	unreg := OnSharedSSHData(func(data string) {
		buf.WriteString(data)
		if shellLooksReady(buf.String()) {
			once.Do(func() { close(done) })
		}
	})
	defer unreg()

	deadline := time.Now().Add(maxWait)
	var lastNudge time.Time
	for {
		select {
		case <-ctx.Done():
			return ctx.Err()
		case <-done:
			return nil
		default:
		}
		if time.Now().After(deadline) {
			if shellLooksReady(buf.String()) {
				return nil
			}
			return fmt.Errorf("timed out waiting for shell prompt")
		}
		cur := buf.String()
		if shellLooksReady(cur) {
			return nil
		}
		if needsLoginNudge(cur) && time.Since(lastNudge) > 2*time.Second {
			_, _ = SharedSSHWrite([]byte("\n"))
			lastNudge = time.Now()
		}
		time.Sleep(250 * time.Millisecond)
	}
}

// SharedSSHWrite sends bytes to the shared PTY stdin (human typing or agent).
func SharedSSHWrite(p []byte) (int, error) {
	sharedSSH.mu.Lock()
	sess := sharedSSH.sess
	st := sharedSSH.state
	sharedSSH.mu.Unlock()
	if sess == nil || st != "connected" {
		return 0, io.ErrClosedPipe
	}
	return sess.Write(p)
}

// SharedSSHResize updates the remote window size.
func SharedSSHResize(cols, rows int) error {
	sharedSSH.mu.Lock()
	sess := sharedSSH.sess
	if sess != nil {
		sharedSSH.cols, sharedSSH.rows = cols, rows
	}
	sharedSSH.mu.Unlock()
	if sess == nil {
		return io.ErrClosedPipe
	}
	return sess.Resize(cols, rows)
}

// CloseSharedSSH tears down the shared PTY (explicit disconnect).
func CloseSharedSSH() error {
	sharedSSH.mu.Lock()
	sess := sharedSSH.sess
	cancel := sharedSSH.pumpCancel
	sharedSSH.sess = nil
	sharedSSH.pumpCancel = nil
	sharedSSH.state = "closed"
	sharedSSH.host = ""
	sharedSSH.wantLive = false
	sharedSSH.reconnecting = false
	sharedSSH.autoRetryCount = 0
	sharedSSH.pumpGen++
	sharedSSH.reconnectGen++ // cancel in-flight auto-reconnect
	sharedSSH.mu.Unlock()
	if cancel != nil {
		cancel()
	}
	if sess != nil {
		return sess.Close()
	}
	return nil
}

func (g *sharedSSHGateway) fanout(data string) {
	if data == "" {
		return
	}
	g.mu.Lock()
	listeners := make([]func(string), 0, len(g.listeners))
	for _, fn := range g.listeners {
		listeners = append(listeners, fn)
	}
	cap := g.capture
	g.mu.Unlock()

	for _, fn := range listeners {
		fn(data)
	}
	if cap != nil {
		cap.buf.WriteString(data)
		// Require marker + exit code digits so we do not complete on the
		// interactive shell's echo of the typed "echo MARKER $?" line.
		if ptyMarkerComplete(cap.buf.String(), cap.marker) {
			cap.once.Do(func() { close(cap.done) })
		}
	}
}

func (g *sharedSSHGateway) pump(ctx context.Context, sess *SSHTermSession, gen uint64) {
	unexpected := false
	defer func() {
		g.mu.Lock()
		schedule := false
		if g.pumpGen == gen {
			g.sess = nil
			g.host = ""
			g.pumpCancel = nil
			if unexpected && g.wantLive {
				g.state = "reconnecting"
				schedule = true
			} else if g.state != "reconnecting" {
				g.state = "closed"
			}
		}
		cols, rows := g.cols, g.rows
		want := g.wantLive
		g.mu.Unlock()
		_ = sess.Close()
		if schedule && want {
			go g.autoReconnect(cols, rows)
		}
	}()
	buf := make([]byte, 4096)
	for {
		select {
		case <-ctx.Done():
			return
		default:
		}
		n, err := sess.Stdout().Read(buf)
		if n > 0 {
			g.fanout(string(buf[:n]))
		}
		if err != nil {
			if err != io.EOF {
				g.fanout(fmt.Sprintf("\r\n\x1b[90m[goar] shared ssh read: %v\x1b[0m\r\n", err))
			}
			// ctx cancel = intentional close; otherwise transport drop.
			select {
			case <-ctx.Done():
				unexpected = false
			default:
				unexpected = true
			}
			return
		}
	}
}

func (g *sharedSSHGateway) keepalive(ctx context.Context, sess *SSHTermSession, gen uint64) {
	ticker := time.NewTicker(20 * time.Second)
	defer ticker.Stop()
	for {
		select {
		case <-ctx.Done():
			return
		case <-ticker.C:
			g.mu.Lock()
			alive := g.pumpGen == gen && g.sess == sess && g.state == "connected"
			g.mu.Unlock()
			if !alive {
				return
			}
			_ = sess.KeepAlive()
		}
	}
}

// RunCommandOnSharedPTY writes a command to the shared interactive PTY, waits
// for a completion marker, and returns captured output. Output is also fanned
// out to UI listeners so the human terminal shows agent work.
func RunCommandOnSharedPTY(ctx context.Context, command string, timeoutSec int) (stdout string, exitCode int, err error) {
	command = strings.TrimSpace(command)
	if command == "" {
		return "", -1, fmt.Errorf("empty command")
	}
	if timeoutSec <= 0 {
		timeoutSec = 120
	}

	sharedSSHCmdMu.Lock()
	defer sharedSSHCmdMu.Unlock()

	if _, err := EnsureSharedSSHTerm(ctx, 80, 24); err != nil {
		return "", -1, err
	}

	marker := fmt.Sprintf("__GOAR_PTY_%d__", time.Now().UnixNano())
	cap := &ptyCapture{marker: marker, done: make(chan struct{})}

	sharedSSH.mu.Lock()
	sharedSSH.capture = cap
	sharedSSH.mu.Unlock()
	defer func() {
		sharedSSH.mu.Lock()
		if sharedSSH.capture == cap {
			sharedSSH.capture = nil
		}
		sharedSSH.mu.Unlock()
	}()

	// Ensure login MOTD/prompt settled (segfault free-tier wait).
	_ = waitSharedShellReady(ctx, 45*time.Second)

	// Clear line + stty -echo so the typed command (and marker) are not echoed
	// into the capture buffer — otherwise marker appears before the command runs.
	inner := command + "; printf '\\n" + marker + " %s\\n' \"$?\""
	wrapped := "\x15\nstty -echo 2>/dev/null\n" +
		"bash --noprofile --norc -c " + strconv.Quote(inner) + "\n" +
		"stty echo 2>/dev/null\n"

	if _, err := SharedSSHWrite([]byte(wrapped)); err != nil {
		return "", -1, fmt.Errorf("pty write: %w", err)
	}

	deadline := time.Now().Add(time.Duration(timeoutSec) * time.Second)
	if dl, ok := ctx.Deadline(); ok && dl.Before(deadline) {
		deadline = dl
	}
	timer := time.NewTimer(time.Until(deadline))
	defer timer.Stop()

	select {
	case <-cap.done:
	case <-ctx.Done():
		return stripPTYCapture(cap.buf.String(), marker), -1, ctx.Err()
	case <-timer.C:
		return stripPTYCapture(cap.buf.String(), marker), -1, fmt.Errorf("shared PTY command timed out after %ds", timeoutSec)
	}

	raw := cap.buf.String()
	out, code := parsePTYCapture(raw, marker)
	return out, code, nil
}

func ptyMarkerRE(marker string) *regexp.Regexp {
	return regexp.MustCompile(regexp.QuoteMeta(marker) + `\s+(\d+)`)
}

func ptyMarkerComplete(raw, marker string) bool {
	return ptyMarkerRE(marker).MatchString(raw)
}

func stripPTYCapture(raw, marker string) string {
	re := ptyMarkerRE(marker)
	loc := re.FindStringIndex(raw)
	if loc != nil {
		return strings.TrimSpace(raw[:loc[0]])
	}
	if idx := strings.Index(raw, marker); idx >= 0 {
		return strings.TrimSpace(raw[:idx])
	}
	return strings.TrimSpace(raw)
}

func parsePTYCapture(raw, marker string) (stdout string, exitCode int) {
	exitCode = 0
	re := ptyMarkerRE(marker)
	loc := re.FindStringSubmatchIndex(raw)
	before := raw
	if loc != nil {
		before = raw[:loc[0]]
		if n, err := strconv.Atoi(raw[loc[2]:loc[3]]); err == nil {
			exitCode = n
		}
	} else if idx := strings.Index(raw, marker); idx >= 0 {
		before = raw[:idx]
	}
	stdout = strings.TrimRight(before, "\r\n")
	stdout = stripBasicANSI(stdout)
	// Drop the echoed typed command line (ends with our bash -c wrapper).
	stdout = stripEchoedPTYCommand(stdout)
	return stdout, exitCode
}

func stripEchoedPTYCommand(s string) string {
	lines := strings.Split(s, "\n")
	out := make([]string, 0, len(lines))
	for _, line := range lines {
		trim := strings.TrimSpace(strings.ReplaceAll(line, "\r", ""))
		trim = stripBasicANSI(trim)
		if trim == "^C" || trim == "" {
			continue
		}
		if strings.Contains(trim, "/bin/bash --noprofile --norc -c") {
			continue
		}
		out = append(out, strings.TrimRight(line, "\r"))
	}
	return strings.TrimSpace(strings.Join(out, "\n"))
}

var ansiRE = regexp.MustCompile(`\x1b\[[0-9;?]*[A-Za-z]|\x1b\][^\x07]*\x07|\r`)

func stripBasicANSI(s string) string {
	return strings.TrimSpace(ansiRE.ReplaceAllString(s, ""))
}



// ReconnectSharedSSH forces a clean recreate of the shared PTY gateway
// (Wisp dial + SSH handshake). Safe to call from UI visibility/wake.
func ReconnectSharedSSH(ctx context.Context, cols, rows int) (*SSHTermSession, error) {
	if cols <= 0 {
		cols = 80
	}
	if rows <= 0 {
		rows = 24
	}
	sharedSSH.mu.Lock()
	sharedSSH.wantLive = true
	sharedSSH.autoRetryCount = 0
	old := sharedSSH.sess
	cancel := sharedSSH.pumpCancel
	sharedSSH.sess = nil
	sharedSSH.pumpCancel = nil
	sharedSSH.state = "reconnecting"
	sharedSSH.errMsg = ""
	sharedSSH.pumpGen++
	sharedSSH.reconnectGen++
	sharedSSH.cols, sharedSSH.rows = cols, rows
	sharedSSH.mu.Unlock()
	if cancel != nil {
		cancel()
	}
	if old != nil {
		_ = old.Close()
	}
	sharedSSH.fanout("\r\n\x1b[90m[goar] reconnecting shared SSH PTY…\x1b[0m\r\n")
	return EnsureSharedSSHTerm(ctx, cols, rows)
}

// SharedSSHWantLive reports whether the gateway should auto-heal after drops.
func SharedSSHWantLive() bool {
	sharedSSH.mu.Lock()
	defer sharedSSH.mu.Unlock()
	return sharedSSH.wantLive
}

func (g *sharedSSHGateway) autoReconnect(cols, rows int) {
	g.mu.Lock()
	if !g.wantLive || g.reconnecting {
		g.mu.Unlock()
		return
	}
	if g.maxAutoRetry <= 0 {
		g.maxAutoRetry = 8
	}
	if g.autoRetryCount >= g.maxAutoRetry {
		g.state = "failed"
		g.errMsg = "shared SSH auto-reconnect exhausted"
		g.mu.Unlock()
		g.fanout("\r\n\x1b[91m[goar] shared SSH reconnect gave up — use Reconnect in terminal\x1b[0m\r\n")
		return
	}
	g.reconnecting = true
	g.autoRetryCount++
	attempt := g.autoRetryCount
	g.reconnectGen++
	gen := g.reconnectGen
	g.state = "reconnecting"
	g.mu.Unlock()

	// Exponential backoff: 0.5s, 1s, 2s, … cap 16s
	shift := attempt - 1
	if shift > 5 {
		shift = 5
	}
	backoff := time.Duration(1<<uint(shift)) * 500 * time.Millisecond
	if backoff > 16*time.Second {
		backoff = 16 * time.Second
	}
	g.fanout(fmt.Sprintf("\r\n\x1b[90m[goar] transport drop — reconnect attempt %d in %s…\x1b[0m\r\n", attempt, backoff))
	timer := time.NewTimer(backoff)
	defer timer.Stop()
	<-timer.C

	g.mu.Lock()
	still := g.wantLive && g.reconnectGen == gen
	g.reconnecting = false
	g.mu.Unlock()
	if !still {
		return
	}

	ctx, cancel := context.WithTimeout(context.Background(), 60*time.Second)
	defer cancel()
	_, err := EnsureSharedSSHTerm(ctx, cols, rows)
	if err != nil {
		g.mu.Lock()
		g.errMsg = err.Error()
		want := g.wantLive
		g.mu.Unlock()
		g.fanout(fmt.Sprintf("\r\n\x1b[91m[goar] shared SSH reconnect failed: %v\x1b[0m\r\n", err))
		if want {
			go g.autoReconnect(cols, rows)
		}
		return
	}
	g.fanout("\r\n\x1b[90m[goar] shared SSH reconnected\x1b[0m\r\n")
}


// RunBashForAPI exposes the WASM bash tool path (shared PTY, ssh_exec fallback)
// for the JS bridge — same execution path agent bash uses under GOOS=js.
func RunBashForAPI(ctx context.Context, command string, timeoutSec int) (any, error) {
	return runCommandViaSharedPTY(ctx, command, timeoutSec)
}

// runCommandViaSharedPTY is the bash WASM path: shared PTY first, ssh_exec fallback.
func runCommandViaSharedPTY(ctx context.Context, command string, timeoutSec int) (any, error) {
	out, code, err := RunCommandOnSharedPTY(ctx, command, timeoutSec)
	if err != nil {
		if isSharedPTYUnavailable(err) {
			res, ferr := runCommandViaSSHExec(ctx, command, timeoutSec)
			if ferr != nil {
				return nil, tools.NewToolError("shared PTY unavailable (%v); ssh_exec fallback also failed: %v", err, ferr)
			}
			if m, ok := res.(map[string]any); ok {
				m["runtime"] = "ssh_exec_fallback"
				m["pty_error"] = err.Error()
			}
			return res, nil
		}
		if out != "" {
			return nil, tools.NewToolError("shared PTY: %v\nStdout: %s", err, out)
		}
		return nil, tools.NewToolError("shared PTY: %v", err)
	}
	if code != 0 {
		// 130 = 128+SIGINT; can still appear if human Ctrl-C raced us — accept when we
		// clearly captured command output via the completion marker path.
		if !(code == 130 && strings.TrimSpace(out) != "") {
			msg := "Command failed: " + command + "\nReturn code: " + itoa(code)
			if out != "" {
				msg += "\nStdout: " + out
			}
			return nil, tools.NewToolError("%s", msg)
		}
	}
	return map[string]any{
		"command":    command,
		"stdout":     out,
		"stderr":     "",
		"returncode": code,
		"runtime":    "ssh_shared_pty",
		"host":       SharedSSHHost(),
	}, nil
}

func isSharedPTYUnavailable(err error) bool {
	if err == nil {
		return false
	}
	msg := strings.ToLower(err.Error())
	if strings.Contains(msg, "ssh not configured") {
		return false
	}
	for _, p := range []string{
		"dial ", "ssh handshake", "ssh session", "request pty", "shell:",
		"browsernet", "closed pipe", "connection refused", "i/o timeout",
		"pty write",
	} {
		if strings.Contains(msg, p) {
			return true
		}
	}
	return false
}
