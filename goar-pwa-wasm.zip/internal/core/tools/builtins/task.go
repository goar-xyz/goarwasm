package builtins

import (
	"context"
	"fmt"
	"strings"

	"github.com/goarxyz/goar/internal/core/tools"
	"github.com/goarxyz/goar/internal/core/types"
)

type taskTool struct{}

// NewTask constructs the task (sub-agent) builtin.
func NewTask() tools.Tool { return &taskTool{} }

func (t *taskTool) Name() string { return "task" }
func (t *taskTool) Description() string {
	return "Spawn a sub-agent task with a focused prompt and optional agent profile."
}
func (t *taskTool) Permission() tools.ToolPermission { return tools.PermissionAsk }
func (t *taskTool) Parameters() map[string]any {
	return map[string]any{
		"type": "object",
		"properties": map[string]any{
			"prompt":      map[string]any{"type": "string", "description": "Focused instruction for the sub-agent"},
			"agent":       map[string]any{"type": "string", "description": "Optional agent profile name (e.g. explore, strategist)"},
			"description": map[string]any{"type": "string", "description": "Short human label for the task"},
			"model":       map[string]any{"type": "string", "description": "Optional model override"},
		},
		"required": []string{"prompt"},
	}
}

func (t *taskTool) ResolvePermission(args map[string]any) *tools.PermissionContext {
	agent := tools.OptionalString(args, "agent", "")
	if agent == "" {
		return nil
	}
	// Spawning YOLO/auto-approve agents still asks once unless bypassed.
	if strings.Contains(strings.ToLower(agent), "auto") || strings.Contains(strings.ToLower(agent), "yolo") {
		return &tools.PermissionContext{
			Permission: tools.PermissionAsk,
			Reason:     "spawning auto-approve sub-agent requires confirmation",
		}
	}
	return nil
}

func (t *taskTool) Run(ctx context.Context, args map[string]any, inv *tools.InvokeContext) (any, error) {
	_ = ctx
	prompt := tools.OptionalString(args, "prompt", "")
	agent := tools.OptionalString(args, "agent", "")
	desc := tools.OptionalString(args, "description", "")
	model := tools.OptionalString(args, "model", "")
	if strings.TrimSpace(prompt) == "" {
		return nil, tools.NewToolError("prompt required")
	}
	if inv != nil && inv.SwitchAgent != nil && agent != "" {
		// Soft-switch is optional; task spawn itself does not require switching the parent.
		_ = inv.SwitchAgent
	}
	return map[string]any{
		"status":      "queued",
		"prompt":      prompt,
		"agent":       agent,
		"description": desc,
		"model":       model,
		"message":     "Sub-agent task recorded for orchestrator execution",
	}, nil
}

// TaskCallDisplay builds the tool-call UI summary.
func TaskCallDisplay(event types.ToolCallEvent) tools.ToolCallDisplay {
	args, _ := tools.ValidateArgsJSON(event.ArgsJSON)
	desc := tools.OptionalString(args, "description", "")
	agent := tools.OptionalString(args, "agent", "")
	summary := "task"
	if desc != "" {
		summary = "task: " + desc
	} else if agent != "" {
		summary = "task → " + agent
	}
	return tools.ToolCallDisplay{Summary: summary, Content: tools.OptionalString(args, "prompt", "")}
}

// TaskResultDisplay builds the tool-result UI summary.
func TaskResultDisplay(event types.ToolResultEvent) tools.ToolResultDisplay {
	if event.Error != "" {
		return tools.ToolResultDisplay{Success: false, Message: event.Error}
	}
	return tools.ToolResultDisplay{Success: true, Message: "Sub-agent task accepted"}
}

// TaskStatusText is the loading spinner text.
func TaskStatusText() string { return "Spawning sub-agent…" }

// FormatTaskSummary renders a one-line status for logs.
func FormatTaskSummary(prompt, agent, desc string) string {
	parts := []string{"task"}
	if desc != "" {
		parts = append(parts, desc)
	}
	if agent != "" {
		parts = append(parts, "agent="+agent)
	}
	if prompt != "" {
		p := prompt
		if len(p) > 60 {
			p = p[:60] + "…"
		}
		parts = append(parts, fmt.Sprintf("%q", p))
	}
	return strings.Join(parts, " ")
}
