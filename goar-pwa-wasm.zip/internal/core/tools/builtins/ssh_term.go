package builtins

import (
	"context"
	"fmt"
	"io"
	"net"
	"strconv"
	"sync"
	"time"

	"golang.org/x/crypto/ssh"
)

// SSHTermSession is an interactive SSH PTY session (browsernet Dial under WASM).
type SSHTermSession struct {
	client  *ssh.Client
	session *ssh.Session
	stdin   io.WriteCloser
	stdout  io.Reader // combined stdout/stderr
	cfg     sshConfig
	mu      sync.Mutex
	closed  bool
}

// IsSSHConfigured reports whether AGENT_SSH_* credentials are present.
func IsSSHConfigured() bool { return sshConfigured() }

// OpenSSHTerm dials SSH via dialSSHConn (browsernet under WASM), requests a PTY,
// and starts an interactive shell. Host keys use known_hosts TOFU (no InsecureIgnoreHostKey).
func OpenSSHTerm(ctx context.Context, cols, rows int) (*SSHTermSession, error) {
	if cols <= 0 {
		cols = 80
	}
	if rows <= 0 {
		rows = 24
	}
	cfg, err := resolveSSHConfig(map[string]any{})
	if err != nil {
		return nil, err
	}
	// Same process as modular connectOnce: try ports in order (443 then 22 for Kali).
	var rawConn net.Conn
	var addr string
	var dialErr error
	for _, port := range sshDialPorts(cfg) {
		addr = net.JoinHostPort(cfg.Host, strconv.Itoa(port))
		rawConn, dialErr = dialSSHConn(ctx, addr)
		if dialErr == nil {
			cfg.Port = port
			break
		}
	}
	if rawConn == nil {
		return nil, fmt.Errorf("dial %s ports %v: %w", cfg.Host, sshDialPorts(cfg), dialErr)
	}

	sshCfg, err := buildSSHClientConfig(cfg)
	if err != nil {
		_ = rawConn.Close()
		return nil, err
	}
	// Interactive sessions may outlive the short dial timeout.
	sshCfg.Timeout = 60 * time.Second

	clientConn, chans, reqs, err := ssh.NewClientConn(rawConn, addr, sshCfg)
	if err != nil {
		_ = rawConn.Close()
		return nil, fmt.Errorf("ssh handshake: %w", err)
	}
	client := ssh.NewClient(clientConn, chans, reqs)

	session, err := client.NewSession()
	if err != nil {
		_ = client.Close()
		return nil, fmt.Errorf("ssh session: %w", err)
	}
	if cfg.Secret != "" {
		_ = session.Setenv("SECRET", cfg.Secret)
	}
	modes := ssh.TerminalModes{
		ssh.ECHO:          1,
		ssh.TTY_OP_ISPEED: 14400,
		ssh.TTY_OP_OSPEED: 14400,
	}
	if err := session.RequestPty("xterm-256color", rows, cols, modes); err != nil {
		_ = session.Close()
		_ = client.Close()
		return nil, fmt.Errorf("request pty: %w", err)
	}
	stdin, err := session.StdinPipe()
	if err != nil {
		_ = session.Close()
		_ = client.Close()
		return nil, err
	}
	stdout, err := session.StdoutPipe()
	if err != nil {
		_ = session.Close()
		_ = client.Close()
		return nil, err
	}
	// PTY multiplexes remote stderr into the stdout stream.
	if err := session.Shell(); err != nil {
		_ = session.Close()
		_ = client.Close()
		return nil, fmt.Errorf("shell: %w", err)
	}
	return &SSHTermSession{
		client:  client,
		session: session,
		stdin:   stdin,
		stdout:  stdout,
		cfg:     cfg,
	}, nil
}

// Host returns user@host:port for status display.
func (s *SSHTermSession) Host() string {
	if s == nil {
		return ""
	}
	return fmt.Sprintf("%s@%s:%d", s.cfg.User, s.cfg.Host, s.cfg.Port)
}

// Stdout returns the remote output reader.
func (s *SSHTermSession) Stdout() io.Reader {
	if s == nil {
		return nil
	}
	return s.stdout
}

// Write sends bytes to the remote PTY stdin.
func (s *SSHTermSession) Write(p []byte) (int, error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	if s == nil || s.closed || s.stdin == nil {
		return 0, io.ErrClosedPipe
	}
	return s.stdin.Write(p)
}

// Resize sends an SSH window-change request.
func (s *SSHTermSession) Resize(cols, rows int) error {
	s.mu.Lock()
	defer s.mu.Unlock()
	if s == nil || s.closed || s.session == nil {
		return io.ErrClosedPipe
	}
	if cols <= 0 {
		cols = 80
	}
	if rows <= 0 {
		rows = 24
	}
	return s.session.WindowChange(rows, cols)
}

// Wait blocks until the remote shell exits.
func (s *SSHTermSession) Wait() error {
	if s == nil || s.session == nil {
		return nil
	}
	return s.session.Wait()
}

// KeepAlive sends an SSH keepalive request (non-fatal if unsupported).
func (s *SSHTermSession) KeepAlive() error {
	s.mu.Lock()
	defer s.mu.Unlock()
	if s == nil || s.closed || s.client == nil {
		return io.ErrClosedPipe
	}
	_, _, err := s.client.SendRequest("keepalive@openssh.com", true, nil)
	return err
}

// Close tears down the session and client.
func (s *SSHTermSession) Close() error {
	s.mu.Lock()
	defer s.mu.Unlock()
	if s == nil || s.closed {
		return nil
	}
	s.closed = true
	if s.stdin != nil {
		_ = s.stdin.Close()
	}
	if s.session != nil {
		_ = s.session.Close()
	}
	if s.client != nil {
		return s.client.Close()
	}
	return nil
}
