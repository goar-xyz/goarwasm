//go:build js && wasm

package builtins

import (
	"context"
	"fmt"
	"net"

	"github.com/goarxyz/goar/browsernet"
)

// dialSSHConn dials TCP through browsernet (set by SDN.Install → browsernet.Dial).
func dialSSHConn(ctx context.Context, addr string) (net.Conn, error) {
	if browsernet.Dial == nil {
		return nil, fmt.Errorf("browsernet not installed; call goar.configure({proxyURL}) first")
	}
	return browsernet.DialContext(ctx, "tcp", addr)
}
