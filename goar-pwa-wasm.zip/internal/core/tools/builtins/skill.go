package builtins

import (
	"context"
	"fmt"
	"os"
	"path/filepath"
	"strings"

	"github.com/goarxyz/goar/internal/core/skills"
	"github.com/goarxyz/goar/internal/core/tools"
)

const maxListedSkillFiles = 10

type skillTool struct{}

// NewSkill constructs the skill builtin tool (Python Skill).
func NewSkill() tools.Tool { return &skillTool{} }

func (t *skillTool) Name() string { return "skill" }

func (t *skillTool) Description() string {
	return "Load a specialized skill that provides domain-specific instructions and workflows. " +
		"When you recognize that a task matches one of the available skills listed in your system prompt, " +
		"use this tool to load the full skill instructions. " +
		"The skill will inject detailed instructions, workflows, and access to bundled resources " +
		"(scripts, references, templates) into the conversation context."
}

func (t *skillTool) Permission() tools.ToolPermission { return tools.PermissionAlways }

func (t *skillTool) Parameters() map[string]any {
	return map[string]any{
		"type": "object",
		"properties": map[string]any{
			"name": map[string]any{
				"type":        "string",
				"description": "The name of the skill to load from available_skills",
			},
		},
		"required": []string{"name"},
	}
}

func (t *skillTool) ResolvePermission(args map[string]any) *tools.PermissionContext {
	_ = args
	return &tools.PermissionContext{Permission: tools.PermissionAlways}
}

func (t *skillTool) Run(ctx context.Context, args map[string]any, inv *tools.InvokeContext) (any, error) {
	_ = ctx
	name := tools.OptionalString(args, "name", "")
	if strings.TrimSpace(name) == "" {
		return nil, tools.NewToolError("name required")
	}
	if inv == nil || inv.SkillManager == nil {
		return nil, tools.NewToolError("Skill manager not available")
	}

	skillInfo, available, err := lookupSkill(inv.SkillManager, name)
	if err != nil {
		return nil, err
	}
	if skillInfo == nil {
		avail := strings.Join(available, ", ")
		if avail == "" {
			avail = "none"
		}
		return nil, tools.NewToolError("Skill %q not found. Available skills: %s", name, avail)
	}

	skillDir := ""
	if skillInfo.Path != "" {
		skillDir = filepath.Dir(skillInfo.Path)
	}

	files := listSkillFiles(skillDir)
	fileLines := make([]string, 0, len(files))
	for _, f := range files {
		fileLines = append(fileLines, "<file>"+f+"</file>")
	}

	baseDirLines := []string{}
	if skillDir != "" {
		baseDirLines = []string{
			fmt.Sprintf("Base directory for this skill: %s", skillDir),
			"Relative paths in this skill are relative to this base directory.",
		}
	}

	prompt := strings.TrimSpace(skillInfo.Content)
	parts := []string{
		fmt.Sprintf(`<skill_content name="%s">`, name),
		fmt.Sprintf("# Skill: %s", name),
		"",
		prompt,
		"",
	}
	parts = append(parts, baseDirLines...)
	parts = append(parts,
		"Note: file list is sampled.",
		"",
		"<skill_files>",
		strings.Join(fileLines, "\n"),
		"</skill_files>",
		"</skill_content>",
	)
	output := strings.Join(parts, "\n")

	var resolvedDir any
	if skillDir != "" {
		resolvedDir = skillDir
	}
	return map[string]any{
		"name":      name,
		"content":   output,
		"skill_dir": resolvedDir,
	}, nil
}

func lookupSkill(sm any, name string) (*skills.Skill, []string, error) {
	switch m := sm.(type) {
	case *skills.Manager:
		s, ok := m.Get(name)
		avail := make([]string, 0)
		for _, sk := range m.List() {
			avail = append(avail, sk.Name)
		}
		if !ok {
			return nil, avail, nil
		}
		return &s, avail, nil
	case interface {
		Get(string) (skills.Skill, bool)
		List() []skills.Skill
	}:
		s, ok := m.Get(name)
		avail := make([]string, 0)
		for _, sk := range m.List() {
			avail = append(avail, sk.Name)
		}
		if !ok {
			return nil, avail, nil
		}
		return &s, avail, nil
	default:
		return nil, nil, tools.NewToolError("unsupported skill manager type")
	}
}

func listSkillFiles(skillDir string) []string {
	if skillDir == "" {
		return nil
	}
	var files []string
	_ = filepath.WalkDir(skillDir, func(path string, d os.DirEntry, err error) error {
		if err != nil || d.IsDir() {
			return nil
		}
		if d.Name() == "SKILL.md" {
			return nil
		}
		rel, rerr := filepath.Rel(skillDir, path)
		if rerr != nil {
			return nil
		}
		files = append(files, filepath.ToSlash(rel))
		if len(files) >= maxListedSkillFiles {
			return filepath.SkipAll
		}
		return nil
	})
	return files
}

// SkillCallDisplay builds the call UI label.
func SkillCallDisplay(args map[string]any) tools.ToolCallDisplay {
	name := tools.OptionalString(args, "name", "")
	return tools.ToolCallDisplay{Summary: "Loading skill: " + name}
}

// SkillStatusText is the spinner text.
func SkillStatusText() string { return "Loading skill" }

// SkillResultDisplay summarizes load result from a ToolResultEvent-like map or result.
func SkillResultDisplay(result any) tools.ToolResultDisplay {
	switch r := result.(type) {
	case map[string]any:
		if errMsg, ok := r["error"].(string); ok && errMsg != "" {
			return tools.ToolResultDisplay{Success: false, Message: errMsg}
		}
		if name, ok := r["name"].(string); ok && name != "" {
			return tools.ToolResultDisplay{Success: true, Message: "Loaded skill: " + name}
		}
		return tools.ToolResultDisplay{Success: true, Message: "Skill loaded"}
	default:
		return tools.ToolResultDisplay{Success: true, Message: "Skill loaded"}
	}
}
