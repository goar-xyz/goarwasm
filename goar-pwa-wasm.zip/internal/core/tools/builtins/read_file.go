package builtins

import (
	"bufio"
	"context"
	"os"
	"strings"

	"github.com/goarxyz/goar/internal/core/tools"
	"github.com/goarxyz/goar/internal/core/utils"
)

type readFile struct{ maxBytes int }

func NewReadFile() tools.Tool { return &readFile{maxBytes: 64000} }
func (t *readFile) Name() string { return "read_file" }
func (t *readFile) Description() string {
	return "Read a text file (encoding detected safely), returning content from a specific line range. Reading is capped by a byte limit for safety. Under WASM this is browser MEMFS (AGENT_HOME), not the VPS — use bash on the shared SSH PTY for remote files."
}
func (t *readFile) Permission() tools.ToolPermission { return tools.PermissionAlways }
func (t *readFile) Parameters() map[string]any {
	return map[string]any{
		"type": "object",
		"properties": map[string]any{
			"path":   map[string]any{"type": "string"},
			"offset": map[string]any{"type": "integer", "description": "Line number to start reading from (0-indexed)."},
			"limit":  map[string]any{"type": "integer", "description": "Maximum number of lines to read."},
		},
		"required": []string{"path"},
	}
}

func (t *readFile) Run(ctx context.Context, args map[string]any, inv *tools.InvokeContext) (any, error) {
	_ = ctx; _ = inv
	path, _ := args["path"].(string)
	if strings.TrimSpace(path) == "" {
		return nil, tools.NewToolError("Path cannot be empty")
	}
	offset := asIntArg(args["offset"])
	var limit *int
	if v, ok := args["limit"]; ok && v != nil {
		n := asIntArg(v)
		limit = &n
	}
	if offset < 0 {
		return nil, tools.NewToolError("Offset cannot be negative")
	}
	if limit != nil && *limit <= 0 {
		return nil, tools.NewToolError("Limit, if provided, must be a positive number")
	}
	resolved, err := utils.ResolvePath(path)
	if err != nil {
		return nil, tools.NewToolError("Error resolving path: %v", err)
	}
	st, err := os.Stat(resolved)
	if err != nil {
		return nil, tools.NewToolError("File not found at: %s", path)
	}
	if st.IsDir() {
		return nil, tools.NewToolError("Path is a directory, not a file: %s", path)
	}
	f, err := os.Open(resolved)
	if err != nil {
		return nil, tools.NewToolError("Error reading %s: %v", path, err)
	}
	defer f.Close()
	sc := bufio.NewScanner(f)
	sc.Buffer(make([]byte, 0, 64*1024), 1024*1024)
	var lines []string
	bytesRead := 0
	lineIdx := 0
	hitLimit := false
	for sc.Scan() {
		line := sc.Text() + "\n"
		if lineIdx < offset {
			lineIdx++
			continue
		}
		if limit != nil && len(lines) >= *limit {
			hitLimit = true
			break
		}
		lb := len(line)
		if bytesRead+lb > t.maxBytes {
			hitLimit = true
			break
		}
		lines = append(lines, line)
		bytesRead += lb
		lineIdx++
	}
	if err := sc.Err(); err != nil {
		return nil, tools.NewToolError("Error reading %s: %v", path, err)
	}
	return map[string]any{
		"path": resolved, "content": strings.Join(lines, ""), "offset": offset,
		"lines_read": len(lines), "was_truncated": hitLimit,
	}, nil
}

func asIntArg(v any) int {
	switch t := v.(type) {
	case int:
		return t
	case int64:
		return int(t)
	case float64:
		return int(t)
	default:
		return 0
	}
}
