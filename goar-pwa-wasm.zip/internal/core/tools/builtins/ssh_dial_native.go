//go:build !(js && wasm)

package builtins

import (
	"context"
	"net"
	"time"
)

// dialSSHConn dials TCP with the process net stack (native CLI).
func dialSSHConn(ctx context.Context, addr string) (net.Conn, error) {
	d := net.Dialer{Timeout: 45 * time.Second}
	return d.DialContext(ctx, "tcp", addr)
}
