package builtins

import (
	"bytes"
	"context"
	"os"
	"os/exec"
	"path/filepath"
	"regexp"
	"runtime"
	"strconv"
	"strings"
	"time"

	"github.com/goarxyz/goar/internal/core/tools"
	"github.com/goarxyz/goar/internal/core/utils"
)

// GrepBackend is ripgrep or gnu grep.
type GrepBackend string

const (
	GrepBackendRipgrep GrepBackend = "ripgrep"
	GrepBackendGNU     GrepBackend = "gnu_grep"
)

type grepTool struct {
	maxOutput  int
	maxMatches int
	timeoutSec int
	excludes   []string
}

// NewGrep constructs the grep builtin tool.
func NewGrep() tools.Tool {
	return &grepTool{
		maxOutput: 64000, maxMatches: 100, timeoutSec: 60,
		excludes: []string{".git/", "node_modules/", ".venv/", "venv/", "__pycache__/", "dist/", "build/", ".tox/", "coverage/", ".mypy_cache/", ".pytest_cache/"},
	}
}

func (t *grepTool) Name() string { return "grep" }
func (t *grepTool) Description() string {
	return "Search file contents with ripgrep (preferred) or grep. Under WASM, uses an in-process MEMFS walker (no local rg/grep binary)."
}
func (t *grepTool) Permission() tools.ToolPermission { return tools.PermissionAlways }
func (t *grepTool) Parameters() map[string]any {
	return map[string]any{
		"type": "object",
		"properties": map[string]any{
			"pattern":            map[string]any{"type": "string", "description": "Regex/pattern to search for"},
			"path":               map[string]any{"type": "string", "default": ".", "description": "File or directory to search"},
			"glob":               map[string]any{"type": "string", "description": "Optional glob filter (ripgrep)"},
			"max_matches":        map[string]any{"type": "integer", "description": "Maximum matches to return"},
			"case_insensitive":   map[string]any{"type": "boolean"},
			"use_default_ignore": map[string]any{"type": "boolean", "default": true},
			"context_before":     map[string]any{"type": "integer"},
			"context_after":      map[string]any{"type": "integer"},
		},
		"required": []string{"pattern"},
	}
}

func (t *grepTool) ResolvePermission(args map[string]any) *tools.PermissionContext {
	path, _ := args["path"].(string)
	if path == "" {
		return nil
	}
	if !tools.IsPathWithinWorkdir(path) {
		return &tools.PermissionContext{
			Permission: tools.PermissionAsk,
			RequiredPermissions: []tools.RequiredPermission{{
				Scope: tools.ScopeOutsideDirectory, InvocationPattern: path, SessionPattern: path, Label: "grep outside workdir",
			}},
		}
	}
	return nil
}

func (t *grepTool) detectBackend() GrepBackend {
	if _, err := exec.LookPath("rg"); err == nil {
		return GrepBackendRipgrep
	}
	return GrepBackendGNU
}

func (t *grepTool) Run(ctx context.Context, args map[string]any, inv *tools.InvokeContext) (any, error) {
	_ = inv
	if err := t.validateArgs(args); err != nil {
		return nil, err
	}
	pattern, _ := args["pattern"].(string)
	path := tools.OptionalString(args, "path", ".")
	maxMatches := t.maxMatches
	if v, ok := args["max_matches"]; ok && v != nil {
		maxMatches = tools.OptionalInt(args, "max_matches", t.maxMatches)
	}
	resolved, err := utils.ResolvePath(path)
	if err != nil {
		return nil, tools.NewToolError("%v", err)
	}
	// WASM: no local rg/grep — walk MEMFS / AGENT_HOME with regexp.
	if runtime.GOOS == "js" {
		result, err := t.searchInProcess(ctx, pattern, resolved, args, maxMatches)
		if err != nil {
			return nil, err
		}
		result["pattern"] = pattern
		result["path"] = resolved
		result["backend"] = "memfs"
		return result, nil
	}
	backend := t.detectBackend()
	cmd := t.buildCommand(backend, pattern, resolved, args, maxMatches)
	out, err := t.executeSearch(ctx, cmd)
	if err != nil && out == "" {
		return nil, tools.NewToolError("grep failed: %v", err)
	}
	result := t.parseOutput(out, maxMatches)
	result["pattern"] = pattern
	result["path"] = resolved
	result["backend"] = string(backend)
	return result, nil
}

func (t *grepTool) validateArgs(args map[string]any) error {
	pattern, _ := args["pattern"].(string)
	if strings.TrimSpace(pattern) == "" {
		return tools.NewToolError("pattern is required")
	}
	if len(pattern) > 10000 {
		return tools.NewToolError("pattern too long")
	}
	return nil
}

func (t *grepTool) collectExcludePatterns() []string {
	out := append([]string{}, t.excludes...)
	out = append(out, t.loadCodeignorePatterns(".codeignore")...)
	out = append(out, t.loadCodeignorePatterns(".gitignore")...)
	return out
}

func (t *grepTool) loadCodeignorePatterns(name string) []string {
	b, err := os.ReadFile(name)
	if err != nil {
		return nil
	}
	var out []string
	for _, line := range strings.Split(string(b), "\n") {
		line = strings.TrimSpace(line)
		if line == "" || strings.HasPrefix(line, "#") || strings.HasPrefix(line, "!") {
			continue
		}
		out = append(out, line)
	}
	return out
}

func (t *grepTool) buildCommand(backend GrepBackend, pattern, path string, args map[string]any, maxMatches int) *exec.Cmd {
	if backend == GrepBackendRipgrep {
		return t.buildRipgrepCommand(pattern, path, args, maxMatches)
	}
	return t.buildGNUGrepCommand(pattern, path, args, maxMatches)
}

func (t *grepTool) buildRipgrepCommand(pattern, path string, args map[string]any, maxMatches int) *exec.Cmd {
	rgArgs := []string{"--line-number", "--no-heading", "--color", "never", "-m", strconv.Itoa(maxMatches)}
	if tools.OptionalBool(args, "case_insensitive", false) {
		rgArgs = append(rgArgs, "-i")
	}
	if glob := tools.OptionalString(args, "glob", ""); glob != "" {
		rgArgs = append(rgArgs, "--glob", glob)
	}
	if before := tools.OptionalInt(args, "context_before", 0); before > 0 {
		rgArgs = append(rgArgs, "-B", strconv.Itoa(before))
	}
	if after := tools.OptionalInt(args, "context_after", 0); after > 0 {
		rgArgs = append(rgArgs, "-A", strconv.Itoa(after))
	}
	useIgnore := true
	if v, ok := args["use_default_ignore"].(bool); ok {
		useIgnore = v
	}
	if useIgnore {
		for _, ex := range t.collectExcludePatterns() {
			ex = strings.TrimSuffix(ex, "/")
			rgArgs = append(rgArgs, "--glob", "!"+ex)
		}
	}
	rgArgs = append(rgArgs, "--", pattern, path)
	return exec.Command("rg", rgArgs...)
}

func (t *grepTool) buildGNUGrepCommand(pattern, path string, args map[string]any, maxMatches int) *exec.Cmd {
	gArgs := []string{"-RIn", "--exclude-dir=.git", "--exclude-dir=node_modules", "--exclude-dir=.venv", "--exclude-dir=venv"}
	if tools.OptionalBool(args, "case_insensitive", false) {
		gArgs = append(gArgs, "-i")
	}
	if before := tools.OptionalInt(args, "context_before", 0); before > 0 {
		gArgs = append(gArgs, "-B", strconv.Itoa(before))
	}
	if after := tools.OptionalInt(args, "context_after", 0); after > 0 {
		gArgs = append(gArgs, "-A", strconv.Itoa(after))
	}
	_ = maxMatches
	gArgs = append(gArgs, "--", pattern, path)
	return exec.Command("grep", gArgs...)
}

func (t *grepTool) executeSearch(ctx context.Context, cmd *exec.Cmd) (string, error) {
	cctx, cancel := context.WithTimeout(ctx, time.Duration(t.timeoutSec)*time.Second)
	defer cancel()
	cmd = exec.CommandContext(cctx, cmd.Path, cmd.Args[1:]...)
	var stdout, stderr bytes.Buffer
	cmd.Stdout = &stdout
	cmd.Stderr = &stderr
	err := cmd.Run()
	out := stdout.String()
	if len(out) > t.maxOutput {
		out = out[:t.maxOutput]
	}
	// grep/rg exit 1 means no matches — not a failure.
	if err != nil {
		if ee, ok := err.(*exec.ExitError); ok && ee.ExitCode() == 1 {
			return out, nil
		}
		if cctx.Err() != nil {
			return out, tools.NewToolError("grep timed out after %ds", t.timeoutSec)
		}
		if out == "" && stderr.Len() > 0 {
			return out, tools.NewToolError("%s", strings.TrimSpace(stderr.String()))
		}
	}
	return out, nil
}

func (t *grepTool) parseOutput(stdout string, maxMatches int) map[string]any {
	matches := []map[string]any{}
	for _, line := range strings.Split(stdout, "\n") {
		line = strings.TrimRight(line, "\r")
		if line == "" {
			continue
		}
		m := parseGrepMatchLine(line)
		if m == nil {
			continue
		}
		matches = append(matches, m)
		if len(matches) >= maxMatches {
			break
		}
	}
	return map[string]any{"matches": matches, "count": len(matches), "truncated": len(matches) >= maxMatches}
}

func parseGrepMatchLine(raw string) map[string]any {
	// path:line:text  or path:text
	parts := strings.SplitN(raw, ":", 3)
	if len(parts) < 2 {
		return nil
	}
	m := map[string]any{"path": parts[0]}
	if len(parts) >= 3 {
		if n, err := strconv.Atoi(parts[1]); err == nil {
			m["line"] = n
			m["text"] = parts[2]
			return m
		}
		m["text"] = strings.Join(parts[1:], ":")
		return m
	}
	m["text"] = parts[1]
	return m
}

// FormatGrepCallDisplay builds a short UI label for a grep invocation.
func FormatGrepCallDisplay(args map[string]any) string {
	pattern := tools.OptionalString(args, "pattern", "")
	path := tools.OptionalString(args, "path", ".")
	return "grep " + strconv.Quote(pattern) + " in " + path
}

// GrepStatusText is the spinner status while grep runs.
func GrepStatusText() string { return "Searching files…" }

// GrepResultDisplay summarizes matches for the tool result widget.
func GrepResultDisplay(result map[string]any) string {
	count, _ := result["count"].(int)
	if count == 0 {
		return "No matches"
	}
	path, _ := result["path"].(string)
	if path == "" {
		path = "."
	}
	base := filepath.Base(path)
	return strconv.Itoa(count) + " matches in " + base
}

// searchInProcess walks the filesystem and matches with Go regexp (WASM MEMFS).
func (t *grepTool) searchInProcess(ctx context.Context, pattern, root string, args map[string]any, maxMatches int) (map[string]any, error) {
	flags := ""
	if tools.OptionalBool(args, "case_insensitive", false) {
		flags = "(?i)"
	}
	re, err := regexp.Compile(flags + pattern)
	if err != nil {
		return nil, tools.NewToolError("invalid pattern: %v", err)
	}
	glob := tools.OptionalString(args, "glob", "")
	matches := []map[string]any{}
	err = filepath.WalkDir(root, func(path string, d os.DirEntry, walkErr error) error {
		if walkErr != nil {
			return nil
		}
		select {
		case <-ctx.Done():
			return ctx.Err()
		default:
		}
		if d.IsDir() {
			name := d.Name()
			for _, ex := range t.excludes {
				ex = strings.TrimSuffix(ex, "/")
				if name == ex || strings.HasSuffix(path, "/"+ex) {
					return filepath.SkipDir
				}
			}
			return nil
		}
		if glob != "" {
			base := filepath.Base(path)
			ok, _ := filepath.Match(glob, base)
			if !ok {
				return nil
			}
		}
		info, err := d.Info()
		if err != nil || info.Size() > 2<<20 {
			return nil
		}
		b, err := os.ReadFile(path)
		if err != nil {
			return nil
		}
		// skip likely binary
		if bytes.IndexByte(b, 0) >= 0 {
			return nil
		}
		for i, line := range strings.Split(string(b), "\n") {
			if re.MatchString(line) {
				matches = append(matches, map[string]any{"path": path, "line": i + 1, "text": line})
				if len(matches) >= maxMatches {
					return errGrepDone
				}
			}
		}
		return nil
	})
	if err != nil && err != errGrepDone && err != context.Canceled {
		return nil, tools.NewToolError("grep walk: %v", err)
	}
	return map[string]any{"matches": matches, "count": len(matches), "truncated": len(matches) >= maxMatches}, nil
}

var errGrepDone = filepath.SkipAll
