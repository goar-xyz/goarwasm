package builtins

import (
	"context"
	"io"
	"net/http"
	"regexp"
	"strings"
	"time"

	"github.com/goarxyz/goar/internal/core/tools"
)

type webFetch struct {
	defaultTimeout int
	maxTimeout     int
	maxBytes       int
	userAgent      string
}

func NewWebFetch() tools.Tool {
	return &webFetch{
		defaultTimeout: 30, maxTimeout: 120, maxBytes: 120000,
		userAgent: "Mozilla/5.0 (compatible; goar-cli)",
	}
}
func (t *webFetch) Name() string { return "webfetch" }
func (t *webFetch) Description() string {
	return "Fetch content from a URL. Converts HTML to markdown for readability."
}
func (t *webFetch) Permission() tools.ToolPermission { return tools.PermissionAsk }
func (t *webFetch) Parameters() map[string]any {
	return map[string]any{
		"type": "object",
		"properties": map[string]any{
			"url":     map[string]any{"type": "string", "description": "URL to fetch (http/https)"},
			"timeout": map[string]any{"type": "integer"},
		},
		"required": []string{"url"},
	}
}

var (
	scriptRE = regexp.MustCompile(`(?is)<script[^>]*>.*?</script>`)
	styleRE  = regexp.MustCompile(`(?is)<style[^>]*>.*?</style>`)
	tagRE    = regexp.MustCompile(`(?is)<[^>]+>`)
	wsRE     = regexp.MustCompile(`[ \t]+\n`)
)

func normalizeURL(u string) string {
	if strings.HasPrefix(u, "//") {
		u = u[2:]
	}
	if !strings.HasPrefix(u, "http://") && !strings.HasPrefix(u, "https://") {
		u = "https://" + u
	}
	return u
}

func htmlToMarkdown(html string) string {
	html = scriptRE.ReplaceAllString(html, "")
	html = styleRE.ReplaceAllString(html, "")
	html = regexp.MustCompile(`(?i)<br\s*/?>`).ReplaceAllString(html, "\n")
	html = regexp.MustCompile(`(?i)</p>`).ReplaceAllString(html, "\n\n")
	html = regexp.MustCompile(`(?i)</h[1-6]>`).ReplaceAllString(html, "\n\n")
	html = regexp.MustCompile(`(?i)<a[^>]+href=["']([^"']+)["'][^>]*>(.*?)</a>`).ReplaceAllString(html, "[$2]($1)")
	html = tagRE.ReplaceAllString(html, "")
	html = strings.ReplaceAll(html, "&nbsp;", " ")
	html = strings.ReplaceAll(html, "&amp;", "&")
	html = strings.ReplaceAll(html, "&lt;", "<")
	html = strings.ReplaceAll(html, "&gt;", ">")
	html = wsRE.ReplaceAllString(html, "\n")
	return strings.TrimSpace(html)
}

func (t *webFetch) Run(ctx context.Context, args map[string]any, inv *tools.InvokeContext) (any, error) {
	_ = inv
	rawURL, _ := args["url"].(string)
	timeout := t.defaultTimeout
	if v, ok := args["timeout"]; ok && v != nil {
		timeout = asIntArg(v)
		if timeout > t.maxTimeout {
			timeout = t.maxTimeout
		}
	}
	u := normalizeURL(rawURL)
	cctx, cancel := context.WithTimeout(ctx, time.Duration(timeout)*time.Second)
	defer cancel()
	req, err := http.NewRequestWithContext(cctx, http.MethodGet, u, nil)
	if err != nil {
		return nil, tools.NewToolError("%v", err)
	}
	req.Header.Set("User-Agent", t.userAgent)
	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		return nil, tools.NewToolError("%v", err)
	}
	defer resp.Body.Close()
	if resp.StatusCode >= 400 {
		return nil, tools.NewToolError("HTTP %d fetching %s", resp.StatusCode, u)
	}
	limited := io.LimitReader(resp.Body, int64(t.maxBytes)+1)
	body, err := io.ReadAll(limited)
	if err != nil {
		return nil, tools.NewToolError("%v", err)
	}
	truncated := len(body) > t.maxBytes
	if truncated {
		body = body[:t.maxBytes]
	}
	ct := resp.Header.Get("Content-Type")
	content := string(body)
	if strings.Contains(ct, "html") || strings.HasPrefix(strings.TrimSpace(content), "<!") || strings.Contains(strings.ToLower(content[:min(200, len(content))]), "<html") {
		content = htmlToMarkdown(content)
		ct = "text/markdown"
	}
	return map[string]any{"url": u, "content": content, "content_type": ct, "was_truncated": truncated}, nil
}

func min(a, b int) int {
	if a < b {
		return a
	}
	return b
}
