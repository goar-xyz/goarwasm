package builtins

import (
	"context"
	"fmt"
	"sync"

	"github.com/goarxyz/goar/internal/core/tools"
)

type todoItem struct {
	ID       string `json:"id"`
	Content  string `json:"content"`
	Status   string `json:"status"`
	Priority string `json:"priority"`
}

type todoTool struct {
	mu       sync.Mutex
	todos    []todoItem
	maxTodos int
}

func NewTodo() tools.Tool { return &todoTool{maxTodos: 100} }
func (t *todoTool) Name() string { return "todo" }
func (t *todoTool) Description() string {
	return "Manage todos. Use action='read' to view, action='write' with complete list to update."
}
func (t *todoTool) Permission() tools.ToolPermission { return tools.PermissionAlways }
func (t *todoTool) Parameters() map[string]any {
	return map[string]any{
		"type": "object",
		"properties": map[string]any{
			"action": map[string]any{"type": "string", "description": "Either 'read' or 'write'"},
			"todos": map[string]any{
				"type": "array",
				"items": map[string]any{
					"type": "object",
					"properties": map[string]any{
						"id": map[string]any{"type": "string"},
						"content": map[string]any{"type": "string"},
						"status": map[string]any{"type": "string"},
						"priority": map[string]any{"type": "string"},
					},
					"required": []string{"id", "content"},
				},
			},
		},
		"required": []string{"action"},
	}
}

func (t *todoTool) Run(ctx context.Context, args map[string]any, inv *tools.InvokeContext) (any, error) {
	_ = ctx; _ = inv
	action, _ := args["action"].(string)
	t.mu.Lock()
	defer t.mu.Unlock()
	switch action {
	case "read":
		return map[string]any{"message": fmt.Sprintf("%d todos", len(t.todos)), "todos": t.todos, "total_count": len(t.todos)}, nil
	case "write":
		raw, _ := args["todos"].([]any)
		items := make([]todoItem, 0, len(raw))
		for _, r := range raw {
			rm, _ := r.(map[string]any)
			it := todoItem{
				ID: fmt.Sprint(rm["id"]), Content: fmt.Sprint(rm["content"]),
				Status: strOr(rm["status"], "pending"), Priority: strOr(rm["priority"], "medium"),
			}
			items = append(items, it)
		}
		if len(items) > t.maxTodos {
			return nil, tools.NewToolError("too many todos (max %d)", t.maxTodos)
		}
		t.todos = items
		return map[string]any{"message": fmt.Sprintf("Wrote %d todos", len(items)), "todos": t.todos, "total_count": len(t.todos)}, nil
	default:
		return nil, tools.NewToolError("unknown action: %s", action)
	}
}

func strOr(v any, def string) string {
	if s, ok := v.(string); ok && s != "" {
		return s
	}
	return def
}
