package builtins

import (
	"context"
	"fmt"
	"strings"

	"github.com/goarxyz/goar/internal/core/agents"
	"github.com/goarxyz/goar/internal/core/tools"
)

// ExitPlanModeArgs is empty — plan mode exit takes no tool arguments.
type ExitPlanModeArgs struct{}

// ExitPlanModeResult is the tool outcome.
type ExitPlanModeResult struct {
	Switched bool   `json:"switched"`
	Message  string `json:"message"`
}

type exitPlanModeTool struct{}

// NewExitPlanMode constructs the exit_plan_mode builtin (Python ExitPlanMode).
func NewExitPlanMode() tools.Tool { return &exitPlanModeTool{} }

func (t *exitPlanModeTool) Name() string { return "exit_plan_mode" }

func (t *exitPlanModeTool) Description() string {
	return "Signal that your plan is complete and you are ready to start implementing. " +
		"This will ask the user to confirm switching from plan mode to accept-edits mode. " +
		"Only use this tool when you have finished writing your plan to the plan file " +
		"and are ready for user approval to begin implementation."
}

func (t *exitPlanModeTool) Permission() tools.ToolPermission { return tools.PermissionAlways }

func (t *exitPlanModeTool) Parameters() map[string]any {
	return map[string]any{
		"type":       "object",
		"properties": map[string]any{},
		"required":   []string{},
	}
}

func (t *exitPlanModeTool) Run(ctx context.Context, args map[string]any, inv *tools.InvokeContext) (any, error) {
	_ = ctx
	_ = args
	if inv == nil {
		return nil, tools.NewToolError("ExitPlanMode requires an agent manager context.")
	}

	activeName := ""
	if am, ok := inv.AgentManager.(interface{ ActiveProfile() agents.AgentProfile }); ok {
		activeName = am.ActiveProfile().Name
	}
	if activeName != "" && activeName != agents.AgentPlan {
		return nil, tools.NewToolError("ExitPlanMode can only be used in plan mode.")
	}

	planPath := ""
	if inv.PlanFilePath != "" {
		planPath = inv.PlanFilePath
	}

	question := "Plan is complete. Switch to accept-edits mode and start implementing?"
	options := []string{
		"Yes, and auto approve edits",
		"Yes, and request approval for edits",
		"No",
	}
	footer := ""
	if planPath != "" {
		footer = fmt.Sprintf("Plan: %s (Ctrl+G to edit)", planPath)
	}

	answer, cancelled, err := promptExitPlanChoice(inv, question, options, footer)
	if err != nil {
		return nil, err
	}
	if cancelled || answer == "" {
		return ExitPlanModeResult{Switched: false, Message: "User cancelled. Staying in plan mode."}, nil
	}

	lower := strings.ToLower(strings.TrimSpace(answer))
	switch {
	case lower == strings.ToLower(options[0]) || strings.HasPrefix(lower, "yes, and auto"):
		if err := switchAgent(inv, agents.AgentAcceptEdits); err != nil {
			return nil, err
		}
		return ExitPlanModeResult{
			Switched: true,
			Message:  "Switched to accept-edits mode. You can now start implementing the plan.",
		}, nil
	case lower == strings.ToLower(options[1]) || strings.HasPrefix(lower, "yes, and request"):
		if err := switchAgent(inv, agents.AgentDefault); err != nil {
			return nil, err
		}
		return ExitPlanModeResult{
			Switched: true,
			Message:  "Switched to default agent mode. Edits will require your approval.",
		}, nil
	case lower == "no" || lower == strings.ToLower(options[2]):
		return ExitPlanModeResult{
			Switched: false,
			Message:  "Staying in plan mode. Continue refining the plan.",
		}, nil
	default:
		return ExitPlanModeResult{
			Switched: false,
			Message:  fmt.Sprintf("Staying in plan mode. User feedback: %s", answer),
		}, nil
	}
}

func switchAgent(inv *tools.InvokeContext, name string) error {
	if inv.SwitchAgent != nil {
		return inv.SwitchAgent(name)
	}
	if am, ok := inv.AgentManager.(interface{ Switch(string) error }); ok {
		return am.Switch(name)
	}
	return tools.NewToolError("no agent switch callback available")
}

func promptExitPlanChoice(inv *tools.InvokeContext, question string, options []string, footer string) (answer string, cancelled bool, err error) {
	prompt := question
	if footer != "" {
		prompt = question + "\n" + footer
	}
	prompt += "\nOptions:\n"
	for i, o := range options {
		prompt += fmt.Sprintf("  %d) %s\n", i+1, o)
	}
	var line string
	if inv.UserInputCallback != nil {
		line, err = inv.UserInputCallback(prompt)
	} else if inv.UserInput != nil {
		line, err = inv.UserInput(prompt)
	} else if inv.Approval != nil {
		ok, aerr := inv.Approval(prompt)
		if aerr != nil {
			return "", true, aerr
		}
		if ok {
			return options[0], false, nil
		}
		return options[2], false, nil
	} else {
		return "", false, tools.NewToolError("ExitPlanMode requires an interactive UI.")
	}
	if err != nil {
		return "", true, nil
	}
	line = strings.TrimSpace(line)
	if line == "" {
		return "", true, nil
	}
	if n := asIntArg(line); n >= 1 && n <= len(options) {
		return options[n-1], false, nil
	}
	for _, o := range options {
		if strings.EqualFold(o, line) {
			return o, false, nil
		}
	}
	return line, false, nil
}

// ExitPlanModeCallDisplay builds the call UI label.
func ExitPlanModeCallDisplay(args map[string]any) tools.ToolCallDisplay {
	_ = args
	return tools.ToolCallDisplay{Summary: "Ready to exit plan mode"}
}

// ExitPlanModeStatusText is the spinner text.
func ExitPlanModeStatusText() string { return "Waiting for user confirmation" }

// ExitPlanModeResultDisplay summarizes the result.
func ExitPlanModeResultDisplay(result any) tools.ToolResultDisplay {
	switch r := result.(type) {
	case ExitPlanModeResult:
		return tools.ToolResultDisplay{Success: r.Switched, Message: r.Message}
	case map[string]any:
		switched, _ := r["switched"].(bool)
		msg, _ := r["message"].(string)
		if msg == "" {
			msg = "Plan mode exited"
		}
		return tools.ToolResultDisplay{Success: switched, Message: msg}
	default:
		return tools.ToolResultDisplay{Success: true, Message: "Plan mode exited"}
	}
}
