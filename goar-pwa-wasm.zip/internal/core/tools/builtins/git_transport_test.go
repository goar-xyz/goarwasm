package builtins

import "testing"

func TestRewriteSSHGitToHTTPS(t *testing.T) {
	u, ok := rewriteSSHGitToHTTPS("git@github.com:org/repo.git")
	if !ok || u != "https://github.com/org/repo.git" {
		t.Fatalf("got %v %v", u, ok)
	}
	u, ok = rewriteSSHGitToHTTPS("ssh://git@gitlab.com/org/repo")
	if !ok || u != "https://gitlab.com/org/repo.git" {
		t.Fatalf("got %v %v", u, ok)
	}
}
