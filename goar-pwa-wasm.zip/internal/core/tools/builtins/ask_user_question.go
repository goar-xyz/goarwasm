package builtins

import (
	"bufio"
	"context"
	"fmt"
	"os"
	"runtime"
	"strings"

	"github.com/goarxyz/goar/internal/core/tools"
)

type askUser struct{}

func NewAskUserQuestion() tools.Tool { return &askUser{} }
func (t *askUser) Name() string { return "ask_user_question" }
func (t *askUser) Description() string {
	return "Ask the user one or more questions and wait for their responses. Each question has 2-4 choices plus an automatic 'Other' option for free text."
}
func (t *askUser) Permission() tools.ToolPermission { return tools.PermissionAlways }
func (t *askUser) Parameters() map[string]any {
	return map[string]any{
		"type": "object",
		"properties": map[string]any{
			"questions": map[string]any{
				"type": "array",
				"items": map[string]any{
					"type": "object",
					"properties": map[string]any{
						"question": map[string]any{"type": "string"},
						"header": map[string]any{"type": "string"},
						"options": map[string]any{
							"type": "array",
							"items": map[string]any{
								"type": "object",
								"properties": map[string]any{
									"label": map[string]any{"type": "string"},
									"description": map[string]any{"type": "string"},
								},
								"required": []string{"label"},
							},
						},
						"multi_select": map[string]any{"type": "boolean"},
						"hide_other": map[string]any{"type": "boolean"},
					},
					"required": []string{"question", "options"},
				},
			},
			"footer_note": map[string]any{"type": "string"},
		},
		"required": []string{"questions"},
	}
}

func (t *askUser) Run(ctx context.Context, args map[string]any, inv *tools.InvokeContext) (any, error) {
	_ = ctx
	questions, _ := args["questions"].([]any)
	if len(questions) == 0 {
		return nil, tools.NewToolError("at least one question required")
	}
	reader := bufio.NewReader(os.Stdin)
	answers := []map[string]any{}
	for _, q := range questions {
		qm, _ := q.(map[string]any)
		question := fmt.Sprint(qm["question"])
		opts, _ := qm["options"].([]any)
		hideOther, _ := qm["hide_other"].(bool)
		labels := []string{}
		for _, o := range opts {
			om, _ := o.(map[string]any)
			labels = append(labels, fmt.Sprint(om["label"]))
		}
		var line string
		var err error
		if inv != nil && inv.UserInput != nil {
			line, err = inv.UserInput(question)
		} else if inv != nil && inv.UserInputCallback != nil {
			line, err = inv.UserInputCallback(question)
		} else if runtime.GOOS == "js" {
			return nil, tools.NewToolError("ask_user_question under WASM requires goar.onAskUser / Runtime UserInputCallback (PWA modal)")
		} else {
			fmt.Fprintf(os.Stderr, "\n%s\n", question)
			for i, label := range labels {
				fmt.Fprintf(os.Stderr, "  %d) %s\n", i+1, label)
			}
			if !hideOther {
				fmt.Fprintf(os.Stderr, "  %d) Other\n", len(labels)+1)
			}
			fmt.Fprint(os.Stderr, "> ")
			line, err = reader.ReadString('\n')
		}
		if err != nil {
			return map[string]any{"answers": answers, "cancelled": true}, nil
		}
		line = strings.TrimSpace(line)
		isOther := false
		answer := line
		if n := asIntArg(line); n >= 1 && n <= len(labels) {
			answer = labels[n-1]
		} else if !hideOther && asIntArg(line) == len(labels)+1 {
			isOther = true
			fmt.Fprint(os.Stderr, "Other: ")
			other, _ := reader.ReadString('\n')
			answer = strings.TrimSpace(other)
		} else if n := indexOf(labels, line); n >= 0 {
			answer = labels[n]
		} else {
			isOther = true
		}
		answers = append(answers, map[string]any{"question": question, "answer": answer, "is_other": isOther})
	}
	return map[string]any{"answers": answers, "cancelled": false}, nil
}

func indexOf(ss []string, s string) int {
	for i, v := range ss {
		if strings.EqualFold(v, s) {
			return i
		}
	}
	return -1
}
