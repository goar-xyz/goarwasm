package mcp

import (
	"bufio"
	"bytes"
	"context"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"os"
	"os/exec"
	"runtime"
	"path/filepath"
	"strings"
	"sync"
	"time"

	"github.com/goarxyz/goar/internal/core/tools"
)

const (
	mcpDefaultTimeout       = 30 * time.Second
	mcpDefaultSSEReadTimeout = 5 * time.Minute
)

// MCPToolResult is the normalized result of an MCP tools/call.
type MCPToolResult struct {
	OK         bool           `json:"ok"`
	Server     string         `json:"server"`
	Tool       string         `json:"tool"`
	Text       string         `json:"text,omitempty"`
	Structured map[string]any `json:"structured,omitempty"`
}

// RemoteTool is a discovered MCP tool descriptor.
type RemoteTool struct {
	Name        string         `json:"name"`
	Description string         `json:"description,omitempty"`
	InputSchema map[string]any `json:"inputSchema"`
}

// Normalize validates and normalizes a RemoteTool.
func (t *RemoteTool) Normalize() error {
	if strings.TrimSpace(t.Name) == "" {
		return fmt.Errorf("MCP tool missing valid 'name'")
	}
	if t.InputSchema == nil {
		t.InputSchema = map[string]any{"type": "object", "properties": map[string]any{}}
	}
	return nil
}

type mcpContentBlock struct {
	Type string `json:"type"`
	Text string `json:"text"`
}

type mcpResultIn struct {
	StructuredContent map[string]any   `json:"structuredContent"`
	Content           []mcpContentBlock `json:"content"`
	IsError           bool             `json:"isError"`
}

func parseCallResult(server, tool string, resultObj any) MCPToolResult {
	b, _ := json.Marshal(resultObj)
	var parsed mcpResultIn
	_ = json.Unmarshal(b, &parsed)
	if parsed.StructuredContent != nil {
		return MCPToolResult{OK: !parsed.IsError, Server: server, Tool: tool, Structured: parsed.StructuredContent}
	}
	parts := make([]string, 0, len(parsed.Content))
	for _, c := range parsed.Content {
		if c.Text != "" {
			parts = append(parts, c.Text)
		}
	}
	text := strings.Join(parts, "\n")
	return MCPToolResult{OK: !parsed.IsError, Server: server, Tool: tool, Text: text}
}

// HTTPClientConfig configures the MCP streamable HTTP client.
type HTTPClientConfig struct {
	Headers        map[string]string
	Timeout        time.Duration
	SSEReadTimeout time.Duration
}

// NewHTTPClient builds an HTTP client with MCP-friendly timeouts.
func NewHTTPClient(cfg HTTPClientConfig) *http.Client {
	timeout := cfg.Timeout
	if timeout == 0 {
		timeout = mcpDefaultTimeout
	}
	return &http.Client{
		Timeout:   timeout + cfg.SSEReadTimeout,
		Transport: http.DefaultTransport, // browsernet under WASM after SDN.Install
	}
}

func applyAuthHeaders(h http.Header, cfg ServerConfig) {
	for k, v := range cfg.Headers {
		h.Set(k, v)
	}
	if cfg.APIKeyEnv == "" {
		return
	}
	token := os.Getenv(cfg.APIKeyEnv)
	hdr := cfg.APIKeyHeader
	if hdr == "" {
		hdr = "Authorization"
	}
	format := cfg.APIKeyFormat
	if format == "" {
		format = "Bearer {token}"
	}
	h.Set(hdr, strings.ReplaceAll(format, "{token}", token))
}

type jsonRPCRequest struct {
	JSONRPC string `json:"jsonrpc"`
	ID      int    `json:"id"`
	Method  string `json:"method"`
	Params  any    `json:"params,omitempty"`
}

type jsonRPCResponse struct {
	JSONRPC string          `json:"jsonrpc"`
	ID      int             `json:"id"`
	Result  json.RawMessage `json:"result"`
	Error   *struct {
		Code    int    `json:"code"`
		Message string `json:"message"`
	} `json:"error"`
}

func postJSONRPC(ctx context.Context, client *http.Client, endpoint string, headers map[string]string, cfg ServerConfig, method string, params any, id int) (json.RawMessage, error) {
	payload := jsonRPCRequest{JSONRPC: "2.0", ID: id, Method: method, Params: params}
	body, err := json.Marshal(payload)
	if err != nil {
		return nil, err
	}
	req, err := http.NewRequestWithContext(ctx, http.MethodPost, endpoint, bytes.NewReader(body))
	if err != nil {
		return nil, err
	}
	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("Accept", "application/json, text/event-stream")
	for k, v := range headers {
		req.Header.Set(k, v)
	}
	applyAuthHeaders(req.Header, cfg)
	resp, err := client.Do(req)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()
	raw, err := io.ReadAll(resp.Body)
	if err != nil {
		return nil, err
	}
	if resp.StatusCode >= 400 {
		return nil, fmt.Errorf("mcp http %s: status %d: %s", method, resp.StatusCode, truncateBytes(raw, 200))
	}
	// Handle SSE-style responses by taking the last data: line JSON
	trimmed := bytes.TrimSpace(raw)
	if bytes.HasPrefix(trimmed, []byte("event:")) || bytes.Contains(trimmed, []byte("\ndata:")) {
		var last []byte
		for _, line := range bytes.Split(trimmed, []byte("\n")) {
			line = bytes.TrimSpace(line)
			if bytes.HasPrefix(line, []byte("data:")) {
				last = bytes.TrimSpace(bytes.TrimPrefix(line, []byte("data:")))
			}
		}
		if len(last) > 0 {
			trimmed = last
		}
	}
	var rpc jsonRPCResponse
	if err := json.Unmarshal(trimmed, &rpc); err != nil {
		return nil, fmt.Errorf("mcp decode %s: %w (%s)", method, err, truncateBytes(trimmed, 120))
	}
	if rpc.Error != nil {
		return nil, fmt.Errorf("mcp error %d: %s", rpc.Error.Code, rpc.Error.Message)
	}
	return rpc.Result, nil
}

func truncateBytes(b []byte, n int) string {
	if len(b) <= n {
		return string(b)
	}
	return string(b[:n]) + "…"
}

// ListToolsHTTP discovers tools over streamable HTTP JSON-RPC.
func ListToolsHTTP(ctx context.Context, endpoint string, cfg ServerConfig) ([]RemoteTool, error) {
	client := NewHTTPClient(HTTPClientConfig{Headers: cfg.Headers})
	startup := mcpDefaultTimeout
	if cfg.StartupTimeoutSec > 0 {
		startup = time.Duration(cfg.StartupTimeoutSec * float64(time.Second))
	}
	cctx, cancel := context.WithTimeout(ctx, startup)
	defer cancel()
	if _, err := postJSONRPC(cctx, client, endpoint, cfg.Headers, cfg, "initialize", map[string]any{
		"protocolVersion": "2024-11-05",
		"capabilities":    map[string]any{},
		"clientInfo":      map[string]any{"name": "goar", "version": "1.1.1"},
	}, 1); err != nil {
		return nil, err
	}
	_, _ = postJSONRPC(cctx, client, endpoint, cfg.Headers, cfg, "notifications/initialized", nil, 2)
	result, err := postJSONRPC(cctx, client, endpoint, cfg.Headers, cfg, "tools/list", map[string]any{}, 3)
	if err != nil {
		return nil, err
	}
	var wrapped struct {
		Tools []RemoteTool `json:"tools"`
	}
	if err := json.Unmarshal(result, &wrapped); err != nil {
		return nil, err
	}
	out := make([]RemoteTool, 0, len(wrapped.Tools))
	for _, t := range wrapped.Tools {
		if err := t.Normalize(); err != nil {
			continue
		}
		out = append(out, t)
	}
	return out, nil
}

// CallToolHTTP invokes tools/call over HTTP.
func CallToolHTTP(ctx context.Context, endpoint, toolName string, args map[string]any, cfg ServerConfig) (MCPToolResult, error) {
	client := NewHTTPClient(HTTPClientConfig{Headers: cfg.Headers})
	timeout := mcpDefaultSSEReadTimeout
	if cfg.ToolTimeoutSec > 0 {
		timeout = time.Duration(cfg.ToolTimeoutSec * float64(time.Second))
	}
	cctx, cancel := context.WithTimeout(ctx, timeout)
	defer cancel()
	if _, err := postJSONRPC(cctx, client, endpoint, cfg.Headers, cfg, "initialize", map[string]any{
		"protocolVersion": "2024-11-05",
		"capabilities":    map[string]any{},
		"clientInfo":      map[string]any{"name": "goar", "version": "1.1.1"},
	}, 1); err != nil {
		return MCPToolResult{}, err
	}
	_, _ = postJSONRPC(cctx, client, endpoint, cfg.Headers, cfg, "notifications/initialized", nil, 2)
	result, err := postJSONRPC(cctx, client, endpoint, cfg.Headers, cfg, "tools/call", map[string]any{
		"name":      toolName,
		"arguments": args,
	}, 3)
	if err != nil {
		return MCPToolResult{}, err
	}
	var obj any
	_ = json.Unmarshal(result, &obj)
	return parseCallResult(endpoint, toolName, obj), nil
}

// stdioSession is a one-shot JSON-RPC stdio MCP session.
type stdioSession struct {
	cmd    *exec.Cmd
	stdin  io.WriteCloser
	stdout *bufio.Reader
	stderr io.ReadCloser
	mu     sync.Mutex
	nextID int
}

func startStdioSession(ctx context.Context, command []string, env map[string]string, cwd string) (*stdioSession, error) {
	if len(command) == 0 {
		return nil, fmt.Errorf("empty stdio command")
	}
	if runtime.GOOS == "js" {
		return nil, fmt.Errorf("MCP stdio transport is unavailable under GOOS=js/wasm (no local subprocess); use HTTP/streamable_http MCP or an in-process shim")
	}
	cmd := exec.CommandContext(ctx, command[0], command[1:]...)
	if cwd != "" {
		cmd.Dir = cwd
	}
	base := os.Environ()
	for k, v := range env {
		base = append(base, k+"="+v)
	}
	cmd.Env = base
	stdin, err := cmd.StdinPipe()
	if err != nil {
		return nil, err
	}
	stdoutPipe, err := cmd.StdoutPipe()
	if err != nil {
		return nil, err
	}
	stderrPipe, err := cmd.StderrPipe()
	if err != nil {
		return nil, err
	}
	if err := cmd.Start(); err != nil {
		return nil, err
	}
	// Drain stderr in background
	go func() {
		sc := bufio.NewScanner(stderrPipe)
		for sc.Scan() {
			line := sc.Text()
			if line != "" {
				fmt.Fprintf(os.Stderr, "[MCP stderr] %s\n", line)
			}
		}
	}()
	return &stdioSession{cmd: cmd, stdin: stdin, stdout: bufio.NewReader(stdoutPipe), stderr: stderrPipe, nextID: 1}, nil
}

func (s *stdioSession) close() {
	_ = s.stdin.Close()
	if s.cmd.Process != nil {
		_ = s.cmd.Process.Kill()
		_, _ = s.cmd.Process.Wait()
	}
}

func (s *stdioSession) call(method string, params any) (json.RawMessage, error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	id := s.nextID
	s.nextID++
	payload := jsonRPCRequest{JSONRPC: "2.0", ID: id, Method: method, Params: params}
	b, err := json.Marshal(payload)
	if err != nil {
		return nil, err
	}
	b = append(b, '\n')
	if _, err := s.stdin.Write(b); err != nil {
		return nil, err
	}
	line, err := s.stdout.ReadBytes('\n')
	if err != nil {
		return nil, err
	}
	var rpc jsonRPCResponse
	if err := json.Unmarshal(line, &rpc); err != nil {
		return nil, err
	}
	if rpc.Error != nil {
		return nil, fmt.Errorf("mcp error %d: %s", rpc.Error.Code, rpc.Error.Message)
	}
	return rpc.Result, nil
}

func (s *stdioSession) initialize() error {
	if _, err := s.call("initialize", map[string]any{
		"protocolVersion": "2024-11-05",
		"capabilities":    map[string]any{},
		"clientInfo":      map[string]any{"name": "goar", "version": "1.1.1"},
	}); err != nil {
		return err
	}
	// notification — ignore errors
	payload := map[string]any{"jsonrpc": "2.0", "method": "notifications/initialized"}
	b, _ := json.Marshal(payload)
	b = append(b, '\n')
	_, _ = s.stdin.Write(b)
	return nil
}

// ListToolsStdio discovers tools from a stdio MCP server.
func ListToolsStdio(ctx context.Context, command []string, env map[string]string, cwd string, startupTimeout time.Duration) ([]RemoteTool, error) {
	if startupTimeout <= 0 {
		startupTimeout = mcpDefaultTimeout
	}
	cctx, cancel := context.WithTimeout(ctx, startupTimeout)
	defer cancel()
	sess, err := startStdioSession(cctx, command, env, cwd)
	if err != nil {
		return nil, err
	}
	defer sess.close()
	if err := sess.initialize(); err != nil {
		return nil, err
	}
	result, err := sess.call("tools/list", map[string]any{})
	if err != nil {
		return nil, err
	}
	var wrapped struct {
		Tools []RemoteTool `json:"tools"`
	}
	if err := json.Unmarshal(result, &wrapped); err != nil {
		return nil, err
	}
	out := make([]RemoteTool, 0, len(wrapped.Tools))
	for _, t := range wrapped.Tools {
		if err := t.Normalize(); err != nil {
			continue
		}
		out = append(out, t)
	}
	return out, nil
}

// CallToolStdio invokes a tool over stdio MCP.
func CallToolStdio(ctx context.Context, command []string, toolName string, args map[string]any, env map[string]string, cwd string, toolTimeout time.Duration) (MCPToolResult, error) {
	if toolTimeout <= 0 {
		toolTimeout = mcpDefaultSSEReadTimeout
	}
	cctx, cancel := context.WithTimeout(ctx, toolTimeout)
	defer cancel()
	sess, err := startStdioSession(cctx, command, env, cwd)
	if err != nil {
		return MCPToolResult{}, err
	}
	defer sess.close()
	if err := sess.initialize(); err != nil {
		return MCPToolResult{}, err
	}
	result, err := sess.call("tools/call", map[string]any{"name": toolName, "arguments": args})
	if err != nil {
		return MCPToolResult{}, err
	}
	var obj any
	_ = json.Unmarshal(result, &obj)
	return parseCallResult("stdio:"+strings.Join(command, " "), toolName, obj), nil
}

func aliasFromURL(raw string) string {
	u, err := url.Parse(raw)
	if err != nil {
		return "mcp"
	}
	host := strings.ReplaceAll(u.Hostname(), ".", "_")
	if host == "" {
		host = "mcp"
	}
	if u.Port() != "" {
		host += "_" + u.Port()
	}
	return host
}

func aliasFromCommand(cmd []string) string {
	prog := "mcp"
	if len(cmd) > 0 {
		prog = strings.ReplaceAll(filepath.Base(cmd[0]), ".", "_")
	}
	sum := sha256.Sum256([]byte(strings.Join(cmd, "\x00")))
	return prog + "_" + hex.EncodeToString(sum[:4])
}

// ProxyTool is a tools.Tool backed by an MCP remote tool (HTTP or stdio).
type ProxyTool struct {
	PublishedName   string
	ServerName      string
	RemoteName      string
	Desc            string
	Schema          map[string]any
	IsConnector     bool
	Config          ServerConfig
	Command         []string
	Env             map[string]string
	Cwd             string
	SamplingEnabled bool
	InProcess       *InProcessServer // WASM-friendly in-process transport
}

func (t *ProxyTool) Name() string        { return t.PublishedName }
func (t *ProxyTool) Description() string { return t.Desc }
func (t *ProxyTool) Parameters() map[string]any {
	if t.Schema == nil {
		return map[string]any{"type": "object", "properties": map[string]any{}}
	}
	return t.Schema
}
func (t *ProxyTool) Permission() tools.ToolPermission { return tools.PermissionAsk }
func (t *ProxyTool) GetServerName() string            { return t.ServerName }
func (t *ProxyTool) GetRemoteName() string {
	if t.RemoteName != "" {
		return t.RemoteName
	}
	return t.PublishedName
}
func (t *ProxyTool) Connector() bool { return t.IsConnector }

func (t *ProxyTool) StatusText() string {
	return fmt.Sprintf("Calling MCP tool %s", t.RemoteName)
}

func (t *ProxyTool) Run(ctx context.Context, args map[string]any, inv *tools.InvokeContext) (any, error) {
	_ = inv
	cfg := NormalizeServerConfig(t.Config)
	switch cfg.Transport {
	case "inprocess":
		if t.InProcess == nil {
			return nil, fmt.Errorf("MCP in-process call failed: no server")
		}
		res, err := t.InProcess.Call(ctx, t.RemoteName, args)
		if err != nil {
			return nil, fmt.Errorf("MCP in-process call failed: %w", err)
		}
		return res, nil
	case "http", "streamable_http":
		res, err := CallToolHTTP(ctx, cfg.URL, t.RemoteName, args, cfg)
		if err != nil {
			return nil, fmt.Errorf("MCP call failed: %w", err)
		}
		return res, nil
	case "wasm", "websocket", "postmessage":
		res, err := CallToolWasm(ctx, cfg, t.RemoteName, args)
		if err != nil {
			return nil, fmt.Errorf("MCP wasm call failed: %w", err)
		}
		return res, nil
	default:
		cmd := t.Command
		if len(cmd) == 0 && t.Config.Command != "" {
			cmd = append([]string{t.Config.Command}, t.Config.Args...)
		}
		timeout := mcpDefaultSSEReadTimeout
		if t.Config.ToolTimeoutSec > 0 {
			timeout = time.Duration(t.Config.ToolTimeoutSec * float64(time.Second))
		}
		env := t.Env
		if env == nil {
			env = t.Config.Env
		}
		res, err := CallToolStdio(ctx, cmd, t.RemoteName, args, env, t.Cwd, timeout)
		if err != nil {
			return nil, fmt.Errorf("MCP stdio call failed: %w", err)
		}
		return res, nil
	}
}

// CreateHTTPProxyTool builds a ProxyTool for an HTTP MCP remote tool.
func CreateHTTPProxyTool(cfg ServerConfig, remote RemoteTool, alias, serverHint string) *ProxyTool {
	if err := remote.Normalize(); err != nil {
		return nil
	}
	computed := alias
	if computed == "" {
		computed = aliasFromURL(cfg.URL)
	}
	desc := remote.Description
	if desc == "" {
		desc = fmt.Sprintf("MCP tool '%s' from %s", remote.Name, cfg.URL)
	}
	if computed != "" {
		desc = fmt.Sprintf("[%s] %s", computed, desc)
	}
	if serverHint != "" {
		desc += "\nHint: " + serverHint
	}
	return &ProxyTool{
		PublishedName:   computed + "_" + remote.Name,
		ServerName:      computed,
		RemoteName:      remote.Name,
		Desc:            desc,
		Schema:          remote.InputSchema,
		Config:          cfg,
		SamplingEnabled: cfg.SamplingEnabled,
	}
}

// CreateStdioProxyTool builds a ProxyTool for a stdio MCP remote tool.
func CreateStdioProxyTool(cfg ServerConfig, remote RemoteTool, command []string, alias, serverHint, cwd string, env map[string]string) *ProxyTool {
	if err := remote.Normalize(); err != nil {
		return nil
	}
	if len(command) == 0 && cfg.Command != "" {
		command = append([]string{cfg.Command}, cfg.Args...)
	}
	computed := alias
	if computed == "" {
		computed = aliasFromCommand(command)
	}
	desc := remote.Description
	if desc == "" {
		desc = fmt.Sprintf("MCP tool '%s' from stdio command: %s", remote.Name, strings.Join(command, " "))
	}
	if computed != "" {
		desc = fmt.Sprintf("[%s] %s", computed, desc)
	}
	if serverHint != "" {
		desc += "\nHint: " + serverHint
	}
	return &ProxyTool{
		PublishedName:   computed + "_" + remote.Name,
		ServerName:      computed,
		RemoteName:      remote.Name,
		Desc:            desc,
		Schema:          remote.InputSchema,
		Config:          cfg,
		Command:         command,
		Env:             env,
		Cwd:             cwd,
		SamplingEnabled: cfg.SamplingEnabled,
	}
}

// ToolAdapter wraps an MCP tool as a tools.Tool (compat with older registry wiring).
type ToolAdapter struct {
	Desc     ToolDesc
	Registry *Registry
	Config   ServerConfig
}

func (t *ToolAdapter) Name() string        { return t.Desc.FullName }
func (t *ToolAdapter) Description() string { return t.Desc.Description }
func (t *ToolAdapter) Parameters() map[string]any {
	if t.Desc.Parameters == nil {
		return map[string]any{"type": "object", "properties": map[string]any{}}
	}
	return t.Desc.Parameters
}
func (t *ToolAdapter) Permission() tools.ToolPermission { return tools.PermissionAsk }

func (t *ToolAdapter) Run(ctx context.Context, args map[string]any, inv *tools.InvokeContext) (any, error) {
	_ = inv
	proxy := &ProxyTool{
		PublishedName: t.Desc.FullName,
		ServerName:    t.Desc.Server,
		RemoteName:    t.Desc.Name,
		Desc:          t.Desc.Description,
		Schema:        t.Desc.Parameters,
		Config:        t.Config,
		Command:       append([]string{t.Config.Command}, t.Config.Args...),
		Env:           t.Config.Env,
	}
	return proxy.Run(ctx, args, inv)
}

// RegisterOnManager discovers and registers MCP tools onto a tools.Manager.
func RegisterOnManager(m *tools.Manager, r *Registry) {
	for _, td := range r.Tools() {
		cfg, _ := r.Server(td.Server)
		m.Register(&ToolAdapter{Desc: td, Registry: r, Config: cfg})
	}
}

// DiscoverAndProxyTools lists tools for a server and returns ProxyTool instances.
func DiscoverAndProxyTools(ctx context.Context, cfg ServerConfig) ([]*ProxyTool, error) {
	var remotes []RemoteTool
	var err error
	switch cfg.Transport {
	case "http", "streamable_http":
		remotes, err = ListToolsHTTP(ctx, cfg.URL, cfg)
	default:
		cmd := append([]string{cfg.Command}, cfg.Args...)
		timeout := mcpDefaultTimeout
		if cfg.StartupTimeoutSec > 0 {
			timeout = time.Duration(cfg.StartupTimeoutSec * float64(time.Second))
		}
		remotes, err = ListToolsStdio(ctx, cmd, cfg.Env, "", timeout)
	}
	if err != nil {
		return nil, err
	}
	out := make([]*ProxyTool, 0, len(remotes))
	for _, remote := range remotes {
		disabled := false
		for _, d := range cfg.DisabledTools {
			if d == remote.Name {
				disabled = true
				break
			}
		}
		if disabled {
			continue
		}
		var p *ProxyTool
		if cfg.Transport == "http" || cfg.Transport == "streamable_http" {
			p = CreateHTTPProxyTool(cfg, remote, cfg.Name, cfg.Prompt)
		} else {
			cmd := append([]string{cfg.Command}, cfg.Args...)
			p = CreateStdioProxyTool(cfg, remote, cmd, cfg.Name, cfg.Prompt, "", cfg.Env)
		}
		if p != nil {
			out = append(out, p)
		}
	}
	return out, nil
}
