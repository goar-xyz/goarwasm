//go:build js && wasm

package mcp

import (
	"context"
	"crypto/tls"
	"encoding/json"
	"fmt"
	"io"
	"net"
	"net/url"
	"strings"
	"sync"
	"syscall/js"

	"golang.org/x/net/websocket"

	"github.com/goarxyz/goar/browsernet"
)

func init() {
	dialWebSocket = dialWebSocketJS
	dialPostMessage = dialPostMessageJS
}

// wsNetConn wraps golang.org/x/net/websocket.Conn for wasmConn JSON-RPC.
type wsNetConn struct {
	ws *websocket.Conn
	mu sync.Mutex
}

func dialWebSocketJS(ctx context.Context, rawURL string) (wasmConn, error) {
	if rawURL == "" {
		return nil, fmt.Errorf("mcp wasm websocket: empty url")
	}
	u, err := url.Parse(rawURL)
	if err != nil {
		return nil, fmt.Errorf("mcp websocket url: %w", err)
	}
	scheme := strings.ToLower(u.Scheme)
	if scheme != "ws" && scheme != "wss" {
		return nil, fmt.Errorf("mcp websocket: unsupported scheme %q", u.Scheme)
	}
	host := u.Hostname()
	port := u.Port()
	if port == "" {
		if scheme == "wss" {
			port = "443"
		} else {
			port = "80"
		}
	}
	addr := net.JoinHostPort(host, port)

	if browsernet.Dial == nil {
		return nil, fmt.Errorf("mcp websocket: browsernet not installed; call goar.configure first (Wisp)")
	}
	raw, err := browsernet.DialContext(ctx, "tcp", addr)
	if err != nil {
		return nil, fmt.Errorf("mcp websocket dial via browsernet: %w", err)
	}

	var rwc io.ReadWriteCloser = raw
	if scheme == "wss" {
		tlsCfg, err := browsernet.TLSConfig()
		if err != nil {
			_ = raw.Close()
			return nil, fmt.Errorf("mcp websocket tls: %w", err)
		}
		if tlsCfg == nil {
			tlsCfg = &tls.Config{}
		}
		cfg := tlsCfg.Clone()
		cfg.ServerName = host
		tc := tls.Client(raw, cfg)
		if err := tc.HandshakeContext(ctx); err != nil {
			_ = raw.Close()
			return nil, fmt.Errorf("mcp websocket tls handshake: %w", err)
		}
		rwc = tc
	}

	origin := "https://" + host
	if scheme == "ws" {
		origin = "http://" + host
	}
	wsCfg, err := websocket.NewConfig(rawURL, origin)
	if err != nil {
		_ = rwc.Close()
		return nil, err
	}
	ws, err := websocket.NewClient(wsCfg, rwc)
	if err != nil {
		_ = rwc.Close()
		return nil, fmt.Errorf("mcp websocket handshake: %w", err)
	}
	return &wsNetConn{ws: ws}, nil
}

func (c *wsNetConn) WriteJSON(v any) error {
	b, err := json.Marshal(v)
	if err != nil {
		return err
	}
	c.mu.Lock()
	defer c.mu.Unlock()
	return websocket.Message.Send(c.ws, string(b))
}

func (c *wsNetConn) ReadJSON(v any) error {
	var s string
	if err := websocket.Message.Receive(c.ws, &s); err != nil {
		return err
	}
	return json.Unmarshal([]byte(s), v)
}

func (c *wsNetConn) Close() error {
	c.mu.Lock()
	defer c.mu.Unlock()
	return c.ws.Close()
}

// postMessageConn uses BroadcastChannel or window message bus.
type postMessageConn struct {
	ch       js.Value
	name     string
	incoming chan []byte
	closed   chan struct{}
}

func dialPostMessageJS(channel string) (wasmConn, error) {
	if channel == "" {
		channel = "goar-mcp"
	}
	var ch js.Value
	bc := js.Global().Get("BroadcastChannel")
	if bc.Truthy() {
		ch = bc.New(channel)
	} else {
		return nil, fmt.Errorf("BroadcastChannel unavailable for postMessage MCP (channel=%s)", channel)
	}
	c := &postMessageConn{
		ch:       ch,
		name:     channel,
		incoming: make(chan []byte, 32),
		closed:   make(chan struct{}),
	}
	ch.Set("onmessage", js.FuncOf(func(this js.Value, args []js.Value) any {
		if len(args) == 0 {
			return nil
		}
		data := args[0].Get("data")
		var text string
		if data.Type() == js.TypeString {
			text = data.String()
		} else if data.Type() == js.TypeObject {
			if data.Get("goarMcp").Truthy() {
				payload := data.Get("payload")
				if payload.Type() == js.TypeString {
					text = payload.String()
				} else {
					text = js.Global().Get("JSON").Call("stringify", payload).String()
				}
			} else {
				text = js.Global().Get("JSON").Call("stringify", data).String()
			}
		}
		if text == "" {
			return nil
		}
		select {
		case c.incoming <- []byte(text):
		default:
		}
		return nil
	}))
	return c, nil
}

func (c *postMessageConn) WriteJSON(v any) error {
	b, err := json.Marshal(v)
	if err != nil {
		return err
	}
	msg := js.Global().Get("Object").New()
	msg.Set("goarMcp", true)
	msg.Set("payload", string(b))
	c.ch.Call("postMessage", msg)
	return nil
}

func (c *postMessageConn) ReadJSON(v any) error {
	select {
	case <-c.closed:
		return fmt.Errorf("postMessage channel closed")
	case b := <-c.incoming:
		return json.Unmarshal(b, v)
	}
}

func (c *postMessageConn) Close() error {
	select {
	case <-c.closed:
	default:
		close(c.closed)
	}
	if c.ch.Truthy() {
		c.ch.Call("close")
	}
	return nil
}
