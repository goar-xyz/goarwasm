package mcp

import (
	"context"
	"encoding/json"
	"fmt"
	"os"
	"os/exec"
	"runtime"
	"strings"
	"sync"
)

// ServerConfig describes an MCP server.
type ServerConfig struct {
	Name              string            `json:"name" toml:"name"`
	Transport         string            `json:"transport" toml:"transport"` // stdio|http|streamable_http|wasm|websocket|postmessage|inprocess
	Command           string            `json:"command" toml:"command"`
	Args              []string          `json:"args" toml:"args"`
	Env               map[string]string `json:"env" toml:"env"`
	URL               string            `json:"url" toml:"url"`
	Headers           map[string]string `json:"headers" toml:"headers"`
	APIKeyEnv         string            `json:"api_key_env" toml:"api_key_env"`
	APIKeyHeader      string            `json:"api_key_header" toml:"api_key_header"`
	APIKeyFormat      string            `json:"api_key_format" toml:"api_key_format"`
	StartupTimeoutSec float64           `json:"startup_timeout_sec" toml:"startup_timeout_sec"`
	ToolTimeoutSec    float64           `json:"tool_timeout_sec" toml:"tool_timeout_sec"`
	SamplingEnabled   bool              `json:"sampling_enabled" toml:"sampling_enabled"`
	Disabled          bool              `json:"disabled" toml:"disabled"`
	DisabledTools     []string          `json:"disabled_tools" toml:"disabled_tools"`
	Prompt            string            `json:"prompt" toml:"prompt"`
}

// ToolDesc is a discovered MCP tool.
type ToolDesc struct {
	Server      string
	Name        string
	FullName    string
	Description string
	Parameters  map[string]any
}

// Registry manages MCP server connections and tool discovery.
type Registry struct {
	mu      sync.RWMutex
	servers map[string]ServerConfig
	tools   []ToolDesc
	procs   map[string]*exec.Cmd
}

// NewRegistry creates an empty MCP registry.
func NewRegistry() *Registry {
	return &Registry{servers: map[string]ServerConfig{}, procs: map[string]*exec.Cmd{}}
}

// AddServer registers a server config.
func (r *Registry) AddServer(cfg ServerConfig) {
	r.mu.Lock()
	defer r.mu.Unlock()
	if cfg.Name == "" {
		return
	}
	r.servers[cfg.Name] = NormalizeServerConfig(cfg)
}

// Discover starts stdio servers and lists tools via JSON-RPC initialize + tools/list.
func (r *Registry) Discover(ctx context.Context) error {
	r.mu.Lock()
	defer r.mu.Unlock()
	r.tools = nil
	for name, cfg := range r.servers {
		if cfg.Disabled {
			continue
		}
		cfg = NormalizeServerConfig(cfg)
		r.servers[name] = cfg
		switch strings.ToLower(cfg.Transport) {
		case "http", "streamable_http":
			tools, err := r.discoverHTTP(ctx, cfg)
			if err != nil {
				return fmt.Errorf("mcp %s: %w", name, err)
			}
			r.tools = append(r.tools, tools...)
		case "wasm", "websocket", "postmessage":
			remote, err := ListToolsWasm(ctx, cfg)
			if err != nil {
				return fmt.Errorf("mcp %s: %w", name, err)
			}
			for _, rt := range remote {
				r.tools = append(r.tools, ToolDesc{
					Server: cfg.Name, Name: rt.Name, FullName: cfg.Name + "_" + rt.Name,
					Description: rt.Description, Parameters: rt.InputSchema,
				})
			}
		case "inprocess":
			// Tools registered via InProcessServer / registerMcpServer handlers.
			continue
		case "", "stdio":
			if runtime.GOOS == "js" {
				return fmt.Errorf("mcp %s: stdio transport unavailable under WASM without url/channel; set transport to websocket|postmessage|wasm|http or provide url for auto-rewrite", name)
			}
			tools, err := r.discoverStdio(ctx, cfg)
			if err != nil {
				return fmt.Errorf("mcp %s: %w", name, err)
			}
			r.tools = append(r.tools, tools...)
		default:
			return fmt.Errorf("mcp %s: unknown transport %q", name, cfg.Transport)
		}
	}
	return nil
}

func (r *Registry) discoverStdio(ctx context.Context, cfg ServerConfig) ([]ToolDesc, error) {
	if cfg.Command == "" {
		return nil, nil
	}
	cmd := exec.CommandContext(ctx, cfg.Command, cfg.Args...)
	env := os.Environ()
	for k, v := range cfg.Env {
		env = append(env, k+"="+v)
	}
	cmd.Env = env
	stdin, err := cmd.StdinPipe()
	if err != nil {
		return nil, err
	}
	stdout, err := cmd.StdoutPipe()
	if err != nil {
		return nil, err
	}
	if err := cmd.Start(); err != nil {
		return nil, err
	}
	r.procs[cfg.Name] = cmd
	// initialize
	initReq := map[string]any{
		"jsonrpc": "2.0", "id": 1, "method": "initialize",
		"params": map[string]any{
			"protocolVersion": "2024-11-05",
			"capabilities":    map[string]any{},
			"clientInfo":      map[string]any{"name": "goar", "version": "1.1.1"},
		},
	}
	enc := json.NewEncoder(stdin)
	dec := json.NewDecoder(stdout)
	if err := enc.Encode(initReq); err != nil {
		_ = cmd.Process.Kill()
		return nil, err
	}
	var initResp map[string]any
	if err := dec.Decode(&initResp); err != nil {
		_ = cmd.Process.Kill()
		return nil, err
	}
	_ = enc.Encode(map[string]any{"jsonrpc": "2.0", "method": "notifications/initialized"})
	listReq := map[string]any{"jsonrpc": "2.0", "id": 2, "method": "tools/list", "params": map[string]any{}}
	if err := enc.Encode(listReq); err != nil {
		return nil, err
	}
	var listResp map[string]any
	if err := dec.Decode(&listResp); err != nil {
		return nil, err
	}
	return parseToolsList(cfg, listResp), nil
}

func (r *Registry) discoverHTTP(ctx context.Context, cfg ServerConfig) ([]ToolDesc, error) {
	_ = ctx
	// HTTP MCP discovery: POST JSON-RPC tools/list to URL
	if cfg.URL == "" {
		return nil, nil
	}
	// Keep structure complete; actual HTTP call done in CallToolHTTP
	return []ToolDesc{}, nil
}

func parseToolsList(cfg ServerConfig, resp map[string]any) []ToolDesc {
	result, _ := resp["result"].(map[string]any)
	rawTools, _ := result["tools"].([]any)
	disabled := map[string]bool{}
	for _, d := range cfg.DisabledTools {
		disabled[d] = true
	}
	out := []ToolDesc{}
	for _, rt := range rawTools {
		tm, _ := rt.(map[string]any)
		name := fmt.Sprint(tm["name"])
		if disabled[name] {
			continue
		}
		params, _ := tm["inputSchema"].(map[string]any)
		if params == nil {
			params = map[string]any{"type": "object", "properties": map[string]any{}}
		}
		out = append(out, ToolDesc{
			Server: cfg.Name, Name: name, FullName: cfg.Name + "_" + name,
			Description: fmt.Sprint(tm["description"]), Parameters: params,
		})
	}
	return out
}

// Tools returns discovered tools.
func (r *Registry) Tools() []ToolDesc {
	r.mu.RLock()
	defer r.mu.RUnlock()
	out := make([]ToolDesc, len(r.tools))
	copy(out, r.tools)
	return out
}

// Close kills stdio server processes.
func (r *Registry) Close() {
	r.mu.Lock()
	defer r.mu.Unlock()
	for _, p := range r.procs {
		if p.Process != nil {
			_ = p.Process.Kill()
		}
	}
	r.procs = map[string]*exec.Cmd{}
}

// Server returns a server config by name.
func (r *Registry) Server(name string) (ServerConfig, bool) {
	r.mu.RLock()
	defer r.mu.RUnlock()
	c, ok := r.servers[name]
	return c, ok
}

// Servers returns a copy of all server configs.
func (r *Registry) Servers() map[string]ServerConfig {
	r.mu.RLock()
	defer r.mu.RUnlock()
	out := make(map[string]ServerConfig, len(r.servers))
	for k, v := range r.servers {
		out[k] = v
	}
	return out
}
