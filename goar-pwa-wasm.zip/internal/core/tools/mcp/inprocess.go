package mcp

import (
	"context"
	"fmt"
	"sync"
)

// InProcessHandler handles a single MCP tool call inside the same process.
// Embedders under WASM can register handlers instead of spawning stdio servers.
type InProcessHandler func(ctx context.Context, args map[string]any) (MCPToolResult, error)

// InProcessServer is a WASM-friendly MCP server that never uses os/exec.
type InProcessServer struct {
	mu       sync.RWMutex
	Name     string
	Prompt   string
	tools    map[string]RemoteTool
	handlers map[string]InProcessHandler
}

// NewInProcessServer constructs an empty in-process MCP server.
func NewInProcessServer(name string) *InProcessServer {
	return &InProcessServer{
		Name:     name,
		tools:    map[string]RemoteTool{},
		handlers: map[string]InProcessHandler{},
	}
}

// RegisterTool adds a tool descriptor and handler.
func (s *InProcessServer) RegisterTool(tool RemoteTool, h InProcessHandler) error {
	if err := tool.Normalize(); err != nil {
		return err
	}
	if h == nil {
		return fmt.Errorf("nil handler for tool %q", tool.Name)
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	s.tools[tool.Name] = tool
	s.handlers[tool.Name] = h
	return nil
}

// ListTools returns registered remote tools.
func (s *InProcessServer) ListTools() []RemoteTool {
	s.mu.RLock()
	defer s.mu.RUnlock()
	out := make([]RemoteTool, 0, len(s.tools))
	for _, t := range s.tools {
		out = append(out, t)
	}
	return out
}

// Call invokes a registered handler.
func (s *InProcessServer) Call(ctx context.Context, toolName string, args map[string]any) (MCPToolResult, error) {
	s.mu.RLock()
	h, ok := s.handlers[toolName]
	s.mu.RUnlock()
	if !ok {
		return MCPToolResult{OK: false, Server: s.Name, Tool: toolName, Text: "unknown tool"}, fmt.Errorf("in-process MCP: unknown tool %q", toolName)
	}
	return h(ctx, args)
}

// CreateInProcessProxyTool wraps an in-process handler as a ProxyTool.
func CreateInProcessProxyTool(server *InProcessServer, remote RemoteTool) *ProxyTool {
	if err := remote.Normalize(); err != nil {
		remote.InputSchema = map[string]any{"type": "object", "properties": map[string]any{}}
	}
	published := remote.Name
	if server.Name != "" {
		published = server.Name + "__" + remote.Name
	}
	desc := remote.Description
	if desc == "" {
		desc = fmt.Sprintf("In-process MCP tool '%s' from server '%s'", remote.Name, server.Name)
	}
	return &ProxyTool{
		PublishedName: published,
		ServerName:    server.Name,
		RemoteName:    remote.Name,
		Desc:          desc,
		Schema:        remote.InputSchema,
		Config:        ServerConfig{Name: server.Name, Transport: "inprocess", Prompt: server.Prompt},
		InProcess:     server,
	}
}
