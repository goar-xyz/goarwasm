package mcp

import (
	"context"
	"encoding/json"
	"fmt"
	"strings"
	"sync"
	"sync/atomic"
	"time"
)

// WasmTransport is the WASM-equivalent of stdio: JSON-RPC framed over
// WebSocket or a postMessage channel.
type WasmTransport struct {
	mu      sync.Mutex
	url     string
	channel string // postMessage channel name
	mode    string // websocket | postmessage | wasm
	conn    wasmConn
	nextID  int64
	pending map[int64]chan rpcWait
}

type rpcWait struct {
	result json.RawMessage
	err    error
}

type wasmConn interface {
	WriteJSON(v any) error
	ReadJSON(v any) error
	Close() error
}

// NewWasmTransport constructs a transport for url (ws/wss) or channel (postMessage).
func NewWasmTransport(mode, url, channel string) *WasmTransport {
	return &WasmTransport{
		url:     strings.TrimSpace(url),
		channel: strings.TrimSpace(channel),
		mode:    strings.ToLower(strings.TrimSpace(mode)),
		pending: map[int64]chan rpcWait{},
	}
}

// NormalizeServerConfig rewrites stdio → wasm/websocket/http when a URL is provided.
// Never silently skip under WASM: callers must surface errors instead.
func NormalizeServerConfig(cfg ServerConfig) ServerConfig {
	t := strings.ToLower(strings.TrimSpace(cfg.Transport))
	switch t {
	case "wasm", "postmessage", "websocket":
		return cfg
	case "ws", "wss":
		cfg.Transport = "websocket"
		return cfg
	case "inprocess":
		return cfg
	case "", "stdio":
		if cfg.URL != "" {
			u := strings.ToLower(cfg.URL)
			if strings.HasPrefix(u, "ws://") || strings.HasPrefix(u, "wss://") {
				cfg.Transport = "websocket"
				return cfg
			}
			if strings.HasPrefix(u, "http://") || strings.HasPrefix(u, "https://") {
				cfg.Transport = "http"
				return cfg
			}
			if strings.HasPrefix(u, "postmessage:") {
				cfg.Transport = "postmessage"
				return cfg
			}
		}
		if cfg.Env != nil {
			if ch := cfg.Env["MCP_WASM_CHANNEL"]; ch != "" {
				cfg.Transport = "postmessage"
				if cfg.URL == "" {
					cfg.URL = "postmessage:" + ch
				}
				return cfg
			}
		}
	}
	return cfg
}

// Dial opens the underlying connection.
func (t *WasmTransport) Dial(ctx context.Context) error {
	t.mu.Lock()
	defer t.mu.Unlock()
	if t.conn != nil {
		return nil
	}
	mode := t.mode
	if mode == "" || mode == "wasm" {
		if strings.HasPrefix(strings.ToLower(t.url), "ws") {
			mode = "websocket"
		} else if t.channel != "" || strings.HasPrefix(t.url, "postmessage:") {
			mode = "postmessage"
		} else {
			mode = "websocket"
		}
	}
	var (
		c   wasmConn
		err error
	)
	switch mode {
	case "postmessage":
		ch := t.channel
		if ch == "" && strings.HasPrefix(t.url, "postmessage:") {
			ch = strings.TrimPrefix(t.url, "postmessage:")
		}
		c, err = dialPostMessage(ch)
	default:
		c, err = dialWebSocket(ctx, t.url)
	}
	if err != nil {
		return err
	}
	t.conn = c
	go t.readLoop()
	return nil
}

func (t *WasmTransport) readLoop() {
	for {
		t.mu.Lock()
		c := t.conn
		t.mu.Unlock()
		if c == nil {
			return
		}
		var msg map[string]any
		if err := c.ReadJSON(&msg); err != nil {
			return
		}
		raw, _ := json.Marshal(msg)
		var envelope struct {
			ID     *float64        `json:"id"`
			Method string          `json:"method"`
			Result json.RawMessage `json:"result"`
			Error  *struct {
				Code    int    `json:"code"`
				Message string `json:"message"`
			} `json:"error"`
		}
		if err := json.Unmarshal(raw, &envelope); err != nil {
			continue
		}
		if envelope.Method != "" && envelope.ID == nil {
			continue
		}
		if envelope.ID != nil {
			id := int64(*envelope.ID)
			t.mu.Lock()
			ch := t.pending[id]
			delete(t.pending, id)
			t.mu.Unlock()
			if ch != nil {
				if envelope.Error != nil {
					ch <- rpcWait{err: fmt.Errorf("mcp error %d: %s", envelope.Error.Code, envelope.Error.Message)}
				} else {
					ch <- rpcWait{result: envelope.Result}
				}
			}
		}
	}
}

// Call performs a JSON-RPC request/response.
func (t *WasmTransport) Call(ctx context.Context, method string, params any) (json.RawMessage, error) {
	if err := t.Dial(ctx); err != nil {
		return nil, err
	}
	id := atomic.AddInt64(&t.nextID, 1)
	wait := make(chan rpcWait, 1)
	t.mu.Lock()
	t.pending[id] = wait
	c := t.conn
	t.mu.Unlock()
	payload := map[string]any{"jsonrpc": "2.0", "id": id, "method": method, "params": params}
	if err := c.WriteJSON(payload); err != nil {
		t.mu.Lock()
		delete(t.pending, id)
		t.mu.Unlock()
		return nil, err
	}
	select {
	case <-ctx.Done():
		return nil, ctx.Err()
	case w := <-wait:
		return w.result, w.err
	}
}

// Notify sends a JSON-RPC notification (no id).
func (t *WasmTransport) Notify(method string, params any) error {
	t.mu.Lock()
	c := t.conn
	t.mu.Unlock()
	if c == nil {
		return fmt.Errorf("mcp wasm: not connected")
	}
	payload := map[string]any{"jsonrpc": "2.0", "method": method}
	if params != nil {
		payload["params"] = params
	}
	return c.WriteJSON(payload)
}

// Close closes the transport.
func (t *WasmTransport) Close() error {
	t.mu.Lock()
	defer t.mu.Unlock()
	if t.conn == nil {
		return nil
	}
	err := t.conn.Close()
	t.conn = nil
	return err
}

func newTransportFromConfig(cfg ServerConfig) *WasmTransport {
	mode := cfg.Transport
	url := cfg.URL
	channel := ""
	if cfg.Env != nil {
		channel = cfg.Env["MCP_WASM_CHANNEL"]
	}
	if strings.HasPrefix(url, "postmessage:") {
		channel = strings.TrimPrefix(url, "postmessage:")
		mode = "postmessage"
	}
	return NewWasmTransport(mode, url, channel)
}

// ListToolsWasm discovers tools over WasmTransport.
func ListToolsWasm(ctx context.Context, cfg ServerConfig) ([]RemoteTool, error) {
	tr := newTransportFromConfig(cfg)
	defer tr.Close()
	cctx, cancel := context.WithTimeout(ctx, mcpTimeout(cfg.StartupTimeoutSec, mcpDefaultTimeout))
	defer cancel()
	if _, err := tr.Call(cctx, "initialize", map[string]any{
		"protocolVersion": "2024-11-05",
		"capabilities":    map[string]any{},
		"clientInfo":      map[string]any{"name": "goar", "version": "1.1.2"},
	}); err != nil {
		return nil, err
	}
	_ = tr.Notify("notifications/initialized", nil)
	result, err := tr.Call(cctx, "tools/list", map[string]any{})
	if err != nil {
		return nil, err
	}
	var wrapped struct {
		Tools []RemoteTool `json:"tools"`
	}
	if err := json.Unmarshal(result, &wrapped); err != nil {
		return nil, err
	}
	out := make([]RemoteTool, 0, len(wrapped.Tools))
	for _, tool := range wrapped.Tools {
		if err := tool.Normalize(); err != nil {
			continue
		}
		out = append(out, tool)
	}
	return out, nil
}

// CallToolWasm invokes tools/call over WasmTransport.
func CallToolWasm(ctx context.Context, cfg ServerConfig, toolName string, args map[string]any) (MCPToolResult, error) {
	tr := newTransportFromConfig(cfg)
	defer tr.Close()
	timeout := mcpTimeout(cfg.ToolTimeoutSec, mcpDefaultSSEReadTimeout)
	cctx, cancel := context.WithTimeout(ctx, timeout)
	defer cancel()
	if _, err := tr.Call(cctx, "initialize", map[string]any{
		"protocolVersion": "2024-11-05",
		"capabilities":    map[string]any{},
		"clientInfo":      map[string]any{"name": "goar", "version": "1.1.2"},
	}); err != nil {
		return MCPToolResult{}, err
	}
	result, err := tr.Call(cctx, "tools/call", map[string]any{"name": toolName, "arguments": args})
	if err != nil {
		return MCPToolResult{}, err
	}
	var obj any
	_ = json.Unmarshal(result, &obj)
	return parseCallResult(cfg.Name, toolName, obj), nil
}

func mcpTimeout(sec float64, fallback time.Duration) time.Duration {
	if sec > 0 {
		return time.Duration(sec * float64(time.Second))
	}
	return fallback
}

// dial hooks — set by build-tagged files.
var (
	dialWebSocket   = dialWebSocketFallback
	dialPostMessage = dialPostMessageFallback
)

func dialWebSocketFallback(ctx context.Context, url string) (wasmConn, error) {
	_ = ctx
	return nil, fmt.Errorf("mcp websocket transport not available on this platform (url=%s); use http/streamable_http or js/wasm", url)
}

func dialPostMessageFallback(channel string) (wasmConn, error) {
	return nil, fmt.Errorf("mcp postMessage transport requires js/wasm (channel=%s)", channel)
}
