// Package mcp implements Model Context Protocol client registry and tools.
package mcp
