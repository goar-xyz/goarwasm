package agents

import (
	"fmt"
	"os"
	"path/filepath"
	"strings"

	"github.com/BurntSushi/toml"
	"github.com/goarxyz/goar/internal/core/config"
	"github.com/goarxyz/goar/internal/core/paths"
	"github.com/goarxyz/goar/internal/core/utils"
)

// AgentSafety classifies how aggressive an agent is with side effects.
type AgentSafety string

const (
	SafetySafe        AgentSafety = "safe"
	SafetyNeutral     AgentSafety = "neutral"
	SafetyDestructive AgentSafety = "destructive"
	SafetyYOLO        AgentSafety = "yolo"
)

// AgentType distinguishes top-level agents from subagents.
type AgentType string

const (
	TypeAgent    AgentType = "agent"
	TypeSubagent AgentType = "subagent"
)

// BuiltinAgentName constants (Python BuiltinAgentName).
const (
	AgentDefault     = "default"
	AgentChat        = "chat"
	AgentPlan        = "plan"
	AgentAcceptEdits = "accept-edits"
	AgentAutoApprove = "auto-approve"
	AgentExplore     = "explore"
	AgentLean        = "lean"
	AgentAdaptive    = "adaptive-engineer"
	AgentStrategist  = "strategist"
	AgentExecutor    = "executor"
	AgentVerifier    = "verifier"
)

// AgentProfile describes a named agent mode (Python AgentProfile).
type AgentProfile struct {
	Name            string         `toml:"name" json:"name"`
	DisplayName     string         `toml:"display_name" json:"display_name"`
	Description     string         `toml:"description" json:"description"`
	Safety          AgentSafety    `toml:"safety" json:"safety"`
	AgentType       AgentType      `toml:"agent_type" json:"agent_type"`
	SystemPromptID  string         `toml:"system_prompt_id" json:"system_prompt_id"`
	InstallRequired bool           `toml:"install_required" json:"install_required"`
	Overrides       map[string]any `toml:"-" json:"overrides,omitempty"`

	// Convenience fields used by ApplyToConfig / older callers.
	BypassToolPermissions bool     `toml:"bypass_tool_permissions" json:"bypass_tool_permissions"`
	DefaultPermission     string   `toml:"default_permission" json:"default_permission"`
	EnabledTools          []string `toml:"enabled_tools" json:"enabled_tools"`
	DisabledTools         []string `toml:"disabled_tools" json:"disabled_tools"`
	ConfigOverrides       map[string]any `toml:"-" json:"config_overrides,omitempty"`
}

// deepMerge recursively merges override into a copy of base.
func deepMerge(base, override map[string]any) map[string]any {
	result := map[string]any{}
	for k, v := range base {
		result[k] = v
	}
	for k, v := range override {
		if existing, ok := result[k]; ok {
			em, eok := existing.(map[string]any)
			vm, vok := v.(map[string]any)
			if eok && vok {
				result[k] = deepMerge(em, vm)
				continue
			}
		}
		result[k] = v
	}
	return result
}

// ApplyToConfig overlays profile flags onto a config copy (Python apply_to_config).
func (p AgentProfile) ApplyToConfig(cfg *config.Config) *config.Config {
	if cfg == nil {
		return nil
	}
	out := *cfg
	overrides := p.Overrides
	if overrides == nil {
		overrides = p.ConfigOverrides
	}
	if overrides != nil {
		if v, ok := overrides["bypass_tool_permissions"].(bool); ok && v {
			out.BypassToolPermissions = true
		}
		if v, ok := overrides["system_prompt_id"].(string); ok && v != "" {
			out.SystemPromptID = v
		}
		if v, ok := overrides["active_model"].(string); ok && v != "" {
			out.ActiveModel = v
		}
		if v, ok := overrides["enabled_tools"].([]string); ok {
			out.EnabledTools = append([]string{}, v...)
		} else if raw, ok := overrides["enabled_tools"].([]any); ok {
			out.EnabledTools = anyStrings(raw)
		}
		if baseDisabled, ok := overrides["base_disabled"].([]string); ok {
			out.DisabledTools = utils.ConcatLists(baseDisabled, out.DisabledTools)
		} else if raw, ok := overrides["base_disabled"].([]any); ok {
			out.DisabledTools = utils.ConcatLists(anyStrings(raw), out.DisabledTools)
		}
	}
	if p.SystemPromptID != "" {
		out.SystemPromptID = p.SystemPromptID
	}
	if p.BypassToolPermissions {
		out.BypassToolPermissions = true
	}
	if len(p.EnabledTools) > 0 {
		out.EnabledTools = append([]string{}, p.EnabledTools...)
	}
	if len(p.DisabledTools) > 0 {
		merged := append([]string{}, p.DisabledTools...)
		merged = append(merged, out.DisabledTools...)
		out.DisabledTools = merged
	}
	// Environment-level disables must take precedence over enabled_tools allowlist.
	if len(cfg.DisabledTools) > 0 && len(out.EnabledTools) > 0 {
		filtered := make([]string, 0, len(out.EnabledTools))
		for _, t := range out.EnabledTools {
			if !utils.AnyMatch(t, cfg.DisabledTools) {
				filtered = append(filtered, t)
			}
		}
		out.EnabledTools = filtered
	}
	return &out
}

func anyStrings(raw []any) []string {
	out := make([]string, 0, len(raw))
	for _, v := range raw {
		if s, ok := v.(string); ok {
			out = append(out, s)
		}
	}
	return out
}

// FromTOML loads an AgentProfile from a TOML file (Python from_toml).
func FromTOML(path string) (AgentProfile, error) {
	var raw map[string]any
	if _, err := toml.DecodeFile(path, &raw); err != nil {
		return AgentProfile{}, err
	}
	stem := strings.TrimSuffix(filepath.Base(path), filepath.Ext(path))
	p := AgentProfile{
		Name:        stem,
		DisplayName: stemTitle(stem),
		Description: "",
		Safety:      SafetyNeutral,
		AgentType:   TypeAgent,
		Overrides:   map[string]any{},
	}
	if v, ok := raw["display_name"].(string); ok {
		p.DisplayName = v
		delete(raw, "display_name")
	}
	if v, ok := raw["description"].(string); ok {
		p.Description = v
		delete(raw, "description")
	}
	if v, ok := raw["safety"].(string); ok {
		p.Safety = AgentSafety(v)
		delete(raw, "safety")
	}
	if v, ok := raw["agent_type"].(string); ok {
		p.AgentType = AgentType(v)
		delete(raw, "agent_type")
	}
	if v, ok := raw["install_required"].(bool); ok {
		p.InstallRequired = v
		delete(raw, "install_required")
	}
	if v, ok := raw["system_prompt_id"].(string); ok {
		p.SystemPromptID = v
	}
	if v, ok := raw["bypass_tool_permissions"].(bool); ok {
		p.BypassToolPermissions = v
	}
	p.Overrides = raw
	return p, nil
}

func stemTitle(stem string) string {
	parts := strings.Split(stem, "-")
	for i, p := range parts {
		if p == "" {
			continue
		}
		parts[i] = strings.ToUpper(p[:1]) + p[1:]
	}
	return strings.Join(parts, " ")
}

// ChatAgentTools is the allowlist for chat mode.
var ChatAgentTools = []string{"grep", "read_file", "ask_user_question", "task"}

func planOverrides() map[string]any {
	plansPattern := filepath.Join(paths.PlansDir(), "*")
	return map[string]any{
		"tools": map[string]any{
			"write_file":     map[string]any{"permission": "never", "allowlist": []string{plansPattern}},
			"search_replace": map[string]any{"permission": "never", "allowlist": []string{plansPattern}},
		},
	}
}

// BuiltinProfiles returns shipped agent profiles (Python BUILTIN_AGENTS).
func BuiltinProfiles() map[string]AgentProfile {
	return map[string]AgentProfile{
		AgentDefault: {
			Name: AgentDefault, DisplayName: "Default",
			Description: "Full agentic mode — plans, codes, executes, and builds",
			Safety: SafetyNeutral, AgentType: TypeAgent, SystemPromptID: "cli",
			DefaultPermission: "ask",
			Overrides:         map[string]any{"base_disabled": []string{"exit_plan_mode"}},
			DisabledTools:     []string{"exit_plan_mode"},
		},
		AgentPlan: {
			Name: AgentPlan, DisplayName: "Plan",
			Description: "Read-only agent for exploration and planning",
			Safety: SafetySafe, AgentType: TypeAgent, SystemPromptID: "cli",
			DefaultPermission: "ask",
			Overrides:         planOverrides(),
			DisabledTools:     []string{"write_file", "search_replace", "bash", "pip_install"},
		},
		AgentChat: {
			Name: AgentChat, DisplayName: "Chat",
			Description: "Read-only conversational mode for questions and discussions",
			Safety: SafetySafe, AgentType: TypeAgent, SystemPromptID: "cli",
			BypassToolPermissions: true, DefaultPermission: "ask",
			EnabledTools:          append([]string{}, ChatAgentTools...),
			Overrides: map[string]any{
				"bypass_tool_permissions": true,
				"enabled_tools":           ChatAgentTools,
			},
		},
		AgentAcceptEdits: {
			Name: AgentAcceptEdits, DisplayName: "Accept Edits",
			Description: "Auto-approves file edits only",
			Safety: SafetyDestructive, AgentType: TypeAgent, SystemPromptID: "cli",
			DefaultPermission: "ask",
			Overrides: map[string]any{
				"base_disabled": []string{"exit_plan_mode"},
				"tools": map[string]any{
					"write_file":     map[string]any{"permission": "always"},
					"search_replace": map[string]any{"permission": "always"},
				},
			},
			DisabledTools: []string{"exit_plan_mode"},
		},
		AgentAutoApprove: {
			Name: AgentAutoApprove, DisplayName: "Auto Approve",
			Description: "Auto-approves all tool executions",
			Safety: SafetyYOLO, AgentType: TypeAgent, SystemPromptID: "cli",
			BypassToolPermissions: true, DefaultPermission: "always",
			Overrides: map[string]any{
				"bypass_tool_permissions": true,
				"base_disabled":           []string{"exit_plan_mode"},
			},
			DisabledTools: []string{"exit_plan_mode"},
		},
		AgentExplore: {
			Name: AgentExplore, DisplayName: "Explore",
			Description: "Read-only subagent for codebase exploration",
			Safety: SafetySafe, AgentType: TypeSubagent, SystemPromptID: "explore",
			EnabledTools: []string{"grep", "read_file"},
			Overrides: map[string]any{
				"enabled_tools":    []string{"grep", "read_file"},
				"system_prompt_id": "explore",
			},
		},
		AgentLean: {
			Name: AgentLean, DisplayName: "Lean",
			Description: "Specialized mode for Lean 4 code analysis, proof assistance, and theorem proving",
			Safety: SafetyNeutral, AgentType: TypeAgent, SystemPromptID: "lean",
			InstallRequired: true,
			Overrides: map[string]any{
				"system_prompt_id": "lean",
				"active_model":     "lean-reasoner",
				"base_disabled":    []string{"exit_plan_mode"},
			},
			DisabledTools: []string{"exit_plan_mode"},
		},
		AgentAdaptive: {
			Name: AgentAdaptive, DisplayName: "Adaptive Engineer",
			Description: "Self-growing full-stack agent. Writes code, builds apps, installs deps, creates tools mid-session.",
			Safety: SafetyYOLO, AgentType: TypeAgent, SystemPromptID: "adaptive_engineer",
			BypassToolPermissions: true, DefaultPermission: "always",
			Overrides: map[string]any{
				"bypass_tool_permissions": true,
				"system_prompt_id":        "adaptive_engineer",
				"base_disabled":           []string{"exit_plan_mode"},
			},
			DisabledTools: []string{"exit_plan_mode"},
		},
		AgentStrategist: {
			Name: AgentStrategist, DisplayName: "Strategist",
			Description: "High-level planning and architectural guidance",
			Safety: SafetySafe, AgentType: TypeSubagent, SystemPromptID: "strategist",
			DefaultPermission: "ask",
			Overrides:         map[string]any{"temperature": 0.2, "system_prompt_id": "strategist"},
		},
		AgentExecutor: {
			Name: AgentExecutor, DisplayName: "Executor",
			Description: "Deterministic tool execution and code generation",
			Safety: SafetyNeutral, AgentType: TypeSubagent, SystemPromptID: "executor",
			BypassToolPermissions: true, DefaultPermission: "always",
			Overrides:             map[string]any{"temperature": 0.0, "system_prompt_id": "executor"},
		},
		AgentVerifier: {
			Name: AgentVerifier, DisplayName: "Verifier",
			Description: "Critical review of tool outputs and code correctness",
			Safety: SafetySafe, AgentType: TypeSubagent, SystemPromptID: "verifier",
			DefaultPermission: "ask",
			Overrides:         map[string]any{"temperature": 0.1, "system_prompt_id": "verifier"},
		},
	}
}

// LoadCustomProfileFiles loads *.toml profiles from the agents home directory.
func LoadCustomProfileFiles() map[string]AgentProfile {
	out := map[string]AgentProfile{}
	dir := paths.AgentsHome()
	entries, err := os.ReadDir(dir)
	if err != nil {
		return out
	}
	for _, e := range entries {
		if e.IsDir() || filepath.Ext(e.Name()) != ".toml" {
			continue
		}
		p, err := FromTOML(filepath.Join(dir, e.Name()))
		if err != nil {
			continue
		}
		out[p.Name] = p
	}
	return out
}

// ValidateProfileName reports whether name is a known builtin.
func ValidateProfileName(name string) error {
	if _, ok := BuiltinProfiles()[name]; ok {
		return nil
	}
	return fmt.Errorf("unknown builtin agent: %s", name)
}
