package agents

import (
	"fmt"
	"strings"
	"sync"
)

// IntentBuffer tracks high-level goal/plan/facts.
type IntentBuffer struct {
	Goal           string
	Steps          []string
	CompletedSteps []string
	Facts          map[string]any
}

// FormatForPrompt renders intent for system injection.
func (i *IntentBuffer) FormatForPrompt() string {
	var lines []string
	lines = append(lines, "PRIMARY GOAL: "+i.Goal)
	if len(i.Steps) > 0 {
		lines = append(lines, "PLAN:")
		for n, step := range i.Steps {
			status := "[PENDING]"
			for _, c := range i.CompletedSteps {
				if c == step {
					status = "[DONE]"
					break
				}
			}
			lines = append(lines, fmt.Sprintf("  %d. %s %s", n+1, status, step))
		}
	}
	if len(i.Facts) > 0 {
		lines = append(lines, "CONTEXTUAL FACTS:")
		for k, v := range i.Facts {
			lines = append(lines, fmt.Sprintf("  - %s: %v", k, v))
		}
	}
	return strings.Join(lines, "\n")
}

// ModelOrchestrator manages intent and role selection.
type ModelOrchestrator struct {
	mu         sync.Mutex
	intent     *IntentBuffer
	activeRole string
}

// NewModelOrchestrator creates an orchestrator.
func NewModelOrchestrator() *ModelOrchestrator {
	return &ModelOrchestrator{activeRole: AgentStrategist}
}

// UpdateIntent updates goal/steps/facts.
func (o *ModelOrchestrator) UpdateIntent(goal string, steps []string, factKey string, factVal any) {
	o.mu.Lock()
	defer o.mu.Unlock()
	if o.intent == nil && goal != "" {
		o.intent = &IntentBuffer{Goal: goal, Facts: map[string]any{}}
	}
	if o.intent == nil {
		return
	}
	if goal != "" {
		o.intent.Goal = goal
	}
	if steps != nil {
		o.intent.Steps = steps
	}
	if factKey != "" {
		if o.intent.Facts == nil {
			o.intent.Facts = map[string]any{}
		}
		o.intent.Facts[factKey] = factVal
	}
}

// MarkStepDone marks a plan step complete.
func (o *ModelOrchestrator) MarkStepDone(step string) {
	o.mu.Lock()
	defer o.mu.Unlock()
	if o.intent == nil {
		return
	}
	for _, c := range o.intent.CompletedSteps {
		if c == step {
			return
		}
	}
	for _, s := range o.intent.Steps {
		if s == step {
			o.intent.CompletedSteps = append(o.intent.CompletedSteps, step)
			return
		}
	}
}

// SelectRoleForTask returns a heuristic role.
func (o *ModelOrchestrator) SelectRoleForTask(taskType string) string {
	mapping := map[string]string{
		"coding": AgentExecutor, "search": AgentExecutor,
		"analysis": AgentStrategist, "security": AgentVerifier, "general": AgentStrategist,
	}
	if r, ok := mapping[taskType]; ok {
		return r
	}
	return AgentStrategist
}

// GetIntentContext returns prompt context or empty.
func (o *ModelOrchestrator) GetIntentContext() string {
	o.mu.Lock()
	defer o.mu.Unlock()
	if o.intent == nil {
		return ""
	}
	return "\n=== CURRENT INTENT ===\n" + o.intent.FormatForPrompt() + "\n"
}
