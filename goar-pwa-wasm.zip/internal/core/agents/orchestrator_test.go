package agents

import "testing"

func TestOrchestratorIntent(t *testing.T) {
	o := NewModelOrchestrator()
	o.UpdateIntent("ship it", []string{"plan", "code"}, "lang", "go")
	o.MarkStepDone("plan")
	ctx := o.GetIntentContext()
	if ctx == "" {
		t.Fatal("empty context")
	}
	if o.SelectRoleForTask("coding") != AgentExecutor {
		t.Fatal("role")
	}
}
