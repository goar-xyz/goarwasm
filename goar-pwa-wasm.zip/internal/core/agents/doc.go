// Package agents implements agent profiles, bus, manager, and orchestrator.
package agents
