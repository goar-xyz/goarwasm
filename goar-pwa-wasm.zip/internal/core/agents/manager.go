package agents

import (
	"fmt"
	"os"
	"path/filepath"
	"sync"

	"github.com/BurntSushi/toml"
	"github.com/goarxyz/goar/internal/core/config"
	"github.com/goarxyz/goar/internal/core/paths"
)

// Manager tracks the active agent profile.
type Manager struct {
	mu            sync.RWMutex
	configGetter  func() *config.Config
	profiles      map[string]AgentProfile
	active        string
	allowSubagent bool
}

// NewManager creates an agent manager.
func NewManager(cfg func() *config.Config, initial string, allowSubagent bool) *Manager {
	m := &Manager{
		configGetter: cfg, profiles: BuiltinProfiles(),
		active: initial, allowSubagent: allowSubagent,
	}
	if m.active == "" {
		m.active = AgentDefault
	}
	m.loadCustomProfiles()
	return m
}

func (m *Manager) loadCustomProfiles() {
	dir := paths.AgentsHome()
	entries, err := os.ReadDir(dir)
	if err != nil {
		return
	}
	for _, e := range entries {
		if e.IsDir() || filepath.Ext(e.Name()) != ".toml" {
			continue
		}
		var p AgentProfile
		if _, err := toml.DecodeFile(filepath.Join(dir, e.Name()), &p); err != nil {
			continue
		}
		if p.Name == "" {
			p.Name = e.Name()[:len(e.Name())-5]
		}
		m.profiles[p.Name] = p
	}
}

// ActiveProfile returns the current profile.
func (m *Manager) ActiveProfile() AgentProfile {
	m.mu.RLock()
	defer m.mu.RUnlock()
	if p, ok := m.profiles[m.active]; ok {
		return p
	}
	return m.profiles[AgentDefault]
}

// Switch activates a named profile.
func (m *Manager) Switch(name string) error {
	m.mu.Lock()
	defer m.mu.Unlock()
	if _, ok := m.profiles[name]; !ok {
		return fmt.Errorf("unknown agent: %s", name)
	}
	m.active = name
	return nil
}

// Config returns config with active profile overlays.
func (m *Manager) Config() *config.Config {
	base := m.configGetter()
	return m.ActiveProfile().ApplyToConfig(base)
}

// List returns all profile names.
func (m *Manager) List() []AgentProfile {
	m.mu.RLock()
	defer m.mu.RUnlock()
	out := make([]AgentProfile, 0, len(m.profiles))
	for _, p := range m.profiles {
		out = append(out, p)
	}
	return out
}
