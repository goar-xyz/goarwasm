package agents

import "sync"

// Message is a multi-agent bus message.
type Message struct {
	From    string
	To      string
	Type    string
	Payload any
}

// MultiAgentBus is an in-process pub/sub for agent coordination.
type MultiAgentBus struct {
	mu   sync.Mutex
	subs map[string][]chan Message
	log  []Message
}

// NewMultiAgentBus creates a bus.
func NewMultiAgentBus() *MultiAgentBus {
	return &MultiAgentBus{subs: map[string][]chan Message{}}
}

// Subscribe registers a listener for a topic (or "*" for all).
func (b *MultiAgentBus) Subscribe(topic string, buf int) <-chan Message {
	b.mu.Lock()
	defer b.mu.Unlock()
	ch := make(chan Message, buf)
	b.subs[topic] = append(b.subs[topic], ch)
	return ch
}

// Publish sends a message to topic subscribers and "*".
func (b *MultiAgentBus) Publish(msg Message) {
	b.mu.Lock()
	defer b.mu.Unlock()
	b.log = append(b.log, msg)
	for _, topic := range []string{msg.Type, "*"} {
		for _, ch := range b.subs[topic] {
			select {
			case ch <- msg:
			default:
			}
		}
	}
}

// History returns published messages.
func (b *MultiAgentBus) History() []Message {
	b.mu.Lock()
	defer b.mu.Unlock()
	out := make([]Message, len(b.log))
	copy(out, b.log)
	return out
}
