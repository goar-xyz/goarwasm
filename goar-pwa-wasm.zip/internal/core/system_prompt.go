package core

import (
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"runtime"
	"strings"
	"time"

	"github.com/go-git/go-git/v5"
	"github.com/go-git/go-git/v5/plumbing/object"

	"github.com/goarxyz/goar/internal/core/prompts"
	"github.com/goarxyz/goar/internal/core/tools"
)

// ProjectContextProvider gathers git/project context for the system prompt.
type ProjectContextProvider struct {
	CommitCount int
	Timeout     time.Duration
	Workdir     string
}

// NewProjectContextProvider constructs a provider with defaults.
func NewProjectContextProvider(commitCount int, timeoutSec float64) *ProjectContextProvider {
	if commitCount <= 0 {
		commitCount = 5
	}
	d := time.Duration(timeoutSec * float64(time.Second))
	if d <= 0 {
		d = 2 * time.Second
	}
	wd, _ := os.Getwd()
	return &ProjectContextProvider{CommitCount: commitCount, Timeout: d, Workdir: wd}
}

func (p *ProjectContextProvider) runGit(args ...string) (string, error) {
	if runtime.GOOS == "js" {
		return "", fmt.Errorf("no local git binary under wasm")
	}
	cmd := exec.Command("git", args...)
	cmd.Dir = p.Workdir
	out, err := cmd.CombinedOutput()
	return string(out), err
}

// GetGitStatus returns a formatted git status block.
func (p *ProjectContextProvider) GetGitStatus() string {
	status, err := p.runGit("status", "-sb")
	if err != nil {
		return p.getGitStatusGoGit()
	}
	logOut, _ := p.runGit("log", fmt.Sprintf("-%d", p.CommitCount), "--oneline", "--decorate")
	if strings.TrimSpace(status) == "" && strings.TrimSpace(logOut) == "" {
		return p.getGitStatusGoGit()
	}
	return p.formatGitStatus(status, logOut)
}

func (p *ProjectContextProvider) formatGitStatus(status, logOut string) string {
	var b strings.Builder
	b.WriteString(strings.TrimSpace(status))
	b.WriteByte('\n')
	if strings.TrimSpace(logOut) != "" {
		b.WriteString("\nRecent commits:\n")
		b.WriteString(strings.TrimSpace(logOut))
		b.WriteByte('\n')
	}
	return b.String()
}

// GetFullContext returns workdir + git status.
func (p *ProjectContextProvider) GetFullContext() string {
	var b strings.Builder
	b.WriteString("Working directory: ")
	b.WriteString(p.Workdir)
	b.WriteByte('\n')
	if gs := p.GetGitStatus(); gs != "" {
		b.WriteString("\nGit status:\n")
		b.WriteString(gs)
	}
	return b.String()
}


func (p *ProjectContextProvider) getGitStatusGoGit() string {
	path := p.Workdir
	if path == "" {
		path, _ = os.Getwd()
	}
	repo, err := git.PlainOpenWithOptions(path, &git.PlainOpenOptions{DetectDotGit: true})
	if err != nil {
		home := strings.TrimSpace(os.Getenv("AGENT_HOME"))
		if home == "" {
			home = "/tmp/goar-agent-home"
		}
		for _, cand := range []string{filepath.Join(home, "workspace"), home} {
			repo, err = git.PlainOpenWithOptions(cand, &git.PlainOpenOptions{DetectDotGit: true})
			if err == nil {
				path = cand
				break
			}
		}
		if err != nil {
			return ""
		}
	}
	wt, err := repo.Worktree()
	if err != nil {
		return ""
	}
	st, err := wt.Status()
	if err != nil {
		return ""
	}
	head, _ := repo.Head()
	branch := "HEAD"
	if head != nil {
		branch = head.Name().Short()
	}
	var status strings.Builder
	status.WriteString("## " + branch + "\n")
	for f, s := range st {
		status.WriteString(fmt.Sprintf("%c%c %s\n", s.Staging, s.Worktree, f))
	}
	var logOut strings.Builder
	iter, err := repo.Log(&git.LogOptions{})
	if err == nil {
		defer iter.Close()
		n := 0
		_ = iter.ForEach(func(c *object.Commit) error {
			if n >= p.CommitCount {
				return fmt.Errorf("done")
			}
			msg := strings.Split(c.Message, "\n")[0]
			logOut.WriteString(c.Hash.String()[:7] + " " + msg + "\n")
			n++
			return nil
		})
	}
	_ = path
	return p.formatGitStatus(status.String(), logOut.String())
}

func getDefaultShell() string {
	if sh := os.Getenv("SHELL"); sh != "" {
		return sh
	}
	if runtime.GOOS == "windows" {
		return "powershell"
	}
	return "/bin/bash"
}

func getOSSystemPrompt() string {
	return fmt.Sprintf("OS: %s/%s\nShell: %s\n", runtime.GOOS, runtime.GOARCH, getDefaultShell())
}

func formatCurrentDate() string {
	return time.Now().Format("Monday, 2006-01-02")
}

func getWindowsSystemPrompt() string {
	if runtime.GOOS != "windows" {
		return ""
	}
	return "You are running on Windows. Prefer PowerShell-compatible commands when using the bash/shell tool; avoid Unix-only utilities unless Git Bash/WSL is available.\n"
}

func getWasmSSHSystemPrompt() string {
	if runtime.GOOS != "js" {
		return ""
	}
	host := strings.TrimSpace(os.Getenv("AGENT_SSH_HOST"))
	if host == "" {
		host = strings.TrimSpace(os.Getenv("AGENT_SSH_RECONNECT_HOST"))
	}
	if host != "" {
		return "\n## Browser / VPS\n" +
			"You run in the GOAR browser app. Shell work uses the **shared SSH PTY** to the user's VPS " +
			"(same session as the top-right Terminal). The human sees your commands and can type in that terminal.\n" +
			"SSH host is configured (" + host + "). Prefer `bash` for remote work.\n" +
			"read_file/write_file/search_replace still target browser MEMFS (AGENT_HOME), not the VPS disk — " +
			"use `bash` (cat/tee/heredoc) for remote files until SSH file tools land.\n"
	}
	return "\n## Browser / VPS\n" +
		"You run in the GOAR browser app. **SSH is not configured.** " +
		"Tell the user to open Settings (top-left) and add their VPS host/user/password or key. " +
		"Do not pretend local browser MEMFS is their VPS.\n"
}

func addCommitSignature(include bool) string {
	if !include {
		return ""
	}
	return "When creating git commits, include a short trailer: `Co-authored-by: Goar <goar@local>`.\n"
}

func getAvailableSkillsSection(skills []string) string {
	if len(skills) == 0 {
		return ""
	}
	var b strings.Builder
	b.WriteString("\n## Available skills\n")
	for _, s := range skills {
		b.WriteString("- ")
		b.WriteString(s)
		b.WriteByte('\n')
	}
	return b.String()
}

func getAvailableSubagentsSection(agents []string) string {
	if len(agents) == 0 {
		return ""
	}
	var b strings.Builder
	b.WriteString("\n## Available subagents\n")
	for _, a := range agents {
		b.WriteString("- ")
		b.WriteString(a)
		b.WriteByte('\n')
	}
	return b.String()
}

func getScratchpadSection(dir string) string {
	if dir == "" {
		return ""
	}
	return fmt.Sprintf("\n## Scratchpad\nSession scratchpad directory: %s\nUse it for ephemeral notes and intermediate artifacts.\n", dir)
}

func getHeadlessSection(headless bool) string {
	if !headless {
		return ""
	}
	return "\n## Mode\nRunning headless/programmatic. Prefer completing the task without interactive questions unless ask_user_question is necessary.\n"
}

func interpolatePrompt(base string, vars map[string]string) string {
	out := base
	for k, v := range vars {
		out = strings.ReplaceAll(out, "{{"+k+"}}", v)
		out = strings.ReplaceAll(out, "{"+k+"}", v)
	}
	return out
}

// SystemPromptOptions controls universal prompt assembly.
type SystemPromptOptions struct {
	PromptID              string
	Headless              bool
	Extra                 string
	IncludeProjectContext bool
	IncludeCommitSig      bool
	Skills                []string
	Subagents             []string
	ScratchpadDir         string
	CommitCount           int
	TimeoutSeconds        float64
}

// GetUniversalSystemPrompt assembles the full system prompt (Python get_universal_system_prompt).
func GetUniversalSystemPrompt(tm *tools.Manager, opt SystemPromptOptions) string {
	base, err := prompts.LoadSystemPrompt(opt.PromptID)
	if err != nil || base == "" {
		base, _ = prompts.LoadSystemPrompt("cli")
	}
	if base == "" {
		base = "You are Goar, an agentic CLI coding agent."
	}
	base = interpolatePrompt(base, map[string]string{
		"date":  formatCurrentDate(),
		"os":    runtime.GOOS,
		"shell": getDefaultShell(),
	})
	var b strings.Builder
	b.WriteString(base)
	b.WriteString("\n\n## Environment\n")
	b.WriteString(getOSSystemPrompt())
	b.WriteString("Date: ")
	b.WriteString(formatCurrentDate())
	b.WriteByte('\n')
	if w := getWindowsSystemPrompt(); w != "" {
		b.WriteString(w)
	}
	if w := getWasmSSHSystemPrompt(); w != "" {
		b.WriteString(w)
	}
	if tm != nil {
		b.WriteString("\n## Available tools\n")
		for _, t := range tm.List() {
			b.WriteString(fmt.Sprintf("- %s: %s\n", t.Name(), t.Description()))
		}
	}
	if opt.IncludeProjectContext {
		pc := NewProjectContextProvider(opt.CommitCount, opt.TimeoutSeconds)
		b.WriteString("\n## Project context\n")
		b.WriteString(pc.GetFullContext())
	}
	b.WriteString(getAvailableSkillsSection(opt.Skills))
	b.WriteString(getAvailableSubagentsSection(opt.Subagents))
	b.WriteString(getScratchpadSection(opt.ScratchpadDir))
	b.WriteString(addCommitSignature(opt.IncludeCommitSig))
	if opt.Extra != "" {
		b.WriteString(opt.Extra)
	}
	b.WriteString(getHeadlessSection(opt.Headless))
	b.WriteString("\n## Clock\n")
	b.WriteString(time.Now().Format(time.RFC3339))
	b.WriteByte('\n')
	return b.String()
}

// BuildSystemPrompt assembles the universal system prompt (compat wrapper).
func BuildSystemPrompt(tm *tools.Manager, promptID string, headless bool, extra string) string {
	return GetUniversalSystemPrompt(tm, SystemPromptOptions{
		PromptID: promptID, Headless: headless, Extra: extra, IncludeProjectContext: true, IncludeCommitSig: true,
	})
}
