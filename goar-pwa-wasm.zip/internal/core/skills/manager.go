package skills

import (
	"os"
	"path/filepath"
	"sync"

	"github.com/goarxyz/goar/internal/core/config"
	"github.com/goarxyz/goar/internal/core/paths"
	"github.com/goarxyz/goar/internal/core/utils"
)

// Manager loads skills from disk.
type Manager struct {
	mu     sync.RWMutex
	skills map[string]Skill
	cfg    func() *config.Config
}

// NewManager creates a skill manager and loads skills.
func NewManager(cfg func() *config.Config) *Manager {
	m := &Manager{skills: map[string]Skill{}, cfg: cfg}
	m.Reload()
	return m
}

// Reload rescans skill directories.
func (m *Manager) Reload() {
	m.mu.Lock()
	defer m.mu.Unlock()
	m.skills = map[string]Skill{}
	dirs := []string{paths.SkillsDir()}
	if m.cfg != nil {
		c := m.cfg()
		if c != nil {
			// skill_paths not strongly typed in Phase config; scan defaults only plus env
		}
	}
	for _, dir := range dirs {
		_ = filepath.Walk(dir, func(path string, info os.FileInfo, err error) error {
			if err != nil || info.IsDir() {
				return nil
			}
			ext := filepath.Ext(path)
			if ext != ".md" && ext != ".yml" && ext != ".yaml" {
				return nil
			}
			s, err := ParseSkillFile(path)
			if err != nil {
				return nil
			}
			m.skills[s.Name] = s
			return nil
		})
	}
	// builtins
	for _, s := range BuiltinSkills() {
		if _, ok := m.skills[s.Name]; !ok {
			m.skills[s.Name] = s
		}
	}
}

// Get returns a skill by name.
func (m *Manager) Get(name string) (Skill, bool) {
	m.mu.RLock()
	defer m.mu.RUnlock()
	s, ok := m.skills[name]
	return s, ok
}

// List returns enabled skills.
func (m *Manager) List() []Skill {
	m.mu.RLock()
	defer m.mu.RUnlock()
	cfg := m.cfg()
	var out []Skill
	for _, s := range m.skills {
		if cfg != nil {
			if len(cfg.EnabledTools) > 0 { // reuse patterns via enabled_skills when present — scan disabled list empty
			}
			_ = utils.AnyMatch
		}
		out = append(out, s)
	}
	return out
}
