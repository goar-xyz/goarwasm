package skills

import (
	"os"
	"path/filepath"
	"strings"

	"gopkg.in/yaml.v3"
)

// Skill is a named instruction pack (Python skills models).
type Skill struct {
	Name        string            `json:"name" yaml:"name"`
	Description string            `json:"description" yaml:"description"`
	Content     string            `json:"content" yaml:"content"`
	Path        string            `json:"path"`
	Metadata    map[string]string `json:"metadata" yaml:"metadata"`
	Source      string            `json:"source,omitempty" yaml:"source,omitempty"`
	Disabled    bool              `json:"disabled,omitempty" yaml:"disabled,omitempty"`
	Tags        []string          `json:"tags,omitempty" yaml:"tags,omitempty"`
}

// SkillFrontmatter is optional YAML front matter for SKILL.md files.
type SkillFrontmatter struct {
	Name        string            `yaml:"name"`
	Description string            `yaml:"description"`
	Metadata    map[string]string `yaml:"metadata"`
	Tags        []string          `yaml:"tags"`
	Disabled    bool              `yaml:"disabled"`
}

// ParseSkillMarkdown parses a SKILL.md with optional YAML front matter.
func ParseSkillMarkdown(path, raw string) Skill {
	s := Skill{Path: path, Metadata: map[string]string{}}
	content := raw
	if strings.HasPrefix(raw, "---") {
		rest := raw[3:]
		idx := strings.Index(rest, "\n---")
		if idx >= 0 {
			fmRaw := rest[:idx]
			content = strings.TrimPrefix(rest[idx+4:], "\n")
			var fm SkillFrontmatter
			if err := yaml.Unmarshal([]byte(fmRaw), &fm); err == nil {
				s.Name = fm.Name
				s.Description = fm.Description
				s.Metadata = fm.Metadata
				s.Tags = fm.Tags
				s.Disabled = fm.Disabled
			}
		}
	}
	s.Content = content
	if s.Name == "" {
		s.Name = strings.TrimSuffix(filepath.Base(path), filepath.Ext(path))
		if s.Name == "SKILL" || s.Name == "skill" {
			s.Name = filepath.Base(filepath.Dir(path))
		}
	}
	if s.Metadata == nil {
		s.Metadata = map[string]string{}
	}
	return s
}

// LoadSkillFile reads and parses a skill markdown file.
func LoadSkillFile(path string) (Skill, error) {
	b, err := os.ReadFile(path)
	if err != nil {
		return Skill{}, err
	}
	return ParseSkillMarkdown(path, string(b)), nil
}

// SkillRef is a lightweight listing row.
type SkillRef struct {
	Name        string
	Description string
	Path        string
	Source      string
}
