package builtins

// Goar returns the built-in goar skill (Python skills/builtins/goar.py).
func Goar() (name, description, content string) {
	return "goar",
		"Understand Goar internals: AGENT_HOME structure, config, agents, skills, tools. Use when the user asks how Goar works or needs to configure it.",
		"# Goar Self-Awareness\n" +
			"\n" +
			"You are Goar, an agentic CLI coding agent.\n" +
			"\n" +
			"## AGENT_HOME\n" +
			"\n" +
			"Defaults to `~/.agent`. Override with `AGENT_HOME` env var.\n" +
			"\n" +
			"```\n" +
			"~/.agent/\n" +
			"  config.toml          # Main config (TOML)\n" +
			"  .env                 # API keys (dotenv format)\n" +
			"  history              # Command history\n" +
			"  trusted_folders.toml # Trusted project dirs\n" +
			"  agents/              # Custom agent profiles (*.toml)\n" +
			"  prompts/             # Custom system prompts (*.md)\n" +
			"  skills/              # User skills (subdirs with SKILL.md)\n" +
			"  tools/               # Custom tools\n" +
			"  logs/\n" +
			"    agent.log          # Main log\n" +
			"    session/           # Per-session logs\n" +
			"  plans/               # Session plans\n" +
			"```\n" +
			"\n" +
			"## Project-local config\n" +
			"\n" +
			"In any trusted folder Goar also reads:\n" +
			"- `.agent/config.toml` — project config\n" +
			"- `.agent/skills/` — project skills\n" +
			"- `.agent/tools/` — project tools\n" +
			"- `.agent/agents/` — project agents\n" +
			"- `AGENTS.md` — agent instructions (read on every turn)\n" +
			"- `AGENT.md` — optional instruction file\n" +
			"\n" +
			"## Minimal config.toml\n" +
			"\n" +
			"```toml\n" +
			"active_model = \"my-model\"\n" +
			"default_agent = \"auto-approve\"\n" +
			"bypass_tool_permissions = true\n" +
			"\n" +
			"[[providers]]\n" +
			"name = \"my-provider\"\n" +
			"api_base = \"https://api.example.com/v1\"\n" +
			"api_key_env_var = \"OPENAI_API_KEY\"\n" +
			"backend = \"generic\"   # OpenAI-compatible\n" +
			"\n" +
			"[[models]]\n" +
			"name = \"my-model-id\"\n" +
			"provider = \"my-provider\"\n" +
			"alias = \"my-model\"\n" +
			"temperature = 0.6\n" +
			"```\n" +
			"\n" +
			"## Built-in agents\n" +
			"\n" +
			"| Agent | Behavior |\n" +
			"|-------|----------|\n" +
			"| `auto-approve` | Runs all tools without asking — default |\n" +
			"| `default` | Asks approval per tool |\n" +
			"| `accept-edits` | Auto-approves file edits only |\n" +
			"| `plan` | Read-only planning mode |\n" +
			"| `chat` | Conversational, no file edits |\n" +
			"| `explore` | Read-only subagent for codebase exploration |\n" +
			"\n" +
			"## Sub-agents\n" +
			"\n" +
			"Use the `task` tool to spawn a sub-agent:\n" +
			"```\n" +
			"task: \"Analyze auth module and return all public functions\"\n" +
			"```\n" +
			"\n" +
			"## Skills\n" +
			"\n" +
			"Each skill is a directory with a `SKILL.md`. Create one at:\n" +
			"`~/.agent/skills/my-skill/SKILL.md` or `.agent/skills/my-skill/SKILL.md`\n" +
			"\n" +
			"## MCP servers\n" +
			"\n" +
			"```toml\n" +
			"[[mcp_servers]]\n" +
			"name = \"filesystem\"\n" +
			"type = \"stdio\"\n" +
			"command = \"npx\"\n" +
			"args = [\"-y\", \"@modelcontextprotocol/server-filesystem\", \".\"]\n" +
			"```\n" +
			"\n"
}
