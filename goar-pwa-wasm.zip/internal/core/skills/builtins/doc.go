// Package builtins ships built-in GOAR skills (Python: goar.core.skills.builtins).
package builtins
