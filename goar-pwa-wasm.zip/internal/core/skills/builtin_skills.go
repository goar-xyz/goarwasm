package skills

import skillbuiltins "github.com/goarxyz/goar/internal/core/skills/builtins"

// BuiltinSkills returns shipped skills.
func BuiltinSkills() []Skill {
	n1, d1, c1 := skillbuiltins.Goar()
	n2, d2, c2 := skillbuiltins.AdaptiveEngineer()
	return []Skill{
		{Name: n1, Description: d1, Content: c1},
		{Name: n2, Description: d2, Content: c2},
	}
}
