// Package skills loads and manages agent skills.
package skills
