package skills

import (
	"os"
	"path/filepath"
	"strings"

	"gopkg.in/yaml.v3"
)

// ParseSkillFile loads a skill from a markdown/yaml file.
func ParseSkillFile(path string) (Skill, error) {
	b, err := os.ReadFile(path)
	if err != nil {
		return Skill{}, err
	}
	text := string(b)
	s := Skill{Path: path, Name: strings.TrimSuffix(filepath.Base(path), filepath.Ext(path))}
	if strings.HasPrefix(text, "---") {
		parts := strings.SplitN(text, "---", 3)
		if len(parts) >= 3 {
			meta := map[string]any{}
			_ = yaml.Unmarshal([]byte(parts[1]), &meta)
			if n, ok := meta["name"].(string); ok {
				s.Name = n
			}
			if d, ok := meta["description"].(string); ok {
				s.Description = d
			}
			s.Content = strings.TrimSpace(parts[2])
			s.Metadata = map[string]string{}
			for k, v := range meta {
				if str, ok := v.(string); ok {
					s.Metadata[k] = str
				}
			}
			return s, nil
		}
	}
	s.Content = text
	return s, nil
}
