package core

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"strings"
	"sync"
	"time"

	"github.com/goarxyz/goar/internal/core/agents"
	"github.com/goarxyz/goar/internal/core/config"
	"github.com/goarxyz/goar/internal/core/hooks"
	"github.com/goarxyz/goar/internal/core/llm"
	"github.com/goarxyz/goar/internal/core/llm/backend"
	"github.com/goarxyz/goar/internal/core/rewind"
	"github.com/goarxyz/goar/internal/core/session"
	"github.com/goarxyz/goar/internal/core/skills"
	"github.com/goarxyz/goar/internal/core/tools"
	"github.com/goarxyz/goar/internal/core/tools/builtins"
	"github.com/goarxyz/goar/internal/core/tools/connectors"
	"github.com/goarxyz/goar/internal/core/tools/mcp"
	"github.com/goarxyz/goar/internal/core/types"
	"github.com/goarxyz/goar/internal/core/utils"
	"github.com/google/uuid"
)

// ToolExecutionResponse is SKIP or EXECUTE.
type ToolExecutionResponse string

const (
	ToolExecSkip    ToolExecutionResponse = "skip"
	ToolExecExecute ToolExecutionResponse = "execute"
)

// ToolDecision is the verdict from permission / approval checks.
type ToolDecision struct {
	Verdict      ToolExecutionResponse
	ApprovalType tools.ToolPermission
	Feedback     string
}

// RuntimeError is the base runtime failure.
type RuntimeError struct{ Msg string }

func (e RuntimeError) Error() string { return e.Msg }

// RuntimeStateError is raised when the runtime is in an invalid state.
type RuntimeStateError struct{ Msg string }

func (e RuntimeStateError) Error() string { return e.Msg }

// RuntimeLLMResponseError is raised when the LLM response is malformed.
type RuntimeLLMResponseError struct{ Msg string }

func (e RuntimeLLMResponseError) Error() string { return e.Msg }

// ApprovalCallback asks the UI whether a tool may run.
type ApprovalCallback func(toolName string, args map[string]any, toolCallID string, required []tools.RequiredPermission) (types.ApprovalResponse, string)

// UserInputCallback asks the UI for free-form input.
type UserInputCallback func(prompt string) (string, error)

// EventHandler receives streaming events from ActStream.
type EventHandler func(Event) error

// Runtime is the GOAR agent engine (Python: GoarRuntime).
type Runtime struct {
	BaseConfig       *config.Config
	Config           *config.Config
	Backend          llm.BackendLike
	backendFactory   func() (llm.BackendLike, error)
	ToolManager      *tools.Manager
	AgentManager     *agents.Manager
	SkillManager     *skills.Manager
	SessionLogger    *session.Logger
	Orchestrator     *agents.ModelOrchestrator
	Bus              *agents.MultiAgentBus
	Hooks            *hooks.Manager
	HookConfigResult *hooks.HookConfigResult
	HookConfigIssues []string
	MCP              *mcp.Registry
	Connectors       *connectors.Registry
	PermissionStore  *tools.PermissionStore
	Rewind           *rewind.Manager
	Middleware       MiddlewarePipeline
	Messages         []LLMMessage
	Stats            AgentStats
	SessionID        string
	ParentSessionID  string
	Headless         bool
	EnableStreaming  bool
	IsSubagent       bool
	MaxTurns         int
	MaxPrice         float64
	MaxSessionTokens int
	ScratchpadDir    string
	ApprovalCallback ApprovalCallback
	UserInputCallback UserInputCallback
	SamplingHandler  *tools.MCPSamplingHandler
	messageObserver  func(LLMMessage)
	pendingInjected  []LLMMessage
	toolBreakers     map[string]*CircuitBreaker
	llmBreaker       *CircuitBreaker
	dlq              *DeadLetterQueue
	deferHeavyInit   bool
	initOnce         sync.Once
	initDone         chan struct{}
	initErr          error
	currentUserMsgID string
	isUserPromptCall bool
	mu               sync.Mutex
}

// RuntimeOptions configures runtime construction.
type RuntimeOptions struct {
	AgentName        string
	Headless         bool
	EnableStreaming  bool
	IsSubagent       bool
	DeferHeavyInit   bool
	MaxTurns         int
	MaxPrice         float64
	MaxSessionTokens int
	HookResult       *hooks.HookConfigResult
	Backend          llm.BackendLike
	PermissionStore  *tools.PermissionStore
	MCPRegistry      *mcp.Registry
	MessageObserver  func(LLMMessage)
}

// NewRuntime constructs a fully wired runtime (Python GoarRuntime.__init__).
func NewRuntime(cfg *config.Config, opt RuntimeOptions) (*Runtime, error) {
	if cfg == nil {
		return nil, fmt.Errorf("config required")
	}
	agentName := opt.AgentName
	if agentName == "" {
		agentName = cfg.DefaultAgent
	}
	permStore := opt.PermissionStore
	if permStore == nil {
		permStore = tools.NewPermissionStore()
	}
	mcpReg := opt.MCPRegistry
	if mcpReg == nil {
		mcpReg = mcp.NewRegistry()
	}
	tm := tools.NewManager()
	builtins.RegisterAll(tm)
	am := agents.NewManager(func() *config.Config { return cfg }, agentName, opt.IsSubagent)
	sm := skills.NewManager(func() *config.Config { return cfg })
	sid := session.GenerateSessionID()
	slog := session.NewLogger(cfg.SessionLogging, sid)
	var scratch string
	if !opt.IsSubagent {
		scratch, _ = InitScratchpad(sid)
	}
	backendFactory := func() (llm.BackendLike, error) {
		if opt.Backend != nil {
			return opt.Backend, nil
		}
		return backend.SelectBackend(cfg)
	}
	be, err := backendFactory()
	if err != nil {
		return nil, err
	}
	r := &Runtime{
		BaseConfig: cfg, Config: cfg, Backend: be, backendFactory: backendFactory,
		ToolManager: tm, AgentManager: am, SkillManager: sm,
		SessionLogger: slog, Orchestrator: agents.NewModelOrchestrator(), Bus: agents.NewMultiAgentBus(),
		MCP: mcpReg, Connectors: rCreateConnectors(cfg),
		PermissionStore: permStore, SessionID: sid, Headless: opt.Headless,
		EnableStreaming: opt.EnableStreaming, IsSubagent: opt.IsSubagent,
		MaxTurns: opt.MaxTurns, MaxPrice: opt.MaxPrice, MaxSessionTokens: opt.MaxSessionTokens,
		ScratchpadDir: scratch, messageObserver: opt.MessageObserver,
		toolBreakers: map[string]*CircuitBreaker{},
		llmBreaker:   NewCircuitBreaker(5, 60*time.Second),
		dlq:          NewDeadLetterQueue(filepath.Join(slog.SessionDir(), "dlq.json")),
		deferHeavyInit: opt.DeferHeavyInit,
		initDone:       make(chan struct{}),
		SamplingHandler: &tools.MCPSamplingHandler{},
	}
	if opt.HookResult != nil {
		r.HookConfigResult = opt.HookResult
		r.Hooks = hooks.NewManager(opt.HookResult.Hooks)
		r.HookConfigIssues = append(r.HookConfigIssues, opt.HookResult.Issues...)
	}
	r.Rewind = rewind.NewManager(&r.Messages, func(msgs []LLMMessage) error {
		return r.SessionLogger.PersistMessages(msgs)
	}, func() error {
		return r.resetSession(true)
	})
	r.setupMiddleware()
	sys := BuildSystemPrompt(tm, am.ActiveProfile().SystemPromptID, opt.Headless, r.Orchestrator.GetIntentContext())
	if scratch != "" {
		sys = GetUniversalSystemPrompt(tm, SystemPromptOptions{
			PromptID: am.ActiveProfile().SystemPromptID, Headless: opt.Headless,
			ScratchpadDir: scratch, IncludeProjectContext: !opt.DeferHeavyInit, IncludeCommitSig: true,
			Extra: r.Orchestrator.GetIntentContext(),
		})
	}
	r.Messages = []LLMMessage{NewMessage(RoleSystem, sys)}
	_ = r.SessionLogger.AppendMessage(r.Messages[0])
	if model, err := cfg.GetActiveModel(); err == nil {
		r.Stats.InputPricePerMillion = model.InputPrice
		r.Stats.OutputPricePerMillion = model.OutputPrice
	}
	go session.MigrateSessionsEntrypoint(cfg.SessionLogging)
	if opt.DeferHeavyInit {
		r.startDeferredInit()
	} else {
		close(r.initDone)
	}
	return r, nil
}

func rCreateConnectors(cfg *config.Config) *connectors.Registry {
	if cfg == nil || !cfg.EnableConnectors {
		return connectors.NewRegistry(false)
	}
	return connectors.NewRegistry(true)
}

func (r *Runtime) startDeferredInit() {
	r.initOnce.Do(func() {
		go func() {
			defer close(r.initDone)
			if err := r.ToolManager.IntegrateAll(); err != nil {
				r.initErr = err
				return
			}
			sys := GetUniversalSystemPrompt(r.ToolManager, SystemPromptOptions{
				PromptID: r.AgentManager.ActiveProfile().SystemPromptID, Headless: r.Headless,
				ScratchpadDir: r.ScratchpadDir, IncludeProjectContext: true, IncludeCommitSig: true,
			})
			r.updateSystemPrompt(sys)
		}()
	})
}

// WaitUntilReady awaits deferred MCP/connector initialization.
func (r *Runtime) WaitUntilReady(ctx context.Context) error {
	if !r.deferHeavyInit {
		return nil
	}
	r.startDeferredInit()
	select {
	case <-r.initDone:
		if r.initErr != nil {
			return r.initErr
		}
		return nil
	case <-ctx.Done():
		return ctx.Err()
	}
}

// IsInitialized reports whether deferred init finished.
func (r *Runtime) IsInitialized() bool {
	if !r.deferHeavyInit {
		return true
	}
	select {
	case <-r.initDone:
		return true
	default:
		return false
	}
}

// AgentProfile returns the active agent profile.
func (r *Runtime) AgentProfile() agents.AgentProfile { return r.AgentManager.ActiveProfile() }

// BypassToolPermissions reports whether approvals are skipped.
func (r *Runtime) BypassToolPermissions() bool {
	cfg := r.AgentManager.Config()
	return cfg != nil && cfg.BypassToolPermissions
}

// RefreshConfig reloads base config from disk.
func (r *Runtime) RefreshConfig() {
	r.BaseConfig = config.Default()
	// Invalidate by reconstructing overlays via AgentManager.Config()
}

func (r *Runtime) drainPendingInjections() bool {
	if len(r.pendingInjected) == 0 {
		return false
	}
	r.Messages = append(r.Messages, r.pendingInjected...)
	r.pendingInjected = nil
	return true
}

// SetApprovalCallback wires UI approval.
func (r *Runtime) SetApprovalCallback(cb ApprovalCallback) { r.ApprovalCallback = cb }

// SetUserInputCallback wires UI free-form input.
func (r *Runtime) SetUserInputCallback(cb UserInputCallback) { r.UserInputCallback = cb }

// SetToolPermission remembers a per-tool permission for this session.
func (r *Runtime) SetToolPermission(name string, perm tools.ToolPermission, savePermanently bool) {
	if r.PermissionStore == nil {
		r.PermissionStore = tools.NewPermissionStore()
	}
	r.PermissionStore.SetToolPermission(name, perm)
	_ = savePermanently
}

// ApproveAlways grants session (or permanent) approval for a tool.
func (r *Runtime) ApproveAlways(name string, required []tools.RequiredPermission, permanent bool) {
	if r.PermissionStore == nil {
		r.PermissionStore = tools.NewPermissionStore()
	}
	if len(required) > 0 {
		for _, rp := range required {
			r.PermissionStore.AddRule(tools.ApprovedRule{
				ToolName: name, Scope: rp.Scope, SessionPattern: rp.SessionPattern,
			})
		}
		_ = permanent
		return
	}
	r.SetToolPermission(name, tools.PermissionAlways, permanent)
}

// Close releases resources.
func (r *Runtime) Close() error {
	if r.MCP != nil {
		r.MCP.Close()
	}
	if r.Backend != nil {
		return r.Backend.Close()
	}
	return nil
}

// RefreshSystemPrompt rebuilds the system prompt from current tool/skill state.
func (r *Runtime) RefreshSystemPrompt(ctx context.Context) error {
	if err := r.WaitUntilReady(ctx); err != nil {
		return err
	}
	sys := GetUniversalSystemPrompt(r.ToolManager, SystemPromptOptions{
		PromptID: r.AgentManager.ActiveProfile().SystemPromptID, Headless: r.Headless,
		ScratchpadDir: r.ScratchpadDir, IncludeProjectContext: true, IncludeCommitSig: true,
	})
	r.updateSystemPrompt(sys)
	return nil
}

func (r *Runtime) updateSystemPrompt(sys string) {
	if len(r.Messages) == 0 {
		r.Messages = []LLMMessage{NewMessage(RoleSystem, sys)}
		return
	}
	msg := NewMessage(RoleSystem, sys)
	r.Messages[0] = msg
}

func (r *Runtime) saveMessages() error {
	return r.SessionLogger.PersistMessages(r.Messages)
}

// InjectUserContext appends a user (or injected) message.
func (r *Runtime) InjectUserContext(ctx context.Context, content string, asMessage bool) error {
	if err := r.WaitUntilReady(ctx); err != nil {
		return err
	}
	msg := NewMessage(RoleUser, content)
	if !asMessage {
		msg.Injected = true
	}
	r.Messages = append(r.Messages, msg)
	r.observe(msg)
	return r.saveMessages()
}

func (r *Runtime) observe(msg LLMMessage) {
	if r.messageObserver != nil {
		r.messageObserver(msg)
	}
}

func (r *Runtime) setupMiddleware() {
	r.Middleware.Clear()
	if r.MaxTurns > 0 {
		r.Middleware.Add(&TurnLimitMiddleware{MaxTurns: r.MaxTurns})
		r.Middleware.AddLegacy(MaxTurnsMiddleware{Max: r.MaxTurns})
	}
	if r.MaxPrice > 0 {
		r.Middleware.Add(&PriceLimitMiddleware{MaxPrice: r.MaxPrice})
		r.Middleware.AddLegacy(MaxPriceMiddleware{Max: r.MaxPrice})
	}
	if r.MaxSessionTokens > 0 {
		r.Middleware.Add(&TokenLimitMiddleware{MaxTokens: r.MaxSessionTokens})
		r.Middleware.AddLegacy(MaxTokensMiddleware{Max: r.MaxSessionTokens})
	}
	r.Middleware.Add(&AutoCompactMiddleware{})
	cfg := r.AgentManager.Config()
	if cfg != nil && cfg.ContextWarnings {
		r.Middleware.Add(NewContextWarningMiddleware(0.5))
	}
	r.Middleware.Add(&ReadOnlyAgentMiddleware{
		ProfileGetter: r.AgentManager.ActiveProfile,
		AgentName:     agents.AgentPlan,
		ReminderFn: func() string {
			planPath := filepath.Join(r.ScratchpadDir, "plan.md")
			if r.ScratchpadDir == "" {
				planPath = "plans/plan.md"
			}
			return MakePlanAgentReminder(planPath, true, true)
		},
		ExitMessage: PlanAgentExit,
	})
	r.Middleware.Add(&ReadOnlyAgentMiddleware{
		ProfileGetter: r.AgentManager.ActiveProfile,
		AgentName:     agents.AgentChat,
		Reminder:      ChatAgentReminder,
		ExitMessage:   ChatAgentExit,
	})
}

func (r *Runtime) getContext() ConversationContext {
	return ConversationContext{
		Messages: r.Messages,
		Stats:    &r.Stats,
		Config:   r.AgentManager.Config(),
	}
}

func (r *Runtime) getExtraHeaders(provider *config.ProviderConfig) map[string]string {
	cfg := r.AgentManager.Config()
	var p config.ProviderConfig
	var err error
	if provider != nil {
		p = *provider
	} else {
		p, err = cfg.GetActiveProvider()
		if err != nil {
			return map[string]string{"user-agent": utils.GetUserAgent("generic"), "x-affinity": r.SessionID}
		}
	}
	headers := map[string]string{}
	for k, v := range p.ExtraHeaders {
		headers[k] = v
	}
	headers["user-agent"] = utils.GetUserAgent(p.Backend)
	headers["x-affinity"] = r.SessionID
	return headers
}

// Act runs one user prompt through the agent loop until no more tool calls.
func (r *Runtime) Act(ctx context.Context, prompt string) (string, []Event, error) {
	var events []Event
	var last string
	err := r.ActStream(ctx, prompt, "", nil, func(ev Event) error {
		events = append(events, ev)
		if ev.Type == "assistant" && len(ev.Payload) > 0 {
			var ae AssistantEvent
			if json.Unmarshal(ev.Payload, &ae) == nil && ae.Content != "" {
				last = ae.Content
			} else {
				var m map[string]any
				if json.Unmarshal(ev.Payload, &m) == nil {
					if c, ok := m["content"].(string); ok {
						last = c
					}
				}
			}
		}
		return nil
	})
	return last, events, err
}

// ActStream runs the conversation loop, emitting events to handler (Python act / _conversation_loop).
func (r *Runtime) ActStream(ctx context.Context, prompt, clientMessageID string, autoTitle *string, handler EventHandler) error {
	if err := r.WaitUntilReady(ctx); err != nil {
		return err
	}
	r.cleanMessageHistory()
	r.Rewind.AddCheckpoint(clientMessageID, nil)

	user := NewMessage(RoleUser, prompt)
	if clientMessageID != "" {
		id := clientMessageID
		user.MessageID = &id
	}
	if user.MessageID == nil {
		id := uuid.NewString()
		user.MessageID = &id
	}
	r.Messages = append(r.Messages, user)
	r.observe(user)
	_ = r.SessionLogger.AppendMessage(user)
	r.Stats.Steps++
	r.currentUserMsgID = *user.MessageID
	r.Orchestrator.UpdateIntent(prompt, nil, "", nil)
	_ = session.WriteLastSession(r.SessionLogger.SessionDir())

	if handler != nil {
		ev, _ := NewEvent("user_message", map[string]any{"content": prompt, "message_id": *user.MessageID})
		if err := handler(ev); err != nil {
			return err
		}
	}
	if autoTitle != nil {
		if err := r.SessionLogger.SetInitialAutoTitle(*autoTitle); err == nil {
			if handler != nil {
				ev, _ := NewEvent("session_title_updated", map[string]any{"title": *autoTitle})
				_ = handler(ev)
			}
		}
	} else {
		_ = r.SessionLogger.SetTitle(session.AutoTitleFromPrompt(prompt), "auto")
	}

	defer func() { _ = r.saveMessages() }()

	firstLLMTurn := true
	for {
		if err := ctx.Err(); err != nil {
			return err
		}
		result := r.Middleware.RunBeforeTurn(r.getContext())
		if err := r.handleMiddlewareResult(ctx, result, handler); err != nil {
			return err
		}
		if result.Action == MiddlewareStop {
			return nil
		}
		// Also honor legacy Max* middleware.
		if stop, reason := r.Middleware.BeforeTurn(r.Messages, &r.Stats); stop {
			content := utils.WrapStopEvent(reason)
			ev, _ := NewEvent("assistant", AssistantEvent{Content: content, StoppedByMiddleware: true})
			if handler != nil {
				_ = handler(ev)
			}
			return nil
		}

		r.Stats.Steps++
		r.isUserPromptCall = firstLLMTurn
		firstLLMTurn = false
		userCancelled, err := r.performLLMTurn(ctx, handler)
		r.isUserPromptCall = false
		if err != nil {
			return err
		}
		_ = r.saveMessages()
		if userCancelled {
			return nil
		}
		shouldBreak := true
		if len(r.Messages) > 0 && r.Messages[len(r.Messages)-1].Role == RoleTool {
			shouldBreak = false
		}
		if r.drainPendingInjections() {
			shouldBreak = false
		}
		if shouldBreak {
			return nil
		}
		_ = r.Middleware.AfterTurn(r.Messages, &r.Stats)
	}
}

func (r *Runtime) handleMiddlewareResult(ctx context.Context, result MiddlewareResult, handler EventHandler) error {
	switch result.Action {
	case MiddlewareStop:
		content := utils.WrapStopEvent(result.Reason)
		ev, _ := NewEvent("assistant", AssistantEvent{Content: content, StoppedByMiddleware: true})
		if handler != nil {
			return handler(ev)
		}
	case MiddlewareInjectMessage:
		if result.Message != "" {
			msg := NewMessage(RoleUser, result.Message)
			msg.Injected = true
			r.Messages = append(r.Messages, msg)
			r.observe(msg)
		}
	case MiddlewareCompact:
		oldTokens := r.Stats.ContextTokens
		if v, ok := result.Metadata["old_tokens"].(int); ok {
			oldTokens = v
		}
		threshold := 0
		if v, ok := result.Metadata["threshold"].(int); ok {
			threshold = v
		}
		oldSessionID := r.SessionID
		toolCallID := uuid.NewString()
		if handler != nil {
			ev, _ := NewEvent("compact_start", map[string]any{
				"tool_call_id": toolCallID, "current_context_tokens": oldTokens, "threshold": threshold,
			})
			_ = handler(ev)
		}
		summary, err := r.Compact(ctx, "")
		if err != nil {
			return err
		}
		if handler != nil {
			ev, _ := NewEvent("compact_end", map[string]any{
				"tool_call_id": toolCallID, "summary_length": len(summary),
				"old_session_id": oldSessionID, "new_session_id": r.SessionID,
			})
			_ = handler(ev)
		}
	}
	return nil
}

func (r *Runtime) performLLMTurn(ctx context.Context, handler EventHandler) (userCancelled bool, err error) {
	if r.EnableStreaming {
		userCancelled, err = r.streamAssistantEvents(ctx, handler)
	} else {
		ev, e := r.getAssistantEvent(ctx)
		if e != nil {
			return false, e
		}
		if ev.Content != "" && handler != nil {
			nev, _ := NewEvent("assistant", ev)
			if err := handler(nev); err != nil {
				return false, err
			}
			if utils.IsUserCancellationEvent(ev.Content) {
				userCancelled = true
			}
		}
	}
	if err != nil || userCancelled {
		return userCancelled, err
	}
	last := r.Messages[len(r.Messages)-1]
	if len(last.ToolCalls) == 0 {
		return false, nil
	}
	profileBefore := r.AgentProfile().Name
	if err := r.handleToolCalls(ctx, last.ToolCalls, handler); err != nil {
		return false, err
	}
	if r.AgentProfile().Name != profileBefore && handler != nil {
		ev, _ := NewEvent("agent_profile_changed", map[string]any{"agent_name": r.AgentProfile().Name})
		_ = handler(ev)
	}
	return false, nil
}

func (r *Runtime) streamAssistantEvents(ctx context.Context, handler EventHandler) (bool, error) {
	cancelled := false
	err := r.chatStreaming(ctx, nil, func(chunk LLMChunk) error {
		msg := chunk.Message
		if msg.ReasoningContent != nil && *msg.ReasoningContent != "" && handler != nil {
			ev, _ := NewEvent("reasoning", map[string]any{
				"content": *msg.ReasoningContent, "message_id": msg.ReasoningMessageID,
			})
			if err := handler(ev); err != nil {
				return err
			}
		}
		content := msg.ContentString()
		if content != "" && handler != nil {
			ev, _ := NewEvent("assistant", AssistantEvent{Content: content, MessageID: msg.MessageID})
			if err := handler(ev); err != nil {
				return err
			}
			if utils.IsUserCancellationEvent(content) {
				cancelled = true
			}
		}
		for _, tc := range msg.ToolCalls {
			if tc.ID == "" || tc.Function.Name == "" {
				continue
			}
			if handler != nil {
				tev, _ := NewEvent("tool_call", ToolCallEvent{ToolCallID: tc.ID, Name: tc.Function.Name, ArgsJSON: tc.Function.Arguments})
				if err := handler(tev); err != nil {
					return err
				}
			}
		}
		return nil
	})
	return cancelled, err
}

func (r *Runtime) getAssistantEvent(ctx context.Context) (AssistantEvent, error) {
	chunk, err := r.chat(ctx, nil, nil)
	if err != nil {
		return AssistantEvent{}, err
	}
	return AssistantEvent{Content: chunk.Message.ContentString(), MessageID: chunk.Message.MessageID}, nil
}

func (r *Runtime) handleToolCalls(ctx context.Context, toolCalls []ToolCall, handler EventHandler) error {
	type result struct {
		idx int
		msg LLMMessage
		ev  Event
		err error
	}
	n := len(toolCalls)
	if n == 0 {
		return nil
	}
	// Emit tool_call events first.
	for _, tc := range toolCalls {
		if handler != nil {
			tev, _ := NewEvent("tool_call", ToolCallEvent{ToolCallID: tc.ID, Name: tc.Function.Name, ArgsJSON: tc.Function.Arguments})
			if err := handler(tev); err != nil {
				return err
			}
		}
	}
	ch := make(chan result, n)
	var wg sync.WaitGroup
	for i, tc := range toolCalls {
		wg.Add(1)
		go func(i int, tc ToolCall) {
			defer wg.Done()
			msg, ev, err := r.executeToolCall(ctx, tc)
			ch <- result{idx: i, msg: msg, ev: ev, err: err}
		}(i, tc)
	}
	go func() { wg.Wait(); close(ch) }()
	results := make([]result, n)
	for res := range ch {
		results[res.idx] = res
	}
	for _, res := range results {
		if res.err != nil && res.msg.Role == "" {
			r.Stats.ToolCallsFailed++
			errStr := res.err.Error()
			tc := toolCalls[res.idx]
			res.msg = LLMMessage{Role: RoleTool, Content: &errStr, ToolCallID: &tc.ID, Name: &tc.Function.Name}
		}
		r.Messages = append(r.Messages, res.msg)
		r.observe(res.msg)
		_ = r.SessionLogger.AppendMessage(res.msg)
		if handler != nil && res.ev.Type != "" {
			if err := handler(res.ev); err != nil {
				return err
			}
		}
	}
	return nil
}

func (r *Runtime) executeToolCall(ctx context.Context, tc ToolCall) (LLMMessage, Event, error) {
	args, err := llm.ParseToolArguments(tc.Function.Arguments)
	if err != nil {
		errMsg := utils.WrapToolError(fmt.Sprintf("%s: invalid arguments: %v", tc.Function.Name, err))
		msg := LLMMessage{Role: RoleTool, Content: &errMsg, ToolCallID: &tc.ID, Name: &tc.Function.Name}
		ev, _ := NewEvent("tool_result", ToolResultEvent{ToolCallID: tc.ID, Name: tc.Function.Name, ResultJSON: errMsg})
		r.Stats.ToolCallsFailed++
		return msg, ev, nil
	}
	cb := r.toolBreakers[tc.Function.Name]
	if cb == nil {
		cb = NewCircuitBreaker(5, 60*time.Second)
		r.toolBreakers[tc.Function.Name] = cb
	}
	if !cb.Allow() {
		errMsg := utils.WrapToolError(fmt.Sprintf("Circuit breaker OPEN for tool '%s'", tc.Function.Name))
		msg := LLMMessage{Role: RoleTool, Content: &errMsg, ToolCallID: &tc.ID, Name: &tc.Function.Name}
		ev, _ := NewEvent("tool_result", ToolResultEvent{ToolCallID: tc.ID, Name: tc.Function.Name, ResultJSON: errMsg})
		r.Stats.ToolCallsFailed++
		return msg, ev, nil
	}
	t, ok := r.ToolManager.Get(tc.Function.Name)
	if !ok {
		errMsg := utils.WrapToolError(fmt.Sprintf("unknown tool: %s", tc.Function.Name))
		msg := LLMMessage{Role: RoleTool, Content: &errMsg, ToolCallID: &tc.ID, Name: &tc.Function.Name}
		ev, _ := NewEvent("tool_result", ToolResultEvent{ToolCallID: tc.ID, Name: tc.Function.Name, ResultJSON: errMsg})
		r.Stats.ToolCallsFailed++
		return msg, ev, nil
	}
	if r.Hooks != nil {
		results := r.Hooks.RunEvent(ctx, hooks.EventPreToolUse, tc.Function.Name, map[string]any{"tool": tc.Function.Name, "args": args})
		if blocked, msgText := hooks.AnyBlocked(results); blocked {
			r.Stats.ToolCallsRejected++
			errMsg := utils.WrapToolError("blocked by hook: " + msgText)
			msg := LLMMessage{Role: RoleTool, Content: &errMsg, ToolCallID: &tc.ID, Name: &tc.Function.Name}
			ev, _ := NewEvent("tool_result", ToolResultEvent{ToolCallID: tc.ID, Name: tc.Function.Name, ResultJSON: errMsg})
			return msg, ev, nil
		}
	}
	decision, err := r.shouldExecuteTool(ctx, t, args, tc.ID)
	if err != nil {
		return LLMMessage{}, Event{}, err
	}
	if decision.Verdict == ToolExecSkip {
		r.Stats.ToolCallsRejected++
		skip := decision.Feedback
		if skip == "" {
			skip = utils.GetUserCancellationMessage(utils.CancelToolSkipped, tc.Function.Name)
		}
		msg := LLMMessage{Role: RoleTool, Content: &skip, ToolCallID: &tc.ID, Name: &tc.Function.Name}
		ev, _ := NewEvent("tool_result", ToolResultEvent{ToolCallID: tc.ID, Name: tc.Function.Name, ResultJSON: skip})
		return msg, ev, nil
	}
	r.Stats.ToolCallsAgreed++
	if snapper, ok := t.(tools.SnapshotableTool); ok {
		if snap := snapper.GetFileSnapshot(args); snap != nil {
			r.Rewind.AddCheckpoint(tc.ID, []rewind.FileSnapshot{*snap})
		}
	}
	start := time.Now()
	inv := &tools.InvokeContext{
		ToolCallID: tc.ID, SessionDir: r.SessionLogger.SessionDir(), ScratchpadDir: r.ScratchpadDir,
		Config: r.AgentManager.Config(), PermissionStore: r.PermissionStore,
		ApprovalCallback: func(toolName string, a map[string]any, id string, req []tools.RequiredPermission) (string, string) {
			if r.ApprovalCallback == nil {
				return string(types.ApprovalNo), "Tool execution not permitted."
			}
			resp, fb := r.ApprovalCallback(toolName, a, id, req)
			return string(resp), fb
		},
		UserInput:         r.UserInputCallback,
		UserInputCallback: r.UserInputCallback,
		SwitchAgent: func(name string) error { return r.SwitchAgent(ctx, name) },
	}
	result, runErr := t.Run(ctx, args, inv)
	if r.Hooks != nil {
		r.Hooks.RunEvent(ctx, hooks.EventPostToolUse, tc.Function.Name, map[string]any{
			"tool": tc.Function.Name, "result": result, "error": fmt.Sprint(runErr),
		})
	}
	if runErr != nil {
		cb.Failure()
		r.dlq.Add(map[string]any{"tool": tc.Function.Name, "args": args, "error": runErr.Error()})
		var permErr *tools.ToolPermissionError
		if errors.As(runErr, &permErr) {
			r.Stats.ToolCallsAgreed--
			r.Stats.ToolCallsRejected++
		} else {
			r.Stats.ToolCallsFailed++
		}
		errMsg := utils.WrapToolError(fmt.Sprintf("%s failed: %v", t.Name(), runErr))
		msg := LLMMessage{Role: RoleTool, Content: &errMsg, ToolCallID: &tc.ID, Name: &tc.Function.Name}
		ev, _ := NewEvent("tool_result", ToolResultEvent{ToolCallID: tc.ID, Name: tc.Function.Name, ResultJSON: errMsg})
		return msg, ev, nil
	}
	cb.Success()
	r.Stats.ToolCallsSucceeded++
	content := tools.ResultText(result)
	if extra, ok := t.(tools.ResultExtraTool); ok {
		if e := extra.GetResultExtra(result); e != "" {
			content += "\n\n" + e
		}
	}
	_ = start
	msg := LLMMessage{Role: RoleTool, Content: &content, ToolCallID: &tc.ID, Name: &tc.Function.Name}
	ev, _ := NewEvent("tool_result", ToolResultEvent{
		ToolCallID: tc.ID, Name: tc.Function.Name, ResultJSON: content,
	})
	return msg, ev, nil
}

func (r *Runtime) shouldExecuteTool(ctx context.Context, t tools.Tool, args map[string]any, toolCallID string) (ToolDecision, error) {
	_ = ctx
	if r.BypassToolPermissions() {
		return ToolDecision{Verdict: ToolExecExecute, ApprovalType: tools.PermissionAlways}, nil
	}
	r.PermissionStore.Lock()
	defer r.PermissionStore.Unlock()
	toolName := t.Name()
	var pctx *tools.PermissionContext
	if rr, ok := t.(tools.PermissionResolvableTool); ok {
		pctx = rr.ResolvePermission(args)
	}
	if pctx == nil {
		pctx = &tools.PermissionContext{Permission: t.Permission()}
	}
	switch pctx.Permission {
	case tools.PermissionAlways:
		return ToolDecision{Verdict: ToolExecExecute, ApprovalType: tools.PermissionAlways}, nil
	case tools.PermissionNever:
		fb := pctx.Reason
		if fb == "" {
			fb = fmt.Sprintf("Tool '%s' is permanently disabled", toolName)
		}
		return ToolDecision{Verdict: ToolExecSkip, ApprovalType: tools.PermissionNever, Feedback: fb}, nil
	default:
		var uncovered []tools.RequiredPermission
		for _, rp := range pctx.RequiredPermissions {
			if !r.PermissionStore.Covers(toolName, rp) {
				uncovered = append(uncovered, rp)
			}
		}
		if len(pctx.RequiredPermissions) > 0 && len(uncovered) == 0 {
			return ToolDecision{Verdict: ToolExecExecute, ApprovalType: tools.PermissionAlways}, nil
		}
		return r.askApproval(toolName, args, toolCallID, uncovered)
	}
}

func (r *Runtime) askApproval(toolName string, args map[string]any, toolCallID string, required []tools.RequiredPermission) (ToolDecision, error) {
	if r.ApprovalCallback == nil {
		return ToolDecision{
			Verdict: ToolExecSkip, ApprovalType: tools.PermissionAsk,
			Feedback: "Tool execution not permitted.",
		}, nil
	}
	resp, feedback := r.ApprovalCallback(toolName, args, toolCallID, required)
	verdict := ToolExecSkip
	if resp == types.ApprovalYes {
		verdict = ToolExecExecute
	}
	return ToolDecision{Verdict: verdict, ApprovalType: tools.PermissionAsk, Feedback: feedback}, nil
}

func (r *Runtime) prepareChat() {
	intent := r.Orchestrator.GetIntentContext()
	if intent == "" || len(r.Messages) == 0 {
		return
	}
	base := r.Messages[0].ContentString()
	if !strings.Contains(base, "=== CURRENT INTENT ===") {
		r.updateSystemPrompt(base + "\n" + intent)
		return
	}
	clean := strings.TrimSpace(strings.Split(base, "=== CURRENT INTENT ===")[0])
	r.updateSystemPrompt(clean + "\n" + intent)
}

func (r *Runtime) chat(ctx context.Context, maxTokens *int, modelOverride *config.ModelConfig) (LLMChunk, error) {
	_ = ctx
	r.prepareChat()
	cfg := r.AgentManager.Config()
	var model config.ModelConfig
	var err error
	if modelOverride != nil {
		model = *modelOverride
	} else {
		model, err = cfg.GetActiveModel()
		if err != nil {
			return LLMChunk{}, err
		}
	}
	provider, err := cfg.GetProviderForModel(model)
	if err != nil {
		return LLMChunk{}, err
	}
	if !r.llmBreaker.Allow() {
		return LLMChunk{}, RuntimeError{Msg: "LLM circuit breaker open"}
	}
	toolsSchema := r.ToolManager.AvailableTools(cfg.EnabledTools, cfg.DisabledTools)
	avail := make([]AvailableTool, 0, len(toolsSchema))
	for _, t := range toolsSchema {
		b, _ := json.Marshal(t)
		var at AvailableTool
		_ = json.Unmarshal(b, &at)
		avail = append(avail, at)
	}
	req := llm.CompleteRequest{
		ModelName: model.Name, Messages: r.Messages, Temperature: model.Temperature,
		Tools: avail, APIBase: provider.APIBase, APIKey: cfg.APIKey(provider),
		APIStyle: provider.APIStyle, TimeoutSec: cfg.APITimeout, ExtraHeaders: r.getExtraHeaders(&provider),
		MaxTokens: maxTokens,
	}
	start := time.Now()
	chunk, err := r.Backend.Complete(req)
	if err != nil {
		r.llmBreaker.Failure()
		return LLMChunk{}, r.mapLLMError(err, provider.Name, model.Name)
	}
	r.llmBreaker.Success()
	if chunk.Usage == nil {
		return LLMChunk{}, RuntimeLLMResponseError{Msg: "Usage data missing in non-streaming completion response"}
	}
	r.updateStats(*chunk.Usage, time.Since(start).Seconds())
	msg := chunk.Message
	if msg.Role == "" {
		msg.Role = RoleAssistant
	}
	r.Messages = append(r.Messages, msg)
	r.observe(msg)
	_ = r.SessionLogger.AppendMessage(msg)
	return LLMChunk{Message: msg, Usage: chunk.Usage}, nil
}

func (r *Runtime) chatStreaming(ctx context.Context, maxTokens *int, emit func(LLMChunk) error) error {
	_ = ctx
	r.prepareChat()
	cfg := r.AgentManager.Config()
	model, err := cfg.GetActiveModel()
	if err != nil {
		return err
	}
	provider, err := cfg.GetActiveProvider()
	if err != nil {
		return err
	}
	toolsSchema := r.ToolManager.AvailableTools(cfg.EnabledTools, cfg.DisabledTools)
	avail := make([]AvailableTool, 0, len(toolsSchema))
	for _, t := range toolsSchema {
		b, _ := json.Marshal(t)
		var at AvailableTool
		_ = json.Unmarshal(b, &at)
		avail = append(avail, at)
	}
	req := llm.CompleteRequest{
		ModelName: model.Name, Messages: r.Messages, Temperature: model.Temperature,
		Tools: avail, APIBase: provider.APIBase, APIKey: cfg.APIKey(provider),
		APIStyle: provider.APIStyle, TimeoutSec: cfg.APITimeout, ExtraHeaders: r.getExtraHeaders(&provider),
		MaxTokens: maxTokens,
	}
	start := time.Now()
	usage := types.LLMUsage{}
	var agg *LLMMessage
	err = r.Backend.CompleteStreaming(req, func(chunk types.LLMChunk) error {
		msg := chunk.Message
		if agg == nil {
			cp := msg
			agg = &cp
		} else {
			if msg.Content != nil {
				cur := agg.ContentString() + *msg.Content
				agg.Content = &cur
			}
			if msg.ReasoningContent != nil {
				cur := ""
				if agg.ReasoningContent != nil {
					cur = *agg.ReasoningContent
				}
				cur += *msg.ReasoningContent
				agg.ReasoningContent = &cur
			}
			if len(msg.ToolCalls) > 0 {
				agg.ToolCalls = append(agg.ToolCalls, msg.ToolCalls...)
			}
		}
		if chunk.Usage != nil {
			usage = usage.Add(*chunk.Usage)
		}
		return emit(LLMChunk{Message: msg, Usage: chunk.Usage})
	})
	if err != nil {
		r.llmBreaker.Failure()
		return r.mapLLMError(err, provider.Name, model.Name)
	}
	if agg == nil {
		return RuntimeLLMResponseError{Msg: "Usage data missing in final chunk of streamed completion"}
	}
	r.updateStats(usage, time.Since(start).Seconds())
	if agg.Role == "" {
		agg.Role = RoleAssistant
	}
	r.Messages = append(r.Messages, *agg)
	r.observe(*agg)
	_ = r.SessionLogger.AppendMessage(*agg)
	return nil
}

func (r *Runtime) mapLLMError(err error, provider, model string) error {
	if llm.ShouldRaiseRateLimitError(err) {
		return llm.RateLimitError{Provider: provider, Model: model, Cause: err}
	}
	if llm.IsContextTooLongError(err) {
		return llm.ContextTooLongError{Provider: provider, Model: model, Cause: err}
	}
	if llm.IsNonRetryableError(err) {
		return err
	}
	return fmt.Errorf("API error from %s (model: %s): %w", provider, model, err)
}

func (r *Runtime) updateStats(usage types.LLMUsage, seconds float64) {
	r.Stats.LastTurnDuration = seconds
	r.Stats.LastTurnPromptTokens = usage.PromptTokens
	r.Stats.LastTurnCompletionTokens = usage.CompletionTokens
	r.Stats.SessionPromptTokens += usage.PromptTokens
	r.Stats.SessionCompletionTokens += usage.CompletionTokens
	r.Stats.ContextTokens = usage.PromptTokens + usage.CompletionTokens
	if seconds > 0 && usage.CompletionTokens > 0 {
		r.Stats.TokensPerSecond = float64(usage.CompletionTokens) / seconds
	}
}

func (r *Runtime) cleanMessageHistory() {
	if len(r.Messages) < 2 {
		return
	}
	r.fillMissingToolResponses()
}

func (r *Runtime) fillMissingToolResponses() {
	i := 1
	for i < len(r.Messages) {
		msg := r.Messages[i]
		if msg.Role == RoleAssistant && len(msg.ToolCalls) > 0 {
			expected := len(msg.ToolCalls)
			responded := map[string]bool{}
			j := i + 1
			for j < len(r.Messages) && r.Messages[j].Role == RoleTool {
				if r.Messages[j].ToolCallID != nil {
					responded[*r.Messages[j].ToolCallID] = true
				}
				j++
			}
			if len(responded) < expected {
				insertion := j
				for _, tc := range msg.ToolCalls {
					id := tc.ID
					if responded[id] {
						continue
					}
					content := utils.GetUserCancellationMessage(utils.CancelToolNoResponse)
					name := ""
					if tc.Function.Name != "" {
						name = tc.Function.Name
					}
					empty := LLMMessage{Role: RoleTool, Content: &content, ToolCallID: &id, Name: &name}
					r.Messages = append(r.Messages[:insertion], append([]LLMMessage{empty}, r.Messages[insertion:]...)...)
					insertion++
				}
			}
			i = i + 1 + expected
			continue
		}
		i++
	}
}

func (r *Runtime) resetSession(keepParent bool) error {
	old := r.SessionID
	suffix := session.ExtractSuffix(r.SessionID)
	r.SessionID = session.GenerateSessionIDWithSuffix(suffix)
	parent := ""
	if keepParent {
		parent = old
		r.ParentSessionID = old
	} else {
		r.ParentSessionID = ""
	}
	return r.SessionLogger.ResetSession(r.SessionID, parent)
}

// Fork creates a child runtime branched from messageID (or full history).
func (r *Runtime) Fork(ctx context.Context, messageID string) (*Runtime, error) {
	msgs, err := r.messagesForFork(messageID)
	if err != nil {
		return nil, err
	}
	cfgCopy := *r.BaseConfig
	forked, err := NewRuntime(&cfgCopy, RuntimeOptions{
		AgentName: r.AgentProfile().Name, EnableStreaming: r.EnableStreaming,
		DeferHeavyInit: true, HookResult: r.HookConfigResult,
	})
	if err != nil {
		return nil, err
	}
	forked.SessionID = session.GenerateSessionIDWithSuffix(session.ExtractSuffix(r.SessionID))
	forked.ParentSessionID = r.SessionID
	_ = forked.SessionLogger.ResetSession(forked.SessionID, r.SessionID)
	forked.Messages = append(forked.Messages, msgs...)
	_ = forked.SessionLogger.PersistMessages(forked.Messages)
	_ = ctx
	return forked, nil
}

func (r *Runtime) messagesForFork(messageID string) ([]LLMMessage, error) {
	var source []LLMMessage
	for _, m := range r.Messages {
		if m.Role != RoleSystem {
			source = append(source, m)
		}
	}
	if messageID == "" {
		out := make([]LLMMessage, len(source))
		copy(out, source)
		return out, nil
	}
	anchor := -1
	for i, m := range source {
		if m.MessageID != nil && *m.MessageID == messageID {
			anchor = i
			break
		}
	}
	if anchor < 0 {
		return nil, fmt.Errorf("Cannot fork from unknown message_id: %s", messageID)
	}
	if source[anchor].Role != RoleUser {
		return nil, fmt.Errorf("Fork from message_id is only supported for user messages")
	}
	next := len(source)
	for i := anchor + 1; i < len(source); i++ {
		if source[i].Role == RoleUser {
			next = i
			break
		}
	}
	out := make([]LLMMessage, next)
	copy(out, source[:next])
	return out, nil
}

// ClearHistory resets conversation to the system prompt and starts a new session.
func (r *Runtime) ClearHistory(ctx context.Context) error {
	if err := r.WaitUntilReady(ctx); err != nil {
		return err
	}
	_ = r.saveMessages()
	if len(r.Messages) > 0 {
		r.Messages = r.Messages[:1]
	}
	r.Stats = types.CreateFreshStats(r.Stats)
	if model, err := r.AgentManager.Config().GetActiveModel(); err == nil {
		r.Stats.UpdatePricing(model.InputPrice, model.OutputPrice)
	}
	r.Middleware.Reset(ResetStop)
	return r.resetSession(false)
}

// Compact summarizes history and resets the session (Python compact).
func (r *Runtime) Compact(ctx context.Context, extraInstructions string) (string, error) {
	if err := r.WaitUntilReady(ctx); err != nil {
		return "", err
	}
	r.cleanMessageHistory()
	_ = r.saveMessages()
	summaryRequest := r.BaseConfig.CompactionPrompt
	if summaryRequest == "" {
		summaryRequest, _ = CompactMessages(r.Messages)
	}
	if extraInstructions != "" {
		summaryRequest += "\n\n## Additional Instructions\n" + extraInstructions
	}
	summaryPrefix := "Conversation summary:"
	r.Stats.Steps++
	r.Messages = append(r.Messages, NewMessage(RoleUser, summaryRequest))
	chunk, err := r.chat(ctx, nil, nil)
	if err != nil {
		_ = r.saveMessages()
		return "", err
	}
	summary := strings.TrimSpace(chunk.Message.ContentString())
	if summary == "" {
		summary = "(no summary available)"
	}
	system := r.Messages[0]
	wrapped := summaryPrefix + "\n" + summary
	summaryMsg := NewMessage(RoleUser, wrapped)
	summaryMsg.Injected = true
	r.Messages = []LLMMessage{system, summaryMsg}
	_ = r.resetSession(true)
	r.Stats.ContextTokens = 0
	_ = r.saveMessages()
	r.Middleware.Reset(ResetCompact)
	return summary, nil
}

// SwitchAgent changes the active agent profile and reloads the system prompt.
func (r *Runtime) SwitchAgent(ctx context.Context, agentName string) error {
	if err := r.WaitUntilReady(ctx); err != nil {
		return err
	}
	if agentName == r.AgentProfile().Name {
		return nil
	}
	if err := r.AgentManager.Switch(agentName); err != nil {
		return err
	}
	return r.ReloadWithInitialMessages(ctx, nil, nil, nil, false)
}

// ReloadWithInitialMessages rebuilds tools/skills/system prompt after config/agent changes.
func (r *Runtime) ReloadWithInitialMessages(ctx context.Context, base *config.Config, maxTurns, maxPrice *float64, resetMiddleware bool) error {
	_ = ctx
	_ = r.saveMessages()
	if base != nil {
		r.BaseConfig = base
	}
	if be, err := r.backendFactory(); err == nil {
		r.Backend = be
	}
	if maxTurns != nil {
		r.MaxTurns = int(*maxTurns)
	}
	if maxPrice != nil {
		r.MaxPrice = *maxPrice
	}
	r.ToolManager = tools.NewManager()
	builtins.RegisterAll(r.ToolManager)
	r.SkillManager = skills.NewManager(func() *config.Config { return r.BaseConfig })
	sys := GetUniversalSystemPrompt(r.ToolManager, SystemPromptOptions{
		PromptID: r.AgentManager.ActiveProfile().SystemPromptID, Headless: r.Headless,
		ScratchpadDir: r.ScratchpadDir, IncludeProjectContext: true, IncludeCommitSig: true,
	})
	r.updateSystemPrompt(sys)
	if len(r.Messages) == 1 {
		r.Stats.ResetContextState()
	}
	if model, err := r.AgentManager.Config().GetActiveModel(); err == nil {
		r.Stats.UpdatePricing(model.InputPrice, model.OutputPrice)
	}
	if resetMiddleware {
		r.setupMiddleware()
	}
	return nil
}

// LastUserMessage returns the last non-injected user message.
func (r *Runtime) LastUserMessage() *LLMMessage {
	for i := len(r.Messages) - 1; i >= 0; i-- {
		m := r.Messages[i]
		if m.Role == RoleUser && !m.Injected {
			cp := m
			return &cp
		}
	}
	return nil
}

// EnsureScratchpad creates the scratchpad if missing (subagent-safe).
func (r *Runtime) EnsureScratchpad() string {
	if r.ScratchpadDir != "" {
		return r.ScratchpadDir
	}
	dir, _ := InitScratchpad(r.SessionID)
	r.ScratchpadDir = dir
	_ = os.MkdirAll(dir, 0o755)
	return dir
}
