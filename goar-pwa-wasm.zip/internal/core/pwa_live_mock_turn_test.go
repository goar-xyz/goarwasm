package core_test

import (
	"context"
	"net/http"
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"

	"github.com/goarxyz/goar/internal/core"
	"github.com/goarxyz/goar/internal/core/config"
)

// TestPWARuntimeLiveMockTurn drives the same agent runtime path the PWA uses
// (core.NewRuntime / RunProgrammatic ← goar.runAgent) against the shared mock
// OpenAI server at 127.0.0.1:18080.
func TestPWARuntimeLiveMockTurn(t *testing.T) {
	base := "http://127.0.0.1:18080/v1"
	client := &http.Client{Timeout: 2 * time.Second}
	resp, err := client.Get(base + "/models")
	if err != nil {
		t.Skipf("mock openai not reachable at %s: %v", base, err)
	}
	resp.Body.Close()
	if resp.StatusCode != 200 {
		t.Skipf("mock openai /models status %d", resp.StatusCode)
	}

	home := t.TempDir()
	t.Setenv("AGENT_HOME", home)
	t.Setenv("OPENAI_API_KEY", "mock")
	t.Setenv("OPENAI_BASE_URL", base)
	t.Setenv("OPENAI_MODEL", "mock-goar")
	t.Setenv("COLORTERM", "truecolor")

	// Mirror cmd/goar-wasm buildMemConfig defaults used by goar.runAgent.
	cfg := &config.Config{
		ActiveModel:           "mock-goar",
		Theme:                 "goar-dark",
		SystemPromptID:        "cli",
		APITimeout:            30,
		BypassToolPermissions: true,
		DefaultAgent:          "chat",
		IncludeProjectContext: false,
		Providers: []config.ProviderConfig{{
			Name: "openai", APIBase: base, APIKeyEnvVar: "OPENAI_API_KEY",
			APIStyle: "openai", Backend: "generic",
		}},
		Models: []config.ModelConfig{{
			Name: "mock-goar", Provider: "openai", Alias: "mock-goar", Temperature: 0, Thinking: "off",
		}},
		SessionLogging: config.SessionLoggingConfig{
			Enabled: false, SaveDir: filepath.Join(home, "logs"),
		},
	}
	_ = os.MkdirAll(filepath.Join(home, "logs"), 0o755)

	text, err := core.RunProgrammatic(context.Background(), cfg, "pwa live turn proof ping", core.RuntimeOptions{
		AgentName: "chat", Headless: true, MaxTurns: 2,
	})
	if err != nil {
		t.Fatalf("RunProgrammatic (PWA runAgent path): %v", err)
	}
	if !strings.Contains(text, liveMarker) {
		t.Fatalf("expected marker %q in assistant text, got %q", liveMarker, text)
	}
	t.Logf("assistant: %s", text)
}
