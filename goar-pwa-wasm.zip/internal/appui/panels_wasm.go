//go:build js && wasm

package appui

import (
	"syscall/js"
)

func (a *App) showSettings() {
	box := byID("settings")
	if !box.Truthy() {
		// legacy fallback panel
		p := byID("settings-panel")
		if p.Truthy() {
			a.showSettingsLegacy(p)
		}
		return
	}
	cfg := a.cfg
	if cfg == nil {
		cfg = &AppConfig{WispURL: defaultWisp}
	}
	pkey, apiKey, base, model := "openai", "", "", ""
	if cfg.Provider != nil {
		pkey, apiKey, base, model = cfg.Provider.Key, cfg.Provider.APIKey, cfg.Provider.BaseURL, cfg.Provider.Model
	}
	prov := byID("provider")
	if prov.Truthy() {
		clear(prov)
		for _, pr := range providers() {
			o := el("option")
			o.Set("value", pr.Key)
			setText(o, pr.Name)
			appendChild(prov, o)
		}
		prov.Set("value", pkey)
	}
	if byID("apiKey").Truthy() {
		byID("apiKey").Set("value", apiKey)
	}
	if byID("apiBase").Truthy() {
		// API base stays hidden; auto-filled from provider catalog / saved config.
		if base != "" {
			byID("apiBase").Set("value", base)
		}
	}
	if byID("apiModel").Truthy() {
		sel := byID("apiModel")
		clear(sel)
		if model != "" {
			o := el("option")
			o.Set("value", model)
			setText(o, model)
			appendChild(sel, o)
			sel.Set("value", model)
		} else {
			o := el("option")
			o.Set("value", "")
			setText(o, "Loading…")
			appendChild(sel, o)
		}
	}
	host, user, pass, secret := DefaultSSHHost, DefaultSSHUser, DefaultSSHPass, ""
	port := DefaultSSHPorts[0]
	if cfg != nil && cfg.SSH != nil {
		if cfg.SSH.Host != "" {
			host = cfg.SSH.Host
		}
		if cfg.SSH.User != "" {
			user = cfg.SSH.User
		}
		if cfg.SSH.Password != "" || cfg.SSH.PrivateKey != "" {
			pass = cfg.SSH.Password
		}
		secret = cfg.SSH.Secret
		if cfg.SSH.Port > 0 {
			port = cfg.SSH.Port
		}
	}
	if byID("sshHost").Truthy() {
		byID("sshHost").Set("value", host)
	}
	if byID("sshPort").Truthy() {
		byID("sshPort").Set("value", itoa(port))
	}
	if byID("sshUser").Truthy() {
		byID("sshUser").Set("value", user)
	}
	if byID("sshPassword").Truthy() {
		byID("sshPassword").Set("value", pass)
	}
	if byID("sshSecret").Truthy() {
		byID("sshSecret").Set("value", secret)
	}
	if byID("sshPrivateKey").Truthy() {
		pk := ""
		if cfg.SSH != nil {
			pk = cfg.SSH.PrivateKey
		}
		byID("sshPrivateKey").Set("value", pk)
	}
	if byID("wispURL").Truthy() {
		w := cfg.WispURL
		// Empty field → placeholder shows Mercury default as optional override.
		if w == "" || w == defaultWisp {
			byID("wispURL").Set("value", "")
			if cfg.WispURL == "" {
				cfg.WispURL = defaultWisp
			}
		} else {
			byID("wispURL").Set("value", w)
		}
	}
	if byID("set-thinking").Truthy() {
		t := cfg.Thinking
		if t == "" {
			t = a.currentThinking()
		}
		byID("set-thinking").Set("value", t)
	}
	if byID("set-theme").Truthy() {
		th := cfg.Theme
		if th == "" {
			th = a.currentTheme()
		}
		byID("set-theme").Set("value", th)
	}

	if box.Get("dataset").Get("wired").String() != "1" {
		box.Get("dataset").Set("wired", "1")
		if byID("provider").Truthy() {
			on(byID("provider"), "change", func(js.Value) {
				key := byID("provider").Get("value").String()
				for _, pr := range providers() {
					if pr.Key == key {
						if byID("apiBase").Truthy() {
							byID("apiBase").Set("value", pr.Base)
						}
						break
					}
				}
				a.settingsRefreshModels()
			})
		}
		if byID("btnSaveSettings").Truthy() {
			on(byID("btnSaveSettings"), "click", func(js.Value) { a.saveSettingsFromDesign() })
		}
		if byID("btnCloseSettings").Truthy() {
			on(byID("btnCloseSettings"), "click", func(js.Value) { a.closeSettingsPanel() })
		}
		if byID("btnCloseSettingsTop").Truthy() {
			on(byID("btnCloseSettingsTop"), "click", func(js.Value) { a.closeSettingsPanel() })
		}
		if byID("refreshModels").Truthy() {
			on(byID("refreshModels"), "click", func(js.Value) { a.settingsRefreshModels() })
		}
		if byID("btnSshDefault").Truthy() {
			on(byID("btnSshDefault"), "click", func(js.Value) {
				byID("sshHost").Set("value", DefaultSSHHost)
				byID("sshPort").Set("value", itoa(DefaultSSHPorts[0]))
				byID("sshUser").Set("value", DefaultSSHUser)
				byID("sshPassword").Set("value", DefaultSSHPass)
			})
		}
		if byID("btnSshReconnect").Truthy() {
			on(byID("btnSshReconnect"), "click", func(js.Value) {
				a.saveSettingsFromDesign()
				a.closeSettingsPanel()
				a.openTermPanel()
			})
		}
	}
	a.openSettingsPanel()
	a.settingsRefreshModels()
}

func (a *App) saveSettingsFromDesign() {
	cfg := a.cfg
	if cfg == nil {
		cfg = &AppConfig{WispURL: defaultWisp}
	}
	if cfg.Provider == nil {
		cfg.Provider = &ProviderConfig{}
	}
	if byID("provider").Truthy() {
		cfg.Provider.Key = byID("provider").Get("value").String()
	}
	if byID("apiKey").Truthy() {
		cfg.Provider.APIKey = byID("apiKey").Get("value").String()
	}
	if byID("apiBase").Truthy() {
		cfg.Provider.BaseURL = byID("apiBase").Get("value").String()
	}
	if byID("apiModel").Truthy() {
		cfg.Provider.Model = byID("apiModel").Get("value").String()
	}
	if cfg.SSH == nil {
		cfg.SSH = &SSHConfig{TrustOnFirstUse: true}
	}
	if byID("sshHost").Truthy() {
		cfg.SSH.Host = byID("sshHost").Get("value").String()
	}
	if byID("sshUser").Truthy() {
		cfg.SSH.User = byID("sshUser").Get("value").String()
	}
	if byID("sshPassword").Truthy() {
		cfg.SSH.Password = byID("sshPassword").Get("value").String()
	}
	if byID("sshSecret").Truthy() {
		cfg.SSH.Secret = byID("sshSecret").Get("value").String()
	}
	if byID("sshPort").Truthy() {
		cfg.SSH.Port = atoi(byID("sshPort").Get("value").String())
	}
	if byID("sshPrivateKey").Truthy() {
		cfg.SSH.PrivateKey = byID("sshPrivateKey").Get("value").String()
	}
	cfg.SSH.TrustOnFirstUse = true
	if byID("wispURL").Truthy() {
		cfg.WispURL = byID("wispURL").Get("value").String()
	}
	if cfg.WispURL == "" {
		cfg.WispURL = defaultWisp
	}
	if byID("set-thinking").Truthy() {
		cfg.Thinking = byID("set-thinking").Get("value").String()
	}
	if byID("set-theme").Truthy() {
		cfg.Theme = byID("set-theme").Get("value").String()
	}
	a.cfg = cfg
	if cfg.Theme != "" {
		a.applyTheme(cfg.Theme)
	}
	saveConfig(cfg)
	a.syncPersist() // flush goar-memory.db.json (incl. config KV) to OPFS
	a.ensureConfigured()
	// modular: after saveSettingsFromForm → ensureSsh({ force: true, reason: "settings" })
	a.ensureSshBoot("settings")
	if st := byID("modelsStatus"); st.Truthy() {
		setHiddenAttr(st, false)
		setText(st, "Saved.")
	}
	a.toast("Settings saved · connecting SSH…", "ok")
	a.refreshStatus()
	a.closeSettingsPanel()
}

func (a *App) settingsRefreshModels() {
	if !a.Goar.Truthy() {
		return
	}
	base, key := "", ""
	if byID("apiBase").Truthy() {
		base = byID("apiBase").Get("value").String()
	}
	if byID("apiKey").Truthy() {
		key = byID("apiKey").Get("value").String()
	}
	// also support legacy set-* ids
	if base == "" && byID("set-base").Truthy() {
		base = byID("set-base").Get("value").String()
	}
	if key == "" && byID("set-apikey").Truthy() {
		key = byID("set-apikey").Get("value").String()
	}
	st := byID("modelsStatus")
	if !st.Truthy() {
		st = byID("settings-status")
	}
	if st.Truthy() {
		setHiddenAttr(st, false)
		setText(st, "Refreshing models…")
	}
	a.Goar.Call("listModels", base, key, onceFunc(func(this js.Value, args []js.Value) any {
		res := args[0]
		sel := byID("apiModel")
		if !sel.Truthy() {
			sel = byID("set-model")
		}
		cur := ""
		if sel.Truthy() {
			cur = sel.Get("value").String()
			clear(sel)
		}
		if !res.Get("ok").Bool() {
			if st.Truthy() {
				setText(st, res.Get("error").String())
			}
			return nil
		}
		ms := res.Get("models")
		for i := 0; i < ms.Length(); i++ {
			id := ms.Index(i).String()
			o := el("option")
			o.Set("value", id)
			setText(o, id)
			if sel.Truthy() {
				appendChild(sel, o)
			}
		}
		if sel.Truthy() && cur != "" {
			sel.Set("value", cur)
		}
		if st.Truthy() {
			setText(st, "Models updated")
		}
		return nil
	}))
}

func (a *App) showSettingsLegacy(p js.Value) {
	setHTML(p, `<h3>Settings</h3><p class="lede">Design shell missing — limited panel</p>`)
	remClass(p, "hidden")
}

func (a *App) showModelPanel() {
	a.showModelPicker()
}
