//go:build js && wasm

package appui

import (
	"strings"
	"syscall/js"
)

func (a *App) openTermPanel() {
	hint := byID("term-hint")
	if a.sshIsConfigured() {
		if hint.Truthy() {
			setHiddenAttr(hint, true)
		}
	} else {
		if hint.Truthy() {
			setHiddenAttr(hint, false)
		}
		a.toast("Add SSH host/user in Settings to open your VPS terminal", "warn")
	}
	// showView("term") connects SSH when configured; otherwise shows chrome only.
	a.showView("term")
}

func (a *App) connectTerm(forceMode string) {
	host := termHost()
	if !host.Truthy() {
		return
	}
	termCtor := win().Get("Terminal")
	if termCtor.Type() != js.TypeFunction {
		setTermStatus("xterm.js missing — vendor web/vendor/xterm/", "err")
		return
	}

	// Ensure host is visible and has non-zero box before open/fit.
	ensureTermHostSize(host)

	term := win().Get("__goarTerm")
	if !term.Truthy() {
		opts := win().Get("Object").New()
		opts.Set("cursorBlink", true)
		opts.Set("fontSize", 14)
		opts.Set("scrollback", 5000)
		theme := win().Get("Object").New()
		theme.Set("background", "#0a0a0a")
		theme.Set("foreground", "#e8e4d9")
		theme.Set("cursor", "#e8e4d9")
		opts.Set("theme", theme)
		term = termCtor.New(opts)
		fitAddon := js.Undefined()
		if win().Get("FitAddon").Truthy() && win().Get("FitAddon").Get("FitAddon").Type() == js.TypeFunction {
			fitAddon = win().Get("FitAddon").Get("FitAddon").New()
			term.Call("loadAddon", fitAddon)
		}
		term.Call("open", host)
		win().Set("__goarTerm", term)
		win().Set("__goarFit", fitAddon)
		fitTermNow()
		wireTermResize()
		term.Call("onData", retainFunc(js.FuncOf(func(this js.Value, args []js.Value) any {
			if a.termID == "" || !a.Goar.Truthy() {
				return nil
			}
			data := ""
			if len(args) > 0 {
				data = args[0].String()
			}
			a.Goar.Call("termWrite", a.termID, data)
			return nil
		})))
		if a.Goar.Truthy() {
			a.Goar.Call("onTermData", retainFunc(js.FuncOf(func(this js.Value, args []js.Value) any {
				if len(args) == 0 {
					return nil
				}
				ev := args[0]
				id := ev.Get("id").String()
				// Accept while connecting (termID not assigned yet) or when ids match.
				if a.termID != "" && id != a.termID {
					return nil
				}
				t := win().Get("__goarTerm")
				if t.Truthy() {
					t.Call("write", ev.Get("data").String())
				}
				return nil
			})))
			a.Goar.Call("onTermExit", retainFunc(js.FuncOf(func(this js.Value, args []js.Value) any {
				a.termID = ""
				setTermStatus("Disconnected (session ended)", "warn")
				return nil
			})))
		}
	} else {
		// Re-parent / re-fit if host moved (e.g. into #term-stage).
		el := term.Get("element")
		if el.Truthy() && el.Get("parentElement").Truthy() && !el.Get("parentElement").Equal(host) {
			// xterm already mounted elsewhere — move the terminal element into host
			appendChild(host, el)
		} else if el.Truthy() && (!el.Get("parentElement").Truthy() || !host.Call("contains", el).Bool()) {
			// If open() already placed under a different node, ensure host contains it
			if host.Get("children").Length() == 0 && el.Truthy() {
				appendChild(host, el)
			}
		}
		fitTermNow()
	}

	a.ensureConfigured()
	if a.termID != "" && a.Goar.Truthy() {
		// Detach UI listener only — keep shared SSH PTY alive for the agent.
		a.Goar.Call("closeTerm", a.termID)
		a.termID = ""
	}
	if a.Goar.Truthy() && a.Goar.Get("sharedSSHStatus").Type() == js.TypeFunction {
		st := a.Goar.Call("sharedSSHStatus")
		if st.Truthy() && st.Get("connected").Truthy() && st.Get("connected").Bool() {
			setTermStatus("Reattaching shared SSH…", "warn")
		} else {
			setTermStatus("Connecting…", "warn")
		}
	} else {
		setTermStatus("Connecting…", "warn")
	}

	// Fit again after layout paint so cols/rows are non-zero.
	fitTermNow()
	cols, rows := 80, 24
	t := win().Get("__goarTerm")
	if t.Truthy() {
		c := t.Get("cols").Int()
		r := t.Get("rows").Int()
		if c > 2 {
			cols = c
		}
		if r > 1 {
			rows = r
		}
	}
	opts := win().Get("Object").New()
	opts.Set("cols", cols)
	opts.Set("rows", rows)
	mode := forceMode
	if mode == "" {
		// Locked v1: prefer SSH when AGENT_SSH / settings SSH is configured; else local REPL.
		if a.sshIsConfigured() {
			mode = "ssh"
		} else {
			mode = "local"
		}
	}
	opts.Set("mode", mode)
	if !a.Goar.Truthy() {
		setTermStatus("goar API missing", "err")
		return
	}
	// Optional callback for async SSH connect completion.
	opts.Set("callback", retainFunc(js.FuncOf(func(this js.Value, args []js.Value) any {
		if len(args) == 0 {
			return nil
		}
		r := args[0]
		if !r.Get("ok").Bool() {
			err := "SSH connect failed"
			if r.Get("error").Truthy() {
				err = r.Get("error").String()
			}
			setTermStatus(err, "err")
			return nil
		}
		a.termID = r.Get("id").String()
		a.termMode = r.Get("mode").String()
		host := ""
		if r.Get("host").Truthy() {
			host = r.Get("host").String()
		}
		if host != "" {
			setTermStatus("Connected · ssh · "+host, "ok")
		} else {
			setTermStatus("Connected · "+a.termMode, "ok")
		}
		fitTermNow()
		return nil
	})))
	res := a.Goar.Call("openTerm", opts)
	if !res.Truthy() || !res.Get("ok").Bool() {
		err := "openTerm failed"
		if res.Truthy() && res.Get("error").Truthy() {
			err = res.Get("error").String()
		}
		setTermStatus("Connect failed: "+err, "err")
		return
	}
	a.termID = res.Get("id").String()
	a.termMode = res.Get("mode").String()
	connecting := res.Get("connecting").Truthy() && res.Get("connecting").Bool()
	if connecting {
		setTermStatus("Connecting · "+a.termMode+"…", "warn")
	} else {
		setTermStatus("Connected · "+a.termMode, "ok")
	}
	// Focus + final fit after prompt is written.
	win().Call("setTimeout", onceFunc(func(this js.Value, args []js.Value) any {
		fitTermNow()
		t := win().Get("__goarTerm")
		if t.Truthy() && t.Get("focus").Type() == js.TypeFunction {
			t.Call("focus")
		}
		return nil
	}), 50)
}

func (a *App) disconnectTerm() {
	if a.termID != "" && a.Goar.Truthy() {
		opts := win().Get("Object").New()
		opts.Set("killShared", true)
		a.Goar.Call("closeTerm", a.termID, opts)
	}
	a.termID = ""
	setTermStatus("Disconnected", "warn")
}

func termHost() js.Value {
	stage := byID("term-stage")
	termEl := byID("terminal")
	if stage.Truthy() {
		if termEl.Truthy() {
			if !termEl.Get("parentElement").Equal(stage) {
				appendChild(stage, termEl)
			}
			addClass(termEl, "live")
			// Clear zero-size styles from #view-term-hidden parent context
			st := termEl.Get("style")
			st.Set("width", "100%")
			st.Set("height", "100%")
			st.Set("minHeight", "200px")
			st.Set("display", "block")
			st.Set("opacity", "1")
			st.Set("pointerEvents", "auto")
			st.Set("position", "relative")
			return termEl
		}
		return stage
	}
	if termEl.Truthy() {
		return termEl
	}
	return byID("xterm")
}

func ensureTermHostSize(host js.Value) {
	if !host.Truthy() {
		return
	}
	// Never force #term-tab visible unless we are actually in the terminal view.
	// Boot/background SharedSSH must not cover chat with an inline display:flex.
	inTerm := false
	if body := doc().Get("body"); body.Truthy() {
		inTerm = hasClass(body, "view-term")
	}
	st := host.Get("style")
	st.Set("width", "100%")
	st.Set("height", "100%")
	st.Set("minHeight", "240px")
	st.Set("display", "block")
	st.Set("flex", "1")
	st.Set("boxSizing", "border-box")
	if stage := byID("term-stage"); stage.Truthy() {
		ss := stage.Get("style")
		ss.Set("flex", "1")
		ss.Set("minHeight", "240px")
		ss.Set("height", "100%")
		ss.Set("width", "100%")
		ss.Set("display", "flex")
		ss.Set("flexDirection", "column")
	}
	if tab := byID("term-tab"); tab.Truthy() {
		ts := tab.Get("style")
		if inTerm {
			ts.Set("display", "flex")
			ts.Set("flexDirection", "column")
		} else {
			ts.Set("display", "")
		}
	}
}

func fitTermNow() {
	fit := win().Get("__goarFit")
	term := win().Get("__goarTerm")
	if fit.Truthy() && fit.Get("fit").Type() == js.TypeFunction {
		// proposeDimensions returns undefined when cell size is 0; retry briefly
		fit.Call("fit")
	}
	if term.Truthy() && aColsRowsBad(term) {
		// Force a sensible default resize so the canvas is visible
		term.Call("resize", 100, 30)
	}
	// Propagate cols/rows to SSH PTY when a session is live.
	if term.Truthy() {
		if app := globalApp; app != nil && app.termID != "" && app.Goar.Truthy() && app.Goar.Get("termResize").Type() == js.TypeFunction {
			cols := term.Get("cols").Int()
			rows := term.Get("rows").Int()
			if cols >= 10 && rows >= 5 {
				app.Goar.Call("termResize", app.termID, cols, rows)
			}
		}
	}
}

func aColsRowsBad(term js.Value) bool {
	if !term.Truthy() {
		return true
	}
	c := term.Get("cols").Int()
	r := term.Get("rows").Int()
	return c < 10 || r < 5
}

func wireTermResize() {
	if win().Get("__goarTermResizeWired").Truthy() {
		return
	}
	win().Set("__goarTermResizeWired", true)
	handler := retainFunc(js.FuncOf(func(this js.Value, args []js.Value) any {
		fitTermNow()
		return nil
	}))
	win().Call("addEventListener", "resize", handler)
	// ResizeObserver on stage when available
	roCtor := win().Get("ResizeObserver")
	if roCtor.Type() == js.TypeFunction {
		stage := byID("term-stage")
		if !stage.Truthy() {
			stage = byID("terminal")
		}
		if stage.Truthy() {
			ro := roCtor.New(handler)
			ro.Call("observe", stage)
			win().Set("__goarTermRO", ro)
		}
	}
}

func setTermStatus(msg, kind string) {
	el := termStatusEl()
	if !el.Truthy() {
		return
	}
	setText(el, msg)
	cls := "status-line"
	if kind != "" {
		cls += " " + kind
	}
	el.Set("className", cls)
	// hdr-status-text is hidden by default in design HTML — show when we write
	if el.Get("id").String() == "hdr-status-text" {
		el.Call("removeAttribute", "hidden")
		setHiddenAttr(el, false)
	}
}

func termStatusEl() js.Value {
	if h := byID("term-status"); h.Truthy() {
		return h
	}
	if h := byID("hdr-status-text"); h.Truthy() {
		return h
	}
	if h := byID("toast"); h.Truthy() {
		return h
	}
	return js.Undefined()
}

// sshIsConfigured reports whether the UI config (or goar status) has SSH credentials.
func (a *App) sshIsConfigured() bool {
	if a == nil {
		return false
	}
	if a.cfg != nil && a.cfg.SSH != nil {
		host := strings.TrimSpace(a.cfg.SSH.Host)
		user := strings.TrimSpace(a.cfg.SSH.User)
		if host != "" && user != "" && (a.cfg.SSH.Password != "" || a.cfg.SSH.PrivateKey != "") {
			return true
		}
	}
	if a.Goar.Truthy() && a.Goar.Get("status").Type() == js.TypeFunction {
		st := a.Goar.Call("status")
		if st.Truthy() && st.Get("sshConfigured").Truthy() && st.Get("sshConfigured").Bool() {
			return true
		}
	}
	return false
}

