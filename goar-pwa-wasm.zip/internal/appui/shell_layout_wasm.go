//go:build js && wasm

package appui

import "syscall/js"

// mountShell hydrates the design HTML already in the document.
// It does NOT wipe #app or inject a simplified layout.
func (a *App) mountShell() {
	root := byID("app")
	if !root.Truthy() {
		// Absolute fallback only — web/index.html Vibe shell should already be present.
		body := doc().Get("body")
		root = el("div")
		setAttr(root, "id", "app")
		appendChild(body, root)
	}
	if !byID("main-stage").Truthy() && !byID("side-rail").Truthy() {
		js.Global().Get("console").Call("error", "appui: Vibe shell missing (#main-stage). Serve web/index.html (Vibe-first).")
	}
	// Vibe-first chrome (floating settings + terminal icons; side-rail not primary).
	if body := doc().Get("body"); body.Truthy() {
		addClass(body, "vibe-cli")
	}
	a.ensureAskModal()
	a.wireChrome()
	a.wireShellRail()
	a.wireV1Chrome()
	a.wireVibeClean()
	a.startParticles()
}

func (a *App) ensureAskModal() {
	if byID("ask-modal").Truthy() {
		return
	}
	m := el("div")
	setAttr(m, "id", "ask-modal")
	addClass(m, "hidden")
	setHTML(m, `<div class="ask-sheet"><h3>Agent question</h3><p id="ask-prompt"></p><textarea id="ask-answer" rows="3"></textarea><div class="row-actions"><button type="button" class="primary" id="btn-ask-submit">Answer</button></div></div>`)
	appendChild(doc().Get("body"), m)
}

func setHiddenAttr(n js.Value, hide bool) {
	if !n.Truthy() {
		return
	}
	if hide {
		n.Call("setAttribute", "hidden", "")
	} else {
		n.Call("removeAttribute", "hidden")
	}
}

func (a *App) showView(name string) {
	if name == "files" || name == "workspace" {
		name = "ide"
	}
	body := doc().Get("body")
	for _, c := range []string{"split-computer", "files-only", "files-ide", "view-computer", "view-files", "view-term", "view-kit", "view-vnc", "view-creative"} {
		remClass(body, c)
	}
	for _, id := range []string{"browser-tab", "files-sheet-overlay", "ide-shell", "term-tab", "vnc-tab", "creative-tab", "kit-tab"} {
		el := byID(id)
		if !el.Truthy() {
			continue
		}
		remClass(el, "open")
		remClass(el, "view-active")
		remClass(el, "active")
		setHiddenAttr(el, true)
		// Clear inline display leaked by ensureTermHostSize / connectTerm.
		if st := el.Get("style"); st.Truthy() {
			st.Set("display", "")
		}
	}
	if chat := byID("chat"); chat.Truthy() {
		remClass(chat, "active")
	}

	rail := byID("side-rail")
	if rail.Truthy() {
		btns := rail.Call("querySelectorAll", ".rail-btn[data-view]")
		for i := 0; i < btns.Length(); i++ {
			b := btns.Index(i)
			v := b.Call("getAttribute", "data-view").String()
			if v == name {
				addClass(b, "active")
			} else {
				remClass(b, "active")
			}
		}
	}
	if lab := byID("hdr-view-label"); lab.Truthy() {
		labels := map[string]string{
			"chat": "Chat", "computer": "Computer", "ide": "Files",
			"kit": "Toolkit", "vnc": "Desktop", "term": "Terminal", "creative": "Create",
		}
		setText(lab, labels[name])
	}

	switch name {
	case "chat":
		// Leave SharedSSH up — agent bash keeps driving Kali while user is in chat.
		if chat := byID("chat"); chat.Truthy() {
			addClass(chat, "active")
		}
		a.updateKaliChip()
	case "computer":
		addClass(body, "view-computer")
		tab := byID("browser-tab")
		if tab.Truthy() {
			addClass(tab, "open")
			addClass(tab, "view-active")
			addClass(tab, "active")
			setHiddenAttr(tab, false)
		}
		a.openFirefoxPanel()
	case "term":
		addClass(body, "view-term")
		tab := byID("term-tab")
		if tab.Truthy() {
			addClass(tab, "open")
			addClass(tab, "view-active")
			addClass(tab, "active")
			setHiddenAttr(tab, false)
		}
		// Move #terminal into #term-stage when present
		stage := byID("term-stage")
		termEl := byID("terminal")
		if stage.Truthy() && termEl.Truthy() {
			if !termEl.Get("parentElement").Equal(stage) {
				appendChild(stage, termEl)
			}
			addClass(termEl, "live")
			st := termEl.Get("style")
			st.Set("width", "100%")
			st.Set("height", "100%")
			st.Set("minHeight", "240px")
			st.Set("display", "block")
			st.Set("opacity", "1")
		}
		// Defer open/fit until after view-term CSS paints (host needs non-zero height).
		// Locked v1: auto-connect SSH when configured; otherwise leave panel idle with hint.
		win().Call("requestAnimationFrame", onceFunc(func(this js.Value, args []js.Value) any {
			win().Call("requestAnimationFrame", onceFunc(func(this js.Value, args []js.Value) any {
				if a.sshIsConfigured() {
					a.connectTerm("")
				} else {
					setTermStatus("SSH not configured — open Settings (top-left)", "warn")
				}
				return nil
			}))
			return nil
		}))
	case "vnc":
		addClass(body, "view-vnc")
		tab := byID("vnc-tab")
		if tab.Truthy() {
			addClass(tab, "open")
			addClass(tab, "view-active")
			addClass(tab, "active")
			setHiddenAttr(tab, false)
		}
		a.openDesktopPanel()
	case "creative":
		addClass(body, "view-creative")
		tab := byID("creative-tab")
		if tab.Truthy() {
			addClass(tab, "open")
			addClass(tab, "view-active")
			addClass(tab, "active")
			setHiddenAttr(tab, false)
		}
		a.openCreativePanel()
	case "ide":
		addClass(body, "view-files")
		addClass(body, "files-ide")
		ov := byID("files-sheet-overlay")
		if ov.Truthy() {
			addClass(ov, "open")
			addClass(ov, "view-active")
			setHiddenAttr(ov, false)
		}
		if ide := byID("ide-shell"); ide.Truthy() {
			addClass(ide, "open")
			addClass(ide, "view-active")
			addClass(ide, "active")
			setHiddenAttr(ide, false)
		}
		a.refreshFiles("/")
	case "kit":
		addClass(body, "view-kit")
		tab := byID("kit-tab")
		if tab.Truthy() {
			addClass(tab, "open")
			addClass(tab, "view-active")
			addClass(tab, "active")
			setHiddenAttr(tab, false)
		}
	}

	// Keep rail/tab/scrim on body for z-index (Samsung edge rail)
	for _, id := range []string{"rail-scrim", "side-rail", "rail-tab"} {
		n := byID(id)
		if n.Truthy() && n.Get("parentElement").Truthy() && !n.Get("parentElement").Equal(body) {
			appendChild(body, n)
		}
	}
}

func (a *App) wireShellRail() {
	rail := byID("side-rail")
	if rail.Truthy() {
		btns := rail.Call("querySelectorAll", ".rail-btn[data-view]")
		for i := 0; i < btns.Length(); i++ {
			b := btns.Index(i)
			on(b, "click", func(ev js.Value) {
				t := ev.Get("currentTarget")
				if !t.Truthy() {
					t = b
				}
				v := t.Call("getAttribute", "data-view").String()
				a.showView(v)
			})
		}
	}
	// drawer menu items
	items := doc().Call("querySelectorAll", ".menu-item[data-view]")
	for i := 0; i < items.Length(); i++ {
		it := items.Index(i)
		on(it, "click", func(ev js.Value) {
			t := ev.Get("currentTarget")
			v := t.Call("getAttribute", "data-view").String()
			a.showView(v)
			if ov := byID("drawer-overlay"); ov.Truthy() {
				setHiddenAttr(ov, true)
				remClass(ov, "open")
			}
		})
	}
	if byID("btn-history").Truthy() {
		on(byID("btn-history"), "click", func(js.Value) {
			a.renderSessions()
			a.toggleHistory()
		})
	}
	if byID("btn-new").Truthy() {
		on(byID("btn-new"), "click", func(js.Value) { a.newSession() })
	}
	if byID("btn-settings").Truthy() {
		on(byID("btn-settings"), "click", func(js.Value) {
			a.showSettings()
		})
	}
	if byID("menu-history").Truthy() {
		on(byID("menu-history"), "click", func(js.Value) {
			a.renderSessions()
			a.toggleHistory()
		})
	}
	if byID("menu-settings").Truthy() {
		on(byID("menu-settings"), "click", func(js.Value) { a.showSettings() })
	}
	if byID("history-clear").Truthy() {
		on(byID("history-clear"), "click", func(js.Value) { a.clearSession() })
	}
	if byID("files-close").Truthy() {
		on(byID("files-close"), "click", func(js.Value) { a.showView("chat") })
	}
	if byID("ide-close").Truthy() {
		on(byID("ide-close"), "click", func(js.Value) { a.showView("chat") })
	}
	if byID("rail-tab").Truthy() {
		on(byID("rail-tab"), "click", func(js.Value) {
			body := doc().Get("body")
			if hasClass(body, "rail-open") {
				remClass(body, "rail-open")
				setHiddenAttr(byID("rail-scrim"), true)
			} else {
				addClass(body, "rail-open")
				setHiddenAttr(byID("rail-scrim"), false)
			}
		})
	}
	if byID("rail-scrim").Truthy() {
		on(byID("rail-scrim"), "click", func(js.Value) {
			remClass(doc().Get("body"), "rail-open")
			setHiddenAttr(byID("rail-scrim"), true)
		})
	}
	// Welcome chips removed — Vibe CLI has no chip welcome surface.
}


func (a *App) toggleHistory() {
	ov := byID("history-overlay")
	if !ov.Truthy() {
		return
	}
	open := !hasClass(ov, "open")
	if open {
		addClass(ov, "open")
		setHiddenAttr(ov, false)
		a.renderSessions()
	} else {
		remClass(ov, "open")
		setHiddenAttr(ov, true)
	}
}

func (a *App) openSettingsPanel() {
	box := byID("settings")
	if !box.Truthy() {
		return
	}
	addClass(box, "open")
	box.Get("style").Set("display", "flex")
	box.Get("style").Set("zIndex", "11000")
	box.Get("style").Set("visibility", "visible")
	box.Get("style").Set("opacity", "1")
	if btn := byID("btn-top-settings"); btn.Truthy() {
		addClass(btn, "active")
	}
	if btn := byID("fab-settings"); btn.Truthy() {
		addClass(btn, "active")
	}
}

func (a *App) closeSettingsPanel() {
	box := byID("settings")
	if !box.Truthy() {
		return
	}
	remClass(box, "open")
	box.Get("style").Set("display", "")
	if btn := byID("btn-top-settings"); btn.Truthy() {
		remClass(btn, "active")
	}
	if btn := byID("fab-settings"); btn.Truthy() {
		remClass(btn, "active")
	}
}

// wireV1Chrome binds floating top-left settings + top-right terminal icons (Vibe chrome).
func (a *App) wireV1Chrome() {
	if byID("btn-top-settings").Truthy() {
		on(byID("btn-top-settings"), "click", func(js.Value) {
			box := byID("settings")
			if box.Truthy() && hasClass(box, "open") {
				a.closeSettingsPanel()
				return
			}
			a.showSettings()
			if btn := byID("btn-top-settings"); btn.Truthy() {
				addClass(btn, "active")
			}
		})
	}
	if byID("btn-top-term").Truthy() {
		on(byID("btn-top-term"), "click", func(js.Value) {
			a.closeSettingsPanel()
			a.toggleTermPanel()
		})
	}
	if byID("btn-term-close").Truthy() {
		on(byID("btn-term-close"), "click", func(js.Value) {
			a.showView("chat")
		})
	}
	// Clicking the settings scrim (outside sheet) closes popup.
	if box := byID("settings"); box.Truthy() {
		on(box, "click", func(ev js.Value) {
			t := ev.Get("target")
			if t.Truthy() && t.Get("id").String() == "settings" {
				a.closeSettingsPanel()
			}
		})
	}
}

func (a *App) toggleTermPanel() {
	body := doc().Get("body")
	if body.Truthy() && hasClass(body, "view-term") {
		a.showView("chat")
		return
	}
	a.openTermPanel()
}
