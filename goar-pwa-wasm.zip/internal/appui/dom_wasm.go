//go:build js && wasm

package appui

import (
	"syscall/js"
)

func doc() js.Value { return js.Global().Get("document") }
func win() js.Value  { return js.Global() }

func byID(id string) js.Value {
	return doc().Call("getElementById", id)
}

func el(tag string) js.Value {
	return doc().Call("createElement", tag)
}

func text(s string) js.Value {
	return doc().Call("createTextNode", s)
}

func setAttr(n js.Value, k, v string) {
	n.Call("setAttribute", k, v)
}

func addClass(n js.Value, c string) {
	n.Get("classList").Call("add", c)
}

func remClass(n js.Value, c string) {
	n.Get("classList").Call("remove", c)
}

func hasClass(n js.Value, c string) bool {
	return n.Get("classList").Call("contains", c).Bool()
}

func appendChild(parent, child js.Value) {
	parent.Call("appendChild", child)
}

func clear(n js.Value) {
	for n.Get("firstChild").Truthy() {
		n.Call("removeChild", n.Get("firstChild"))
	}
}

func setHTML(n js.Value, html string) {
	n.Set("innerHTML", html)
}

func setText(n js.Value, s string) {
	n.Set("textContent", s)
}

func on(n js.Value, event string, fn func(js.Value)) {
	cb := retainFunc(js.FuncOf(func(this js.Value, args []js.Value) any {
		ev := js.Undefined()
		if len(args) > 0 {
			ev = args[0]
		}
		fn(ev)
		return nil
	}))
	n.Call("addEventListener", event, cb)
}

func localGet(key string) string {
	v := win().Get("localStorage").Call("getItem", key)
	if v.Type() == js.TypeNull || v.Type() == js.TypeUndefined {
		return ""
	}
	return v.String()
}

func localSet(key, val string) {
	win().Get("localStorage").Call("setItem", key, val)
}

func localRemove(key string) {
	win().Get("localStorage").Call("removeItem", key)
}

func postGoarNotifySW(title, body string) {
	sw := win().Get("navigator").Get("serviceWorker")
	if !sw.Truthy() {
		return
	}
	msg := map[string]any{
		"type":  "goar-notify",
		"title": title,
		"body":  body,
	}
	ctrl := sw.Get("controller")
	if ctrl.Truthy() {
		ctrl.Call("postMessage", msg)
		localSet("goar.lastNotifySW", "controller")
		return
	}
	ready := sw.Get("ready")
	if ready.Truthy() {
		promiseThen(ready, func(reg js.Value) {
			if !reg.Truthy() {
				return
			}
			active := reg.Get("active")
			if active.Truthy() {
				active.Call("postMessage", msg)
				localSet("goar.lastNotifySW", "ready-active")
			}
		}, nil)
	}
}

func notify(title, body string) {
	// Always attempt SW goar-notify when permission allows (or will allow).
	notif := win().Get("Notification")
	opts := map[string]any{
		"body":     body,
		"tag":      "goar-attention",
		"renotify": true,
		"icon":     "./icons/icon-192.png",
	}
	show := func() {
		postGoarNotifySW(title, body)
		if notif.Type() != js.TypeFunction {
			return
		}
		n := notif.New(title, opts)
		if n.Truthy() && n.Get("addEventListener").Type() == js.TypeFunction {
			n.Call("addEventListener", "click", js.FuncOf(func(this js.Value, args []js.Value) any {
				if len(args) > 0 {
					args[0].Call("preventDefault")
				}
				win().Call("focus")
				if n.Get("close").Type() == js.TypeFunction {
					n.Call("close")
				}
				return nil
			}))
		}
	}
	if notif.Type() != js.TypeFunction {
		// Still try SW path (may no-op without permission).
		postGoarNotifySW(title, body)
		return
	}
	perm := notif.Get("permission").String()
	if perm == "granted" {
		show()
		return
	}
	if perm != "denied" {
		promiseThen(notif.Call("requestPermission"), func(v js.Value) {
			if v.Truthy() && v.String() == "granted" {
				show()
			} else {
				// Persist probe marker even if user dismisses prompt.
				localSet("goar.lastNotifySW", "permission-pending")
			}
		}, nil)
	} else {
		localSet("goar.lastNotifySW", "permission-denied")
	}
}

// notifyAttention fires for approvals / ask_user / needs-attention.
func notifyAttention(kind, detail string) {
	title := "GOAR needs attention"
	switch kind {
	case "approval":
		title = "GOAR — tool approval"
	case "ask":
		title = "GOAR — question"
	case "done":
		title = "GOAR — task complete"
	}
	notify(title, detail)
	localSet("goar.needsAttention", kind+":"+detail)
}

func clipboardWrite(s string) {
	nav := win().Get("navigator")
	if !nav.Truthy() {
		return
	}
	clip := nav.Get("clipboard")
	if clip.Truthy() && clip.Get("writeText").Type() == js.TypeFunction {
		clip.Call("writeText", s)
	}
}
