//go:build js && wasm

package appui

import (
	"encoding/json"
	"fmt"
	"strings"
	"syscall/js"
)

// hydrateOPFS loads AGENT_HOME tree + persist store from OPFS (and Puter if opted in).
func (a *App) hydrateOPFS() {
	js.Global().Call("eval", `(() => {
	  if (!globalThis.__goarHydrateOPFS) {
	    globalThis.__goarHydrateOPFS = async function() {
	      const out = { files: {}, dirs: [] };
	      try {
	        if (!navigator.storage || !navigator.storage.getDirectory) return JSON.stringify(out);
	        const root = await navigator.storage.getDirectory();
	        const dir = await root.getDirectoryHandle('goar-agent-home', { create: true });
	        async function walk(handle, prefix) {
	          for await (const [name, h] of handle.entries()) {
	            const rel = prefix ? prefix + '/' + name : name;
	            if (h.kind === 'directory') {
	              out.dirs.push(rel);
	              await walk(h, rel);
	            } else {
	              const f = await h.getFile();
	              if (f.size <= 2*1024*1024) out.files[rel] = await f.text();
	            }
	          }
	        }
	        await walk(dir, '');
	      } catch (e) {
	        out.error = String(e && e.message ? e.message : e);
	        try { console.warn('OPFS hydrate degraded', e); } catch (_) {}
	      }
	      return JSON.stringify(out);
	    };
	  }
	})()`)

	done := make(chan struct{}, 1)
	promise := win().Call("__goarHydrateOPFS")
	promiseThen(promise, func(v js.Value) {
		defer func() { done <- struct{}{} }()
		if !v.Truthy() {
			return
		}
		raw := v.String()
		if a.Goar.Truthy() && a.Goar.Get("fsHydrate").Type() == js.TypeFunction {
			a.Goar.Call("fsHydrate", raw)
		}
		var tree struct {
			Files map[string]string `json:"files"`
		}
		_ = json.Unmarshal([]byte(raw), &tree)
		if a.store != nil && tree.Files != nil {
			if s, ok := tree.Files["persist/goar-memory.db.json"]; ok && s != "" {
				_ = a.store.ImportJSON(s)
			}
			setConfigStore(a.store)
			// If OPFS store lacks config but we have in-memory/localStorage cfg, re-save.
			if _, ok := a.store.GetKV(configPersistNS, configPersistKey); !ok && a.cfg != nil && a.cfg.configured() {
				saveConfig(a.cfg)
			} else if raw, ok := a.store.GetKV(configPersistNS, configPersistKey); ok && raw != "" {
				if c := decodeConfig(raw); c != nil {
					a.cfg = c
				}
			}
		}
		a.hydratePuter()
		if strings.Contains(raw, `"error"`) {
			fmt.Println("appui: OPFS hydrate degraded (localStorage/MEMFS still work)")
			a.toast("OPFS unavailable — using memory persist", "warn")
		}
	}, func(js.Value) {
		done <- struct{}{}
	})
	<-done
	fmt.Println("appui: OPFS hydrate done")
}

func (a *App) syncPersist() {
	if a.store != nil {
		_ = a.store.Flush()
	}
	if a.Goar.Truthy() && a.Goar.Get("fsSync").Type() == js.TypeFunction {
		res := a.Goar.Call("fsSync")
		if res.Truthy() && res.Get("ok").Bool() {
			raw := res.Get("json").String()
			if !win().Get("__goarWriteOPFS").Truthy() {
				win().Set("__goarWriteOPFS", retainFunc(js.FuncOf(func(this js.Value, args []js.Value) any {
					if len(args) == 0 {
						return nil
					}
					payload := args[0].String()
					win().Call("eval", `(async (raw) => {
					  try {
					    if (!navigator.storage || !navigator.storage.getDirectory) return;
					    const tree = JSON.parse(raw);
					    const root = await navigator.storage.getDirectory();
					    const dir = await root.getDirectoryHandle('goar-agent-home', { create: true });
					    for (const d of (tree.dirs||[])) {
					      const parts = d.split('/').filter(Boolean);
					      let cur = dir;
					      for (const p of parts) cur = await cur.getDirectoryHandle(p, { create: true });
					    }
					    for (const [rel, content] of Object.entries(tree.files||{})) {
					      const parts = rel.split('/').filter(Boolean);
					      let cur = dir;
					      for (let i=0;i<parts.length-1;i++) cur = await cur.getDirectoryHandle(parts[i], { create: true });
					      const fh = await cur.getFileHandle(parts[parts.length-1], { create: true });
					      const w = await fh.createWritable();
					      await w.write(content);
					      await w.close();
					    }
					  } catch(e) { console.warn('OPFS sync', e); }
					})(`+jsQuote(payload)+`)`)
					return nil
				})))
			}
			win().Call("__goarWriteOPFS", raw)
		}
	}
	a.syncPuter()
}

func jsQuote(s string) string {
	b, _ := json.Marshal(s)
	return string(b)
}

func (a *App) puterAvailable() bool {
	p := win().Get("puter")
	return p.Truthy() && p.Get("fs").Truthy()
}

func (a *App) hydratePuter() {
	if a.cfg == nil || a.cfg.Puter == nil || !a.cfg.Puter.Enabled || !a.puterAvailable() {
		return
	}
	root := a.cfg.Puter.Root
	if root == "" {
		root = "goar-agent-home"
	}
	fmt.Println("appui: Puter FS enabled, root=", root)
	fs := win().Get("puter").Get("fs")
	path := "/" + root + "/persist/goar-memory.db.json"
	promise := fs.Call("read", path)
	if !promise.Truthy() {
		return
	}
	promiseThen(promise, func(v js.Value) {
		if a.store == nil || !v.Truthy() {
			return
		}
		if v.Type() == js.TypeString {
			_ = a.store.ImportJSON(v.String())
		}
	}, func(js.Value) {})
}

func (a *App) syncPuter() {
	if a.cfg == nil || a.cfg.Puter == nil || !a.cfg.Puter.Enabled || !a.puterAvailable() || a.store == nil {
		return
	}
	raw, err := a.store.ExportJSON()
	if err != nil {
		return
	}
	fs := win().Get("puter").Get("fs")
	root := a.cfg.Puter.Root
	if root == "" {
		root = "goar-agent-home"
	}
	mkdirOpts := win().Get("Object").New()
	_ = fs.Call("mkdir", "/"+root+"/persist", mkdirOpts)
	fs.Call("write", "/"+root+"/persist/goar-memory.db.json", raw)
}
