//go:build js && wasm

package appui

import (
	"path"
	"strings"
	"syscall/js"
)

func (a *App) wireFilesChrome() {
	if byID("files-refresh").Truthy() {
		on(byID("files-refresh"), "click", func(js.Value) {
			crumb := "/"
			if byID("files-crumb").Truthy() {
				crumb = byID("files-crumb").Get("textContent").String()
			}
			a.refreshFiles(crumb)
		})
	}
	if byID("files-new").Truthy() {
		on(byID("files-new"), "click", func(js.Value) {
			name := win().Call("prompt", "New file path", "/tmp/note.txt")
			if !name.Truthy() || name.String() == "" {
				return
			}
			a.writeFile(name.String(), "")
			a.refreshFiles(path.Dir(name.String()))
		})
	}
	if byID("files-upload-btn").Truthy() {
		on(byID("files-upload-btn"), "click", func(js.Value) {
			byID("files-upload-input").Call("click")
		})
	}
	if byID("files-upload-input").Truthy() {
		on(byID("files-upload-input"), "change", func(ev js.Value) {
			files := ev.Get("target").Get("files")
			n := files.Length()
			for i := 0; i < n; i++ {
				f := files.Index(i)
				fname := f.Get("name").String()
				reader := win().Get("FileReader").New()
				on(reader, "load", func(e js.Value) {
					text := e.Get("target").Get("result").String()
					a.writeFile("/"+fname, text)
					a.refreshFiles("/")
				})
				reader.Call("readAsText", f)
			}
		})
	}
	if byID("ide-save").Truthy() {
		on(byID("ide-save"), "click", func(js.Value) {
			p := byID("ide-path").Get("textContent").String()
			body := byID("ide-editor").Get("value").String()
			a.writeFile(p, body)
			a.toast("Saved "+p, "ok")
		})
	}
	if ideCloseBtn().Truthy() {
		on(ideCloseBtn(), "click", func(js.Value) {
			addClass(byID("ide-editor-wrap"), "hidden")
		})
	}
}

func (a *App) refreshFiles(dir string) {
	list := byID("files-list")
	if !list.Truthy() {
		return
	}
	if dir == "" {
		dir = "/"
	}
	setText(byID("files-crumb"), dir)
	clear(list)
	setHTML(list, `<div class="files-empty">Reading…</div>`)
	if !a.Goar.Truthy() {
		setHTML(list, `<div class="files-empty">goar FS API missing</div>`)
		return
	}
	// Prefer listDir if present; else readDir / fsList
	fn := a.Goar.Get("listDir")
	if fn.Type() != js.TypeFunction {
		fn = a.Goar.Get("readdir")
	}
	if fn.Type() != js.TypeFunction {
		fn = a.Goar.Get("fsList")
	}
	if fn.Type() != js.TypeFunction {
		// Fallback: show AGENT_HOME note
		setHTML(list, `<div class="files-empty">Use chat tools for FS; listDir not exposed. AGENT_HOME=/tmp/goar-agent-home</div>`)
		return
	}
	done := onceFunc(func(this js.Value, args []js.Value) any {
		res := js.Undefined()
		if len(args) > 0 {
			res = args[0]
		}
		clear(list)
		entries := res
		if res.Truthy() && res.Get("entries").Truthy() {
			entries = res.Get("entries")
		}
		if !entries.Truthy() || entries.Length() == 0 {
			setHTML(list, `<div class="files-empty">Empty</div>`)
			return nil
		}
		for i := 0; i < entries.Length(); i++ {
			e := entries.Index(i)
			name := ""
			isDir := false
			if e.Type() == js.TypeString {
				name = e.String()
			} else {
				name = e.Get("name").String()
				if e.Get("isDir").Truthy() {
					isDir = e.Get("isDir").Bool()
				} else if e.Get("dir").Truthy() {
					isDir = e.Get("dir").Bool()
				}
			}
			row := el("div")
			addClass(row, "files-row")
			label := name
			if isDir {
				label = "📁 " + name
			} else {
				label = "📄 " + name
			}
			setText(row, label)
			full := path.Join(dir, name)
			isDirCopy := isDir
			fullCopy := full
			on(row, "click", func(js.Value) {
				if isDirCopy {
					a.refreshFiles(fullCopy)
				} else {
					a.openFileEditor(fullCopy)
				}
			})
			appendChild(list, row)
		}
		return nil
	})
	fn.Invoke(dir, done)
}

func (a *App) openFileEditor(p string) {
	wrap := byID("ide-editor-wrap")
	remClass(wrap, "hidden")
	setText(byID("ide-path"), p)
	ed := byID("ide-editor")
	ed.Set("value", "Loading…")
	read := a.Goar.Get("readFile")
	if read.Type() != js.TypeFunction {
		read = a.Goar.Get("fsRead")
	}
	if read.Type() != js.TypeFunction {
		ed.Set("value", "")
		return
	}
	read.Invoke(p, onceFunc(func(this js.Value, args []js.Value) any {
		res := args[0]
		body := ""
		if res.Truthy() {
			if res.Type() == js.TypeString {
				body = res.String()
			} else if res.Get("body").Truthy() {
				body = res.Get("body").String()
			} else if res.Get("content").Truthy() {
				body = res.Get("content").String()
			}
		}
		ed.Set("value", body)
		return nil
	}))
}

func (a *App) writeFile(p, body string) {
	if !a.Goar.Truthy() {
		return
	}
	w := a.Goar.Get("writeFile")
	if w.Type() != js.TypeFunction {
		w = a.Goar.Get("fsWrite")
	}
	if w.Type() != js.TypeFunction {
		return
	}
	w.Invoke(p, body)
	_ = strings.TrimSpace(p)
}


func ideCloseBtn() js.Value {
	if h := byID("ide-close"); h.Truthy() {
		return h
	}
	return byID("ide-close-ed")
}
