//go:build js && wasm

package appui

import (
	"encoding/json"
	"fmt"
	"strconv"
	"strings"

	"github.com/goarxyz/goar/browsernet"
	"github.com/goarxyz/goar/internal/core/persist"
)

const (
	configKey   = "goar.pwa.config.v1"
	activeSessK = "goar.pwa.activeSession.v1"
	defaultWisp = browsernet.DefaultWispURL

	// Persist KV namespace/key for OPFS-backed settings (secrets stay on-device).
	configPersistNS  = "config"
	configPersistKey = "app.v1"

	// Default SSH target (THC segfault). User can override any field in Settings.
	DefaultSSHHost = "segfault.net"
	DefaultSSHUser = "root"
	DefaultSSHPass = "segfault"
)

// DefaultSSHPorts is the dial order when port is unset or the default host is used.
var DefaultSSHPorts = []int{443, 22}

// Package-level store pointer set by Boot so load/save can use OPFS-backed persist.
var configStore *persist.Store

// AppConfig is persisted via OPFS-backed persist store (with localStorage
// migration/cache). Secrets stay on-device; never log Password/APIKey/PrivateKey.
type AppConfig struct {
	WispURL  string          `json:"wispURL"`
	ProxyURL string          `json:"-"` // deprecated SOCKS; ignored
	Theme    string          `json:"theme,omitempty"`
	Thinking string          `json:"thinking,omitempty"`
	SSH      *SSHConfig      `json:"ssh,omitempty"`
	Provider *ProviderConfig `json:"provider,omitempty"`
	Puter    *PuterConfig    `json:"puter,omitempty"`
}

type SSHConfig struct {
	Host            string `json:"host"`
	Port            int    `json:"port"`
	User            string `json:"user"`
	Password        string `json:"password,omitempty"`
	PrivateKey      string `json:"privateKey,omitempty"`
	Secret          string `json:"secret,omitempty"`
	ReconnectHost   string `json:"reconnectHost,omitempty"`
	Stabilized      bool   `json:"stabilized,omitempty"`
	StabilizedAt    string `json:"stabilizedAt,omitempty"`
	TrustOnFirstUse bool   `json:"trustOnFirstUse"`
}

type ProviderConfig struct {
	Key     string `json:"key"`
	APIKey  string `json:"apiKey,omitempty"`
	BaseURL string `json:"baseURL"`
	Model   string `json:"model"`
}

// PuterConfig opts into Puter.js cloud FS (privacy-first: off by default).
type PuterConfig struct {
	Enabled bool   `json:"enabled"`
	Root    string `json:"root,omitempty"` // e.g. goar-agent-home
}

func setConfigStore(s *persist.Store) {
	configStore = s
}

func loadConfig() *AppConfig {
	// Prefer OPFS-backed persist KV.
	if configStore != nil {
		if raw, ok := configStore.GetKV(configPersistNS, configPersistKey); ok && strings.TrimSpace(raw) != "" {
			if c := decodeConfig(raw); c != nil {
				return applySSHDefaultsInMemory(c)
			}
		}
	}
	// Migrate from localStorage if present.
	raw := localGet(configKey)
	if raw == "" {
		// Same as modular loadSettings() on empty: in-memory DEFAULTS (not forced persist until Save).
		return applySSHDefaultsInMemory(nil)
	}
	c := decodeConfig(raw)
	if c == nil {
		return applySSHDefaultsInMemory(nil)
	}
	c = applySSHDefaultsInMemory(c)
	// Best-effort migrate into persist (and keep localStorage as cache).
	saveConfig(c)
	return c
}

func decodeConfig(raw string) *AppConfig {
	var c AppConfig
	if err := json.Unmarshal([]byte(raw), &c); err != nil {
		return nil
	}
	if c.WispURL == "" {
		c.WispURL = defaultWisp
	}
	if c.Theme == "" {
		c.Theme = "goar-dark"
	}
	if c.Thinking == "" {
		c.Thinking = "off"
	}
	return &c
}


// applySSHDefaultsInMemory mirrors modular loadSettings()+resolveSshTarget defaults.
// User overrides in Settings always win; empty fields fall back to Kali segfault defaults.
func applySSHDefaultsInMemory(c *AppConfig) *AppConfig {
	if c == nil {
		c = &AppConfig{WispURL: defaultWisp, Theme: "goar-dark", Thinking: "off"}
	}
	if c.WispURL == "" {
		c.WispURL = defaultWisp
	}
	tgt := resolveSSHTarget(c)
	c.SSH = &SSHConfig{
		Host:            tgt.Host,
		Port:            tgt.Port,
		User:            tgt.User,
		Password:        tgt.Password,
		PrivateKey:      tgt.PrivateKey,
		Secret:          tgt.Secret,
		ReconnectHost:   tgt.ReconnectHost,
		TrustOnFirstUse: true,
	}
	return c
}

// sshTarget is the resolved dial target (modular resolveSshTarget).
type sshTarget struct {
	Host, User, Password, PrivateKey, Secret, ReconnectHost string
	Port                                                    int
	Ports                                                   []int
}

// resolveSSHTarget matches modular web resolveSshTarget():
// DEFAULT_HOST/USER/PASS/PORTS, password only for Kali default host, ports [443,22].
func resolveSSHTarget(c *AppConfig) sshTarget {
	defHost, defUser, defPass := DefaultSSHHost, DefaultSSHUser, DefaultSSHPass
	host, user, pass, key, secret, rh := "", "", "", "", "", ""
	port := 0
	if c != nil && c.SSH != nil {
		host = strings.TrimSpace(c.SSH.Host)
		user = strings.TrimSpace(c.SSH.User)
		pass = c.SSH.Password
		key = c.SSH.PrivateKey
		secret = strings.TrimSpace(c.SSH.Secret)
		rh = strings.TrimSpace(c.SSH.ReconnectHost)
		port = c.SSH.Port
	}
	if host == "" {
		host = defHost
	}
	if user == "" {
		user = defUser
	}
	// user@host in host field
	if at := strings.SplitN(host, "@", 2); len(at) == 2 && at[0] != "" && at[1] != "" {
		user, host = at[0], at[1]
	}
	// host:port
	if i := strings.LastIndex(host, ":"); i > 0 && !strings.Contains(host[i+1:], ":") {
		if n, err := strconv.Atoi(host[i+1:]); err == nil && n > 0 {
			port = n
			host = host[:i]
		}
	}
	isKali := host == "" || host == defHost
	if strings.TrimSpace(pass) == "" && strings.TrimSpace(key) == "" {
		if isKali {
			pass = defPass
		}
	}
	ports := []int{}
	if port > 0 {
		ports = []int{port}
		if isKali {
			for _, p := range DefaultSSHPorts {
				if p != port {
					ports = append(ports, p)
				}
			}
		}
	} else if isKali {
		ports = append([]int{}, DefaultSSHPorts...)
		port = DefaultSSHPorts[0]
	} else {
		ports = []int{22}
		port = 22
	}
	return sshTarget{
		Host: host, User: user, Password: pass, PrivateKey: key, Secret: secret,
		ReconnectHost: rh, Port: port, Ports: ports,
	}
}

func saveConfig(c *AppConfig) {
	if c == nil {
		return
	}
	b, err := json.Marshal(c)
	if err != nil {
		fmt.Println("appui: config marshal failed")
		return
	}
	raw := string(b)
	// OPFS-backed persist (primary).
	if configStore != nil {
		if err := configStore.SetKV(configPersistNS, configPersistKey, raw); err != nil {
			fmt.Println("appui: persist config write failed")
		}
	}
	// localStorage cache for fast boot before OPFS hydrate completes.
	localSet(configKey, raw)
	// Never log secrets — only non-sensitive summary.
	fmt.Println("appui: config saved via OPFS gateway (host=", configHostSummary(c), ")")
}

func configHostSummary(c *AppConfig) string {
	if c == nil {
		return ""
	}
	parts := []string{}
	if c.WispURL != "" {
		parts = append(parts, "wisp")
	}
	if c.SSH != nil && c.SSH.Host != "" {
		parts = append(parts, "ssh:"+c.SSH.Host)
	}
	if c.Provider != nil && c.Provider.Model != "" {
		parts = append(parts, "model:"+c.Provider.Model)
	}
	return strings.Join(parts, ",")
}

func (c *AppConfig) configured() bool {
	if c == nil {
		return false
	}
	// Provider model must be set (verified via /models in cred UI).
	if c.Provider == nil || strings.TrimSpace(c.Provider.Model) == "" || strings.TrimSpace(c.Provider.BaseURL) == "" {
		return false
	}
	if strings.TrimSpace(c.WispURL) == "" {
		c.WispURL = defaultWisp
	}
	// SSH optional — when present, require auth material (fail closed at connect).
	if c.SSH != nil && c.SSH.Host != "" {
		if c.SSH.User == "" || (c.SSH.Password == "" && c.SSH.PrivateKey == "") {
			return false
		}
	}
	return true
}

type providerInfo struct {
	Key, Name, Base string
	Models          []string
	NoKey           bool
	RequiresBase    bool
}

func providers() []providerInfo {
	return []providerInfo{
		{Key: "freeai", Name: "free.ai", Base: "https://api.free.ai/v1", Models: []string{"qwen7b", "qwen-coder"}, NoKey: true},
		{Key: "openai", Name: "OpenAI", Base: "https://api.openai.com/v1", Models: []string{"gpt-4.1", "gpt-4o", "o4-mini", "gpt-4o-mini"}},
		{Key: "openrouter", Name: "OpenRouter", Base: "https://openrouter.ai/api/v1", Models: []string{"anthropic/claude-sonnet-4.5", "openai/gpt-4.1"}},
		{Key: "groq", Name: "Groq", Base: "https://api.groq.com/openai/v1", Models: []string{"llama-3.3-70b-versatile"}},
		{Key: "together", Name: "Together", Base: "https://api.together.xyz/v1", Models: []string{"meta-llama/Meta-Llama-3.1-70B-Instruct-Turbo"}},
		{Key: "fireworks", Name: "Fireworks", Base: "https://api.fireworks.ai/inference/v1", Models: []string{"accounts/fireworks/models/llama-v3p1-8b-instruct"}},
		{Key: "ollama", Name: "Ollama (local)", Base: "http://127.0.0.1:11434/v1", Models: []string{"llama3.1"}, NoKey: true},
		{Key: "custom", Name: "Custom OpenAI-compatible", Base: "", Models: []string{"custom-model"}, RequiresBase: true},
	}
}

func itoa(n int) string { return strconv.Itoa(n) }

func atoi(s string) int {
	n, _ := strconv.Atoi(s)
	return n
}
