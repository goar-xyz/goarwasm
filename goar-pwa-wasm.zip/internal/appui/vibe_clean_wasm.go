//go:build js && wasm

package appui

import (
	"fmt"
	"syscall/js"
)

// isVibeClean reports whether the document is the web-vibe/ clean-room shell
// (data-vibe-clean on <html> or <body>, or #fab-settings present without pack chrome).
func isVibeClean() bool {
	doc := doc()
	if !doc.Truthy() {
		return false
	}
	for _, root := range []js.Value{doc.Get("documentElement"), doc.Get("body")} {
		if root.Truthy() {
			ds := root.Get("dataset")
			if ds.Truthy() && ds.Get("vibeClean").String() == "1" {
				return true
			}
			if root.Call("getAttribute", "data-vibe-clean").String() == "1" {
				return true
			}
		}
	}
	// Fallback: clean-room fab ids without pack #btn-top-settings
	if byID("fab-settings").Truthy() && !byID("btn-top-settings").Truthy() {
		return true
	}
	return false
}

// wireVibeClean binds web-vibe floating icons and adjusts boot/wizard for the
// clean DOM only. Does not rewrite pack chat_wasm overlays.
func (a *App) wireVibeClean() {
	if !isVibeClean() {
		return
	}
	fmt.Println("appui: vibe-clean DOM detected (web-vibe/)")

	if body := doc().Get("body"); body.Truthy() {
		addClass(body, "vibe-cli")
		addClass(body, "vibe-clean")
	}

	if byID("fab-settings").Truthy() {
		on(byID("fab-settings"), "click", func(js.Value) {
			box := byID("settings")
			if box.Truthy() && hasClass(box, "open") {
				a.closeSettingsPanel()
				remClass(byID("fab-settings"), "active")
				return
			}
			a.showSettings()
			addClass(byID("fab-settings"), "active")
		})
	}
	if byID("fab-term").Truthy() {
		on(byID("fab-term"), "click", func(js.Value) {
			a.closeSettingsPanel()
			if btn := byID("fab-settings"); btn.Truthy() {
				remClass(btn, "active")
			}
			a.toggleTermPanel()
		})
	}
	if byID("btn-term-close").Truthy() {
		// Idempotent with wireV1Chrome when pack ids absent.
		on(byID("btn-term-close"), "click", func(js.Value) {
			a.showView("chat")
		})
	}
	if box := byID("settings"); box.Truthy() && box.Get("dataset").Get("vibeScrim").String() != "1" {
		box.Get("dataset").Set("vibeScrim", "1")
		on(box, "click", func(ev js.Value) {
			t := ev.Get("target")
			if t.Truthy() && t.Get("id").String() == "settings" {
				a.closeSettingsPanel()
				if btn := byID("fab-settings"); btn.Truthy() {
					remClass(btn, "active")
				}
			}
		})
	}
}

// vibeCleanAfterBoot: if unconfigured, show workspace + settings instead of pack #setup wizard.
func (a *App) vibeCleanAfterBoot() {
	if !isVibeClean() {
		return
	}
	// Hide thin #boot if still visible.
	if boot := byID("boot"); boot.Truthy() {
		addClass(boot, "hide")
	}
	if !a.cfg.configured() {
		a.showWorkspace()
		a.showSettings()
		if btn := byID("fab-settings"); btn.Truthy() {
			addClass(btn, "active")
		}
	}
}
