//go:build js && wasm

package appui

import (
	"fmt"
	"net/url"
	"strings"
	"syscall/js"
	"time"
)

// wireCreativePanel binds Create rail → Pollinations image gen (no API key).
func (a *App) wireCreativePanel() {
	form := byID("cr-form")
	if !form.Truthy() {
		return
	}
	if form.Get("dataset").Get("wired").String() == "1" {
		return
	}
	form.Get("dataset").Set("wired", "1")
	on(form, "submit", func(ev js.Value) {
		ev.Call("preventDefault")
		a.creativeGenerate()
	})
	if byID("cr-go").Truthy() {
		on(byID("cr-go"), "click", func(ev js.Value) {
			ev.Call("preventDefault")
			a.creativeGenerate()
		})
	}
	a.paintCreativeGallery()
}

func (a *App) openCreativePanel() {
	a.wireCreativePanel()
	a.paintCreativeGallery()
	if st := byID("cr-status"); st.Truthy() {
		setText(st, "Pollinations · no key · images saved in this browser")
	}
}

func (a *App) creativeGenerate() {
	prompt := ""
	if byID("cr-prompt").Truthy() {
		prompt = strings.TrimSpace(byID("cr-prompt").Get("value").String())
	}
	if prompt == "" {
		a.toast("Describe an image first", "warn")
		return
	}
	model := "flux"
	if byID("cr-model").Truthy() {
		model = byID("cr-model").Get("value").String()
	}
	size := "1:1"
	if byID("cr-size").Truthy() {
		size = byID("cr-size").Get("value").String()
	}
	w, h := 1024, 1024
	switch size {
	case "16:9":
		w, h = 1456, 816
	case "9:16":
		w, h = 816, 1456
	case "4:3":
		w, h = 1232, 928
	}
	seed := time.Now().UnixNano() % 2147483647
	q := url.Values{}
	q.Set("model", model)
	q.Set("width", fmt.Sprintf("%d", w))
	q.Set("height", fmt.Sprintf("%d", h))
	q.Set("nologo", "true")
	q.Set("enhance", "true")
	q.Set("private", "true")
	q.Set("seed", fmt.Sprintf("%d", seed))
	imgURL := "https://image.pollinations.ai/prompt/" + url.PathEscape(prompt) + "?" + q.Encode()

	goBtn := byID("cr-go")
	if goBtn.Truthy() {
		goBtn.Set("disabled", true)
	}
	if st := byID("cr-status"); st.Truthy() {
		setText(st, "Generating…")
	}

	id := fmt.Sprintf("cr_%d", time.Now().UnixNano())
	item := win().Get("Object").New()
	item.Set("id", id)
	item.Set("prompt", prompt)
	item.Set("url", imgURL)
	item.Set("model", model)
	item.Set("width", w)
	item.Set("height", h)
	item.Set("seed", seed)
	item.Set("at", float64(time.Now().UnixMilli()))
	a.creativePush(item)
	a.paintCreativeGallery()

	// Prefer browser fetch→blob (works with COEP credentialless); update gallery on success.
	win().Call("eval", `(async (url, id, model, w, h) => {
	  const done = (ok, msg, objUrl) => {
	    const st = document.getElementById("cr-status");
	    const go = document.getElementById("cr-go");
	    if (go) go.disabled = false;
	    if (st) st.textContent = msg;
	    if (ok && objUrl) {
	      try {
	        const list = JSON.parse(localStorage.getItem("goar_creative_gallery_v1") || "[]");
	        const it = list.find((x) => x.id === id);
	        if (it) { it.url = objUrl; localStorage.setItem("goar_creative_gallery_v1", JSON.stringify(list)); }
	        const img = document.querySelector('#cr-grid .cr-card[data-id="'+id+'"] img');
	        if (img) img.src = objUrl;
	      } catch (_) {}
	    }
	  };
	  try {
	    const r = await fetch(url, { mode: "cors", cache: "no-store" });
	    if (!r.ok) throw new Error("HTTP " + r.status);
	    const blob = await r.blob();
	    if (!blob || blob.size < 32) throw new Error("empty image");
	    const obj = URL.createObjectURL(blob);
	    done(true, "Ready · " + model + " · " + w + "x" + h, obj);
	  } catch (e) {
	    done(false, "Generate failed: " + (e && e.message ? e.message : e), null);
	  }
	})`+"("+jsQuote(imgURL)+","+jsQuote(id)+","+jsQuote(model)+","+fmt.Sprintf("%d", w)+","+fmt.Sprintf("%d", h)+")")

	if a.Goar.Truthy() && a.Goar.Get("writeFile").Type() == js.TypeFunction {
		meta := fmt.Sprintf("prompt: %s\nmodel: %s\nurl: %s\n", prompt, model, imgURL)
		a.Goar.Call("writeFile", "/creative/"+id+".txt", meta)
	}
}

func (a *App) creativePush(item js.Value) {
	key := "goar_creative_gallery_v1"
	raw := localGet(key)
	arr := win().Get("JSON").Call("parse", func() string {
		if raw == "" {
			return "[]"
		}
		return raw
	}())
	if !arr.Truthy() || arr.Type() != js.TypeObject {
		arr = win().Get("Array").New()
	}
	// unshift
	win().Get("Array").Get("prototype").Get("unshift").Call("call", arr, item)
	// cap 64
	for arr.Length() > 64 {
		arr.Call("pop")
	}
	localSet(key, win().Get("JSON").Call("stringify", arr).String())
}

func (a *App) paintCreativeGallery() {
	grid := byID("cr-grid")
	if !grid.Truthy() {
		return
	}
	raw := localGet("goar_creative_gallery_v1")
	if raw == "" || raw == "[]" {
		setHTML(grid, `<div class="cr-empty"><h3>Create</h3><p>Describe a still. Flux on Pollinations — no key. Saved in this browser + /creative notes in agent files.</p></div>`)
		return
	}
	arr := win().Get("JSON").Call("parse", raw)
	var b strings.Builder
	for i := 0; i < arr.Length(); i++ {
		it := arr.Index(i)
		id := it.Get("id").String()
		prompt := it.Get("prompt").String()
		u := it.Get("url").String()
		model := it.Get("model").String()
		w := it.Get("width")
		h := it.Get("height")
		esc := func(s string) string {
			s = strings.ReplaceAll(s, "&", "&amp;")
			s = strings.ReplaceAll(s, "<", "&lt;")
			s = strings.ReplaceAll(s, "\"", "&quot;")
			return s
		}
		cap := prompt
		if len(cap) > 110 {
			cap = cap[:110]
		}
		b.WriteString(`<figure class="cr-card" data-id="` + esc(id) + `"><img src="` + esc(u) + `" alt="" loading="lazy"><figcaption>` + esc(cap) + `<em>` + esc(model) + ` · ` + fmt.Sprint(w) + `×` + fmt.Sprint(h) + `</em></figcaption></figure>`)
	}
	setHTML(grid, b.String())
}
