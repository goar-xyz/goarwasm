//go:build js && wasm

package appui

import (
	"fmt"
	"strings"
	"sync"
	"syscall/js"

	"github.com/goarxyz/goar/internal/core/persist"
	"github.com/google/uuid"
)

// App is the single-WASM browser application.
type App struct {
	mu       sync.Mutex
	cfg      *AppConfig
	store    *persist.Store
	session  string
	busy     bool
	termID   string
	termMode string
	wizard   int
	// live stream buffers (Vibe AssistantMessage / ReasoningMessage)
	streamBuf  string
	thinkBuf   string
	liveToolID string
	// callbacks registered with global goar (set by cmd/goar-wasm)
	Goar js.Value
}

var globalApp *App
var pendingGoar js.Value // set by SetGoar before Boot creates globalApp

// Boot hydrates the design HTML shell (cred/rail/chat/term/Firefox) and starts the app.
func Boot() {
	a := &App{wizard: 1}
	globalApp = a
	// Prefer explicit SetGoar stash; fall back to window.goar (main sets it before Boot).
	if pendingGoar.Truthy() {
		a.Goar = pendingGoar
	} else if g := js.Global().Get("goar"); g.Truthy() {
		a.Goar = g
	}
	store, err := persist.Open("")
	if err != nil {
		fmt.Println("appui: persist open:", err)
	} else {
		a.store = store
		setConfigStore(store)
	}
	a.cfg = loadConfig()
	if a.cfg == nil {
		a.cfg = &AppConfig{WispURL: defaultWisp, Puter: &PuterConfig{Enabled: false, Root: "goar-agent-home"}}
	}
	a.wireTransportReconnect()
	sid := localGet(activeSessK)
	if sid == "" {
		sid = uuid.NewString()
		localSet(activeSessK, sid)
		if a.store != nil {
			_, _ = a.store.UpsertSession(sid, "New session")
		}
	}
	a.session = sid
	a.mountShell()
	a.bindGlobalHelpers()
	a.wireNotifyTestHook()
	a.restorePersistedChrome()
	if a.cfg.configured() {
		a.showWorkspace()
	} else if isVibeClean() {
		// web-vibe/: no pack #setup wizard — workspace + settings popup
		a.showWorkspace()
		a.vibeCleanAfterBoot()
	} else {
		a.showWizard()
	}
	go a.hydrateOPFS()
	fmt.Println("appui: Go UI booted (single-wasm app)")
}

// SetGoar attaches the globalThis.goar object so UI can call configure/runAgent/openTerm.
// Safe to call before Boot — value is stashed and applied when the App is created.
func SetGoar(goar js.Value) {
	pendingGoar = goar
	if globalApp != nil {
		globalApp.Goar = goar
		globalApp.bindGlobalHelpers()
	}
}

func (a *App) wireChrome() {
	// Vibe CLI: Enter submits — no send button. Input id is #input (textual_ui).
	inp := chatInput()
	if inp.Truthy() {
		on(inp, "keydown", func(ev js.Value) {
			if ev.Get("key").String() == "Enter" && !ev.Get("shiftKey").Bool() {
				// Slash popup may consume Enter via wireSlashCompletion
				pop := byID("completion-popup")
				if pop.Truthy() && (hasClass(pop, "open") || pop.Get("dataset").Get("open").String() == "1") {
					val := strings.TrimSpace(inp.Get("value").String())
					if strings.HasPrefix(val, "/") && !strings.Contains(strings.TrimPrefix(val, "/"), " ") {
						return
					}
				}
				ev.Call("preventDefault")
				a.sendPrompt()
			}
		})
	}
	a.wireSlashCompletion()
	// Auto-grow Vibe #input textarea (textual_ui TextArea height: auto)
	if inp := chatInput(); inp.Truthy() {
		grow := func(js.Value) {
			inp.Get("style").Set("height", "auto")
			h := inp.Get("scrollHeight").Int()
			if h < 48 {
				h = 48
			}
			inp.Get("style").Set("height", fmt.Sprintf("%dpx", h))
		}
		on(inp, "input", grow)
		grow(js.Value{})
	}
	if byID("btn-session-new").Truthy() {
		on(byID("btn-session-new"), "click", func(js.Value) { a.newSession() })
	}
	if byID("btn-session-clear").Truthy() {
		on(byID("btn-session-clear"), "click", func(js.Value) { a.clearSession() })
	}
	if byID("history-clear").Truthy() {
		on(byID("history-clear"), "click", func(js.Value) { a.clearSession() })
	}
	if byID("hdr-new").Truthy() {
		on(byID("hdr-new"), "click", func(js.Value) { a.newSession() })
	}
	if byID("btn-term-reconnect").Truthy() {
		on(byID("btn-term-reconnect"), "click", func(js.Value) { a.connectTerm("") })
	}
	if byID("btn-term-disconnect").Truthy() {
		on(byID("btn-term-disconnect"), "click", func(js.Value) { a.disconnectTerm() })
	}
	if byID("btn-term-local").Truthy() {
		on(byID("btn-term-local"), "click", func(js.Value) { a.connectTerm("local") })
	}
	if byID("btn-term-ssh").Truthy() {
		on(byID("btn-term-ssh"), "click", func(js.Value) { a.connectTerm("ssh") })
	}
	// vnc-reload wired in wireDesktopPanel
	if byID("btn-ask-submit").Truthy() {
		on(byID("btn-ask-submit"), "click", func(js.Value) { a.submitAsk() })
	}
	if byID("abortBtn").Truthy() {
		on(byID("abortBtn"), "click", func(js.Value) {
			if a.Goar.Truthy() && a.Goar.Get("abortAgent").Type() == js.TypeFunction {
				a.Goar.Call("abortAgent")
			}
			a.finishBusy()
		})
	}
	a.wireFirefoxChrome()
	a.wireFilesChrome()
	a.wireCreativePanel()
	a.wireDesktopPanel()
}

func (a *App) toast(msg, kind string) {
	el := byID("toast")
	if !el.Truthy() {
		return
	}
	setText(el, msg)
	el.Set("className", kind)
	addClass(el, "show")
	win().Call("setTimeout", onceFunc(func(this js.Value, args []js.Value) any {
		setText(el, "")
		remClass(el, "show")
		return nil
	}), 3200)
}

func (a *App) togglePanel(id string) {
	if id == "settings-panel" || id == "settings" {
		box := byID("settings")
		if box.Truthy() && hasClass(box, "open") {
			a.closeSettingsPanel()
		} else {
			a.showSettings()
		}
		return
	}
	if id == "sessions-panel" || id == "history-overlay" {
		a.toggleHistory()
		return
	}
	p := byID(id)
	if !p.Truthy() {
		return
	}
	if hasClass(p, "hidden") {
		remClass(p, "hidden")
	} else {
		addClass(p, "hidden")
	}
}

func (a *App) showWorkspace() {
	doc := js.Global().Get("document")
	if doc.Truthy() {
		if b := doc.Get("body"); b.Truthy() {
			addClass(b, "goar-ready")
		}
	}
	if setup := byID("setup"); setup.Truthy() {
		addClass(setup, "hide")
		addClass(setup, "hidden")
	}
	if wiz := byID("wizard"); wiz.Truthy() {
		addClass(wiz, "hidden")
	}
	if cp := byID("credPhase"); cp.Truthy() {
		remClass(cp, "on")
		remClass(cp, "show")
		setHiddenAttr(cp, true)
		addClass(cp, "hidden")
	}
	// Design HTML: #app is the workspace shell
	if app := byID("app"); app.Truthy() {
		addClass(app, "show")
		remClass(app, "hidden")
		app.Get("style").Set("display", "flex")
	}
	if shell := byID("app-shell"); shell.Truthy() {
		remClass(shell, "hidden")
	}
	if stop := win().Get("__goarStopParticles"); stop.Type() == js.TypeFunction {
		stop.Invoke()
	}
	a.refreshStatus()
	a.renderMessages()
	a.ensureConfigured()
	// Same process as modular runSetup: ensureSsh({ reason: "boot" })
	a.ensureSshBoot("boot")
	a.showView("chat")
	if inp := chatInput(); inp.Truthy() {
		inp.Call("focus")
	}
}

func (a *App) showWizard() {
	if setup := byID("setup"); setup.Truthy() {
		remClass(setup, "hide")
		remClass(setup, "hidden")
	}
	if app := byID("app"); app.Truthy() {
		remClass(app, "show")
		app.Get("style").Set("display", "none")
	}
	if shell := byID("app-shell"); shell.Truthy() {
		addClass(shell, "hidden")
	}
	if bp := byID("bootPhase"); bp.Truthy() {
		setHiddenAttr(bp, true)
		addClass(bp, "hidden")
	}
	if cp := byID("credPhase"); cp.Truthy() {
		setHiddenAttr(cp, false)
		remClass(cp, "hidden")
		addClass(cp, "on")
		addClass(cp, "show")
	}
	a.renderCredPhase()
}

func (a *App) bindGlobalHelpers() {
	if !a.Goar.Truthy() {
		return
	}
	if a.Goar.Get("onAskUser").Type() == js.TypeFunction {
		a.Goar.Call("onAskUser", retainFunc(js.FuncOf(func(this js.Value, args []js.Value) any {
			prompt := "Agent question"
			id := ""
			if len(args) > 0 {
				ev := args[0]
				if ev.Type() == js.TypeObject {
					if ev.Get("prompt").Truthy() {
						prompt = ev.Get("prompt").String()
					} else if ev.Get("question").Truthy() {
						prompt = ev.Get("question").String()
					}
					if ev.Get("id").Truthy() {
						id = ev.Get("id").String()
					}
				} else if ev.Type() == js.TypeString {
					prompt = ev.String()
				}
			}
			if len(args) > 1 && args[1].Type() == js.TypeString {
				id = args[1].String()
			}
			setText(byID("ask-prompt"), prompt)
			byID("ask-modal").Get("dataset").Set("askId", id)
			byID("ask-answer").Set("value", "")
			remClass(byID("ask-modal"), "hidden")
			notifyAttention("ask", truncateRunes(prompt, 120))
			return nil
		})))
	}
}

func (a *App) refreshStatus() {
	a.updateKaliChip()
	parts := []string{"Go WASM app"}
	model := ""
	if a.Goar.Truthy() && a.Goar.Get("status").Type() == js.TypeFunction {
		st := a.Goar.Call("status")
		if st.Truthy() {
			if t := st.Get("transportMode"); t.Truthy() {
				parts = append(parts, t.String())
			}
			if w := st.Get("wispURL"); w.Truthy() && w.String() != "" {
				parts = append(parts, "wisp")
			}
			if st.Get("sshConfigured").Truthy() && st.Get("sshConfigured").Bool() {
				parts = append(parts, "ssh "+st.Get("sshHost").String())
			}
			if st.Get("termAPI").Truthy() && st.Get("termAPI").Bool() {
				parts = append(parts, "term")
			}
			if st.Get("persistEngine").Truthy() {
				parts = append(parts, st.Get("persistEngine").String())
			}
		}
	}
	if a.cfg != nil && a.cfg.Provider != nil {
		model = a.cfg.Provider.Model
		if model != "" {
			parts = append(parts, model)
		}
	}
	line := byID("hdr-status-text")
	if !line.Truthy() {
		line = byID("status-line")
	}
	if line.Truthy() {
		setText(line, strings.Join(parts, " · "))
	}
	// Vibe banner fields
	if bm := byID("banner-model"); bm.Truthy() {
		if model == "" {
			model = "ready"
		}
		setText(bm, model)
	}
	if counts := byID("banner-meta-counts"); counts.Truthy() {
		setText(counts, strings.Join(parts, " · "))
	}
	if am := byID("active-model"); am.Truthy() && model != "" {
		setText(am, model)
	}
}


func (a *App) updateKaliChip() {
	chip := byID("kali-status-chip")
	if !chip.Truthy() || !a.Goar.Truthy() {
		return
	}
	st := a.Goar.Call("status")
	if !st.Truthy() {
		setHiddenAttr(chip, true)
		return
	}
	connected := st.Get("sharedSSHConnected").Truthy() && st.Get("sharedSSHConnected").Bool()
	want := st.Get("sharedSSHWantLive").Truthy() && st.Get("sharedSSHWantLive").Bool()
	host := ""
	if st.Get("sharedSSHHost").Truthy() {
		host = st.Get("sharedSSHHost").String()
	}
	if !connected && !want {
		setHiddenAttr(chip, true)
		return
	}
	msg := "Kali agent session live"
	if host != "" {
		msg = "Kali · " + host + " (agent-driven from chat)"
	} else if want && !connected {
		msg = "Kali connecting… (stays on while you chat)"
	}
	setText(chip, msg)
	setHiddenAttr(chip, false)
	addClass(chip, "on")
}

func (a *App) ensureConfigured() {
	if !a.Goar.Truthy() || a.cfg == nil {
		return
	}
	cfg := a.cfg
	obj := win().Get("Object").New()
	obj.Set("wispURL", cfg.WispURL)
	if cfg.Provider != nil {
		obj.Set("apiKey", cfg.Provider.APIKey)
		obj.Set("baseURL", cfg.Provider.BaseURL)
		obj.Set("model", cfg.Provider.Model)
	}
	think := cfg.Thinking
	if think == "" {
		think = "off"
	}
	obj.Set("thinking", think)
	// Always resolve SSH like modular resolveSshTarget (Kali defaults when empty).
	tgt := resolveSSHTarget(cfg)
	cfg.SSH = &SSHConfig{
		Host: tgt.Host, Port: tgt.Port, User: tgt.User, Password: tgt.Password,
		PrivateKey: tgt.PrivateKey, Secret: tgt.Secret, ReconnectHost: tgt.ReconnectHost,
		TrustOnFirstUse: true,
	}
	ssh := win().Get("Object").New()
	ssh.Set("host", tgt.Host)
	ssh.Set("port", tgt.Port)
	ssh.Set("user", tgt.User)
	if tgt.Password != "" {
		ssh.Set("password", tgt.Password)
	}
	if tgt.PrivateKey != "" {
		ssh.Set("privateKey", tgt.PrivateKey)
	}
	if tgt.Secret != "" {
		ssh.Set("secret", tgt.Secret)
	}
	if tgt.ReconnectHost != "" {
		ssh.Set("reconnectHost", tgt.ReconnectHost)
	}
	// ports array → dial order [443,22] for Kali (connectOnce parity)
	portsArr := win().Get("Array").New()
	for i, p := range tgt.Ports {
		portsArr.SetIndex(i, p)
	}
	ssh.Set("ports", portsArr)
	ssh.Set("trustOnFirstUse", true)
	obj.Set("ssh", ssh)
	a.Goar.Call("configure", obj)
	a.refreshStatus()
}

// ensureSshBoot mirrors modular ensureSsh({ reason }): configure then SharedSSH connect.
func (a *App) ensureSshBoot(reason string) {
	if a == nil || !a.Goar.Truthy() {
		return
	}
	a.ensureConfigured()
	// Always keep chat as the landing view. Kali is warmed via SharedSSH only —
	// never open the terminal panel on boot (that was squashing/covering chat).
	force := reason == "settings" || reason == "reconnect"
	win().Call("setTimeout", onceFunc(func(this js.Value, args []js.Value) any {
		if !a.sshIsConfigured() {
			a.updateKaliChip()
			return nil
		}
		if force {
			a.tryReattachSSH(reason)
		} else if a.Goar.Get("reconnectSSH").Type() == js.TypeFunction {
			// Soft ensure: ReconnectSharedSSH / Ensure path without xterm UI.
			opts := win().Get("Object").New()
			opts.Set("cols", 80)
			opts.Set("rows", 24)
			a.Goar.Call("reconnectSSH", opts)
		} else {
			a.tryReattachSSH("boot")
		}
		a.updateKaliChip()
		return nil
	}), 0)
}

// wireTransportReconnect heals Wisp/SSH after tab sleep, BFCache restore, or
// visibility wake without a full page reload.
func (a *App) wireTransportReconnect() {
	if win().Get("__goarTransportReconnectWired").Truthy() {
		return
	}
	win().Set("__goarTransportReconnectWired", true)
	handler := retainFunc(js.FuncOf(func(this js.Value, args []js.Value) any {
		// Only act when document is visible again.
		doc := js.Global().Get("document")
		if doc.Truthy() {
			st := doc.Get("visibilityState").String()
			if st != "" && st != "visible" {
				return nil
			}
		}
		a.tryReattachSSH("visibility")
		return nil
	}))
	doc := js.Global().Get("document")
	if doc.Truthy() {
		doc.Call("addEventListener", "visibilitychange", handler)
	}
	win().Call("addEventListener", "pageshow", handler)
	win().Call("addEventListener", "online", handler)
	fmt.Println("appui: transport reconnect wired (visibility/pageshow/online)")
}

func (a *App) tryReattachSSH(reason string) {
	if a == nil || !a.sshIsConfigured() {
		return
	}
	if !a.Goar.Truthy() {
		return
	}
	// Skip if shared PTY is already live.
	if a.Goar.Get("sharedSSHStatus").Type() == js.TypeFunction {
		st := a.Goar.Call("sharedSSHStatus")
		if st.Truthy() && st.Get("connected").Truthy() && st.Get("connected").Bool() {
			return
		}
		// If actively reconnecting, let the supervisor finish.
		if st.Truthy() && st.Get("reconnecting").Truthy() && st.Get("reconnecting").Bool() {
			return
		}
	}
	// Prefer dedicated reconnectSSH; fall back to openTerm connect path.
	if a.Goar.Get("reconnectSSH").Type() == js.TypeFunction {
		setTermStatus("Reconnecting SSH ("+reason+")…", "warn")
		cols, rows := 80, 24
		if t := win().Get("__goarTerm"); t.Truthy() {
			if c := t.Get("cols").Int(); c >= 10 {
				cols = c
			}
			if r := t.Get("rows").Int(); r >= 5 {
				rows = r
			}
		}
		opts := win().Get("Object").New()
		opts.Set("cols", cols)
		opts.Set("rows", rows)
		opts.Set("callback", onceFunc(func(this js.Value, args []js.Value) any {
			if len(args) == 0 {
				return nil
			}
			r := args[0]
			if r.Get("ok").Bool() {
				host := ""
				if r.Get("host").Truthy() {
					host = r.Get("host").String()
				}
				msg := "SSH reattached"
				if host != "" {
					msg += " · " + host
				}
				setTermStatus(msg, "ok")
				a.toast(msg, "ok")
				// Ensure UI term listener is bound if user had term open.
				if a.termID == "" && a.termMode == "ssh" {
					a.connectTerm("ssh")
				} else if a.termID == "" {
					// Soft reattach status only; user can open terminal.
				}
			} else {
				err := "reconnect failed"
				if r.Get("error").Truthy() {
					err = r.Get("error").String()
				}
				setTermStatus(err, "err")
			}
			a.refreshStatus()
			return nil
		}))
		a.Goar.Call("reconnectSSH", opts)
		return
	}
	// Legacy: re-run connectTerm which EnsureSharedSSHTerm reuses/recreates.
	if a.termMode == "ssh" || a.sshIsConfigured() {
		a.connectTerm("ssh")
	}
}
