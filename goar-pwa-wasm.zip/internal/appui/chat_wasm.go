//go:build js && wasm

package appui

import (
	"encoding/json"
	"fmt"
	"html"
	"regexp"
	"strings"
	"syscall/js"

	"github.com/goarxyz/goar/internal/cli"
)

// Vibe textual_ui message DOM parity (widgets/messages.py + tools.py + app.tcss).
// Class names mirror upstream; brand accent is red (#E11D2E) via web/vibe.css.

func (a *App) renderMessages() {
	box := chatMessagesHost()
	if !box.Truthy() || a.store == nil {
		return
	}
	// Remove prior vibe message nodes; banner lives outside #messages
	old := box.Call("querySelectorAll", ":scope > .user-message, :scope > .assistant-message, :scope > .reasoning-message, :scope > .tool-call, :scope > .tool-result, :scope > .bash-output-message, :scope > .error-message, :scope > .interrupt-message, :scope > .warning-message, :scope > .queue-header-message, :scope > .msg, :scope > .slash-command-message")
	for i := old.Length() - 1; i >= 0; i-- {
		box.Call("removeChild", old.Index(i))
	}
	msgs := a.store.ListMessages(a.session)
	if len(msgs) > 0 {
		hideWelcome()
	} else {
		showWelcome()
	}
	prevUser := false
	for _, m := range msgs {
		switch m.Role {
		case "user":
			node := buildUserMessage(m.Content, strings.HasPrefix(strings.TrimSpace(m.Content), "/"), false)
			if prevUser {
				addClass(node, "follows-user")
			}
			appendChild(box, node)
			prevUser = true
		case "assistant", "ai":
			prevUser = false
			if strings.HasPrefix(m.Content, "Error:") {
				appendChild(box, buildErrorMessage(m.Content))
			} else {
				appendChild(box, buildAssistantMessage(m.Content, false))
			}
		case "reasoning", "thinking":
			prevUser = false
			appendChild(box, buildReasoningMessage(m.Content, true, true))
		case "tool":
			prevUser = false
			name := m.ToolName
			if name == "" {
				name = "tool"
			}
			content := m.Content
			if isBashTool(name) && looksLikeBashOutput(content) {
				cmd, out, okExit := parseBashStored(content)
				appendChild(box, buildBashOutputMessage(cmd, out, okExit, false))
			} else if strings.HasPrefix(content, "→") || strings.HasPrefix(content, "calling") {
				appendChild(box, buildToolCallMessage(name, content, true, false, ""))
			} else {
				appendChild(box, buildToolCallMessage(name, summarizeToolLine(name, content), false, !strings.Contains(strings.ToLower(content), "error"), ""))
				if body := strings.TrimSpace(stripToolArrow(content)); body != "" && body != name {
					appendChild(box, buildToolResultMessage(name, body, strings.Contains(strings.ToLower(content), "error")))
				}
			}
		case "error":
			prevUser = false
			appendChild(box, buildErrorMessage(m.Content))
		default:
			prevUser = false
			appendChild(box, buildAssistantMessage(m.Content, false))
		}
	}
	scrollChatBottom(box)
}

func (a *App) appendLocal(role, content, toolName string) {
	if a.store != nil {
		_, _ = a.store.AppendMessage(a.session, role, content, toolName)
	}
	a.renderMessages()
	go a.syncPersist()
}

func (a *App) sendPrompt() {
	a.mu.Lock()
	if a.busy {
		a.mu.Unlock()
		return
	}
	ta := chatInput()
	text := strings.TrimSpace(ta.Get("value").String())
	if text == "" {
		a.mu.Unlock()
		return
	}
	ta.Set("value", "")
	a.hideSlashPopup()
	a.busy = true
	a.streamBuf = ""
	a.thinkBuf = ""
	a.liveToolID = ""
	a.mu.Unlock()
	a.setBusyUI(true, "Thinking")

	if strings.HasPrefix(text, "/") {
		a.handleSlash(text)
		a.mu.Lock()
		a.busy = false
		a.mu.Unlock()
		if btn := chatSendBtn(); btn.Truthy() {
			btn.Set("disabled", false)
		}
		a.setBusyUI(false, "")
		return
	}

	hideWelcome()
	a.appendLocal("user", text, "")
	// Placeholder assistant bubble for streaming (Vibe AssistantMessage)
	box := chatMessagesHost()
	if box.Truthy() {
		ph := buildAssistantMessage("", true)
		ph.Set("id", "stream-assistant")
		appendChild(box, ph)
		scrollChatBottom(box)
	}
	if a.store != nil {
		_, _ = a.store.AppendMessage(a.session, "assistant", "…", "")
	}

	a.ensureConfigured()
	if !a.Goar.Truthy() || a.Goar.Get("runAgent").Type() != js.TypeFunction {
		a.replaceLastAssistant("Error: goar.runAgent missing")
		a.finishBusy()
		return
	}

	if a.Goar.Get("runAgentStream").Type() == js.TypeFunction {
		a.Goar.Call("runAgentStream", text, retainFunc(js.FuncOf(func(this js.Value, args []js.Value) any {
			if len(args) == 0 {
				return nil
			}
			a.onAgentEvent(args[0])
			return nil
		})))
		return
	}

	a.Goar.Call("runAgent", text, onceFunc(func(this js.Value, args []js.Value) any {
		res := js.Undefined()
		if len(args) > 0 {
			res = args[0]
		}
		content := ""
		if res.Truthy() && res.Get("ok").Bool() {
			content = res.Get("text").String()
			if content == "" {
				content = "(empty)"
			}
		} else {
			err := "unknown"
			if res.Truthy() {
				err = res.Get("error").String()
			}
			content = "Error: " + err
		}
		a.replaceLastAssistant(content)
		a.mirrorTerm(content)
		notifyAttention("done", truncateRunes(content, 80))
		a.finishBusy()
		return nil
	}))
}

func (a *App) onAgentEvent(ev js.Value) {
	typ := ev.Get("type").String()
	switch typ {
	case "assistant_delta", "assistant":
		content := ev.Get("content").String()
		if content == "" && ev.Get("payload").Truthy() {
			content = ev.Get("payload").String()
		}
		// Runtime emits per-chunk deltas for assistant.
		a.updateStreamingAssistant(content)
		a.setBusyUI(true, "Writing")
	case "reasoning", "thinking", "reasoning_delta", "thinking_delta":
		content := ev.Get("content").String()
		if content == "" {
			content = payloadContent(ev)
		}
		a.updateStreamingReasoning(content)
		a.setBusyUI(true, "Thinking")
	case "tool_call":
		name := ev.Get("name").String()
		args := ev.Get("args").String()
		id := ev.Get("id").String()
		a.liveToolID = id
		if isBashTool(name) {
			cmd := extractBashCommand(args)
			a.appendBashLive(cmd, id)
		} else {
			a.appendToolCallLive(name, args, id)
		}
		a.mirrorTerm("[tool] " + name)
		if a.store != nil {
			_, _ = a.store.AddToolEvent(a.session, name, args, "", "")
			_, _ = a.store.AppendMessage(a.session, "tool", "→ "+name+" "+truncateRunes(args, 200), name)
		}
		a.setBusyUI(true, name)
	case "tool_result":
		name := ev.Get("name").String()
		result := ev.Get("result").String()
		id := ev.Get("id").String()
		errStr := ""
		if ev.Get("error").Truthy() {
			errStr = ev.Get("error").String()
		}
		ok := errStr == ""
		a.finishToolLive(name, result, errStr, id, ok)
		msg := result
		if errStr != "" {
			msg = "error: " + errStr
		}
		if a.store != nil {
			_, _ = a.store.AddToolEvent(a.session, name, "", result, errStr)
			_, _ = a.store.AppendMessage(a.session, "tool", "← "+name+"\n"+truncateRunes(msg, 800), name)
		}
	case "done":
		a.collapseReasoningLive()
		if ev.Get("ok").Truthy() && !ev.Get("ok").Bool() {
			a.replaceLastAssistant("Error: " + ev.Get("error").String())
		} else if t := ev.Get("text"); t.Truthy() && t.String() != "" {
			a.replaceLastAssistant(t.String())
		} else if a.streamBuf != "" {
			a.replaceLastAssistant(a.streamBuf)
		}
		notifyAttention("done", "Agent turn complete")
		a.finishBusy()
	case "error":
		a.replaceLastAssistant("Error: " + ev.Get("error").String())
		a.finishBusy()
	default:
		// ignore unknown (no telemetry/junk surfaces)
	}
}

func payloadContent(ev js.Value) string {
	raw := ev.Get("payload").String()
	if raw == "" {
		return ""
	}
	var m map[string]any
	if json.Unmarshal([]byte(raw), &m) == nil {
		if c, ok := m["content"].(string); ok {
			return c
		}
	}
	return raw
}

func (a *App) updateStreamingAssistant(delta string) {
	box := chatMessagesHost()
	if !box.Truthy() {
		return
	}
	a.streamBuf += delta
	node := byID("stream-assistant")
	if !node.Truthy() {
		node = box.Call("querySelector", ".assistant-message.streaming")
	}
	if !node.Truthy() {
		node = buildAssistantMessage(a.streamBuf, true)
		node.Set("id", "stream-assistant")
		appendChild(box, node)
	} else {
		setHTML(node, renderMarkdown(a.streamBuf)+`<span class="stream-cursor"></span>`)
		addClass(node, "streaming")
	}
	scrollChatBottom(box)
}

func (a *App) updateStreamingReasoning(delta string) {
	box := chatMessagesHost()
	if !box.Truthy() {
		return
	}
	a.thinkBuf += delta
	node := byID("stream-reasoning")
	if !node.Truthy() {
		node = buildReasoningMessage(a.thinkBuf, false, false)
		node.Set("id", "stream-reasoning")
		// Insert before streaming assistant if present
		asst := byID("stream-assistant")
		if asst.Truthy() {
			box.Call("insertBefore", node, asst)
		} else {
			appendChild(box, node)
		}
	} else {
		body := node.Call("querySelector", ".reasoning-message-content")
		if body.Truthy() {
			setText(body, a.thinkBuf)
			body.Set("hidden", false)
		}
		ind := node.Call("querySelector", ".reasoning-indicator")
		if ind.Truthy() {
			setText(ind, "●")
		}
		st := node.Call("querySelector", ".reasoning-collapsed-text")
		if st.Truthy() {
			setText(st, "Thinking")
		}
		remClass(node, "collapsed")
	}
	scrollChatBottom(box)
}

func (a *App) collapseReasoningLive() {
	node := byID("stream-reasoning")
	if !node.Truthy() {
		return
	}
	addClass(node, "collapsed")
	body := node.Call("querySelector", ".reasoning-message-content")
	if body.Truthy() {
		body.Set("hidden", true)
	}
	ind := node.Call("querySelector", ".reasoning-indicator")
	if ind.Truthy() {
		setText(ind, "⏵")
		addClass(ind, "success")
	}
	st := node.Call("querySelector", ".reasoning-collapsed-text")
	if st.Truthy() {
		setText(st, "Thought")
	}
	if a.store != nil && a.thinkBuf != "" {
		_, _ = a.store.AppendMessage(a.session, "reasoning", a.thinkBuf, "")
	}
}

func (a *App) appendToolCallLive(name, args, id string) {
	box := chatMessagesHost()
	if !box.Truthy() {
		return
	}
	summary := name
	if s := summarizeArgsJSON(name, args); s != "" {
		summary = s
	}
	node := buildToolCallMessage(name, summary, true, false, id)
	if id != "" {
		node.Set("id", "tool-"+sanitizeID(id))
	}
	asst := byID("stream-assistant")
	if asst.Truthy() {
		box.Call("insertBefore", node, asst)
	} else {
		appendChild(box, node)
	}
	scrollChatBottom(box)
}

func (a *App) appendBashLive(cmd, id string) {
	box := chatMessagesHost()
	if !box.Truthy() {
		return
	}
	node := buildBashOutputMessage(cmd, "", true, true)
	if id != "" {
		node.Set("id", "tool-"+sanitizeID(id))
	} else {
		node.Set("id", "stream-bash")
	}
	asst := byID("stream-assistant")
	if asst.Truthy() {
		box.Call("insertBefore", node, asst)
	} else {
		appendChild(box, node)
	}
	scrollChatBottom(box)
}

func (a *App) finishToolLive(name, result, errStr, id string, ok bool) {
	box := chatMessagesHost()
	if !box.Truthy() {
		return
	}
	var node js.Value
	if id != "" {
		node = byID("tool-" + sanitizeID(id))
	}
	if !node.Truthy() {
		node = box.Call("querySelector", ".tool-call.running, .bash-output-message.bash-pending")
	}
	if isBashTool(name) || (node.Truthy() && hasClass(node, "bash-output-message")) {
		if node.Truthy() && hasClass(node, "bash-output-message") {
			remClass(node, "bash-pending")
			if ok {
				addClass(node, "bash-success")
			} else {
				addClass(node, "bash-error")
			}
			pr := node.Call("querySelector", ".bash-prompt")
			if pr.Truthy() {
				setText(pr, "$ ")
				remClass(pr, "bash-pending")
				if ok {
					addClass(pr, "bash-success")
				} else {
					addClass(pr, "bash-error")
				}
			}
			out := result
			if errStr != "" {
				out = errStr
			}
			ensureBashOutputBody(node, out)
		} else {
			cmd := extractBashCommand(result)
			if cmd == "" {
				cmd = name
			}
			n := buildBashOutputMessage(cmd, result, ok, false)
			appendChild(box, n)
		}
		scrollChatBottom(box)
		return
	}
	if node.Truthy() && hasClass(node, "tool-call") {
		remClass(node, "running")
		hdr := node.Call("querySelector", ".tool-call-header")
		if hdr.Truthy() {
			remClass(hdr, "running")
		}
		icon := node.Call("querySelector", ".status-indicator-icon")
		if icon.Truthy() {
			if ok {
				setText(icon, "✓")
				addClass(icon, "success")
			} else {
				setText(icon, "✗")
				addClass(icon, "error")
			}
		}
	}
	body := result
	if errStr != "" {
		body = errStr
	}
	res := buildToolResultMessage(name, truncateRunes(body, 2000), !ok)
	if node.Truthy() && node.Get("parentNode").Truthy() {
		node.Get("parentNode").Call("insertBefore", res, node.Get("nextSibling"))
	} else {
		appendChild(box, res)
	}
	scrollChatBottom(box)
}

func ensureBashOutputBody(node js.Value, out string) {
	cont := node.Call("querySelector", ".bash-output-container")
	if !cont.Truthy() {
		cont = el("div")
		addClass(cont, "bash-output-container")
		border := el("div")
		addClass(border, "bash-output-border")
		body := el("pre")
		addClass(body, "bash-output")
		setText(body, out)
		appendChild(cont, border)
		appendChild(cont, body)
		appendChild(node, cont)
		return
	}
	body := cont.Call("querySelector", ".bash-output")
	if body.Truthy() {
		setText(body, out)
	}
}

func (a *App) replaceLastAssistant(content string) {
	if a.store == nil {
		return
	}
	_, _ = a.store.ReplaceLastMessage(a.session, "assistant", content, "")
	// Update live node if present; else full re-render
	node := byID("stream-assistant")
	if node.Truthy() {
		remClass(node, "streaming")
		node.Set("id", "")
		setHTML(node, renderMarkdown(content))
		a.streamBuf = content
		go a.syncPersist()
		return
	}
	a.renderMessages()
	go a.syncPersist()
}

func (a *App) finishBusy() {
	a.mu.Lock()
	a.busy = false
	a.mu.Unlock()
	btn := chatSendBtn()
	if btn.Truthy() {
		btn.Set("disabled", false)
	}
	a.setBusyUI(false, "")
	a.refreshStatus()
}

func (a *App) setBusyUI(on bool, label string) {
	if lw := byID("live-work"); lw.Truthy() {
		setHiddenAttr(lw, !on)
	}
	if label != "" {
		if tx := byID("live-work-text"); tx.Truthy() {
			setText(tx, label)
		}
	}
	btn := chatSendBtn()
	if btn.Truthy() {
		btn.Set("disabled", on)
	}
	ibox := byID("input-box")
	if ibox.Truthy() {
		if on {
			addClass(ibox, "border-recording")
		} else {
			remClass(ibox, "border-recording")
		}
	}
}

func (a *App) mirrorTerm(s string) {
	if a.termID == "" || !a.Goar.Truthy() {
		return
	}
	term := win().Get("__goarTerm")
	if term.Truthy() && term.Get("writeln").Type() == js.TypeFunction {
		term.Call("writeln", "\x1b[90m"+truncateRunes(strings.ReplaceAll(s, "\n", " "), 120)+"\x1b[0m")
	}
}

func (a *App) handleSlash(line string) {
	reg := cli.NewCommandRegistry(nil, nil)
	name, cmd, args, ok := reg.ParseCommand(line)
	_ = cmd
	box := chatMessagesHost()
	if box.Truthy() {
		appendChild(box, buildUserMessage(line, true, false))
		hideWelcome()
		scrollChatBottom(box)
	}
	if a.store != nil {
		_, _ = a.store.AppendMessage(a.session, "user", line, "")
	}
	if !ok {
		a.appendLocal("assistant", "Unknown command. Try /help", "")
		return
	}
	switch name {
	case "help":
		a.appendLocal("assistant", reg.GetHelpText(), "")
	case "clear", "new":
		a.clearSession()
		a.appendLocal("assistant", "Conversation cleared.", "")
		if strings.TrimSpace(args) != "" {
			inp := chatInput()
			if inp.Truthy() {
				inp.Set("value", strings.TrimSpace(args))
				a.sendPrompt()
			}
		}
	case "copy":
		if a.store == nil {
			a.appendLocal("assistant", "No store.", "")
			return
		}
		msgs := a.store.ListMessages(a.session)
		for i := len(msgs) - 1; i >= 0; i-- {
			if msgs[i].Role == "assistant" {
				clipboardWrite(msgs[i].Content)
				a.appendLocal("assistant", fmt.Sprintf("Copied %d characters to clipboard.", len([]rune(msgs[i].Content))), "")
				return
			}
		}
		a.appendLocal("assistant", "No assistant message to copy.", "")
	case "status":
		argsTrim := strings.TrimSpace(strings.ToLower(args))
		if argsTrim == "notify" || argsTrim == "test-notify" {
			notifyAttention("ask", "slash /status notify probe")
			a.appendLocal("assistant", "Notify probe fired (goar-notify → SW + Notification). needsAttention="+localGet("goar.needsAttention"), "")
			return
		}
		st := "{}"
		if a.Goar.Truthy() {
			raw, _ := json.Marshal(jsValueToMap(a.Goar.Call("status")))
			st = string(raw)
		}
		theme, think := a.currentTheme(), a.currentThinking()
		a.appendLocal("assistant", fmt.Sprintf("Status:\ntheme=%s thinking=%s\n%s\nTip: /status notify — fire notification smoke", theme, think, st), "")
	case "model":
		a.showModelPicker()
	case "theme":
		a.showThemePicker()
	case "thinking":
		lvl := strings.TrimSpace(strings.ToLower(args))
		if lvl != "" {
			ok := false
			for _, l := range pwaThinkingLevels {
				if l == lvl {
					ok = true
					break
				}
			}
			if ok {
				a.applyThinking(lvl)
				a.appendLocal("assistant", "Thinking level → "+lvl, "")
				a.toast("Thinking: "+lvl, "ok")
			} else {
				a.appendLocal("assistant", "Usage: /thinking [off|low|medium|high|xhigh] — or omit args to open picker", "")
				a.showThinkingPicker()
			}
		} else {
			a.showThinkingPicker()
		}
	case "mcp", "connectors":
		a.showMCPPanel()
	case "config", "setup", "onboard", "provider", "proxy", "proxy-setup":
		a.showSettings()
		a.appendLocal("assistant", "Settings opened.", "")
	case "resume", "continue", "session":
		a.togglePanel("sessions-panel")
		a.renderSessions()
		a.appendLocal("assistant", "Session picker opened (History).", "")
	case "rewind":
		a.pwaRewind()
	case "compact":
		a.pwaCompact(args)
	case "retry":
		extra := strings.TrimSpace(args)
		if extra != "" {
			inp := chatInput()
			if inp.Truthy() {
				inp.Set("value", extra)
				a.sendPrompt()
			}
		} else {
			a.appendLocal("assistant", "Retry: re-send your last prompt, or pass instructions: /retry <text>", "")
		}
	case "branch":
		old := a.session
		a.newSession()
		if a.store != nil {
			for _, m := range a.store.ListMessages(old) {
				_, _ = a.store.AppendMessage(a.session, m.Role, m.Content, m.ToolName)
			}
			a.renderMessages()
		}
		a.appendLocal("assistant", "Branched into a new session (copy of prior messages).", "")
	case "rename":
		title := strings.TrimSpace(args)
		if title == "" {
			a.appendLocal("assistant", "Usage: /rename <title>", "")
		} else if a.store != nil {
			_, _ = a.store.UpsertSession(a.session, title)
			a.renderSessions()
			a.appendLocal("assistant", "Renamed session to "+title, "")
		}
	case "reload":
		a.appendLocal("assistant", "Reload: re-open Settings to refresh provider/models; skills reload on next agent turn.", "")
	case "skills":
		a.appendLocal("assistant", "Skills live under AGENT_HOME/skills. Use /reload after editing.", "")
	case "log":
		a.appendLocal("assistant", "Interaction logs: AGENT_HOME/logs (OPFS persist in PWA).", "")
	case "log-level":
		lvl := strings.TrimSpace(strings.ToLower(args))
		if lvl == "" {
			a.appendLocal("assistant", "Usage: /log-level debug|info|warn|error", "")
		} else {
			localSet("goar.logLevel", lvl)
			a.appendLocal("assistant", "Log level set to "+lvl+" (this device).", "")
		}
	case "debug":
		a.appendLocal("assistant", "Debug: open browser DevTools. WASM logs print to the console.", "")
	case "voice":
		a.appendLocal("assistant", "Voice input is not available in this build (no microphone pipeline).", "")
		notify("GOAR", "Voice not available")
	case "loop":
		a.appendLocal("assistant", "Loop scheduling is CLI-oriented. Args: "+args, "")
	case "data-retention":
		a.appendLocal("assistant", "Local-first: chats persist on this device (OPFS / IndexedDB). No remote retention policy.", "")
	case "whoami":
		st := "provider-agnostic"
		if a.cfg != nil && a.cfg.Provider != nil {
			st = fmt.Sprintf("provider=%s model=%s", a.cfg.Provider.Key, a.cfg.Provider.Model)
		}
		a.appendLocal("assistant", st, "")
	case "paste-image":
		a.appendLocal("assistant", "Use the attach (+) control or paste an image into the composer when supported.", "")
	case "plugins", "reload-plugins":
		a.appendLocal("assistant", "No experimental harness plugins in this PWA build.", "")
	case "exit", "quit":
		a.appendLocal("assistant", "Close the tab or uninstall the PWA to exit. (No process exit in-browser.)", "")
	default:
		a.appendLocal("assistant", "Command /"+name+" recognized. Args: "+args, "")
	}
}

func (a *App) pwaRewind() {
	if a.store == nil {
		a.appendLocal("assistant", "Rewind: no session store.", "")
		return
	}
	msgs := a.store.ListMessages(a.session)
	// Drop last user+assistant pair when present.
	if len(msgs) == 0 {
		a.appendLocal("assistant", "Rewind: nothing to rewind.", "")
		return
	}
	cut := len(msgs) - 1
	if msgs[cut].Role == "assistant" && cut > 0 {
		cut--
	}
	if cut >= 0 && msgs[cut].Role == "user" {
		// rebuild session without trailing pair
		keep := msgs[:cut]
		_ = a.store.DeleteSession(a.session)
		_, _ = a.store.UpsertSession(a.session, "Rewound session")
		for _, m := range keep {
			_, _ = a.store.AppendMessage(a.session, m.Role, m.Content, m.ToolName)
		}
		a.renderMessages()
		a.appendLocal("assistant", "Rewound one turn.", "")
		notify("GOAR", "Rewound one turn")
		return
	}
	a.appendLocal("assistant", "Rewind: could not find a turn boundary.", "")
}

func (a *App) pwaCompact(instructions string) {
	_ = instructions
	if a.store == nil {
		a.appendLocal("assistant", "Compact: no store.", "")
		return
	}
	msgs := a.store.ListMessages(a.session)
	if len(msgs) < 4 {
		a.appendLocal("assistant", "Compact: conversation too short.", "")
		return
	}
	// Keep last 4 messages; summarize older as a system note.
	keep := msgs[len(msgs)-4:]
	summary := fmt.Sprintf("[compacted %d earlier messages]", len(msgs)-4)
	if strings.TrimSpace(instructions) != "" {
		summary += " focus: " + strings.TrimSpace(instructions)
	}
	_ = a.store.DeleteSession(a.session)
	_, _ = a.store.UpsertSession(a.session, "Compacted session")
	_, _ = a.store.AppendMessage(a.session, "assistant", summary, "")
	for _, m := range keep {
		_, _ = a.store.AppendMessage(a.session, m.Role, m.Content, m.ToolName)
	}
	a.renderMessages()
	a.appendLocal("assistant", "Compacted conversation (kept last 4 messages).", "")
	notify("GOAR", "Conversation compacted")
}

// ---------- DOM builders (Vibe class semantics) ----------

func buildUserMessage(content string, slash, pending bool) js.Value {
	root := el("div")
	addClass(root, "user-message")
	if slash {
		addClass(root, "slash-command-message")
	}
	if pending {
		addClass(root, "pending")
	}
	wrap := el("div")
	addClass(wrap, "user-message-wrapper")
	row := el("div")
	addClass(row, "user-message-container")
	prompt := el("span")
	addClass(prompt, "user-message-prompt")
	setText(prompt, "> ")
	body := el("span")
	addClass(body, "user-message-content")
	setText(body, content)
	appendChild(row, prompt)
	appendChild(row, body)
	appendChild(wrap, row)
	sep := el("div")
	addClass(sep, "user-message-separator")
	appendChild(wrap, sep)
	appendChild(root, wrap)
	return root
}

func buildAssistantMessage(content string, streaming bool) js.Value {
	root := el("div")
	addClass(root, "assistant-message")
	if streaming {
		addClass(root, "streaming")
		setHTML(root, renderMarkdown(content)+`<span class="stream-cursor"></span>`)
	} else {
		setHTML(root, renderMarkdown(content))
	}
	return root
}

func buildReasoningMessage(content string, collapsed, completed bool) js.Value {
	root := el("div")
	addClass(root, "reasoning-message")
	if collapsed {
		addClass(root, "collapsed")
	}
	wrap := el("div")
	addClass(wrap, "reasoning-message-wrapper")
	hdr := el("div")
	addClass(hdr, "reasoning-message-header")
	ind := el("span")
	addClass(ind, "reasoning-indicator")
	if completed {
		if collapsed {
			setText(ind, "⏵")
		} else {
			setText(ind, "⏷")
		}
		addClass(ind, "success")
	} else {
		setText(ind, "●")
	}
	st := el("span")
	addClass(st, "reasoning-collapsed-text")
	if completed {
		setText(st, "Thought")
	} else {
		setText(st, "Thinking")
	}
	appendChild(hdr, ind)
	appendChild(hdr, st)
	body := el("div")
	addClass(body, "reasoning-message-content")
	setText(body, content)
	if collapsed {
		body.Set("hidden", true)
	}
	on(hdr, "click", func(js.Value) {
		now := body.Get("hidden").Bool()
		body.Set("hidden", !now)
		if now {
			remClass(root, "collapsed")
			setText(ind, "⏷")
		} else {
			addClass(root, "collapsed")
			setText(ind, "⏵")
		}
	})
	appendChild(wrap, hdr)
	appendChild(wrap, body)
	appendChild(root, wrap)
	return root
}

func buildToolCallMessage(name, summary string, running, ok bool, id string) js.Value {
	root := el("div")
	addClass(root, "tool-call")
	if running {
		addClass(root, "running")
	}
	cont := el("div")
	addClass(cont, "tool-call-container")
	hdr := el("div")
	addClass(hdr, "tool-call-header")
	if running {
		addClass(hdr, "running")
	}
	icon := el("span")
	addClass(icon, "status-indicator-icon")
	if running {
		setText(icon, "…")
	} else if ok {
		setText(icon, "✓")
		addClass(icon, "success")
	} else {
		setText(icon, "✗")
		addClass(icon, "error")
	}
	text := el("span")
	addClass(text, "status-indicator-text")
	if summary == "" {
		summary = name
	}
	setText(text, summary)
	appendChild(hdr, icon)
	appendChild(hdr, text)
	appendChild(cont, hdr)
	appendChild(root, cont)
	_ = id
	return root
}

func buildToolResultMessage(name, content string, isErr bool) js.Value {
	root := el("div")
	addClass(root, "tool-result")
	if isErr {
		addClass(root, "error-text")
	}
	cont := el("div")
	addClass(cont, "tool-result-container")
	border := el("div")
	addClass(border, "tool-result-border")
	inner := el("div")
	addClass(inner, "tool-result-content")
	detail := el("pre")
	addClass(detail, "tool-result-detail")
	setText(detail, content)
	_ = name
	appendChild(inner, detail)
	appendChild(cont, border)
	appendChild(cont, inner)
	appendChild(root, cont)
	return root
}

func buildBashOutputMessage(command, output string, ok bool, pending bool) js.Value {
	root := el("div")
	addClass(root, "bash-output-message")
	status := "bash-success"
	if pending {
		status = "bash-pending"
	} else if !ok {
		status = "bash-error"
	}
	addClass(root, status)
	line := el("div")
	addClass(line, "bash-command-line")
	pr := el("span")
	addClass(pr, "bash-prompt")
	addClass(pr, status)
	if pending {
		setText(pr, "… ")
	} else {
		setText(pr, "$ ")
	}
	cmd := el("span")
	addClass(cmd, "bash-command")
	setText(cmd, command)
	appendChild(line, pr)
	appendChild(line, cmd)
	appendChild(root, line)
	if !pending && output != "" {
		ensureBashOutputBody(root, output)
	}
	return root
}

func buildErrorMessage(content string) js.Value {
	root := el("div")
	addClass(root, "error-message")
	cont := el("div")
	addClass(cont, "error-container")
	border := el("div")
	addClass(border, "error-border")
	body := el("div")
	addClass(body, "error-content")
	setText(body, content)
	appendChild(cont, border)
	appendChild(cont, body)
	appendChild(root, cont)
	return root
}

// ---------- slash completion popup ----------

func (a *App) wireSlashCompletion() {
	inp := chatInput()
	if !inp.Truthy() || inp.Get("dataset").Get("slashWired").String() == "1" {
		return
	}
	inp.Get("dataset").Set("slashWired", "1")
	on(inp, "input", func(js.Value) {
		a.refreshSlashPopup()
	})
	on(inp, "keydown", func(ev js.Value) {
		key := ev.Get("key").String()
		pop := byID("completion-popup")
		open := pop.Truthy() && (hasClass(pop, "open") || pop.Get("dataset").Get("open").String() == "1")
		if !open {
			return
		}
		rows := pop.Call("querySelectorAll", ".completion-row")
		if rows.Length() == 0 {
			return
		}
		idx := 0
		for i := 0; i < rows.Length(); i++ {
			if hasClass(rows.Index(i), "completion-selected") {
				idx = i
				break
			}
		}
		switch key {
		case "ArrowDown":
			ev.Call("preventDefault")
			remClass(rows.Index(idx), "completion-selected")
			idx = (idx + 1) % rows.Length()
			addClass(rows.Index(idx), "completion-selected")
		case "ArrowUp":
			ev.Call("preventDefault")
			remClass(rows.Index(idx), "completion-selected")
			idx = (idx - 1 + rows.Length()) % rows.Length()
			addClass(rows.Index(idx), "completion-selected")
		case "Tab", "Enter":
			if key == "Enter" && !ev.Get("shiftKey").Bool() {
				// If popup open and selection present, apply completion instead of send when text is only /cmd prefix
				val := strings.TrimSpace(inp.Get("value").String())
				if strings.HasPrefix(val, "/") && !strings.Contains(strings.TrimPrefix(val, "/"), " ") {
					ev.Call("preventDefault")
					a.applySlashSelection(rows.Index(idx))
				}
			} else if key == "Tab" {
				ev.Call("preventDefault")
				a.applySlashSelection(rows.Index(idx))
			}
		case "Escape":
			ev.Call("preventDefault")
			a.hideSlashPopup()
		}
	})
}

func (a *App) refreshSlashPopup() {
	inp := chatInput()
	pop := byID("completion-popup")
	if !inp.Truthy() || !pop.Truthy() {
		return
	}
	val := inp.Get("value").String()
	if !strings.HasPrefix(val, "/") || strings.Contains(val, " ") {
		a.hideSlashPopup()
		return
	}
	q := strings.ToLower(strings.TrimPrefix(val, "/"))
	clear(pop)
	n := 0
	reg := cli.NewCommandRegistry(nil, nil)
	for _, ent := range reg.EntriesForCompleter() {
		alias, desc := ent[0], ent[1]
		al := strings.ToLower(strings.TrimPrefix(alias, "/"))
		if q != "" && !strings.HasPrefix(al, q) {
			continue
		}
		row := el("div")
		addClass(row, "completion-row")
		if n == 0 {
			addClass(row, "completion-selected")
		}
		cmd := el("span")
		addClass(cmd, "completion-command")
		setText(cmd, alias)
		d := el("span")
		addClass(d, "completion-description")
		setText(d, desc)
		appendChild(row, cmd)
		appendChild(row, d)
		ins := alias
		on(row, "mousedown", func(ev js.Value) {
			ev.Call("preventDefault")
			inp.Set("value", ins+" ")
			a.hideSlashPopup()
			inp.Call("focus")
		})
		appendChild(pop, row)
		n++
		if n >= 64 {
			break
		}
	}
	if n == 0 {
		a.hideSlashPopup()
		return
	}
	pop.Set("hidden", false)
	addClass(pop, "open")
	pop.Get("dataset").Set("open", "1")
}

func (a *App) applySlashSelection(row js.Value) {
	inp := chatInput()
	if !inp.Truthy() || !row.Truthy() {
		return
	}
	cmd := row.Call("querySelector", ".completion-command")
	if cmd.Truthy() {
		inp.Set("value", cmd.Get("textContent").String()+" ")
	}
	a.hideSlashPopup()
}

func (a *App) hideSlashPopup() {
	pop := byID("completion-popup")
	if !pop.Truthy() {
		return
	}
	remClass(pop, "open")
	pop.Get("dataset").Set("open", "0")
	pop.Set("hidden", true)
	clear(pop)
}

// ---------- helpers ----------

func truncateRunes(s string, n int) string {
	r := []rune(s)
	if len(r) <= n {
		return s
	}
	return string(r[:n]) + "…"
}

func jsValueToMap(v js.Value) map[string]any {
	out := map[string]any{}
	if !v.Truthy() {
		return out
	}
	keys := win().Get("Object").Call("keys", v)
	for i := 0; i < keys.Length(); i++ {
		k := keys.Index(i).String()
		val := v.Get(k)
		switch val.Type() {
		case js.TypeString:
			out[k] = val.String()
		case js.TypeBoolean:
			out[k] = val.Bool()
		case js.TypeNumber:
			out[k] = val.Float()
		default:
			out[k] = val.String()
		}
	}
	return out
}

func (a *App) newSession() {
	id := newID()
	a.session = id
	localSet(activeSessK, id)
	if a.store != nil {
		_, _ = a.store.UpsertSession(id, "New session")
	}
	a.streamBuf = ""
	a.thinkBuf = ""
	a.renderMessages()
	a.renderSessions()
	a.toast("New session", "ok")
}

func (a *App) clearSession() {
	if a.store != nil {
		_ = a.store.DeleteSession(a.session)
		_, _ = a.store.UpsertSession(a.session, "New session")
	}
	a.streamBuf = ""
	a.thinkBuf = ""
	a.renderMessages()
	go a.syncPersist()
}

func (a *App) renderSessions() {
	box := historyListHost()
	if !box.Truthy() || a.store == nil {
		return
	}
	clear(box)
	for _, s := range a.store.ListSessions() {
		btn := el("button")
		btn.Set("type", "button")
		mark := "○ "
		if s.ID == a.session {
			mark = "● "
		}
		setText(btn, mark+s.Title+" · "+s.UpdatedAt)
		id := s.ID
		on(btn, "click", func(js.Value) {
			a.session = id
			localSet(activeSessK, id)
			a.renderMessages()
			a.renderSessions()
		})
		appendChild(box, btn)
	}
}

func newID() string {
	if win().Get("crypto").Truthy() && win().Get("crypto").Get("randomUUID").Type() == js.TypeFunction {
		return win().Get("crypto").Call("randomUUID").String()
	}
	return fmt.Sprintf("s%d", js.Global().Get("Date").New().Call("getTime").Int())
}

func (a *App) submitAsk() {
	ans := byID("ask-answer").Get("value").String()
	addClass(byID("ask-modal"), "hidden")
	if a.Goar.Truthy() && a.Goar.Get("answerAskUser").Type() == js.TypeFunction {
		id := byID("ask-modal").Get("dataset").Get("askId").String()
		a.Goar.Call("answerAskUser", id, ans)
	}
}

func chatMessagesHost() js.Value {
	if h := byID("messages"); h.Truthy() {
		return h
	}
	if h := byID("chat-inner"); h.Truthy() && !h.Get("hidden").Bool() {
		return h
	}
	return byID("messages")
}

func chatInput() js.Value {
	// Vibe textual_ui uses #input (ChatTextArea id="input"); msg-input is legacy alias.
	if h := byID("input"); h.Truthy() {
		return h
	}
	if h := byID("msg-input"); h.Truthy() {
		return h
	}
	return js.Value{}
}

func chatSendBtn() js.Value {
	if h := byID("send-btn"); h.Truthy() {
		return h
	}
	return byID("btn-send")
}

func historyListHost() js.Value {
	if h := byID("history-list"); h.Truthy() {
		return h
	}
	return byID("sessions-list")
}

func hideWelcome() {
	// Vibe banner stays visible at top of #chat (not a welcome-chips panel).
}

func showWelcome() {
	// No welcome/chips UI — empty #messages under the Vibe banner is correct.
}

func scrollChatBottom(box js.Value) {
	if !box.Truthy() {
		return
	}
	box.Set("scrollTop", box.Get("scrollHeight"))
	if chat := byID("chat"); chat.Truthy() {
		chat.Set("scrollTop", chat.Get("scrollHeight"))
	}
}

func isBashTool(name string) bool {
	n := strings.ToLower(name)
	return n == "bash" || n == "shell" || n == "run_terminal_cmd" || n == "terminal"
}

func looksLikeBashOutput(content string) bool {
	return strings.Contains(content, "$ ") || strings.HasPrefix(content, "← bash") || strings.HasPrefix(content, "← shell")
}

func parseBashStored(content string) (cmd, out string, ok bool) {
	ok = !strings.Contains(strings.ToLower(content), "error")
	lines := strings.SplitN(content, "\n", 2)
	cmd = strings.TrimPrefix(strings.TrimSpace(lines[0]), "← ")
	cmd = strings.TrimPrefix(cmd, "→ ")
	if len(lines) > 1 {
		out = lines[1]
	}
	return cmd, out, ok
}

func extractBashCommand(argsJSON string) string {
	var m map[string]any
	if json.Unmarshal([]byte(argsJSON), &m) == nil {
		if c, ok := m["command"].(string); ok {
			return c
		}
		if c, ok := m["cmd"].(string); ok {
			return c
		}
	}
	return truncateRunes(argsJSON, 120)
}

func summarizeArgsJSON(name, argsJSON string) string {
	var m map[string]any
	if json.Unmarshal([]byte(argsJSON), &m) == nil {
		switch strings.ToLower(name) {
		case "bash", "shell":
			if c, ok := m["command"].(string); ok {
				return "$ " + truncateRunes(c, 160)
			}
		case "read_file", "read":
			if p, ok := m["path"].(string); ok {
				return "read " + p
			}
		case "write_file", "write":
			if p, ok := m["path"].(string); ok {
				return "write " + p
			}
		case "search_replace", "edit":
			if p, ok := m["path"].(string); ok {
				return "edit " + p
			}
		case "grep":
			pat, _ := m["pattern"].(string)
			return "grep " + truncateRunes(pat, 80)
		case "web_search", "websearch":
			if q, ok := m["query"].(string); ok {
				return "search: " + q
			}
		}
	}
	if argsJSON == "" {
		return name
	}
	return name + " " + truncateRunes(argsJSON, 80)
}

func summarizeToolLine(name, content string) string {
	content = stripToolArrow(content)
	if content == "" {
		return name
	}
	return truncateRunes(content, 160)
}

func stripToolArrow(s string) string {
	s = strings.TrimSpace(s)
	s = strings.TrimPrefix(s, "→ ")
	s = strings.TrimPrefix(s, "← ")
	return s
}

func sanitizeID(id string) string {
	var b strings.Builder
	for _, r := range id {
		if (r >= 'a' && r <= 'z') || (r >= 'A' && r <= 'Z') || (r >= '0' && r <= '9') || r == '-' || r == '_' {
			b.WriteRune(r)
		} else {
			b.WriteByte('_')
		}
	}
	return b.String()
}

var (
	reCodeFence = regexp.MustCompile("(?s)```([a-zA-Z0-9_-]*)\\n(.*?)```")
	reInlineCode = regexp.MustCompile("`([^`]+)`")
	reBold      = regexp.MustCompile(`\*\*([^*]+)\*\*`)
	reLink      = regexp.MustCompile(`\[([^\]]+)\]\(([^)]+)\)`)
)

func renderMarkdown(src string) string {
	if src == "" || src == "…" {
		return ""
	}
	// Escape first, then selectively re-introduce safe tags from markdown.
	esc := html.EscapeString(src)
	esc = reCodeFence.ReplaceAllStringFunc(esc, func(m string) string {
		sub := reCodeFence.FindStringSubmatch(m)
		if len(sub) < 3 {
			return m
		}
		return `<pre class="md-code"><code>` + sub[2] + `</code></pre>`
	})
	esc = reInlineCode.ReplaceAllString(esc, `<code>$1</code>`)
	esc = reBold.ReplaceAllString(esc, `<strong>$1</strong>`)
	esc = reLink.ReplaceAllString(esc, `<a href="$2" target="_blank" rel="noopener">$1</a>`)
	// Paragraph-ish: keep newlines as <br> outside pre
	parts := strings.Split(esc, `<pre class="md-code">`)
	var b strings.Builder
	for i, part := range parts {
		if i == 0 {
			b.WriteString(nlToBr(part))
			continue
		}
		// rest starts with code...
		if idx := strings.Index(part, `</pre>`); idx >= 0 {
			b.WriteString(`<pre class="md-code">`)
			b.WriteString(part[:idx+6])
			b.WriteString(nlToBr(part[idx+6:]))
		} else {
			b.WriteString(`<pre class="md-code">`)
			b.WriteString(part)
		}
	}
	return `<div class="md">` + b.String() + `</div>`
}

func nlToBr(s string) string {
	return strings.ReplaceAll(s, "\n", "<br>")
}
