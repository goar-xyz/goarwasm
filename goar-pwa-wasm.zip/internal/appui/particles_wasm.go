//go:build js && wasm

package appui

import "syscall/js"

// startParticles installs the same lightweight particle field as the GOAR shell HTML.
func (a *App) startParticles() {
	// Prefer already-running HTML particles; else inject compact script.
	if win().Get("__goarStopParticles").Type() == js.TypeFunction {
		return
	}
	host := byID("particles-js")
	if !host.Truthy() {
		return
	}
	// Minimal invoke of shell particle script via Function constructor.
	src := `(function(){var host=document.getElementById("particles-js");if(!host||host.querySelector("canvas"))return;var canvas=document.createElement("canvas");host.appendChild(canvas);var ctx=canvas.getContext("2d",{alpha:true});var dpr=Math.min(window.devicePixelRatio||1,1.5);var N=0,CAP=160;var x=new Float32Array(CAP),y=new Float32Array(CAP),vx=new Float32Array(CAP),vy=new Float32Array(CAP),r=new Float32Array(CAP);var mouseX=-1e6,mouseY=-1e6,mouseOn=0,running=true,raf=0,W=0,H=0,LINK=160,LINK2=LINK*LINK,REP=180,REP2=REP*REP,CELL=LINK,lastMove=0;function spawnAt(i,px,py){var ang=Math.random()*6.28318,sp=(0.25+Math.random()*0.55)*0.7;x[i]=px!=null?px:Math.random()*W;y[i]=py!=null?py:Math.random()*H;vx[i]=Math.cos(ang)*sp;vy[i]=Math.sin(ang)*sp;r[i]=1.2+Math.random()*2.4;}function seed(){var gap=120,cols=Math.max(4,Math.ceil(W/gap)),rows=Math.max(3,Math.ceil(H/gap));N=0;for(var row=0;row<rows&&N<CAP;row++)for(var col=0;col<cols&&N<CAP;col++){spawnAt(N,(col+0.5)*(W/cols),(row+0.5)*(H/rows));N++;}}function resize(){W=Math.max(1,window.innerWidth);H=Math.max(1,window.innerHeight);canvas.width=Math.floor(W*dpr);canvas.height=Math.floor(H*dpr);canvas.style.width="100%";canvas.style.height="100%";ctx.setTransform(dpr,0,0,dpr,0,0);seed();}function tick(){if(!running)return;raf=requestAnimationFrame(tick);if(document.hidden)return;ctx.clearRect(0,0,W,H);var grid=Object.create(null),i,j,dx,dy,d2,inv,f,doMouse=mouseOn&&(performance.now()-lastMove<1200);ctx.beginPath();for(i=0;i<N;i++){var xi=x[i],yi=y[i];if(doMouse){dx=xi-mouseX;dy=yi-mouseY;d2=dx*dx+dy*dy;if(d2<REP2&&d2>0.01){inv=1/Math.sqrt(d2);f=(REP-d2*inv)/REP*1.15;vx[i]+=dx*inv*f;vy[i]+=dy*inv*f;}}xi+=vx[i];yi+=vy[i];vx[i]*=0.992;vy[i]*=0.992;if(xi<-8)xi=W+8;else if(xi>W+8)xi=-8;if(yi<-8)yi=H+8;else if(yi>H+8)yi=-8;x[i]=xi;y[i]=yi;var rr=r[i];ctx.moveTo(xi,yi-rr);ctx.lineTo(xi+rr*0.9,yi+rr*0.7);ctx.lineTo(xi-rr*0.9,yi+rr*0.7);var key=((xi/CELL)|0)+","+((yi/CELL)|0);(grid[key]=grid[key]||[]).push(i);}ctx.fillStyle="rgba(255,255,255,0.5)";ctx.fill();ctx.strokeStyle="rgba(255,255,255,0.28)";ctx.beginPath();for(var key in grid){var list=grid[key],comma=key.indexOf(","),gx=+key.slice(0,comma),gy=+key.slice(comma+1);for(var k=0;k<5;k++){var offs=[[0,0],[1,0],[0,1],[1,1],[-1,1]][k];var cell=k===0?list:grid[(gx+offs[0])+","+(gy+offs[1])];if(!cell)continue;for(i=0;i<list.length;i++){var ia=list[i],start=cell===list?i+1:0;for(j=start;j<cell.length;j++){var ib=cell[j];dx=x[ia]-x[ib];dy=y[ia]-y[ib];d2=dx*dx+dy*dy;if(d2<LINK2&&d2>0){ctx.moveTo(x[ia],y[ia]);ctx.lineTo(x[ib],y[ib]);}}}}}ctx.stroke();}window.addEventListener("resize",resize,{passive:true});window.addEventListener("pointermove",function(e){mouseOn=1;lastMove=performance.now();mouseX=e.clientX;mouseY=e.clientY;},{passive:true});resize();raf=requestAnimationFrame(tick);window.__goarStopParticles=function(){running=false;if(raf)cancelAnimationFrame(raf);host.style.opacity="0";};})();`
	fn := win().Get("Function").New(src)
	fn.Invoke()
	_ = js.Undefined()
}
