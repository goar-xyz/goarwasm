//go:build js && wasm

package appui

import (
	"fmt"
	"strings"
	"syscall/js"
)

// PWA theme catalog (aligned with CLI goar-dark / goar-light; brand accent stays #E11D2E).
var pwaThemes = []struct {
	ID, Label, Hint string
}{
	{"goar-dark", "goar-dark", "Black canvas · Vibe red accent"},
	{"goar-light", "goar-light", "Light canvas · Vibe red accent"},
}

var pwaThinkingLevels = []string{"off", "low", "medium", "high", "xhigh"}

func (a *App) ensurePickerHost() js.Value {
	host := byID("slash-picker")
	if host.Truthy() {
		return host
	}
	host = el("div")
	host.Set("id", "slash-picker")
	addClass(host, "slash-picker")
	addClass(host, "hidden")
	host.Set("role", "dialog")
	host.Call("setAttribute", "aria-modal", "true")
	sheet := el("div")
	addClass(sheet, "slash-picker-sheet")
	head := el("div")
	addClass(head, "slash-picker-head")
	title := el("h3")
	title.Set("id", "slash-picker-title")
	setText(title, "Choose")
	closeBtn := el("button")
	closeBtn.Set("type", "button")
	addClass(closeBtn, "settings-x")
	closeBtn.Set("id", "slash-picker-close")
	setText(closeBtn, "✕")
	appendChild(head, title)
	appendChild(head, closeBtn)
	list := el("div")
	list.Set("id", "slash-picker-list")
	addClass(list, "slash-picker-list")
	hint := el("p")
	hint.Set("id", "slash-picker-hint")
	addClass(hint, "slash-picker-hint")
	appendChild(sheet, head)
	appendChild(sheet, list)
	appendChild(sheet, hint)
	appendChild(host, sheet)
	body := doc().Get("body")
	if body.Truthy() {
		appendChild(body, host)
	}
	on(closeBtn, "click", func(js.Value) { a.closeSlashPicker() })
	on(host, "click", func(ev js.Value) {
		t := ev.Get("target")
		if t.Truthy() && t.Get("id").String() == "slash-picker" {
			a.closeSlashPicker()
		}
	})
	return host
}

func (a *App) closeSlashPicker() {
	host := byID("slash-picker")
	if host.Truthy() {
		addClass(host, "hidden")
		remClass(host, "open")
	}
}

func (a *App) openSlashPicker(title, hint string, rows []pickerRow) {
	host := a.ensurePickerHost()
	if tit := byID("slash-picker-title"); tit.Truthy() {
		setText(tit, title)
	}
	if h := byID("slash-picker-hint"); h.Truthy() {
		setText(h, hint)
	}
	list := byID("slash-picker-list")
	if !list.Truthy() {
		return
	}
	clear(list)
	for _, row := range rows {
		btn := el("button")
		btn.Set("type", "button")
		addClass(btn, "slash-picker-item")
		if row.Active {
			addClass(btn, "active")
		}
		btn.Get("dataset").Set("value", row.Value)
		label := el("span")
		addClass(label, "slash-picker-label")
		setText(label, row.Label)
		appendChild(btn, label)
		if row.Meta != "" {
			meta := el("span")
			addClass(meta, "slash-picker-meta")
			setText(meta, row.Meta)
			appendChild(btn, meta)
		}
		val := row.Value
		onClick := row.OnSelect
		on(btn, "click", func(js.Value) {
			if onClick != nil {
				onClick(val)
			}
			a.closeSlashPicker()
		})
		appendChild(list, btn)
	}
	remClass(host, "hidden")
	addClass(host, "open")
}

type pickerRow struct {
	Value    string
	Label    string
	Meta     string
	Active   bool
	OnSelect func(string)
}

func (a *App) currentTheme() string {
	if a.cfg != nil && strings.TrimSpace(a.cfg.Theme) != "" {
		return a.cfg.Theme
	}
	if t := localGet("goar.pwa.theme"); t != "" {
		return t
	}
	return "goar-dark"
}

func (a *App) currentThinking() string {
	if a.cfg != nil && strings.TrimSpace(a.cfg.Thinking) != "" {
		return a.cfg.Thinking
	}
	if t := localGet("goar.pwa.thinking"); t != "" {
		return t
	}
	return "off"
}

func (a *App) applyTheme(name string) {
	name = strings.TrimSpace(name)
	if name == "" {
		name = "goar-dark"
	}
	known := false
	for _, t := range pwaThemes {
		if t.ID == name {
			known = true
			break
		}
	}
	if !known {
		name = "goar-dark"
	}
	html := doc().Get("documentElement")
	body := doc().Get("body")
	if html.Truthy() {
		html.Call("setAttribute", "data-theme", name)
	}
	if body.Truthy() {
		body.Call("setAttribute", "data-theme", name)
		remClass(body, "theme-goar-dark")
		remClass(body, "theme-goar-light")
		addClass(body, "theme-"+name)
	}
	// Brand accent stays #E11D2E for both themes.
	if html.Truthy() {
		html.Get("style").Call("setProperty", "--accent", "#E11D2E")
		html.Get("style").Call("setProperty", "--brand-red", "#E11D2E")
		html.Get("style").Call("setProperty", "--mistral_orange", "#E11D2E")
		html.Get("style").Call("setProperty", "--secondary", "#E11D2E")
	}
	meta := doc().Call("querySelector", "meta[name=theme-color]")
	if meta.Truthy() {
		meta.Call("setAttribute", "content", "#E11D2E")
	}
	if a.cfg == nil {
		a.cfg = &AppConfig{WispURL: defaultWisp}
	}
	a.cfg.Theme = name
	localSet("goar.pwa.theme", name)
	saveConfig(a.cfg)
	a.syncPersist()
}

func (a *App) applyThinking(level string) {
	level = strings.ToLower(strings.TrimSpace(level))
	ok := false
	for _, l := range pwaThinkingLevels {
		if l == level {
			ok = true
			break
		}
	}
	if !ok {
		level = "off"
	}
	if a.cfg == nil {
		a.cfg = &AppConfig{WispURL: defaultWisp}
	}
	a.cfg.Thinking = level
	localSet("goar.pwa.thinking", level)
	saveConfig(a.cfg)
	a.syncPersist()
	a.ensureConfigured()
}

func (a *App) showThemePicker() {
	cur := a.currentTheme()
	rows := make([]pickerRow, 0, len(pwaThemes))
	for _, t := range pwaThemes {
		tt := t
		rows = append(rows, pickerRow{
			Value:  tt.ID,
			Label:  tt.Label,
			Meta:   tt.Hint,
			Active: tt.ID == cur,
			OnSelect: func(v string) {
				a.applyTheme(v)
				a.appendLocal("assistant", "Theme set to "+v+" (brand #E11D2E).", "")
				a.toast("Theme: "+v, "ok")
			},
		})
	}
	a.openSlashPicker("Theme", "Brand accent stays #E11D2E. Choice persists on this device.", rows)
}

func (a *App) showThinkingPicker() {
	cur := a.currentThinking()
	rows := make([]pickerRow, 0, len(pwaThinkingLevels))
	for _, lvl := range pwaThinkingLevels {
		l := lvl
		rows = append(rows, pickerRow{
			Value:  l,
			Label:  l,
			Meta:   thinkingHint(l),
			Active: l == cur,
			OnSelect: func(v string) {
				a.applyThinking(v)
				a.appendLocal("assistant", "Thinking level → "+v, "")
				a.toast("Thinking: "+v, "ok")
			},
		})
	}
	a.openSlashPicker("Thinking level", "Applies to the next agent turn (persisted).", rows)
}

func thinkingHint(l string) string {
	switch l {
	case "off":
		return "No extra reasoning effort"
	case "low":
		return "Light reasoning"
	case "medium":
		return "Balanced"
	case "high":
		return "Deeper reasoning"
	case "xhigh":
		return "Maximum effort"
	default:
		return ""
	}
}

func (a *App) showModelPicker() {
	// Prefer a real picker when models are already in the settings select; else open settings.
	sel := byID("apiModel")
	models := []string{}
	cur := ""
	if a.cfg != nil && a.cfg.Provider != nil {
		cur = a.cfg.Provider.Model
	}
	if sel.Truthy() {
		opts := sel.Get("options")
		if opts.Truthy() {
			for i := 0; i < opts.Length(); i++ {
				o := opts.Index(i)
				v := o.Get("value").String()
				if strings.TrimSpace(v) != "" {
					models = append(models, v)
				}
			}
		}
		if cur == "" {
			cur = sel.Get("value").String()
		}
	}
	if len(models) == 0 && cur != "" {
		models = []string{cur}
	}
	if len(models) == 0 {
		a.showSettings()
		a.appendLocal("assistant", "Model picker: open Settings → Model (refresh after API key).", "")
		a.toast("Open Settings to pick a model", "warn")
		return
	}
	rows := make([]pickerRow, 0, len(models)+1)
	for _, m := range models {
		mm := m
		rows = append(rows, pickerRow{
			Value:  mm,
			Label:  mm,
			Active: mm == cur,
			OnSelect: func(v string) {
				a.applyModelChoice(v)
			},
		})
	}
	rows = append(rows, pickerRow{
		Value: "__settings__",
		Label: "Open full Settings…",
		Meta:  "Provider, API key, SSH",
		OnSelect: func(string) {
			a.showSettings()
		},
	})
	a.openSlashPicker("Model", "Select an active model (persisted).", rows)
}

func (a *App) applyModelChoice(model string) {
	model = strings.TrimSpace(model)
	if model == "" {
		return
	}
	if a.cfg == nil {
		a.cfg = &AppConfig{WispURL: defaultWisp}
	}
	if a.cfg.Provider == nil {
		a.cfg.Provider = &ProviderConfig{}
	}
	a.cfg.Provider.Model = model
	if sel := byID("apiModel"); sel.Truthy() {
		sel.Set("value", model)
	}
	saveConfig(a.cfg)
	a.syncPersist()
	a.ensureConfigured()
	a.refreshStatus()
	a.appendLocal("assistant", "Model set to "+model, "")
	a.toast("Model: "+model, "ok")
}

func (a *App) showMCPPanel() {
	rows := []pickerRow{
		{
			Value: "info",
			Label: "MCP / connectors",
			Meta:  "HTTP MCP + in-process tools (stdio skipped in PWA)",
			OnSelect: func(string) {
				a.appendLocal("assistant", "MCP: browser build uses HTTP MCP transports and in-process servers. Configure tool allow/deny via agent settings; connectors open here for status.", "")
			},
		},
		{
			Value: "settings",
			Label: "Open Settings",
			Meta:  "Provider / tools live with the agent runtime",
			OnSelect: func(string) { a.showSettings() },
		},
		{
			Value: "status",
			Label: "Runtime status",
			Meta:  "Dump goar.status()",
			OnSelect: func(string) {
				st := "{}"
				if a.Goar.Truthy() {
					raw, _ := jsonMarshalStatus(a.Goar.Call("status"))
					st = raw
				}
				a.appendLocal("assistant", "MCP / runtime status:\n"+st, "")
			},
		},
	}
	a.openSlashPicker("Connectors / MCP", "PWA MCP panel — real actions, not a dead end.", rows)
	a.toast("MCP panel", "ok")
}

func jsonMarshalStatus(v js.Value) (string, error) {
	// reuse chat_wasm pattern via jsValueToMap if available
	raw, err := marshalJSValue(v)
	return raw, err
}

func marshalJSValue(v js.Value) (string, error) {
	if !v.Truthy() {
		return "{}", nil
	}
	json := win().Get("JSON")
	if json.Truthy() && json.Get("stringify").Type() == js.TypeFunction {
		s := json.Call("stringify", v, js.Null(), 2)
		if s.Truthy() {
			return s.String(), nil
		}
	}
	return fmt.Sprintf("%v", v), nil
}

// wireNotifyTestHook exposes window.__goarTestNotify for smoke proofs.
func (a *App) wireNotifyTestHook() {
	fn := retainFunc(js.FuncOf(func(this js.Value, args []js.Value) any {
		kind := "ask"
		detail := "smoke-test notify"
		if len(args) > 0 && args[0].Type() == js.TypeString && strings.TrimSpace(args[0].String()) != "" {
			kind = args[0].String()
		}
		if len(args) > 1 && args[1].Type() == js.TypeString {
			detail = args[1].String()
		}
		notifyAttention(kind, detail)
		out := win().Get("Object").New()
		out.Set("ok", true)
		out.Set("kind", kind)
		out.Set("detail", detail)
		out.Set("needsAttention", localGet("goar.needsAttention"))
		out.Set("permission", "")
		if n := win().Get("Notification"); n.Truthy() {
			out.Set("permission", n.Get("permission").String())
		}
		swPosted := false
		if sw := win().Get("navigator").Get("serviceWorker"); sw.Truthy() {
			if sw.Get("controller").Truthy() {
				swPosted = true
			}
		}
		out.Set("swController", swPosted)
		return out
	}))
	win().Set("__goarTestNotify", fn)
	if a.Goar.Truthy() {
		a.Goar.Set("testNotify", fn)
	}
}

func (a *App) restorePersistedChrome() {
	a.applyTheme(a.currentTheme())
	// thinking is applied via ensureConfigured; keep cfg field warm
	if a.cfg != nil && a.cfg.Thinking == "" {
		a.cfg.Thinking = a.currentThinking()
	}
}
