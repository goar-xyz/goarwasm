//go:build !(js && wasm)

package appui

// Boot is a no-op on native builds (CLI uses textualui).
func Boot() {}
