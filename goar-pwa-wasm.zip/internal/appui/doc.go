// Package appui is the GOAR single-WASM browser app UI.
//
// All panels (onboarding, chat, settings, sessions, MCP, terminal host) are
// built and driven from Go via syscall/js. The HTML shell is a thin Vibe-first
// loader (index.html + vibe.css + wasm_exec.js + goar.wasm + optional xterm).
// Primary chat chrome mirrors Mistral Vibe textual_ui (app.tcss / _compose_main_ui).
// There is no app.js business logic — network stays in browsernet (Go).
package appui
