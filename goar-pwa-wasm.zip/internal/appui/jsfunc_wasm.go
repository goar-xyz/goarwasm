//go:build js && wasm

package appui

import (
	"sync"
	"syscall/js"
)

// Long-lived js.Func values must stay reachable from Go. If the only reference is
// the JS wrapper and Go GC collects the Func value without Release, behavior is
// undefined; if someone Releases while JS still calls → "call to released function".
var (
	funcMu   sync.Mutex
	funcKeep []js.Func
)

func retainFunc(fn js.Func) js.Func {
	funcMu.Lock()
	funcKeep = append(funcKeep, fn)
	funcMu.Unlock()
	return fn
}

// onceFunc is for Promise then/catch and one-shot timers: self-releases after first call.
// The closure captures f so the Func stays alive until it runs.
func onceFunc(fn func(this js.Value, args []js.Value) any) js.Func {
	var f js.Func
	f = js.FuncOf(func(this js.Value, args []js.Value) any {
		defer func() {
			func() {
				defer func() { _ = recover() }()
				f.Release()
			}()
		}()
		return fn(this, args)
	})
	return f
}

func promiseThen(prom js.Value, onOK, onErr func(js.Value)) {
	if !prom.Truthy() || prom.Get("then").Type() != js.TypeFunction {
		return
	}
	ok := onceFunc(func(this js.Value, args []js.Value) any {
		v := js.Undefined()
		if len(args) > 0 {
			v = args[0]
		}
		if onOK != nil {
			onOK(v)
		}
		return nil
	})
	if onErr != nil {
		bad := onceFunc(func(this js.Value, args []js.Value) any {
			v := js.Undefined()
			if len(args) > 0 {
				v = args[0]
			}
			onErr(v)
			return nil
		})
		prom.Call("then", ok).Call("catch", bad)
		return
	}
	prom.Call("then", ok)
}
