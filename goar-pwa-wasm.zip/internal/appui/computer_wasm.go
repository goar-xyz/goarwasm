//go:build js && wasm

package appui

import (
	"strings"
	"syscall/js"
)

func (a *App) wireFirefoxChrome() {
	if byID("browser-go").Truthy() {
		on(byID("browser-go"), "click", func(js.Value) { a.firefoxNavigate("") })
	}
	if byID("browser-url-form").Truthy() {
		on(byID("browser-url-form"), "submit", func(ev js.Value) {
			ev.Call("preventDefault")
			a.firefoxNavigate("")
		})
	}
	if byID("browser-reload").Truthy() {
		on(byID("browser-reload"), "click", func(js.Value) { a.firefoxNavigate("") })
	}
	if byID("browser-back").Truthy() {
		on(byID("browser-back"), "click", func(js.Value) {
			if win().Get("geckoBack").Type() == js.TypeFunction {
				win().Call("geckoBack")
			}
		})
	}
	if byID("browser-forward").Truthy() {
		on(byID("browser-forward"), "click", func(js.Value) {
			if win().Get("geckoForward").Type() == js.TypeFunction {
				win().Call("geckoForward")
			}
		})
	}
}

func (a *App) openFirefoxPanel() {
	st := geckoStatusEl()
	if st.Truthy() {
		setText(st, "Loading Firefox WASM (gecko)… network = browsernet → Mercury Wisp")
		st.Set("className", "status-line warn")
	}
	a.ensureConfigured()
	// Absolute same-origin paths: dynamic import() resolves relative to gecko-plane.js
	// under /vendor/gecko/, so "./assets/..." would 404 as /vendor/gecko/assets/...
	win().Set("GOAR_GECKO_WASM_URL", "/assets/gecko/gecko.wasm.zst")
	win().Set("GOAR_GECKO_JS_URL", "/assets/gecko/gecko.js")
	win().Set("GOAR_GECKO_FORCE", true)
	win().Set("GOAR_GECKO_PREFER_WASM", true)
	wisp := defaultWisp
	if a.cfg != nil && a.cfg.WispURL != "" {
		wisp = a.cfg.WispURL
	}
	win().Set("GOAR_WISP_URL", wisp)
	url := "https://duckduckgo.com/"
	if byID("browser-url").Truthy() {
		u := strings.TrimSpace(byID("browser-url").Get("value").String())
		if u != "" {
			url = u
		}
	}
	ensure := win().Get("ensureGecko")
	install := win().Get("installGeckoWispBridge")
	run := func() {
		if ensure.Type() != js.TypeFunction {
			setGeckoStatus("gecko-plane.js not loaded — check vendor/gecko/", "err")
			return
		}
		opts := win().Get("Object").New()
		opts.Set("mode", "embed")
		opts.Set("wasm", true)
		opts.Set("forceWasm", true)
		opts.Set("show", true)
		opts.Set("url", url)
		opts.Set("force", false)
		if host := byID("browser-frame-wrap"); host.Truthy() {
			opts.Set("host", host)
			opts.Set("container", host)
		}
		prom := ensure.Invoke(opts)
		promiseThen(prom, func(v js.Value) {
			mode := "embed"
			bridge := "browsernet"
			if v.Truthy() {
				if v.Get("mode").Truthy() {
					mode = v.Get("mode").String()
				}
				if v.Get("bridge").Truthy() {
					bridge = v.Get("bridge").String()
				}
			}
			setGeckoStatus("Ready · Firefox "+mode+" · "+url+" · "+bridge+" · Wisp "+wisp, "ok")
			setHiddenAttr(geckoStatusEl(), false)
		}, func(err js.Value) {
			msg := "gecko boot failed"
			if err.Truthy() {
				if err.Get("message").Truthy() {
					msg = err.Get("message").String()
				} else {
					msg = err.String()
				}
			}
			setGeckoStatus(msg, "err")
		})
	}
	if install.Type() == js.TypeFunction {
		p := install.Invoke(wisp)
		if p.Truthy() && p.Get("then").Type() == js.TypeFunction {
			promiseThen(p, func(js.Value) { run() }, func(js.Value) { run() })
			return
		}
	}
	run()
}

func (a *App) firefoxNavigate(url string) {
	if url == "" && byID("browser-url").Truthy() {
		url = strings.TrimSpace(byID("browser-url").Get("value").String())
	}
	if url == "" {
		return
	}
	if !strings.Contains(url, "://") {
		url = "https://" + url
		byID("browser-url").Set("value", url)
	}
	setGeckoStatus("Navigating "+url+"…", "warn")
	load := win().Get("geckoLoad")
	if load.Type() == js.TypeFunction {
		prom := load.Invoke(url)
		if prom.Truthy() && prom.Get("then").Type() == js.TypeFunction {
			promiseThen(prom, func(js.Value) {
				setGeckoStatus("Ready · Loaded "+url, "ok")
			}, func(js.Value) {
				a.openFirefoxPanel()
			})
			return
		}
	}
	a.openFirefoxPanel()
}

func setGeckoStatus(msg, kind string) {
	st := geckoStatusEl()
	if !st.Truthy() {
		return
	}
	setText(st, msg)
	st.Set("className", "status-line "+kind)
}

func geckoStatusEl() js.Value {
	if h := byID("gecko-status-pill"); h.Truthy() {
		return h
	}
	if h := byID("browser-status"); h.Truthy() {
		return h
	}
	return byID("gecko-status")
}
