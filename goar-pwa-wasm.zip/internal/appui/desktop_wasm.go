//go:build js && wasm

package appui

import (
	"strings"
	"syscall/js"
)

// wireDesktopPanel binds the Desktop (VNC) rail to a real remote path:
// SSH session + optional Xvnc probe via goar.sshExec. No muted stubs.
func (a *App) wireDesktopPanel() {
	tab := byID("vnc-tab")
	if !tab.Truthy() {
		return
	}
	if tab.Get("dataset").Get("wired").String() == "1" {
		return
	}
	tab.Get("dataset").Set("wired", "1")
	// Rebuild chrome actions into useful controls.
	screen := byID("vnc-screen")
	if screen.Truthy() && screen.Get("dataset").Get("ui").String() != "1" {
		screen.Get("dataset").Set("ui", "1")
		setHTML(screen, `<div class="desk-panel">
  <p class="desk-lede">Remote desktop over SSH (browsernet / Wisp). Configure SSH in Settings, then connect.</p>
  <div class="desk-actions">
    <button type="button" class="primary" id="desk-ssh-term">Open SSH terminal</button>
    <button type="button" id="desk-probe">Probe display :5900</button>
    <button type="button" id="desk-start-xvnc">Start Xvnc</button>
    <button type="button" id="desk-reconnect">Reconnect</button>
  </div>
  <pre id="desk-log" class="desk-log" aria-live="polite"></pre>
  <p class="desk-hint">Full RFB/noVNC tunnel needs a listening Xvnc on the SSH host (e.g. segfault <code>startxvnc</code>). Until then this panel drives SSH + display bootstrap — not a muted stub.</p>
</div>`)
	}
	if byID("desk-ssh-term").Truthy() {
		on(byID("desk-ssh-term"), "click", func(js.Value) {
			a.connectTerm("ssh")
			a.showView("term")
		})
	}
	if byID("desk-probe").Truthy() {
		on(byID("desk-probe"), "click", func(js.Value) { a.desktopProbe() })
	}
	if byID("desk-start-xvnc").Truthy() {
		on(byID("desk-start-xvnc"), "click", func(js.Value) { a.desktopStartXvnc() })
	}
	if byID("desk-reconnect").Truthy() {
		on(byID("desk-reconnect"), "click", func(js.Value) { a.openDesktopPanel() })
	}
	if byID("vnc-reload").Truthy() {
		on(byID("vnc-reload"), "click", func(js.Value) { a.openDesktopPanel() })
	}
}

func (a *App) openDesktopPanel() {
	a.wireDesktopPanel()
	sshOK := false
	host := ""
	if a.Goar.Truthy() && a.Goar.Get("status").Type() == js.TypeFunction {
		st := a.Goar.Call("status")
		if st.Truthy() && st.Get("sshConfigured").Truthy() && st.Get("sshConfigured").Bool() {
			sshOK = true
			if st.Get("sshHost").Truthy() {
				host = st.Get("sshHost").String()
			}
		}
	}
	if st := byID("vnc-status"); st.Truthy() {
		if sshOK {
			setText(st, "SSH ready · "+host+" · probe or open terminal")
		} else {
			setText(st, "SSH not configured — open Settings → SSH instance")
		}
	}
	a.deskLog(func() string {
		if sshOK {
			return "SSH configured for " + host + ".\nUse Probe / Start Xvnc, or Open SSH terminal."
		}
		return "No SSH credentials yet.\nSettings → SSH instance (host/user/password or key),\nthen return here. Computer rail still uses Firefox WASM."
	}())
}

func (a *App) deskLog(msg string) {
	el := byID("desk-log")
	if el.Truthy() {
		setText(el, msg)
	}
}

func (a *App) desktopProbe() {
	if !a.Goar.Truthy() || a.Goar.Get("sshExec").Type() != js.TypeFunction {
		a.deskLog("sshExec API missing")
		return
	}
	a.ensureConfigured()
	if st := byID("vnc-status"); st.Truthy() {
		setText(st, "Probing :5900…")
	}
	cmd := "ss -lnt 2>/dev/null | grep 5900 || netstat -lnt 2>/dev/null | grep 5900 || echo VNC_DOWN; command -v startxvnc; command -v Xvnc; hostname; whoami"
	a.Goar.Call("sshExec", cmd, 25000, onceFunc(func(this js.Value, args []js.Value) any {
		res := args[0]
		if !res.Get("ok").Bool() {
			err := "probe failed"
			if res.Get("error").Truthy() {
				err = res.Get("error").String()
			}
			a.deskLog(err)
			if st := byID("vnc-status"); st.Truthy() {
				setText(st, "Probe failed")
			}
			return nil
		}
		out := ""
		if res.Get("stdout").Truthy() {
			out = res.Get("stdout").String()
		}
		if res.Get("stderr").Truthy() && res.Get("stderr").String() != "" {
			out += "\n" + res.Get("stderr").String()
		}
		a.deskLog(out)
		up := strings.Contains(out, "5900") && !strings.Contains(out, "VNC_DOWN")
		if st := byID("vnc-status"); st.Truthy() {
			if up {
				setText(st, "Display :5900 listening")
			} else {
				setText(st, "No listener on :5900 — try Start Xvnc")
			}
		}
		return nil
	}))
}

func (a *App) desktopStartXvnc() {
	if !a.Goar.Truthy() || a.Goar.Get("sshExec").Type() != js.TypeFunction {
		a.deskLog("sshExec API missing")
		return
	}
	a.ensureConfigured()
	if st := byID("vnc-status"); st.Truthy() {
		setText(st, "Starting Xvnc…")
	}
	cmd := "if ss -lnt 2>/dev/null | grep -q ':5900' || netstat -lnt 2>/dev/null | grep -q ':5900'; then echo VNC_UP; " +
		"else (command -v startxvnc >/dev/null && nohup startxvnc >/tmp/.goar-xvnc.log 2>&1 &); " +
		"sleep 2; " +
		"if ss -lnt 2>/dev/null | grep -q ':5900' || netstat -lnt 2>/dev/null | grep -q ':5900'; then echo VNC_UP; " +
		"else echo VNC_WAIT; tail -20 /tmp/.goar-xvnc.log 2>/dev/null; fi; fi"
	a.Goar.Call("sshExec", cmd, 30000, onceFunc(func(this js.Value, args []js.Value) any {
		res := args[0]
		out := ""
		if res.Truthy() {
			if res.Get("stdout").Truthy() {
				out = res.Get("stdout").String()
			}
			if !res.Get("ok").Bool() && res.Get("error").Truthy() {
				out = res.Get("error").String() + "\n" + out
			}
		}
		a.deskLog(out)
		if st := byID("vnc-status"); st.Truthy() {
			if strings.Contains(out, "VNC_UP") {
				setText(st, "Xvnc up · use Open SSH terminal or external VNC :5900 via tunnel")
			} else {
				setText(st, "Xvnc start inconclusive — see log")
			}
		}
		return nil
	}))
}
