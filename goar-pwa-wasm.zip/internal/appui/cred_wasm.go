//go:build js && wasm

package appui

import (
	"strings"
	"syscall/js"
)

// renderCredPhase fills the design HTML cred fields (does not replace markup).
func (a *App) renderCredPhase() {
	phase := byID("credPhase")
	if !phase.Truthy() {
		return
	}
	cfg := a.cfg
	if cfg == nil {
		cfg = &AppConfig{WispURL: defaultWisp}
		a.cfg = cfg
	}
	sel := "freeai"
	if cfg.Provider != nil && cfg.Provider.Key != "" {
		sel = cfg.Provider.Key
	}
	prov := byID("credProvider")
	if prov.Truthy() {
		clear(prov)
		for _, p := range providers() {
			o := el("option")
			o.Set("value", p.Key)
			setText(o, p.Name)
			if p.Key == sel {
				o.Set("selected", true)
			}
			appendChild(prov, o)
		}
		prov.Set("value", sel)
	}
	apiKey, base, model := "", "", ""
	if cfg.Provider != nil {
		apiKey, base, model = cfg.Provider.APIKey, cfg.Provider.BaseURL, cfg.Provider.Model
	}
	if base == "" {
		for _, p := range providers() {
			if p.Key == sel {
				base = p.Base
				break
			}
		}
	}
	if byID("credKey").Truthy() {
		byID("credKey").Set("value", apiKey)
	}
	if byID("credBase").Truthy() {
		byID("credBase").Set("value", base)
	}
	if wrap := byID("credBaseWrap"); wrap.Truthy() {
		// keep visible — design has it
		setHiddenAttr(wrap, false)
	}
	if model != "" && byID("credModel").Truthy() {
		selEl := byID("credModel")
		clear(selEl)
		opt := el("option")
		opt.Set("value", model)
		setText(opt, model+" (cached)")
		appendChild(selEl, opt)
		selEl.Set("value", model)
	}

	setHiddenAttr(phase, false)
	remClass(phase, "hidden")
	addClass(phase, "on")
	addClass(phase, "show")

	// Wire once
	if phase.Get("dataset").Get("wired").String() != "1" {
		phase.Get("dataset").Set("wired", "1")
		if byID("credProvider").Truthy() {
			on(byID("credProvider"), "change", func(js.Value) {
				key := byID("credProvider").Get("value").String()
				for _, p := range providers() {
					if p.Key == key {
						if byID("credBase").Truthy() {
							byID("credBase").Set("value", p.Base)
						}
						break
					}
				}
				a.disableEnter("Provider changed — verify models")
				a.refreshModelsLive()
			})
		}
		if byID("credKey").Truthy() {
			on(byID("credKey"), "change", func(js.Value) { a.disableEnter("Key changed — verify models"); a.refreshModelsLive() })
			on(byID("credKey"), "input", func(js.Value) { a.disableEnter("Key changed — verify models") })
		}
		if byID("credBase").Truthy() {
			on(byID("credBase"), "change", func(js.Value) { a.disableEnter("Base changed — verify models"); a.refreshModelsLive() })
		}
		if byID("credVerify").Truthy() {
			on(byID("credVerify"), "click", func(js.Value) { a.refreshModelsLive() })
		}
		if byID("retry").Truthy() {
			on(byID("retry"), "click", func(js.Value) { a.refreshModelsLive() })
		}
		if byID("credGo").Truthy() {
			on(byID("credGo"), "click", func(js.Value) { a.finishCred() })
		}
	}
	a.refreshModelsLive()
}

func (a *App) disableEnter(msg string) {
	goBtn := byID("credGo")
	if goBtn.Truthy() {
		goBtn.Set("disabled", true)
	}
	st := byID("credStatus")
	if st.Truthy() {
		setText(st, msg)
		st.Set("className", "status-line warn")
	}
}

func (a *App) refreshModelsLive() {
	if !a.Goar.Truthy() || a.Goar.Get("listModels").Type() != js.TypeFunction {
		a.disableEnter("goar.listModels unavailable")
		return
	}
	base := ""
	if byID("credBase").Truthy() {
		base = strings.TrimSpace(byID("credBase").Get("value").String())
	}
	key := ""
	if byID("credKey").Truthy() {
		key = byID("credKey").Get("value").String()
	}
	wisp := defaultWisp
	if byID("credWisp").Truthy() {
		if w := strings.TrimSpace(byID("credWisp").Get("value").String()); w != "" {
			wisp = w
		}
	} else if a.cfg != nil && a.cfg.WispURL != "" {
		wisp = a.cfg.WispURL
	}
	obj := win().Get("Object").New()
	obj.Set("wispURL", wisp)
	a.Goar.Call("configure", obj)

	st := byID("credStatus")
	if st.Truthy() {
		setText(st, "Querying "+base+"/models via browsernet…")
		st.Set("className", "status-line warn")
	}
	if byID("credGo").Truthy() {
		byID("credGo").Set("disabled", true)
	}
	sel := byID("credModel")
	if sel.Truthy() {
		clear(sel)
		ph := el("option")
		ph.Set("value", "")
		setText(ph, "Loading models…")
		appendChild(sel, ph)
	}

	a.Goar.Call("listModels", base, key, onceFunc(func(this js.Value, args []js.Value) any {
		res := js.Undefined()
		if len(args) > 0 {
			res = args[0]
		}
		if !res.Truthy() || !res.Get("ok").Bool() {
			err := "models failed"
			if res.Truthy() && res.Get("error").Truthy() {
				err = res.Get("error").String()
			}
			if st.Truthy() {
				setText(st, err)
				st.Set("className", "status-line err")
			}
			if byID("credGo").Truthy() {
				byID("credGo").Set("disabled", true)
			}
			if sel.Truthy() {
				clear(sel)
				o := el("option")
				o.Set("value", "")
				setText(o, "Verification failed")
				appendChild(sel, o)
			}
			return nil
		}
		models := res.Get("models")
		if sel.Truthy() {
			clear(sel)
		}
		n := models.Length()
		if n == 0 {
			if st.Truthy() {
				setText(st, "No models returned")
				st.Set("className", "status-line err")
			}
			if byID("credGo").Truthy() {
				byID("credGo").Set("disabled", true)
			}
			return nil
		}
		for i := 0; i < n; i++ {
			id := models.Index(i).String()
			o := el("option")
			o.Set("value", id)
			setText(o, id)
			if sel.Truthy() {
				appendChild(sel, o)
			}
		}
		if sel.Truthy() {
			sel.Set("selectedIndex", 0)
		}
		if st.Truthy() {
			setText(st, "Verified · "+itoa(n)+" models")
			st.Set("className", "status-line ok")
		}
		if byID("credGo").Truthy() {
			byID("credGo").Set("disabled", false)
		}
		return nil
	}))
}

func (a *App) finishCred() {
	model := ""
	if byID("credModel").Truthy() {
		model = byID("credModel").Get("value").String()
	}
	if model == "" {
		a.disableEnter("Select a verified model")
		return
	}
	pkey := "freeai"
	if byID("credProvider").Truthy() {
		pkey = byID("credProvider").Get("value").String()
	}
	apiKey := ""
	if byID("credKey").Truthy() {
		apiKey = byID("credKey").Get("value").String()
	}
	base := ""
	if byID("credBase").Truthy() {
		base = strings.TrimSpace(byID("credBase").Get("value").String())
	}
	wisp := defaultWisp
	if a.cfg != nil && a.cfg.WispURL != "" {
		wisp = a.cfg.WispURL
	}
	if byID("credWisp").Truthy() {
		if w := strings.TrimSpace(byID("credWisp").Get("value").String()); w != "" {
			wisp = w
		}
	}
	cfg := a.cfg
	if cfg == nil {
		cfg = &AppConfig{}
	}
	cfg.WispURL = wisp
	cfg.Provider = &ProviderConfig{Key: pkey, APIKey: apiKey, BaseURL: base, Model: model}
	// SSH remains optional — configure in Settings (design fields sshHost/…)
	a.cfg = cfg
	saveConfig(cfg)
	a.syncPersist()
	a.ensureConfigured()
	a.showWorkspace()
	a.toast("Authenticated · models verified", "ok")
}
