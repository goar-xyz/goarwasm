//go:build js && wasm

package appui

import (
	"strconv"
	"strings"
	"syscall/js"
)

func (a *App) renderWizard() {
	w := byID("wizard")
	clear(w)
	setHTML(w, `
<div class="panel step" id="wiz-step">
  <h2 id="wiz-title">Setup</h2>
  <p class="lede" id="wiz-lede"></p>
  <div id="wiz-body"></div>
  <div class="wizard-nav">
    <button type="button" id="wiz-back">Back</button>
    <button type="button" class="primary" id="wiz-next">Next</button>
  </div>
  <div id="wiz-err" class="error hidden"></div>
</div>`)
	on(byID("wiz-back"), "click", func(js.Value) {
		if a.wizard > 1 {
			a.wizard--
			a.renderWizardStep()
		}
	})
	on(byID("wiz-next"), "click", func(js.Value) { a.wizardNext() })
	a.renderWizardStep()
}

func (a *App) renderWizardStep() {
	title := byID("wiz-title")
	lede := byID("wiz-lede")
	body := byID("wiz-body")
	clear(body)
	addClass(byID("wiz-err"), "hidden")
	cfg := a.cfg
	if cfg == nil {
		cfg = &AppConfig{WispURL: defaultWisp}
		a.cfg = cfg
	}
	switch a.wizard {
	case 1:
		setText(title, "1 · Network (Wisp)")
		setText(lede, "Browsernet dials through Mercury Wisp by default. Leave blank to use wss://wisp.mercurywork.shop/ — override only if you run your own Wisp.")
		wispVal := ""
		if cfg.WispURL != "" && cfg.WispURL != defaultWisp {
			wispVal = cfg.WispURL
		}
		setHTML(body, `
<div class="field"><label>Wisp URL (optional override)</label>
<input id="wiz-wisp" type="url" value="`+esc(wispVal)+`" placeholder="`+esc(defaultWisp)+`" /></div>
<p class="lede" style="opacity:.75;font-size:.9em">Wisp-only networking — Mercury Wisp by default; override via Settings.</p>`)
	case 2:
		setText(title, "2 · VPS SSH target")
		setText(lede, "Remote execution via SSH over Wisp. Stored only in this browser.")
		port := 22
		host, user, key, pass := "", "", "", ""
		if cfg.SSH != nil {
			host, user, key, pass = cfg.SSH.Host, cfg.SSH.User, cfg.SSH.PrivateKey, cfg.SSH.Password
			if cfg.SSH.Port > 0 {
				port = cfg.SSH.Port
			}
		}
		setHTML(body, `
<div class="field"><label>Host</label><input id="wiz-host" value="`+esc(host)+`" /></div>
<div class="field"><label>Port</label><input id="wiz-port" type="number" value="`+strconv.Itoa(port)+`" /></div>
<div class="field"><label>User</label><input id="wiz-user" value="`+esc(user)+`" /></div>
<div class="field"><label>Private key (PEM)</label><textarea id="wiz-key" rows="4">`+esc(key)+`</textarea></div>
<div class="field"><label>Password (alt)</label><input id="wiz-pass" type="password" value="`+esc(pass)+`" /></div>`)
	case 3:
		setText(title, "3 · Model provider")
		setText(lede, "OpenAI-compatible API. Calls go through browsernet (Go), not a GOAR server.")
		var opts strings.Builder
		sel := "openai"
		model, base, key := "gpt-4o-mini", "https://api.openai.com/v1", ""
		if cfg.Provider != nil {
			sel = cfg.Provider.Key
			model, base, key = cfg.Provider.Model, cfg.Provider.BaseURL, cfg.Provider.APIKey
		}
		for _, p := range providers() {
			s := ""
			if p.Key == sel {
				s = " selected"
			}
			opts.WriteString(`<option value="` + p.Key + `"` + s + `>` + p.Name + `</option>`)
		}
		setHTML(body, `
<div class="field"><label>Provider</label><select id="wiz-prov">`+opts.String()+`</select></div>
<div class="field"><label>API key</label><input id="wiz-apikey" type="password" value="`+esc(key)+`" /></div>
<div class="field"><label>Base URL</label><input id="wiz-base" value="`+esc(base)+`" /></div>
<div class="field"><label>Model</label><input id="wiz-model" value="`+esc(model)+`" /></div>
<div class="field"><label><input type="checkbox" id="wiz-puter" /> Enable Puter.js cloud FS (optional, opt-in)</label></div>`)
		setText(byID("wiz-next"), "Finish")
	}
	if a.wizard < 3 {
		setText(byID("wiz-next"), "Next")
	}
}

func (a *App) wizardNext() {
	cfg := a.cfg
	errEl := byID("wiz-err")
	switch a.wizard {
	case 1:
		wisp := strings.TrimSpace(byID("wiz-wisp").Get("value").String())
		if wisp == "" {
			wisp = defaultWisp
		}
		cfg.WispURL = wisp
		// Wisp-only: no SOCKS collection.
		cfg.ProxyURL = ""
		a.wizard = 2
		a.renderWizardStep()
	case 2:
		host := strings.TrimSpace(byID("wiz-host").Get("value").String())
		user := strings.TrimSpace(byID("wiz-user").Get("value").String())
		key := strings.TrimSpace(byID("wiz-key").Get("value").String())
		pass := byID("wiz-pass").Get("value").String()
		port, _ := strconv.Atoi(byID("wiz-port").Get("value").String())
		if host == "" || user == "" || (key == "" && pass == "") {
			remClass(errEl, "hidden")
			setText(errEl, "Host, user, and key or password required.")
			return
		}
		if port == 0 {
			port = 22
		}
		cfg.SSH = &SSHConfig{Host: host, Port: port, User: user, PrivateKey: key, Password: pass, TrustOnFirstUse: true}
		a.wizard = 3
		a.renderWizardStep()
	case 3:
		pkey := byID("wiz-prov").Get("value").String()
		apiKey := byID("wiz-apikey").Get("value").String()
		base := strings.TrimSpace(byID("wiz-base").Get("value").String())
		model := strings.TrimSpace(byID("wiz-model").Get("value").String())
		if model == "" {
			remClass(errEl, "hidden")
			setText(errEl, "Model required.")
			return
		}
		cfg.Provider = &ProviderConfig{Key: pkey, APIKey: apiKey, BaseURL: base, Model: model}
		puterOn := byID("wiz-puter").Get("checked").Bool()
		cfg.Puter = &PuterConfig{Enabled: puterOn, Root: "goar-agent-home"}
		saveConfig(cfg)
		a.cfg = cfg
		a.syncPersist()
		a.ensureConfigured()
		a.showWorkspace()
		a.toast("Configured. Agent ready.", "ok")
		notify("GOAR", "Setup complete")
	}
}

func esc(s string) string {
	r := strings.NewReplacer(`&`, "&amp;", `<`, "&lt;", `>`, "&gt;", `"`, "&quot;")
	return r.Replace(s)
}
