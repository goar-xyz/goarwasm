//go:build !(js && wasm)

package onboardui

import (
	"strings"

	tea "github.com/charmbracelet/bubbletea"
	"github.com/charmbracelet/lipgloss"
	"github.com/goarxyz/goar/internal/core/providers"
)

type providerModel struct {
	list  fadeList
	keys  []string
	theme string
}

func newProvider(theme, initial string) providerModel {
	items := make([]string, 0, len(providers.Catalog))
	keys := make([]string, 0, len(providers.Catalog))
	for _, p := range providers.Catalog {
		items = append(items, p.DisplayName)
		keys = append(keys, p.Key)
	}
	if initial == "" {
		initial = "openai"
	}
	label := initial
	if p := providers.Find(initial); p != nil {
		label = p.DisplayName
	}
	m := providerModel{
		list:  newFadeList("Select your provider", items, label, theme),
		keys:  keys,
		theme: theme,
	}
	m.list.theme = theme
	return m
}

func (m providerModel) Init() tea.Cmd { return nil }

func (m providerModel) SelectedKey() string {
	if m.list.index < 0 || m.list.index >= len(m.keys) {
		return "openai"
	}
	return m.keys[m.list.index]
}

func (m providerModel) Selected() *providers.Preset {
	return providers.Find(m.SelectedKey())
}

func (m providerModel) Update(msg tea.Msg) (providerModel, tea.Cmd) {
	switch msg := msg.(type) {
	case tea.WindowSizeMsg:
		m.list.width, m.list.height = msg.Width, msg.Height
	case tea.KeyMsg:
		if msg.String() == "enter" {
			return m, nextScreenCmd(flowToScreen(NextAfterProvider(m.Selected())))
		}
		var cmd tea.Cmd
		m.list, cmd, _ = m.list.handleKey(msg)
		return m, cmd
	}
	return m, nil
}

func (m providerModel) View() string {
	p := m.Selected()
	preview := providerPreview(p, m.theme)
	return m.list.renderChrome(preview)
}

func providerPreview(p *providers.Preset, theme string) string {
	s := styleFrom(themeOf(theme))
	if p == nil {
		return s.dim().Render("No provider selected")
	}
	api := p.APIBase
	if api == "" {
		api = p.DefaultBaseHint
		if api == "" {
			api = "(you provide)"
		}
	}
	var b strings.Builder
	b.WriteString(s.title().Render(p.DisplayName) + "\n")
	b.WriteString(s.body().Render(p.Description) + "\n\n")
	b.WriteString(s.dim().Render("API  "+api) + "\n")
	if p.APIKeyEnvVar != "" {
		b.WriteString(s.dim().Render("Key  "+p.APIKeyEnvVar) + "\n")
	} else {
		b.WriteString(s.dim().Render("Key  not required") + "\n")
	}
	if p.Notes != "" {
		b.WriteString("\n" + s.dim().Render(p.Notes))
	}
	if len(p.Models) > 0 {
		b.WriteString("\n\n" + s.dim().Render("Models"))
		for i, m := range p.Models {
			if i >= 3 {
				b.WriteString("\n" + s.dim().Render("  …"))
				break
			}
			b.WriteString("\n" + s.body().Render("  "+m.Alias+"  →  "+m.ID))
		}
	}
	_ = lipgloss.NewStyle()
	return b.String()
}
