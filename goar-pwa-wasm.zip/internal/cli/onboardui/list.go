//go:build !(js && wasm)

package onboardui

import (
	"strings"

	tea "github.com/charmbracelet/bubbletea"
	"github.com/charmbracelet/lipgloss"
)

const (
	visibleNeighbors = 3
)

// fadeList is the Vibe theme-list motion: selected item bordered, neighbors fade.
type fadeList struct {
	items   []string
	index   int
	title   string
	navHint string
	okHint  string
	theme   string
	width   int
	height  int
}

func newFadeList(title string, items []string, initial string, theme string) fadeList {
	idx := 0
	for i, it := range items {
		if it == initial {
			idx = i
			break
		}
	}
	return fadeList{
		items:   items,
		index:   idx,
		title:   title,
		navHint: "Navigate ↑↓",
		okHint:  "Press Enter ↵",
		theme:   theme,
	}
}

func (l fadeList) selected() string {
	if len(l.items) == 0 {
		return ""
	}
	return l.items[l.index]
}

func (l fadeList) move(delta int) fadeList {
	if len(l.items) == 0 {
		return l
	}
	l.index = (l.index + delta) % len(l.items)
	if l.index < 0 {
		l.index += len(l.items)
	}
	return l
}

func (l fadeList) atOffset(offset int) string {
	if len(l.items) == 0 {
		return ""
	}
	i := (l.index + offset) % len(l.items)
	if i < 0 {
		i += len(l.items)
	}
	return l.items[i]
}

func (l fadeList) handleKey(msg tea.KeyMsg) (fadeList, tea.Cmd, bool) {
	switch msg.String() {
	case "up", "k":
		l = l.move(-1)
		return l, nil, true
	case "down", "j":
		l = l.move(1)
		return l, nil, true
	case "esc", "ctrl+c":
		return l, cancelCmd(), true
	}
	return l, nil, false
}

func (l fadeList) renderColumn() string {
	s := styleFrom(themeOf(l.theme))
	var lines []string
	for i := 0; i < visibleNeighbors*2+1; i++ {
		offset := i - visibleNeighbors
		name := l.atOffset(offset)
		if offset == 0 {
			lines = append(lines, s.selectedItem().Render(" "+name+" "))
		} else {
			dist := abs(offset) - 1
			if dist > 2 {
				dist = 2
			}
			lines = append(lines, s.fadeItem(dist+1).Render(name))
		}
	}
	return lipgloss.JoinVertical(lipgloss.Center, lines...)
}

func (l fadeList) renderChrome(preview string) string {
	s := styleFrom(themeOf(l.theme))
	title := s.subtitle().Align(lipgloss.Center).Width(60).Render(l.title)
	nav := s.body().Width(16).Align(lipgloss.Right).Render("Navigate " + shortcut("↑↓"))
	ok := s.body().Width(18).Align(lipgloss.Left).Render("Press " + shortcut("Enter") + " ↵")
	list := l.renderColumn()
	row := lipgloss.JoinHorizontal(lipgloss.Center, nav, "  ", list, "  ", ok)
	parts := []string{title, "", row}
	if preview != "" {
		box := s.previewBox()
		// lipgloss doesn't have BorderTitle; prefix a centered label.
		label := s.dim().Width(56).Align(lipgloss.Center).Render("Preview")
		parts = append(parts, "", label, box.Render(preview))
	}
	inner := lipgloss.JoinVertical(lipgloss.Center, parts...)
	return center(l.width, l.height, inner)
}

func abs(n int) int {
	if n < 0 {
		return -n
	}
	return n
}

func renderMarkdownPreview(theme string) string {
	th := themeOf(theme)
	s := styleFrom(th)
	h := lipgloss.NewStyle().Bold(true).Foreground(s.accent)
	b := lipgloss.NewStyle().Bold(true).Foreground(s.fg)
	it := lipgloss.NewStyle().Italic(true).Foreground(s.fg)
	code := lipgloss.NewStyle().Foreground(s.accent).Background(lipgloss.Color("#1A1D24"))
	if strings.EqualFold(theme, "goar-light") {
		code = lipgloss.NewStyle().Foreground(s.accent).Background(lipgloss.Color("#D8D4C9"))
	}
	dim := s.dim()
	var out strings.Builder
	out.WriteString(h.Render("### Heading") + "\n\n")
	out.WriteString(b.Render("Bold") + ", " + it.Render("italic") + ", and " + code.Render(" inline code ") + ".\n\n")
	out.WriteString(s.body().Render("• Bullet point") + "\n")
	out.WriteString(s.body().Render("• Another bullet point") + "\n\n")
	out.WriteString(s.body().Render("1. First item") + "\n")
	out.WriteString(s.body().Render("2. Second item") + "\n\n")
	out.WriteString(code.Render("def greet(name: str = \"World\") -> str:") + "\n")
	out.WriteString(code.Render("    return f\"Hello, {name}!\"") + "\n\n")
	out.WriteString(dim.Render("│ Blockquote") + "\n")
	out.WriteString(dim.Render("────────────") + "\n")
	out.WriteString(s.body().Render("Column 1   Column 2") + "\n")
	out.WriteString(s.body().Render("Item 1     Item 2"))
	return out.String()
}
