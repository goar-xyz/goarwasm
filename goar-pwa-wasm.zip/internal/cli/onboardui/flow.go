package onboardui

import "github.com/goarxyz/goar/internal/core/providers"

// Welcome copy matches Vibe's "Welcome to {product} - Let's get you started!"
// with the GOAR brand name as the gradient highlight.
const (
	brandName        = "GOAR"
	welcomePrefix    = "Welcome to "
	welcomeHighlight = "GOAR"
	welcomeSuffix    = " - Let's get you started!"
	welcomeText      = welcomePrefix + welcomeHighlight + welcomeSuffix
	buttonText       = "Press Enter ↵"
)

func welcomeHighlightBounds() (int, int) {
	start := len(welcomePrefix)
	return start, start + len(welcomeHighlight)
}

// Result is the outcome of the onboarding wizard.
type Result struct {
	Cancelled bool
	Theme     string
	Preset    *providers.Preset
	APIKey    string
	APIBase   string
	ModelID   string
	Alias     string
}

const (
	FlowWelcome  = "welcome"
	FlowTheme    = "theme"
	FlowProvider = "provider"
	FlowAPIKey   = "apikey"
	FlowBaseURL  = "baseurl"
	FlowModel    = "model"
	FlowDone     = "done"
)

// NextAfterProvider is Vibe's theme→auth hop: GOAR shows API key (or skips
// when the provider has no key), then optional base URL / model cards.
func NextAfterProvider(p *providers.Preset) string {
	if p == nil {
		return FlowAPIKey
	}
	if p.APIKeyEnvVar != "" {
		return FlowAPIKey
	}
	return NextAfterAPIKey(p)
}

// NextAfterAPIKey returns the follow-up screen after credentials.
func NextAfterAPIKey(p *providers.Preset) string {
	if p == nil {
		return FlowDone
	}
	if p.RequiresCustomBase || p.APIBase == "" {
		return FlowBaseURL
	}
	if NeedsModelScreen(p) {
		return FlowModel
	}
	return FlowDone
}

// NextAfterBaseURL returns the screen after a custom base URL card.
func NextAfterBaseURL(p *providers.Preset) string {
	if NeedsModelScreen(p) {
		return FlowModel
	}
	return FlowDone
}

// NeedsModelScreen reports whether a Vibe-styled model card/list is required.
func NeedsModelScreen(p *providers.Preset) bool {
	if p == nil {
		return true
	}
	if p.RequiresCustomBase {
		return true
	}
	return len(p.Models) != 1
}
