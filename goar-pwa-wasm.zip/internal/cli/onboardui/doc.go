// Package onboardui is the Bubble Tea first-run wizard.
// Screen style, motion, and step order mirror Mistral Vibe's onboarding
// (welcome typewriter → theme fade-list → credentials cards) while keeping
// the GOAR brand and multi-provider catalog.
package onboardui
