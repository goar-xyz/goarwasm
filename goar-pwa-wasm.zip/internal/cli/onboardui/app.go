//go:build !(js && wasm)

package onboardui

import (
	"fmt"
	"os"

	tea "github.com/charmbracelet/bubbletea"
	"github.com/goarxyz/goar/internal/cli/textualui/uitheme"
	"github.com/goarxyz/goar/internal/cli/textualui"
	"github.com/goarxyz/goar/internal/core/providers"
)

type screenID int

const (
	screenWelcome screenID = iota
	screenTheme
	screenProvider
	screenAPIKey
	screenBaseURL
	screenModel
	screenDone
)

func (s screenID) String() string {
	switch s {
	case screenWelcome:
		return "welcome"
	case screenTheme:
		return "theme"
	case screenProvider:
		return "provider"
	case screenAPIKey:
		return "apikey"
	case screenBaseURL:
		return "baseurl"
	case screenModel:
		return "model"
	case screenDone:
		return "done"
	default:
		return fmt.Sprintf("screen(%d)", int(s))
	}
}

func flowToScreen(name string) screenID {
	switch name {
	case FlowWelcome:
		return screenWelcome
	case FlowTheme:
		return screenTheme
	case FlowProvider:
		return screenProvider
	case FlowAPIKey:
		return screenAPIKey
	case FlowBaseURL:
		return screenBaseURL
	case FlowModel:
		return screenModel
	case FlowDone:
		return screenDone
	default:
		return screenDone
	}
}

type nextScreenMsg struct{ next screenID }
type cancelMsg struct{}

func nextScreenCmd(id screenID) tea.Cmd {
	return func() tea.Msg { return nextScreenMsg{next: id} }
}

func cancelCmd() tea.Cmd {
	return func() tea.Msg { return cancelMsg{} }
}

// Model is the Bubble Tea onboarding app (Vibe OnboardingApp).
type Model struct {
	screen   screenID
	width    int
	height   int
	theme    string
	welcome  welcomeModel
	themeSel themeModel
	provider providerModel
	apikey   apiKeyModel
	baseurl  baseURLModel
	modelSel modelScreen
	result   Result
	err      error
	instant  bool
}

// New creates the onboarding app. GOAR_ONBOARD_INSTANT=1 skips the typewriter.
func New() Model {
	instant := os.Getenv("GOAR_ONBOARD_INSTANT") != ""
	theme := textualui.DefaultAgentTheme
	return Model{
		screen:   screenWelcome,
		theme:    theme,
		welcome:  newWelcome(theme, instant),
		themeSel: newTheme(theme),
		instant:  instant,
	}
}

func (m Model) Init() tea.Cmd { return m.welcome.Init() }

func (m Model) Update(msg tea.Msg) (tea.Model, tea.Cmd) {
	switch msg := msg.(type) {
	case tea.WindowSizeMsg:
		m.width, m.height = msg.Width, msg.Height
		return m.forwardSize(msg)
	case cancelMsg:
		m.result.Cancelled = true
		return m, tea.Quit
	case nextScreenMsg:
		return m.switchTo(msg.next)
	case tea.KeyMsg:
		// Global cancel is handled per-screen so welcome can ignore Enter until typed.
	}
	return m.updateCurrent(msg)
}

func (m Model) forwardSize(msg tea.WindowSizeMsg) (tea.Model, tea.Cmd) {
	var cmd tea.Cmd
	switch m.screen {
	case screenWelcome:
		m.welcome, cmd = m.welcome.Update(msg)
	case screenTheme:
		m.themeSel, cmd = m.themeSel.Update(msg)
	case screenProvider:
		m.provider, cmd = m.provider.Update(msg)
	case screenAPIKey:
		m.apikey, cmd = m.apikey.Update(msg)
	case screenBaseURL:
		m.baseurl, cmd = m.baseurl.Update(msg)
	case screenModel:
		m.modelSel, cmd = m.modelSel.Update(msg)
	}
	return m, cmd
}

func (m Model) updateCurrent(msg tea.Msg) (tea.Model, tea.Cmd) {
	var cmd tea.Cmd
	switch m.screen {
	case screenWelcome:
		m.welcome, cmd = m.welcome.Update(msg)
	case screenTheme:
		m.themeSel, cmd = m.themeSel.Update(msg)
		m.theme = m.themeSel.Selected()
	case screenProvider:
		m.provider, cmd = m.provider.Update(msg)
	case screenAPIKey:
		m.apikey, cmd = m.apikey.Update(msg)
	case screenBaseURL:
		m.baseurl, cmd = m.baseurl.Update(msg)
	case screenModel:
		m.modelSel, cmd = m.modelSel.Update(msg)
	}
	return m, cmd
}

func (m Model) switchTo(next screenID) (tea.Model, tea.Cmd) {
	if next == screenDone {
		m.collect()
		if err := persist(m.result); err != nil {
			m.err = err
			m.result.Cancelled = false
		}
		return m, tea.Quit
	}
	m.screen = next
	preset := m.currentPreset()
	theme := m.themeSel.Selected()
	m.theme = theme
	var cmd tea.Cmd
	switch next {
	case screenTheme:
		m.themeSel = newTheme(theme)
		m.themeSel.list.width, m.themeSel.list.height = m.width, m.height
		cmd = m.themeSel.Init()
	case screenProvider:
		key := "openai"
		if preset != nil {
			key = preset.Key
		}
		m.provider = newProvider(theme, key)
		m.provider.list.width, m.provider.list.height = m.width, m.height
		cmd = m.provider.Init()
	case screenAPIKey:
		m.apikey = newAPIKey(preset, theme)
		m.apikey.width, m.apikey.height = m.width, m.height
		cmd = m.apikey.Init()
	case screenBaseURL:
		m.baseurl = newBaseURL(preset, theme)
		m.baseurl.width, m.baseurl.height = m.width, m.height
		cmd = m.baseurl.Init()
	case screenModel:
		m.modelSel = newModelScreen(preset, theme)
		m.modelSel.width, m.modelSel.height = m.width, m.height
		m.modelSel.list.width, m.modelSel.list.height = m.width, m.height
		cmd = m.modelSel.Init()
	}
	return m, cmd
}

func (m Model) currentPreset() *providers.Preset {
	if m.provider.keys != nil {
		return m.provider.Selected()
	}
	return providers.Find("openai")
}

func (m *Model) collect() {
	preset := m.currentPreset()
	m.result.Theme = m.themeSel.Selected()
	m.result.Preset = preset
	m.result.APIKey = m.apikey.Value()
	if m.baseurl.preset != nil || m.baseurl.input.Value() != "" {
		m.result.APIBase = m.baseurl.Value()
	}
	if preset != nil && m.result.APIBase == "" {
		m.result.APIBase = preset.APIBase
		if m.result.APIBase == "" {
			m.result.APIBase = stringsTrimSlash(preset.DefaultBaseHint)
		}
	}
	if m.modelSel.preset != nil || m.modelSel.useInput || len(m.modelSel.ids) > 0 {
		m.result.ModelID, m.result.Alias = m.modelSel.Choice()
	}
	if preset != nil && m.result.ModelID == "" && len(preset.Models) > 0 {
		m.result.ModelID = preset.Models[0].ID
		m.result.Alias = preset.Models[0].Alias
	}
}

func stringsTrimSlash(s string) string {
	for len(s) > 0 && s[len(s)-1] == '/' {
		s = s[:len(s)-1]
	}
	return s
}

func (m Model) View() string {
	switch m.screen {
	case screenWelcome:
		return m.welcome.View()
	case screenTheme:
		return m.themeSel.View()
	case screenProvider:
		return m.provider.View()
	case screenAPIKey:
		return m.apikey.View()
	case screenBaseURL:
		return m.baseurl.View()
	case screenModel:
		return m.modelSel.View()
	default:
		return ""
	}
}

func (m Model) Screen() screenID { return m.screen }

func (m Model) Result() Result { return m.result }

func (m Model) Err() error { return m.err }

// Run launches the onboarding TUI. Returns a cancelled result (not an error) on Esc.
func Run() (Result, error) {
	uitheme.EnsureColorProfile()
	m := New()
	opts := []tea.ProgramOption{}
	if os.Getenv("GOAR_ONBOARD_INSTANT") == "" {
		opts = append(opts, tea.WithAltScreen())
	}
	p := tea.NewProgram(m, opts...)
	final, err := p.Run()
	if err != nil {
		return Result{}, err
	}
	done, ok := final.(Model)
	if !ok {
		return Result{}, fmt.Errorf("onboarding: unexpected model type")
	}
	if done.err != nil {
		return done.result, done.err
	}
	return done.result, nil
}
