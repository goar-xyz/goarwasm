//go:build !(js && wasm)

package onboardui

import (
	"time"

	tea "github.com/charmbracelet/bubbletea"
	"github.com/charmbracelet/lipgloss"
)

const (
	highlightStart = len(welcomePrefix)
	highlightEnd   = highlightStart + len(welcomeHighlight)
)

type typeTickMsg struct{}
type gradientTickMsg struct{}
type showButtonMsg struct{}
type resumeTypingMsg struct{}
type buttonTickMsg struct{}

type welcomeModel struct {
	charIndex      int
	gradientOffset int
	typingDone     bool
	paused         bool
	buttonIndex    int
	buttonVisible  bool
	buttonDone     bool
	width, height  int
	theme          string
	instant        bool
}

func newWelcome(theme string, instant bool) welcomeModel {
	w := welcomeModel{theme: theme, instant: instant}
	if instant {
		w.charIndex = len(welcomeText)
		w.typingDone = true
		w.buttonVisible = true
		w.buttonIndex = len(buttonText)
		w.buttonDone = true
	}
	return w
}

func (w welcomeModel) Init() tea.Cmd {
	if w.instant {
		return nil
	}
	return tea.Tick(40*time.Millisecond, func(time.Time) tea.Msg { return typeTickMsg{} })
}

func (w welcomeModel) Update(msg tea.Msg) (welcomeModel, tea.Cmd) {
	switch msg := msg.(type) {
	case tea.WindowSizeMsg:
		w.width, w.height = msg.Width, msg.Height
	case typeTickMsg:
		return w.typeNext()
	case gradientTickMsg:
		w.gradientOffset = (w.gradientOffset + 1) % len(gradientColors)
		if w.paused {
			return w, tea.Tick(80*time.Millisecond, func(time.Time) tea.Msg { return gradientTickMsg{} })
		}
		return w, nil
	case resumeTypingMsg:
		w.paused = false
		return w, tea.Tick(30*time.Millisecond, func(time.Time) tea.Msg { return typeTickMsg{} })
	case showButtonMsg:
		w.buttonVisible = true
		return w, tea.Tick(30*time.Millisecond, func(time.Time) tea.Msg { return buttonTickMsg{} })
	case buttonTickMsg:
		if w.buttonIndex >= len(buttonText) {
			w.buttonDone = true
			return w, nil
		}
		w.buttonIndex++
		return w, tea.Tick(30*time.Millisecond, func(time.Time) tea.Msg { return buttonTickMsg{} })
	case tea.KeyMsg:
		switch msg.String() {
		case "enter":
			if w.typingDone {
				return w, nextScreenCmd(screenTheme)
			}
		case "esc", "ctrl+c":
			return w, cancelCmd()
		}
	}
	return w, nil
}

func (w welcomeModel) typeNext() (welcomeModel, tea.Cmd) {
	if w.charIndex >= len(welcomeText) {
		if !w.typingDone {
			w.typingDone = true
			return w, tea.Tick(500*time.Millisecond, func(time.Time) tea.Msg { return showButtonMsg{} })
		}
		return w, nil
	}
	if w.charIndex == highlightEnd && !w.paused {
		w.paused = true
		return w, tea.Batch(
			tea.Tick(80*time.Millisecond, func(time.Time) tea.Msg { return gradientTickMsg{} }),
			tea.Tick(1400*time.Millisecond, func(time.Time) tea.Msg { return resumeTypingMsg{} }),
		)
	}
	w.charIndex++
	return w, tea.Tick(40*time.Millisecond, func(time.Time) tea.Msg { return typeTickMsg{} })
}

func (w welcomeModel) renderWelcome(length int) string {
	text := welcomeText
	if length < len(text) {
		text = text[:length]
	}
	s := styleFrom(themeOf(w.theme))
	plain := s.body()
	if length <= highlightStart {
		return plain.Render(text)
	}
	prefix := plain.Render(text[:highlightStart])
	hlLen := highlightEnd - highlightStart
	if length < highlightEnd {
		hlLen = length - highlightStart
	}
	highlight := gradientMarkup(welcomeHighlight[:hlLen], w.gradientOffset)
	if length > highlightEnd {
		return prefix + highlight + plain.Render(text[highlightEnd:])
	}
	return prefix + highlight
}

func (w welcomeModel) View() string {
	s := styleFrom(themeOf(w.theme))
	box := s.welcomeBox().Render(w.renderWelcome(w.charIndex))
	hint := ""
	if w.buttonVisible {
		raw := buttonText
		if w.buttonIndex < len(raw) {
			raw = raw[:w.buttonIndex]
		}
		// Style "Enter" in red once fully typed (Vibe shortcut hint).
		if w.buttonDone {
			hint = "Press " + shortcut("Enter") + " ↵"
		} else {
			hint = s.body().Render(raw)
		}
	} else {
		hint = s.dim().Render(" ")
	}
	inner := lipgloss.JoinVertical(lipgloss.Center, box, "", hint)
	return center(w.width, w.height, inner)
}

func (w welcomeModel) canAdvance() bool { return w.typingDone }

func renderWelcomeAt(length, offset int, theme string) string {
	w := welcomeModel{charIndex: length, gradientOffset: offset, theme: theme}
	return w.renderWelcome(length)
}
