//go:build !(js && wasm)

package onboardui

import (
	tea "github.com/charmbracelet/bubbletea"
	"github.com/goarxyz/goar/internal/cli/textualui"
)

type themeModel struct {
	list fadeList
}

func newTheme(initial string) themeModel {
	names := textualui.SortedThemeNames()
	if len(names) == 0 {
		names = []string{textualui.DefaultAgentTheme}
	}
	if initial == "" {
		initial = textualui.DefaultAgentTheme
	}
	return themeModel{list: newFadeList("Select your preferred theme", names, initial, initial)}
}

func (m themeModel) Init() tea.Cmd { return nil }

func (m themeModel) Selected() string { return m.list.selected() }

func (m themeModel) Update(msg tea.Msg) (themeModel, tea.Cmd) {
	switch msg := msg.(type) {
	case tea.WindowSizeMsg:
		m.list.width, m.list.height = msg.Width, msg.Height
	case tea.KeyMsg:
		if msg.String() == "enter" {
			return m, nextScreenCmd(screenProvider)
		}
		var cmd tea.Cmd
		var handled bool
		m.list, cmd, handled = m.list.handleKey(msg)
		if handled {
			m.list.theme = m.list.selected()
			return m, cmd
		}
	}
	return m, nil
}

func (m themeModel) View() string {
	return m.list.renderChrome(renderMarkdownPreview(m.list.selected()))
}
