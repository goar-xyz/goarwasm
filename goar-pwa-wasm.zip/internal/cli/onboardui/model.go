//go:build !(js && wasm)

package onboardui

import (
	"strings"

	"github.com/charmbracelet/bubbles/textinput"
	tea "github.com/charmbracelet/bubbletea"
	"github.com/charmbracelet/lipgloss"
	"github.com/goarxyz/goar/internal/core/providers"
)

type modelScreen struct {
	list          fadeList
	input         textinput.Model
	preset        *providers.Preset
	theme         string
	width, height int
	useInput      bool
	ids           []string
	aliases       []string
}

func newModelScreen(preset *providers.Preset, theme string) modelScreen {
	m := modelScreen{preset: preset, theme: theme}
	if preset != nil && len(preset.Models) > 0 {
		items := make([]string, 0, len(preset.Models)+1)
		m.ids = make([]string, 0, len(preset.Models)+1)
		m.aliases = make([]string, 0, len(preset.Models)+1)
		for _, pair := range preset.Models {
			items = append(items, pair.Alias+"  →  "+pair.ID)
			m.ids = append(m.ids, pair.ID)
			m.aliases = append(m.aliases, pair.Alias)
		}
		items = append(items, "Custom model id…")
		m.ids = append(m.ids, "")
		m.aliases = append(m.aliases, "")
		m.list = newFadeList("Select a model", items, items[0], theme)
	} else {
		m.useInput = true
		ti := textinput.New()
		ti.Placeholder = "model-id"
		ti.CharLimit = 256
		ti.Width = 60
		ti.Focus()
		m.input = ti
	}
	return m
}

func (m modelScreen) Init() tea.Cmd {
	if m.useInput {
		return textinput.Blink
	}
	return nil
}

func (m modelScreen) Choice() (id, alias string) {
	if m.useInput {
		v := strings.TrimSpace(m.input.Value())
		return v, v
	}
	i := m.list.index
	if i < 0 || i >= len(m.ids) {
		return "", ""
	}
	if m.ids[i] == "" {
		v := strings.TrimSpace(m.input.Value())
		return v, v
	}
	return m.ids[i], m.aliases[i]
}

func (m modelScreen) customSelected() bool {
	return !m.useInput && m.list.index == len(m.ids)-1 && len(m.ids) > 0 && m.ids[len(m.ids)-1] == ""
}

func (m modelScreen) Update(msg tea.Msg) (modelScreen, tea.Cmd) {
	switch msg := msg.(type) {
	case tea.WindowSizeMsg:
		m.width, m.height = msg.Width, msg.Height
		m.list.width, m.list.height = msg.Width, msg.Height
	case tea.KeyMsg:
		switch msg.String() {
		case "esc", "ctrl+c":
			return m, cancelCmd()
		case "enter":
			id, _ := m.Choice()
			if id == "" && (m.useInput || m.customSelected()) {
				return m, nil
			}
			if m.customSelected() && !m.useInput && m.input.Value() == "" {
				m.useInput = true
				if m.input.Value() == "" {
					ti := textinput.New()
					ti.Placeholder = "custom-model-id"
					ti.CharLimit = 256
					ti.Width = 60
					ti.Focus()
					m.input = ti
				}
				return m, textinput.Blink
			}
			return m, nextScreenCmd(screenDone)
		}
		if m.useInput {
			var cmd tea.Cmd
			m.input, cmd = m.input.Update(msg)
			return m, cmd
		}
		var cmd tea.Cmd
		m.list, cmd, _ = m.list.handleKey(msg)
		return m, cmd
	}
	if m.useInput {
		var cmd tea.Cmd
		m.input, cmd = m.input.Update(msg)
		return m, cmd
	}
	return m, nil
}

func (m modelScreen) View() string {
	if m.useInput {
		return m.inputView()
	}
	preview := ""
	if p := m.preset; p != nil {
		id, alias := m.Choice()
		s := styleFrom(themeOf(m.theme))
		if id == "" {
			preview = s.dim().Render("Type a custom model id on the next step.")
		} else {
			preview = s.title().Render(alias) + "\n" + s.dim().Render(id)
		}
	}
	return m.list.renderChrome(preview)
}

func (m modelScreen) inputView() string {
	s := styleFrom(themeOf(m.theme))
	title := s.heading().Render("Set your model id")
	sub := s.subtitle().Render("Any id your provider accepts.")
	ok := strings.TrimSpace(m.input.Value()) != ""
	card := s.card("Model id", &ok)
	inner := lipgloss.JoinVertical(lipgloss.Left,
		s.body().Bold(true).Render("Model id"),
		m.input.View(),
	)
	fb := s.dim().Render("Press " + shortcut("Enter") + " to submit ↵")
	if !ok {
		fb = lipgloss.NewStyle().Foreground(s.err).Render("Enter a model id.")
	}
	panel := lipgloss.JoinVertical(lipgloss.Left,
		s.accentMark(),
		title,
		sub,
		"",
		card.Render(inner),
		fb,
	)
	return center(m.width, m.height, lipgloss.NewStyle().Width(72).Render(panel))
}
