//go:build !(js && wasm)

package onboardui

import (
	"strings"

	"github.com/charmbracelet/bubbles/textinput"
	tea "github.com/charmbracelet/bubbletea"
	"github.com/charmbracelet/lipgloss"
	"github.com/goarxyz/goar/internal/core/paths"
	"github.com/goarxyz/goar/internal/core/providers"
)

type apiKeyModel struct {
	input         textinput.Model
	preset        *providers.Preset
	theme         string
	width, height int
	touched       bool
}

func newAPIKey(preset *providers.Preset, theme string) apiKeyModel {
	ti := textinput.New()
	ti.Placeholder = "sk-…"
	ti.EchoMode = textinput.EchoPassword
	ti.EchoCharacter = '•'
	ti.CharLimit = 512
	ti.Width = 60
	ti.Focus()
	return apiKeyModel{input: ti, preset: preset, theme: theme}
}

func (m apiKeyModel) Init() tea.Cmd { return textinput.Blink }

func (m apiKeyModel) Value() string { return strings.TrimSpace(m.input.Value()) }

func (m apiKeyModel) Update(msg tea.Msg) (apiKeyModel, tea.Cmd) {
	switch msg := msg.(type) {
	case tea.WindowSizeMsg:
		m.width, m.height = msg.Width, msg.Height
	case tea.KeyMsg:
		switch msg.String() {
		case "esc", "ctrl+c":
			return m, cancelCmd()
		case "enter":
			if m.Value() == "" {
				m.touched = true
				return m, nil
			}
			return m, nextScreenCmd(flowToScreen(NextAfterAPIKey(m.preset)))
		}
	}
	var cmd tea.Cmd
	m.input, cmd = m.input.Update(msg)
	if m.input.Value() != "" {
		m.touched = true
	}
	return m, cmd
}

func (m apiKeyModel) View() string {
	s := styleFrom(themeOf(m.theme))
	name := "Provider"
	help := "your provider"
	if m.preset != nil {
		name = m.preset.DisplayName
		help = m.preset.DisplayName
	}
	title := s.heading().Render("Get your " + name + " API key")
	sub := s.subtitle().Render("Visit " + help + " to generate or copy your GOAR key")

	valid := m.Value() != ""
	var validPtr *bool
	if m.touched {
		validPtr = &valid
	}
	card := s.card("Paste API key", validPtr)
	// Border title via a header line inside the card.
	inner := lipgloss.JoinVertical(lipgloss.Left,
		s.body().Bold(true).Render("Paste API key"),
		m.input.View(),
	)
	box := card.Render(inner)

	feedback := ""
	if m.touched && !valid {
		feedback = lipgloss.NewStyle().Foreground(s.err).Render("No API key provided.")
	} else if valid {
		feedback = s.dim().Render("Press " + shortcut("Enter") + " to submit ↵")
	}

	docs := s.dim().Render("API key is stored in " + paths.EnvFile())
	if m.preset != nil && m.preset.APIKeyEnvVar != "" {
		docs = s.dim().Render("Stored in " + paths.EnvFile() + " as " + m.preset.APIKeyEnvVar)
	}
	more := s.dim().Faint(true).Render("Learn more about GOAR configurations")

	panel := lipgloss.JoinVertical(lipgloss.Left,
		s.accentMark(),
		title,
		sub,
		"",
		box,
		feedback,
		"",
		docs,
		more,
	)
	return center(m.width, m.height, lipgloss.NewStyle().Width(72).Render(panel))
}

func (s styles) accentMark() string {
	// Small GOAR mark in place of Vibe's petit-chat mascot.
	return lipgloss.NewStyle().Foreground(s.accent).Bold(true).Render("◆  GOAR")
}
