package onboardui

import (
	"fmt"

	"github.com/goarxyz/goar/internal/core/config"
)

func persist(r Result) error {
	if r.Preset == nil {
		return fmt.Errorf("no provider selected")
	}
	if r.Preset.APIKeyEnvVar != "" && r.APIKey != "" {
		if err := config.WriteEnvValue(r.Preset.APIKeyEnvVar, r.APIKey); err != nil {
			return err
		}
	}
	base := r.APIBase
	if base == "" {
		base = r.Preset.APIBase
	}
	if base == "" {
		base = r.Preset.DefaultBaseHint
	}
	modelID, alias := r.ModelID, r.Alias
	if modelID == "" && len(r.Preset.Models) > 0 {
		modelID, alias = r.Preset.Models[0].ID, r.Preset.Models[0].Alias
	}
	if modelID == "" {
		return fmt.Errorf("no model selected")
	}
	pc := config.ProviderConfig{
		Name: r.Preset.Key, APIBase: base, APIKeyEnvVar: r.Preset.APIKeyEnvVar,
		APIStyle: r.Preset.APIStyle, Backend: r.Preset.Backend, ReasoningFieldName: "reasoning_content",
	}
	mc := config.ModelConfig{Name: modelID, Provider: r.Preset.Key, Alias: alias, Temperature: 0.2, Thinking: "off"}
	theme := r.Theme
	if theme == "" {
		theme = config.DefaultTheme
	}
	return config.SaveMinimal(pc, mc, alias, theme)
}
