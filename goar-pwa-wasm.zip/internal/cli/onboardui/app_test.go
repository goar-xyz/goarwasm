//go:build !(js && wasm)

package onboardui

import (
	"testing"

	tea "github.com/charmbracelet/bubbletea"
)

func TestWelcomeEnterAdvancesToTheme(t *testing.T) {
	t.Setenv("GOAR_ONBOARD_INSTANT", "1")
	m := New()
	if m.Screen() != screenWelcome {
		t.Fatalf("start %s", m.Screen())
	}
	if !m.welcome.canAdvance() {
		t.Fatal("instant welcome should be ready")
	}
	next, cmd := m.Update(tea.KeyMsg{Type: tea.KeyEnter})
	m = next.(Model)
	if cmd != nil {
		if msg := cmd(); msg != nil {
			next, _ = m.Update(msg)
			m = next.(Model)
		}
	}
	if m.Screen() != screenTheme {
		t.Fatalf("after enter: %s", m.Screen())
	}
}

func TestThemeEnterAdvancesToProvider(t *testing.T) {
	t.Setenv("GOAR_ONBOARD_INSTANT", "1")
	m := New()
	m, cmd := step(m, tea.KeyMsg{Type: tea.KeyEnter})
	_ = cmd
	if m.Screen() != screenTheme {
		t.Fatalf("want theme, got %s", m.Screen())
	}
	m, _ = step(m, tea.KeyMsg{Type: tea.KeyEnter})
	if m.Screen() != screenProvider {
		t.Fatalf("want provider, got %s", m.Screen())
	}
}

func TestEscCancels(t *testing.T) {
	t.Setenv("GOAR_ONBOARD_INSTANT", "1")
	m := New()
	_, cmd := m.welcome.Update(tea.KeyMsg{Type: tea.KeyEsc})
	if cmd == nil {
		t.Fatal("expected cancel cmd")
	}
	msg := cmd()
	next, q := m.Update(msg)
	m = next.(Model)
	if !m.Result().Cancelled {
		t.Fatal("expected cancelled")
	}
	if q == nil {
		t.Fatal("expected quit")
	}
}

func step(m Model, msg tea.Msg) (Model, tea.Cmd) {
	next, cmd := m.Update(msg)
	m = next.(Model)
	if cmd == nil {
		return m, nil
	}
	if out := cmd(); out != nil {
		next, cmd = m.Update(out)
		m = next.(Model)
		return m, cmd
	}
	return m, cmd
}
