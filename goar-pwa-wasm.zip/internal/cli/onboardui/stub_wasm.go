//go:build js && wasm

package onboardui

import "fmt"

// Run is unavailable in the browser; first-run setup uses the native CLI.
func Run() (Result, error) {
	return Result{}, fmt.Errorf("onboarding UI is not available under GOOS=js/wasm; run the native goar --setup")
}
