package onboardui

import (
	"os"
	"path/filepath"
	"testing"

	"github.com/goarxyz/goar/internal/core/config"
	"github.com/goarxyz/goar/internal/core/providers"
)

func TestFlowMapsLikeVibe(t *testing.T) {
	// Vibe: Welcome → Theme → Auth → API key.
	// GOAR: Welcome → Theme → Provider → API key → (base/model if needed).
	order := []string{FlowWelcome, FlowTheme, FlowProvider}
	if order[0] != "welcome" || order[1] != "theme" || order[2] != "provider" {
		t.Fatal(order)
	}

	openai := providers.Find("openai")
	if openai == nil {
		t.Fatal("openai")
	}
	if got := NextAfterProvider(openai); got != FlowAPIKey {
		t.Fatalf("openai after provider: %s", got)
	}
	// openai has a default base and 3 models → model picker after key
	if got := NextAfterAPIKey(openai); got != FlowModel {
		t.Fatalf("openai after key: %s", got)
	}

	azure := providers.Find("azure")
	if azure == nil {
		t.Fatal("azure")
	}
	if got := NextAfterProvider(azure); got != FlowAPIKey {
		t.Fatalf("azure after provider: %s", got)
	}
	if got := NextAfterAPIKey(azure); got != FlowBaseURL {
		t.Fatalf("azure after key: %s", got)
	}
	if got := NextAfterBaseURL(azure); got != FlowModel {
		t.Fatalf("azure after base: %s", got)
	}

	ollama := providers.Find("ollama")
	if ollama == nil {
		t.Fatal("ollama")
	}
	// no key, default base, single model → done
	if got := NextAfterProvider(ollama); got != FlowDone {
		t.Fatalf("ollama after provider: %s", got)
	}

	custom := providers.Find("custom")
	if custom == nil {
		t.Fatal("custom")
	}
	if got := NextAfterProvider(custom); got != FlowAPIKey {
		t.Fatalf("custom after provider: %s", got)
	}
	if got := NextAfterAPIKey(custom); got != FlowBaseURL {
		t.Fatalf("custom after key: %s", got)
	}
}

func TestWelcomeHighlightIsGOAR(t *testing.T) {
	if welcomeHighlight != "GOAR" {
		t.Fatalf("brand highlight %q", welcomeHighlight)
	}
	if welcomeText != "Welcome to GOAR - Let's get you started!" {
		t.Fatalf("welcome text %q", welcomeText)
	}
	start, end := welcomeHighlightBounds()
	if welcomeText[start:end] != "GOAR" {
		t.Fatalf("bounds %d:%d", start, end)
	}
}

func TestPersistWritesThemeAndKey(t *testing.T) {
	dir := t.TempDir()
	t.Setenv("AGENT_HOME", dir)
	t.Setenv("AGENT_THEME", "")
	p := providers.Find("openai")
	err := persist(Result{
		Theme:   "goar-light",
		Preset:  p,
		APIKey:  "sk-test-onboard",
		APIBase: p.APIBase,
		ModelID: "gpt-4.1",
		Alias:   "gpt-4.1",
	})
	if err != nil {
		t.Fatal(err)
	}
	if _, err := os.Stat(filepath.Join(dir, "config.toml")); err != nil {
		t.Fatal(err)
	}
	if _, err := os.Stat(filepath.Join(dir, ".env")); err != nil {
		t.Fatal(err)
	}
	cfg, err := config.Load()
	if err != nil {
		t.Fatal(err)
	}
	if cfg.Theme != "goar-light" {
		t.Fatalf("theme %q", cfg.Theme)
	}
	if cfg.ActiveModel != "gpt-4.1" {
		t.Fatalf("model %q", cfg.ActiveModel)
	}
	if os.Getenv("OPENAI_API_KEY") != "sk-test-onboard" {
		// WriteEnvValue does not export; LoadDotEnv should have run in Load
	}
	b, err := os.ReadFile(filepath.Join(dir, ".env"))
	if err != nil {
		t.Fatal(err)
	}
	if string(b) == "" || !contains(string(b), "OPENAI_API_KEY=sk-test-onboard") {
		t.Fatalf("env file: %s", b)
	}
}

func contains(s, sub string) bool {
	return len(s) >= len(sub) && (s == sub || len(sub) == 0 || (len(s) > 0 && indexOf(s, sub) >= 0))
}

func indexOf(s, sub string) int {
	for i := 0; i+len(sub) <= len(s); i++ {
		if s[i:i+len(sub)] == sub {
			return i
		}
	}
	return -1
}
