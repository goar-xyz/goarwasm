//go:build !(js && wasm)

package onboardui

import (
	"strings"

	"github.com/charmbracelet/lipgloss"
	"github.com/goarxyz/goar/internal/cli/textualui/uitheme"
)

const (
	brandRed     = "#E11D2E"
	brandTitle   = "#E11D2E"
	ink          = "#0B0D10"
	bone         = "#E8E4D9"
	muted        = "#8B93A7"
	cardBorder   = "#303040"
	successColor = "#3DDC97"
	errorColor   = "#E25B4A"
)

// Red gradient — Vibe motion, GOAR brand (#E11D2E).
var gradientColors = []string{
	"#8B0F1A",
	"#A81420",
	"#C41828",
	"#E11D2E",
	"#ff2a3d",
	"#ff4d5c",
	"#ff2a3d",
	"#E11D2E",
	"#C41828",
	"#A81420",
}

func gradientMarkup(text string, offset int) string {
	var b strings.Builder
	for i, r := range text {
		color := gradientColors[(i+offset)%len(gradientColors)]
		b.WriteString(lipgloss.NewStyle().Bold(true).Foreground(lipgloss.Color(color)).Render(string(r)))
	}
	return b.String()
}

func themeOf(name string) uitheme.Theme {
	return uitheme.Get(name)
}

func styleFrom(th uitheme.Theme) styles {
	fg := th.Foreground
	if fg == "" {
		fg = bone
	}
	md := th.Muted
	if md == "" {
		md = muted
	}
	ac := th.Accent
	if ac == "" {
		ac = brandRed
	}
	bd := th.Border
	if bd == "" {
		bd = cardBorder
	}
	return styles{
		fg:      lipgloss.Color(fg),
		muted:   lipgloss.Color(md),
		accent:  lipgloss.Color(ac),
		border:  lipgloss.Color(bd),
		success: lipgloss.Color(th.Success),
		err:     lipgloss.Color(th.Error),
		bg:      lipgloss.Color(th.Background),
	}
}

type styles struct {
	fg, muted, accent, border, success, err, bg lipgloss.Color
}

func (s styles) title() lipgloss.Style {
	return lipgloss.NewStyle().Bold(true).Foreground(s.accent)
}

func (s styles) heading() lipgloss.Style {
	return lipgloss.NewStyle().Bold(true).Foreground(lipgloss.Color(brandTitle))
}

func (s styles) subtitle() lipgloss.Style {
	return lipgloss.NewStyle().Bold(true).Foreground(s.fg)
}

func (s styles) dim() lipgloss.Style {
	return lipgloss.NewStyle().Foreground(s.muted)
}

func (s styles) body() lipgloss.Style {
	return lipgloss.NewStyle().Foreground(s.fg)
}

func (s styles) welcomeBox() lipgloss.Style {
	return lipgloss.NewStyle().
		Border(lipgloss.RoundedBorder()).
		BorderForeground(s.muted).
		Padding(1, 3).
		Align(lipgloss.Center)
}

func (s styles) selectedItem() lipgloss.Style {
	return lipgloss.NewStyle().
		Bold(true).
		Foreground(s.fg).
		Border(lipgloss.RoundedBorder()).
		BorderForeground(s.accent).
		Padding(0, 2).
		Align(lipgloss.Center).
		Width(28)
}

func (s styles) fadeItem(level int) lipgloss.Style {
	// Vibe fade-1/2/3 ≈ 50% / 25% / 10%
	st := lipgloss.NewStyle().Align(lipgloss.Center).Width(28)
	switch level {
	case 1:
		return st.Foreground(s.muted)
	case 2:
		return st.Foreground(s.muted).Faint(true)
	default:
		return st.Foreground(s.border).Faint(true)
	}
}

func (s styles) card(title string, valid *bool) lipgloss.Style {
	border := s.border
	if valid != nil {
		if *valid {
			border = s.success
		} else {
			border = s.err
		}
	}
	return lipgloss.NewStyle().
		Border(lipgloss.NormalBorder()).
		BorderForeground(border).
		Padding(0, 1).
		Width(68)
}

func (s styles) previewBox() lipgloss.Style {
	return lipgloss.NewStyle().
		Border(lipgloss.RoundedBorder()).
		BorderForeground(s.muted).
		Padding(0, 1).
		Width(56)
}

func center(width, height int, content string) string {
	if width < 1 {
		width = 80
	}
	if height < 1 {
		height = 24
	}
	return lipgloss.Place(width, height, lipgloss.Center, lipgloss.Center, content)
}

func shortcut(label string) string {
	return lipgloss.NewStyle().Bold(true).Foreground(lipgloss.Color(brandRed)).Render(label)
}
