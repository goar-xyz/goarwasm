//go:build !(js && wasm)

package onboardui

import (
	"strings"

	"github.com/charmbracelet/bubbles/textinput"
	tea "github.com/charmbracelet/bubbletea"
	"github.com/charmbracelet/lipgloss"
	"github.com/goarxyz/goar/internal/core/providers"
)

type baseURLModel struct {
	input         textinput.Model
	preset        *providers.Preset
	theme         string
	width, height int
}

func newBaseURL(preset *providers.Preset, theme string) baseURLModel {
	ti := textinput.New()
	hint := "https://your-host/v1"
	if preset != nil {
		if preset.DefaultBaseHint != "" {
			hint = preset.DefaultBaseHint
		} else if preset.APIBase != "" {
			hint = preset.APIBase
		}
	}
	ti.Placeholder = hint
	ti.CharLimit = 512
	ti.Width = 60
	ti.Focus()
	return baseURLModel{input: ti, preset: preset, theme: theme}
}

func (m baseURLModel) Init() tea.Cmd { return textinput.Blink }

func (m baseURLModel) Value() string {
	v := strings.TrimRight(strings.TrimSpace(m.input.Value()), "/")
	if v == "" && m.preset != nil {
		if m.preset.DefaultBaseHint != "" {
			return strings.TrimRight(m.preset.DefaultBaseHint, "/")
		}
		return strings.TrimRight(m.preset.APIBase, "/")
	}
	return v
}

func (m baseURLModel) Update(msg tea.Msg) (baseURLModel, tea.Cmd) {
	switch msg := msg.(type) {
	case tea.WindowSizeMsg:
		m.width, m.height = msg.Width, msg.Height
	case tea.KeyMsg:
		switch msg.String() {
		case "esc", "ctrl+c":
			return m, cancelCmd()
		case "enter":
			if m.Value() == "" {
				return m, nil
			}
			return m, nextScreenCmd(flowToScreen(NextAfterBaseURL(m.preset)))
		}
	}
	var cmd tea.Cmd
	m.input, cmd = m.input.Update(msg)
	return m, cmd
}

func (m baseURLModel) View() string {
	s := styleFrom(themeOf(m.theme))
	title := s.heading().Render("Set your API base URL")
	sub := s.subtitle().Render("Point GOAR at this provider’s OpenAI-compatible endpoint.")
	if m.preset != nil && m.preset.Notes != "" {
		sub = s.subtitle().Render(m.preset.Notes)
	}
	ok := m.Value() != ""
	card := s.card("API base URL", &ok)
	inner := lipgloss.JoinVertical(lipgloss.Left,
		s.body().Bold(true).Render("API base URL"),
		m.input.View(),
	)
	box := card.Render(inner)
	fb := s.dim().Render("Press " + shortcut("Enter") + " to submit ↵")
	if !ok {
		fb = lipgloss.NewStyle().Foreground(s.err).Render("Enter a base URL.")
	}
	panel := lipgloss.JoinVertical(lipgloss.Left,
		s.accentMark(),
		title,
		sub,
		"",
		box,
		fb,
	)
	return center(m.width, m.height, lipgloss.NewStyle().Width(72).Render(panel))
}
