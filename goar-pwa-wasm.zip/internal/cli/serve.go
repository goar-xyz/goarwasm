package cli

import (
	"fmt"
	"net/http"
	"os"
	"os/exec"
	"runtime"
	"time"

	"github.com/spf13/cobra"

	"github.com/goarxyz/goar/internal/webui"
)

func newServeCmd() *cobra.Command {
	var addr string
	var dir string
	var noOpen bool

	c := &cobra.Command{
		Use:          "serve",
		Short:        "Host the GOAR web UI in a local browser",
		Long:         "Serve the embedded GOAR PWA (or a filesystem directory) over HTTP and optionally open a browser.",
		SilenceUsage: true,
		RunE: func(cmd *cobra.Command, args []string) error {
			return runServe(addr, dir, noOpen)
		},
	}
	c.Flags().StringVar(&addr, "addr", "127.0.0.1:8787", "Listen address (host:port)")
	c.Flags().StringVar(&dir, "dir", "", "Serve this directory instead of the embedded web UI")
	c.Flags().BoolVar(&noOpen, "no-open", false, "Do not open a browser")
	return c
}

func runServe(addr, dir string, noOpen bool) error {
	var handler http.Handler
	if dir != "" {
		fi, err := os.Stat(dir)
		if err != nil {
			return fmt.Errorf("serve --dir: %w", err)
		}
		if !fi.IsDir() {
			return fmt.Errorf("serve --dir: %s is not a directory", dir)
		}
		handler = http.FileServer(http.Dir(dir))
	} else {
		h, err := webui.Handler()
		if err != nil {
			return fmt.Errorf("embedded web UI: %w", err)
		}
		handler = h
	}

	url := "http://" + addr
	fmt.Printf("GOAR web UI on %s\n", url)

	if !noOpen {
		go func() {
			time.Sleep(200 * time.Millisecond)
			_ = openBrowser(url)
		}()
	}

	server := &http.Server{Addr: addr, Handler: handler}
	if err := server.ListenAndServe(); err != nil && err != http.ErrServerClosed {
		return err
	}
	return nil
}

func openBrowser(url string) error {
	var cmd *exec.Cmd
	switch runtime.GOOS {
	case "darwin":
		cmd = exec.Command("open", url)
	case "windows":
		cmd = exec.Command("rundll32", "url.dll,FileProtocolHandler", url)
	default:
		cmd = exec.Command("xdg-open", url)
	}
	cmd.Stdout = nil
	cmd.Stderr = nil
	return cmd.Start()
}
