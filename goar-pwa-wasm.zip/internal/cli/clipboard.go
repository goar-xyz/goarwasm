package cli

import (
	"bytes"
	"encoding/base64"
	"fmt"
	"os"
	"os/exec"
	"runtime"
	"strings"
)

// ClipboardError is raised when no clipboard backend works.
type ClipboardError struct{ Msg string }

func (e ClipboardError) Error() string { return e.Msg }

func hasCmd(cmd string) bool {
	_, err := exec.LookPath(cmd)
	return err == nil
}

func copyOSC52(text string) {
	payload := base64.StdEncoding.EncodeToString([]byte(text))
	seq := fmt.Sprintf("\x1b]52;c;%s\x07", payload)
	_, _ = os.Stderr.WriteString(seq)
}

func copyPbcopy(text string) error {
	cmd := exec.Command("pbcopy")
	cmd.Stdin = strings.NewReader(text)
	return cmd.Run()
}

func copyXclip(text string) error {
	cmd := exec.Command("xclip", "-selection", "clipboard")
	cmd.Stdin = strings.NewReader(text)
	return cmd.Run()
}

func copyWlCopy(text string) error {
	cmd := exec.Command("wl-copy")
	cmd.Stdin = strings.NewReader(text)
	return cmd.Run()
}

func pastePbpaste() (string, error) {
	out, err := exec.Command("pbpaste").Output()
	return string(out), err
}

func pasteXclip() (string, error) {
	out, err := exec.Command("xclip", "-selection", "clipboard", "-o").Output()
	return string(out), err
}

func pasteWlPaste() (string, error) {
	out, err := exec.Command("wl-paste", "-n").Output()
	return string(out), err
}

// ReadClipboard reads clipboard text via the best available backend.
func ReadClipboard() (string, error) {
	switch {
	case runtime.GOOS == "darwin" && hasCmd("pbpaste"):
		return pastePbpaste()
	case hasCmd("wl-paste"):
		return pasteWlPaste()
	case hasCmd("xclip"):
		return pasteXclip()
	default:
		return "", ClipboardError{Msg: "no clipboard paste backend available"}
	}
}

// CopyToClipboard writes text to the system clipboard.
func CopyToClipboard(text string) error {
	var errs []string
	switch {
	case runtime.GOOS == "darwin" && hasCmd("pbcopy"):
		if err := copyPbcopy(text); err == nil {
			return nil
		} else {
			errs = append(errs, err.Error())
		}
	}
	if hasCmd("wl-copy") {
		if err := copyWlCopy(text); err == nil {
			return nil
		} else {
			errs = append(errs, err.Error())
		}
	}
	if hasCmd("xclip") {
		if err := copyXclip(text); err == nil {
			return nil
		} else {
			errs = append(errs, err.Error())
		}
	}
	// Always also emit OSC 52 for terminal clipboard support.
	copyOSC52(text)
	if len(errs) == 0 {
		return nil
	}
	return ClipboardError{Msg: "clipboard copy failed: " + strings.Join(errs, "; ")}
}

// CopyTextToClipboard copies text and returns a user-facing status message.
func CopyTextToClipboard(text string, showToast bool) (string, error) {
	text = strings.TrimRight(text, "\n")
	if text == "" {
		return "", ClipboardError{Msg: "nothing to copy"}
	}
	if err := CopyToClipboard(text); err != nil {
		// OSC52 may still have worked
		if showToast {
			return "Copied via terminal (OSC 52)", nil
		}
		return "", err
	}
	msg := fmt.Sprintf("Copied %d characters to clipboard", len([]rune(text)))
	if !showToast {
		return msg, nil
	}
	return msg, nil
}

// SelectedTexts collects non-empty selected strings from a list of candidates.
func SelectedTexts(candidates []string) []string {
	var out []string
	seen := map[string]bool{}
	for _, c := range candidates {
		c = strings.TrimSpace(c)
		if c == "" || seen[c] {
			continue
		}
		seen[c] = true
		out = append(out, c)
	}
	return out
}

// CopySelectionToClipboard joins selected texts and copies them.
func CopySelectionToClipboard(selected []string, showToast bool) (string, error) {
	texts := SelectedTexts(selected)
	if len(texts) == 0 {
		return "", ClipboardError{Msg: "no selection"}
	}
	var buf bytes.Buffer
	for i, t := range texts {
		if i > 0 {
			buf.WriteByte('\n')
		}
		buf.WriteString(t)
	}
	return CopyTextToClipboard(buf.String(), showToast)
}

// HasClipboardWrite reports whether a native clipboard write tool exists.
func HasClipboardWrite() bool {
	if runtime.GOOS == "darwin" && hasCmd("pbcopy") {
		return true
	}
	return hasCmd("wl-copy") || hasCmd("xclip")
}

// HasClipboardRead reports whether a native clipboard read tool exists.
func HasClipboardRead() bool {
	if runtime.GOOS == "darwin" && hasCmd("pbpaste") {
		return true
	}
	return hasCmd("wl-paste") || hasCmd("xclip")
}

// ReadClipboardImage tries to read an image from the OS clipboard.
// Returns PNG/JPEG bytes and a suggested extension (".png", ".jpg").
func ReadClipboardImage() (data []byte, ext string, err error) {
	try := func(cmd string, args ...string) ([]byte, error) {
		out, e := exec.Command(cmd, args...).Output()
		if e != nil {
			return nil, e
		}
		if len(out) == 0 {
			return nil, ClipboardError{Msg: "clipboard image empty"}
		}
		return out, nil
	}
	switch {
	case hasCmd("wl-paste"):
		for _, mime := range []struct{ t, ext string }{
			{"image/png", ".png"},
			{"image/jpeg", ".jpg"},
			{"image/jpg", ".jpg"},
			{"image/webp", ".webp"},
		} {
			if out, e := try("wl-paste", "--type", mime.t); e == nil {
				return out, mime.ext, nil
			}
		}
		// Some compositors omit type; try raw
		if out, e := try("wl-paste", "-t", "image/png"); e == nil {
			return out, ".png", nil
		}
	case hasCmd("xclip"):
		for _, mime := range []struct{ t, ext string }{
			{"image/png", ".png"},
			{"image/jpeg", ".jpg"},
			{"image/jpg", ".jpg"},
		} {
			if out, e := try("xclip", "-selection", "clipboard", "-t", mime.t, "-o"); e == nil {
				return out, mime.ext, nil
			}
		}
	case runtime.GOOS == "darwin" && hasCmd("pngpaste"):
		f, e := os.CreateTemp("", "goar-clip-*.png")
		if e == nil {
			tmp := f.Name()
			_ = f.Close()
			_ = os.Remove(tmp)
			if e2 := exec.Command("pngpaste", tmp).Run(); e2 == nil {
				b, e3 := os.ReadFile(tmp)
				_ = os.Remove(tmp)
				if e3 == nil && len(b) > 0 {
					return b, ".png", nil
				}
			}
		}
	}
	return nil, "", ClipboardError{Msg: "no clipboard image available (try /paste-image /path/to/image.png)"}
}
