package cli

import (
	"encoding/json"
	"os"
	"sync"
	"time"
)

// Profiler records named timing spans.
type Profiler struct {
	mu     sync.Mutex
	spans  map[string]time.Duration
	starts map[string]time.Time
}

func NewProfiler() *Profiler {
	return &Profiler{spans: map[string]time.Duration{}, starts: map[string]time.Time{}}
}

func (p *Profiler) Start(name string) {
	p.mu.Lock()
	defer p.mu.Unlock()
	p.starts[name] = time.Now()
}

func (p *Profiler) Stop(name string) {
	p.mu.Lock()
	defer p.mu.Unlock()
	if t, ok := p.starts[name]; ok {
		p.spans[name] += time.Since(t)
		delete(p.starts, name)
	}
}

func (p *Profiler) Report() map[string]float64 {
	p.mu.Lock()
	defer p.mu.Unlock()
	out := map[string]float64{}
	for k, v := range p.spans {
		out[k] = v.Seconds()
	}
	return out
}

func (p *Profiler) DumpJSON(path string) error {
	b, _ := json.MarshalIndent(p.Report(), "", "  ")
	return os.WriteFile(path, b, 0o644)
}
