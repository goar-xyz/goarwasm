package textualui

import (
	"sync"
	"time"
)

// QuitConfirmKey identifies which quit chord is awaiting confirmation.
type QuitConfirmKey string

const (
	QuitCtrlC QuitConfirmKey = "Ctrl+C"
	QuitCtrlD QuitConfirmKey = "Ctrl+D"
)

// QuitConfirmDelay is the confirmation window (Python QUIT_CONFIRM_DELAY).
const QuitConfirmDelay = time.Second

// QuitManager requires a double quit key within a window (Python QuitManager).
type QuitManager struct {
	mu          sync.Mutex
	confirmTime time.Time
	confirmKey  QuitConfirmKey
	Window      time.Duration
	OnPrompt    func(message string)
	OnRestore   func()
	timerCancel chan struct{}
}

// NewQuitManager creates a quit manager with the default delay window.
func NewQuitManager() *QuitManager {
	return &QuitManager{Window: QuitConfirmDelay}
}

// ConfirmKey returns the key currently awaiting confirmation, or "".
func (q *QuitManager) ConfirmKey() QuitConfirmKey {
	q.mu.Lock()
	defer q.mu.Unlock()
	return q.confirmKey
}

// IsConfirmed reports whether key was already requested within the window.
func (q *QuitManager) IsConfirmed(key QuitConfirmKey) bool {
	q.mu.Lock()
	defer q.mu.Unlock()
	if q.confirmTime.IsZero() || q.confirmKey != key {
		return false
	}
	return time.Since(q.confirmTime) < q.Window
}

// RequestConfirmation arms the double-press window and shows a prompt.
func (q *QuitManager) RequestConfirmation(key QuitConfirmKey, extra string) {
	q.mu.Lock()
	if q.timerCancel != nil {
		close(q.timerCancel)
		q.timerCancel = nil
	}
	q.confirmTime = time.Now()
	q.confirmKey = key
	cancel := make(chan struct{})
	q.timerCancel = cancel
	window := q.Window
	if window <= 0 {
		window = QuitConfirmDelay
	}
	onPrompt := q.OnPrompt
	q.mu.Unlock()

	prompt := "Press " + string(key) + " again to quit"
	if extra != "" {
		prompt = prompt + " (" + extra + ")"
	}
	if onPrompt != nil {
		onPrompt(prompt)
	}
	go func() {
		t := time.NewTimer(window)
		defer t.Stop()
		select {
		case <-t.C:
			q.CancelConfirmation()
		case <-cancel:
		}
	}()
}

// CancelConfirmation clears the pending confirmation.
func (q *QuitManager) CancelConfirmation() {
	q.mu.Lock()
	if q.confirmTime.IsZero() && q.confirmKey == "" {
		q.mu.Unlock()
		return
	}
	q.confirmTime = time.Time{}
	q.confirmKey = ""
	if q.timerCancel != nil {
		// already closed by timer path sometimes; ignore
		select {
		case <-q.timerCancel:
		default:
			close(q.timerCancel)
		}
		q.timerCancel = nil
	}
	onRestore := q.OnRestore
	q.mu.Unlock()
	if onRestore != nil {
		onRestore()
	}
}

// Hit is a compat helper: returns true on second press within Window.
func (q *QuitManager) Hit() bool {
	if q.IsConfirmed(QuitCtrlC) {
		return true
	}
	q.RequestConfirmation(QuitCtrlC, "")
	return false
}

// HitKey is Hit for an explicit key.
func (q *QuitManager) HitKey(key QuitConfirmKey) bool {
	if q.IsConfirmed(key) {
		return true
	}
	q.RequestConfirmation(key, "")
	return false
}
