//go:build !(js && wasm)

package textualui

import (
	"context"
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"sort"
	"strings"
	"time"

	tea "github.com/charmbracelet/bubbletea"

	"github.com/goarxyz/goar/internal/core/config"
	"github.com/goarxyz/goar/internal/core/paths"
	"github.com/goarxyz/goar/internal/core/types"
)

type setupFinishedMsg struct{ err error }

type pluginEntry struct {
	Name string
	Path string
}

func (a *App) ensureLoopRunner() {
	if a.LoopRunner != nil {
		return
	}
	if a.Runtime != nil && a.Runtime.SessionLogger != nil {
		a.LoopRunner = NewScheduledLoopRunner(a.Runtime.SessionLogger)
	} else {
		a.LoopRunner = NewScheduledLoopRunner(nil)
	}
	a.LoopRunner.CanFire = func() bool { return !a.Busy }
	a.LoopRunner.OnFire = func(prompt string) {
		if a.Queue != nil {
			a.Queue.Enqueue(prompt)
		}
	}
	a.LoopRunner.Start(context.Background())
}

func (a App) launchSetupFlow() (tea.Model, tea.Cmd) {
	bin, err := os.Executable()
	if err != nil || bin == "" {
		bin = "goar"
	}
	c := exec.Command(bin, "--setup")
	c.Env = append(os.Environ(), "GOAR_FROM_TUI=1")
	a.Status = "launching setup…"
	return a, tea.ExecProcess(c, func(err error) tea.Msg {
		return setupFinishedMsg{err: err}
	})
}

func (a App) onSetupFinished(msg setupFinishedMsg) (tea.Model, tea.Cmd) {
	if msg.err != nil {
		a.Status = "setup ended: " + msg.err.Error()
		return a, nil
	}
	cfg, err := config.Load()
	if err != nil {
		a.Status = "setup done, reload failed: " + err.Error()
		return a, nil
	}
	a.Cfg = cfg
	a.reloadConfig()
	a.Status = "setup complete — config reloaded"
	return a, nil
}

func (a *App) showVoiceSettings() string {
	if !voiceAvailable() {
		return "Voice input disabled (no microphone pipeline). Paste text as an alternative, or set GOAR_VOICE=1 when a mic pipeline is available. /voice is hidden from completion while unavailable."
	}
	return "Voice settings: microphone pipeline enabled (GOAR_VOICE). Use your OS dictation / mic tooling; in-TUI capture is experimental."
}

func (a *App) showDataRetention() string {
	home := paths.Home()
	targets := []struct {
		Label string
		Path  string
	}{
		{"AGENT_HOME", home},
		{"sessions", paths.SessionLogDir()},
		{"logs", paths.LogDir()},
		{"history", paths.HistoryFile()},
		{"plugins", paths.PluginsDir()},
		{"skills", paths.SkillsDir()},
	}
	var b strings.Builder
	b.WriteString("Local-first data retention (no remote policy)\n")
	for _, t := range targets {
		size, note := dirSizeNote(t.Path)
		fmt.Fprintf(&b, "  %-10s %s  %s\n", t.Label, t.Path, size)
		if note != "" {
			fmt.Fprintf(&b, "             (%s)\n", note)
		}
	}
	return strings.TrimRight(b.String(), "\n")
}

func dirSizeNote(p string) (string, string) {
	info, err := os.Stat(p)
	if err != nil {
		if os.IsNotExist(err) {
			return "missing", ""
		}
		return "?", err.Error()
	}
	if !info.IsDir() {
		return formatBytes(info.Size()), "file"
	}
	var total int64
	var files int
	_ = filepath.Walk(p, func(_ string, fi os.FileInfo, err error) error {
		if err != nil || fi == nil {
			return nil
		}
		if !fi.IsDir() {
			total += fi.Size()
			files++
		}
		return nil
	})
	return fmt.Sprintf("%s / %d files", formatBytes(total), files), "dir"
}

func formatBytes(n int64) string {
	const (
		kb = 1024
		mb = kb * 1024
		gb = mb * 1024
	)
	switch {
	case n >= gb:
		return fmt.Sprintf("%.1fG", float64(n)/float64(gb))
	case n >= mb:
		return fmt.Sprintf("%.1fM", float64(n)/float64(mb))
	case n >= kb:
		return fmt.Sprintf("%.1fK", float64(n)/float64(kb))
	default:
		return fmt.Sprintf("%dB", n)
	}
}

func (a *App) scanPlugins() []pluginEntry {
	dir := paths.PluginsDir()
	_ = os.MkdirAll(dir, 0o755)
	ents, err := os.ReadDir(dir)
	if err != nil {
		return nil
	}
	var out []pluginEntry
	for _, e := range ents {
		name := e.Name()
		if strings.HasPrefix(name, ".") {
			continue
		}
		// Accept directories or common plugin manifests / shared libs.
		if e.IsDir() || strings.HasSuffix(name, ".so") || strings.HasSuffix(name, ".wasm") ||
			strings.HasSuffix(name, ".json") || strings.HasSuffix(name, ".toml") || strings.HasSuffix(name, ".yaml") || strings.HasSuffix(name, ".yml") {
			out = append(out, pluginEntry{Name: name, Path: filepath.Join(dir, name)})
		}
	}
	sort.Slice(out, func(i, j int) bool { return out[i].Name < out[j].Name })
	a.Plugins = out
	return out
}

func (a *App) showPlugins() string {
	list := a.scanPlugins()
	if len(list) == 0 {
		return fmt.Sprintf("No plugins under %s\nDrop plugin dirs or manifests there, then /reload-plugins.", paths.PluginsDir())
	}
	var b strings.Builder
	fmt.Fprintf(&b, "Plugins (%d) in %s\n", len(list), paths.PluginsDir())
	for _, p := range list {
		fmt.Fprintf(&b, "  • %s\n", p.Name)
	}
	return strings.TrimRight(b.String(), "\n")
}

func (a *App) reloadPlugins() string {
	before := map[string]bool{}
	for _, p := range a.Plugins {
		before[p.Name] = true
	}
	after := a.scanPlugins()
	var added, removed []string
	now := map[string]bool{}
	for _, p := range after {
		now[p.Name] = true
		if !before[p.Name] {
			added = append(added, p.Name)
		}
	}
	for name := range before {
		if !now[name] {
			removed = append(removed, name)
		}
	}
	sort.Strings(added)
	sort.Strings(removed)
	parts := []string{fmt.Sprintf("reloaded plugins (%d pinned)", len(after))}
	if len(added) > 0 {
		parts = append(parts, "added: "+strings.Join(added, ", "))
	}
	if len(removed) > 0 {
		parts = append(parts, "removed: "+strings.Join(removed, ", "))
	}
	if len(added) == 0 && len(removed) == 0 {
		parts = append(parts, "no changes")
	}
	return strings.Join(parts, " · ")
}

func (a *App) pasteImage(args string) string {
	args = strings.TrimSpace(args)
	var (
		data []byte
		ext  string
		src  string
		err  error
	)
	if args != "" {
		path := args
		if strings.HasPrefix(path, "~/") {
			if home, e := os.UserHomeDir(); e == nil {
				path = filepath.Join(home, path[2:])
			}
		}
		data, err = os.ReadFile(path)
		if err != nil {
			return "paste-image: " + err.Error()
		}
		ext = strings.ToLower(filepath.Ext(path))
		if ext == "" {
			ext = ".png"
		}
		src = path
	} else {
		data, ext, err = readClipboardImage()
		if err != nil {
			return "paste-image: " + err.Error()
		}
		src = "clipboard"
	}
	dir := filepath.Join(paths.Home(), "tmp", "paste-images")
	if err := os.MkdirAll(dir, 0o755); err != nil {
		return "paste-image: " + err.Error()
	}
	name := fmt.Sprintf("paste-%d%s", time.Now().UnixNano(), ext)
	out := filepath.Join(dir, name)
	if err := os.WriteFile(out, data, 0o644); err != nil {
		return "paste-image: " + err.Error()
	}
	// Attach path into the input so the user can submit with context.
	cur := strings.TrimSpace(a.Input.Value())
	attach := fmt.Sprintf("[image: %s]", out)
	if cur == "" {
		a.Input.SetValue(attach + " ")
	} else {
		a.Input.SetValue(cur + "\n" + attach + " ")
	}
	return fmt.Sprintf("attached image from %s → %s (%s)", src, out, formatBytes(int64(len(data))))
}

func (a *App) runRetryReal(args string) (tea.Model, tea.Cmd) {
	extra := strings.TrimSpace(args)
	if a.Busy {
		a.Status = "retry: agent is still running"
		return a, nil
	}
	// Prefer re-submitting the last user message; append extra instructions when given.
	lastUser := ""
	for i := len(a.Messages) - 1; i >= 0; i-- {
		m := a.Messages[i]
		if m.Role == types.RoleUser && m.Content != nil {
			lastUser = *m.Content
			break
		}
	}
	prompt := lastUser
	if extra != "" {
		if prompt == "" {
			prompt = extra
		} else {
			prompt = prompt + "\n\n[retry] " + extra
		}
	}
	if prompt == "" {
		a.Status = "retry: no prior user turn to continue — pass instructions: /retry <text>"
		return a, nil
	}
	a.Status = "retrying last turn"
	return a.handleUserMessage(prompt)
}

func (a *App) branchSessionReal() string {
	if a.Runtime == nil {
		return "branch: no runtime"
	}
	forked, err := a.Runtime.Fork(context.Background(), "")
	if err != nil {
		return "branch: " + err.Error()
	}
	oldID := a.Runtime.SessionID
	a.Runtime = forked
	a.Messages = append([]types.LLMMessage{}, forked.Messages...)
	a.resumeHistoryFromMessages()
	a.refreshViewport()
	return fmt.Sprintf("branched session %s → %s (parent %s) — use /resume to switch back", shortID(oldID), shortID(forked.SessionID), shortID(forked.ParentSessionID))
}

func shortID(id string) string {
	if id == "" {
		return "(none)"
	}
	if len(id) <= 10 {
		return id
	}
	return id[:10]
}

func (a *App) runLoopCommandReal(args string) string {
	a.ensureLoopRunner()
	res := a.LoopRunner.HandleCommand(args)
	return res.Message
}

func (a App) mountAssistantStatus(text string) App {
	msg := types.NewMessage(types.RoleAssistant, text)
	a.Messages = append(a.Messages, msg)
	if a.Runtime != nil {
		a.Runtime.Messages = append(a.Runtime.Messages, msg)
	}
	a.refreshViewport()
	return a
}

func voiceAvailable() bool {
	v := strings.TrimSpace(strings.ToLower(os.Getenv("GOAR_VOICE")))
	return v == "1" || v == "true" || v == "yes"
}

func readClipboardImage() (data []byte, ext string, err error) {
	try := func(name string, args ...string) ([]byte, error) {
		out, e := exec.Command(name, args...).Output()
		if e != nil {
			return nil, e
		}
		if len(out) == 0 {
			return nil, fmt.Errorf("clipboard image empty")
		}
		return out, nil
	}
	has := func(name string) bool {
		_, e := exec.LookPath(name)
		return e == nil
	}
	if has("wl-paste") {
		for _, mime := range []struct{ t, ext string }{
			{"image/png", ".png"}, {"image/jpeg", ".jpg"}, {"image/webp", ".webp"},
		} {
			if out, e := try("wl-paste", "--type", mime.t); e == nil {
				return out, mime.ext, nil
			}
		}
	}
	if has("xclip") {
		for _, mime := range []struct{ t, ext string }{
			{"image/png", ".png"}, {"image/jpeg", ".jpg"},
		} {
			if out, e := try("xclip", "-selection", "clipboard", "-t", mime.t, "-o"); e == nil {
				return out, mime.ext, nil
			}
		}
	}
	if has("pngpaste") {
		f, e := os.CreateTemp("", "goar-clip-*.png")
		if e == nil {
			tmp := f.Name()
			_ = f.Close()
			_ = os.Remove(tmp)
			if e2 := exec.Command("pngpaste", tmp).Run(); e2 == nil {
				b, e3 := os.ReadFile(tmp)
				_ = os.Remove(tmp)
				if e3 == nil && len(b) > 0 {
					return b, ".png", nil
				}
			}
		}
	}
	return nil, "", fmt.Errorf("no clipboard image available (try /paste-image /path/to/image.png)")
}
