//go:build !(js && wasm)

package panels

import (
	"fmt"
	"strings"

	tea "github.com/charmbracelet/bubbletea"
	"github.com/charmbracelet/lipgloss"
)

type authOptionID string

const (
	authOpenBrowser authOptionID = "open_browser"
	authRefresh     authOptionID = "refresh"
	authClose       authOptionID = "close"
)

// ConnectorAuthResult is emitted when the panel closes.
type ConnectorAuthResult struct {
	ConnectorName string
	OpenedBrowser bool
	Refreshed     bool
	AuthURL       string
}

// ConnectorAuthPanel guides OAuth / connector authentication.
// Port of goar.cli.textual_ui.panels.connector_auth_panel.ConnectorAuthPanel.
type ConnectorAuthPanel struct {
	ConnectorName string
	AuthURL       string
	Status        string
	Error         string
	Selected      int
	Done          bool
	Result        ConnectorAuthResult
	Refreshing    bool
	Width         int
	options       []struct {
		id    authOptionID
		label string
	}
}

// NewConnectorAuthPanel constructs the panel.
func NewConnectorAuthPanel(name, authURL string) ConnectorAuthPanel {
	p := ConnectorAuthPanel{
		ConnectorName: name,
		AuthURL:       authURL,
		Status:        "Waiting for authentication…",
	}
	p.options = []struct {
		id    authOptionID
		label string
	}{
		{authOpenBrowser, "Open browser to authenticate"},
		{authRefresh, "I've authenticated — refresh connector"},
		{authClose, "Close"},
	}
	return p
}

func (m ConnectorAuthPanel) Init() tea.Cmd { return nil }

func (m *ConnectorAuthPanel) onAuthURLFetched(url string, err error) {
	if err != nil {
		m.Error = err.Error()
		m.Status = "Failed to fetch auth URL"
		return
	}
	m.AuthURL = url
	m.Status = "Auth URL ready"
	m.Error = ""
}

func (m *ConnectorAuthPanel) onConnectorRefreshed(ok bool, err error) {
	m.Refreshing = false
	if err != nil {
		m.Error = err.Error()
		m.Status = "Refresh failed"
		return
	}
	if ok {
		m.Status = "Connector refreshed"
		m.Result = ConnectorAuthResult{ConnectorName: m.ConnectorName, Refreshed: true, AuthURL: m.AuthURL}
		m.Done = true
	} else {
		m.Status = "Still not connected — try again after signing in"
	}
}

func (m ConnectorAuthPanel) Update(msg tea.Msg) (tea.Model, tea.Cmd) {
	switch msg := msg.(type) {
	case tea.WindowSizeMsg:
		m.Width = msg.Width
	case tea.KeyMsg:
		switch msg.String() {
		case "up", "k":
			if m.Selected > 0 {
				m.Selected--
			}
		case "down", "j":
			if m.Selected < len(m.options)-1 {
				m.Selected++
			}
		case "enter":
			opt := m.options[m.Selected]
			switch opt.id {
			case authOpenBrowser:
				m.Result = ConnectorAuthResult{ConnectorName: m.ConnectorName, OpenedBrowser: true, AuthURL: m.AuthURL}
				m.Status = "Opened browser — complete sign-in, then choose refresh"
			case authRefresh:
				m.Refreshing = true
				m.Status = "Refreshing connector…"
				// caller should kick off refresh; panel marks intent
				m.Result = ConnectorAuthResult{ConnectorName: m.ConnectorName, Refreshed: true, AuthURL: m.AuthURL}
			case authClose:
				m.Result = ConnectorAuthResult{ConnectorName: m.ConnectorName, AuthURL: m.AuthURL}
				m.Done = true
			}
		case "r":
			m.Refreshing = true
			m.Status = "Refreshing connector…"
			m.Result = ConnectorAuthResult{ConnectorName: m.ConnectorName, Refreshed: true, AuthURL: m.AuthURL}
		case "esc", "backspace", "q":
			m.Result = ConnectorAuthResult{ConnectorName: m.ConnectorName, AuthURL: m.AuthURL}
			m.Done = true
		}
	}
	return m, nil
}

func (m ConnectorAuthPanel) View() string {
	title := lipgloss.NewStyle().Bold(true)
	sel := lipgloss.NewStyle().Foreground(lipgloss.Color("12")).Bold(true)
	muted := lipgloss.NewStyle().Faint(true)
	errStyle := lipgloss.NewStyle().Foreground(lipgloss.Color("9"))
	var b strings.Builder
	b.WriteString(title.Render(fmt.Sprintf("Authenticate: %s", m.ConnectorName)))
	b.WriteString("\n\n")
	if m.AuthURL != "" {
		b.WriteString(muted.Render(m.AuthURL) + "\n\n")
	}
	b.WriteString(m.Status + "\n")
	if m.Error != "" {
		b.WriteString(errStyle.Render(m.Error) + "\n")
	}
	b.WriteString("\n")
	for i, opt := range m.options {
		if i == m.Selected {
			b.WriteString(sel.Render("› "+opt.label) + "\n")
		} else {
			b.WriteString("  " + opt.label + "\n")
		}
	}
	b.WriteString("\n")
	b.WriteString(muted.Render("↑↓ navigate  Enter select  r refresh  Esc close"))
	return b.String()
}
