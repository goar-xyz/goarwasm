//go:build !(js && wasm)

package panels

import (
	"strings"
	"testing"
	"time"

	tea "github.com/charmbracelet/bubbletea"

	"github.com/goarxyz/goar/internal/core/tools"
)

func TestApprovalPanelAllowOnceAfterGrace(t *testing.T) {
	m := NewApprovalPanel("bash", map[string]any{"command": "echo hi"}, "echo hi", []tools.RequiredPermission{{
		Scope: tools.ScopeCommandPattern,
		Label: "execute",
	}})
	if m.Done {
		t.Fatal("expected not done at mount")
	}
	if !m.IsWithinGracePeriod() {
		t.Fatal("expected within grace period immediately after mount")
	}

	// Enter during grace must be ignored.
	updated, _ := m.Update(tea.KeyMsg{Type: tea.KeyEnter})
	m = updated.(ApprovalPanel)
	if m.Done {
		t.Fatal("enter during grace period should not select")
	}

	// Expire grace.
	m.mountTime = time.Now().Add(-approvalInputGracePeriod - time.Millisecond)

	view := m.View()
	if !strings.Contains(view, "Permission for the bash tool") {
		t.Fatalf("view missing title: %q", view)
	}
	if !strings.Contains(view, "Allow once") || !strings.Contains(view, "Deny") {
		t.Fatalf("view missing options: %q", view)
	}

	updated, _ = m.Update(tea.KeyMsg{Type: tea.KeyRunes, Runes: []rune{'y'}})
	m = updated.(ApprovalPanel)
	if !m.Done {
		t.Fatal("expected done after y")
	}
	if m.Result.Outcome != ApprovalOnce {
		t.Fatalf("outcome=%v want ApprovalOnce", m.Result.Outcome)
	}
	if m.Result.ToolName != "bash" {
		t.Fatalf("tool=%q", m.Result.ToolName)
	}
	if !m.Allowed() {
		t.Fatal("Allowed() should be true for ApprovalOnce")
	}
}

func TestApprovalPanelDeny(t *testing.T) {
	m := NewApprovalPanel("write_file", map[string]any{"path": "/tmp/x"}, "write /tmp/x", nil)
	m.mountTime = time.Now().Add(-time.Second)
	updated, _ := m.Update(tea.KeyMsg{Type: tea.KeyRunes, Runes: []rune{'n'}})
	m = updated.(ApprovalPanel)
	if !m.Done || m.Result.Outcome != ApprovalDenied {
		t.Fatalf("done=%v outcome=%v", m.Done, m.Result.Outcome)
	}
	if m.Allowed() {
		t.Fatal("Allowed() should be false when denied")
	}
}

func TestApprovalPanelNavigateAndEnter(t *testing.T) {
	m := NewApprovalPanel("read_file", nil, "", nil)
	m.mountTime = time.Now().Add(-time.Second)
	updated, _ := m.Update(tea.KeyMsg{Type: tea.KeyDown})
	m = updated.(ApprovalPanel)
	if m.Selected != 1 {
		t.Fatalf("selected=%d after down", m.Selected)
	}
	updated, _ = m.Update(tea.KeyMsg{Type: tea.KeyEnter})
	m = updated.(ApprovalPanel)
	if !m.Done || m.Result.Outcome != ApprovalSession {
		t.Fatalf("done=%v outcome=%v want session", m.Done, m.Result.Outcome)
	}
}
