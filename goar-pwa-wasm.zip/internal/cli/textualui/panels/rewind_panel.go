//go:build !(js && wasm)

package panels

import (
	"fmt"
	"strings"

	tea "github.com/charmbracelet/bubbletea"
	"github.com/charmbracelet/lipgloss"
)

type rewindAction string

const (
	rewindWithRestore    rewindAction = "with_restore"
	rewindWithoutRestore rewindAction = "without_restore"
	rewindCancel         rewindAction = "cancel"
)

// RewindOutcome describes the chosen rewind action.
type RewindOutcome int

const (
	RewindOutcomeCancel RewindOutcome = iota
	RewindOutcomeWithRestore
	RewindOutcomeWithoutRestore
)

// RewindPanel confirms rewinding conversation (and optionally files).
// Port of goar.cli.textual_ui.panels.rewind_panel.RewindPanel.
type RewindPanel struct {
	MessagePreview string
	HasFileChanges bool
	Selected       int
	Done           bool
	Outcome        RewindOutcome
	Width          int
	options        []rewindOption
}

type rewindOption struct {
	Label  string
	Action rewindAction
}

// NewRewindPanel constructs the panel.
func NewRewindPanel(preview string, hasFileChanges bool) RewindPanel {
	p := RewindPanel{MessagePreview: preview, HasFileChanges: hasFileChanges}
	p.buildOptions()
	return p
}

func (m *RewindPanel) buildOptions() {
	m.options = nil
	if m.HasFileChanges {
		m.options = append(m.options,
			rewindOption{"Rewind conversation and restore files", rewindWithRestore},
			rewindOption{"Rewind conversation only (keep file changes)", rewindWithoutRestore},
		)
	} else {
		m.options = append(m.options,
			rewindOption{"Rewind conversation to this message", rewindWithoutRestore},
		)
	}
	m.options = append(m.options, rewindOption{"Cancel", rewindCancel})
}

// UpdatePreview refreshes the message preview text.
func (m *RewindPanel) UpdatePreview(preview string) {
	m.MessagePreview = preview
}

func (m RewindPanel) Init() tea.Cmd { return nil }

func (m RewindPanel) optionCount() int { return len(m.options) }

func (m *RewindPanel) handleSelection(idx int) {
	if idx < 0 || idx >= len(m.options) {
		return
	}
	switch m.options[idx].Action {
	case rewindWithRestore:
		m.Outcome = RewindOutcomeWithRestore
	case rewindWithoutRestore:
		m.Outcome = RewindOutcomeWithoutRestore
	default:
		m.Outcome = RewindOutcomeCancel
	}
	m.Done = true
}

func (m RewindPanel) Update(msg tea.Msg) (tea.Model, tea.Cmd) {
	switch msg := msg.(type) {
	case tea.WindowSizeMsg:
		m.Width = msg.Width
	case tea.KeyMsg:
		switch msg.String() {
		case "up", "k":
			if m.Selected > 0 {
				m.Selected--
			}
		case "down", "j":
			if m.Selected < m.optionCount()-1 {
				m.Selected++
			}
		case "enter":
			m.handleSelection(m.Selected)
		case "1":
			m.handleSelection(0)
		case "2":
			if m.optionCount() > 1 {
				m.handleSelection(1)
			}
		case "3":
			if m.optionCount() > 2 {
				m.handleSelection(2)
			}
		case "esc", "q":
			m.Outcome = RewindOutcomeCancel
			m.Done = true
		}
	}
	return m, nil
}

func (m RewindPanel) View() string {
	title := lipgloss.NewStyle().Bold(true)
	sel := lipgloss.NewStyle().Foreground(lipgloss.Color("12")).Bold(true)
	muted := lipgloss.NewStyle().Faint(true)
	var b strings.Builder
	b.WriteString(title.Render("Rewind"))
	b.WriteString("\n\n")
	preview := m.MessagePreview
	if len(preview) > 200 {
		preview = preview[:197] + "…"
	}
	b.WriteString(muted.Render(preview))
	b.WriteString("\n\n")
	for i, opt := range m.options {
		line := fmt.Sprintf("%d. %s", i+1, opt.Label)
		if i == m.Selected {
			b.WriteString(sel.Render("› "+line) + "\n")
		} else {
			b.WriteString("  " + line + "\n")
		}
	}
	b.WriteString("\n")
	b.WriteString(muted.Render("↑↓ navigate  Enter select  Esc cancel"))
	return b.String()
}
