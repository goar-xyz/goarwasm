//go:build !(js && wasm)

package panels

import (
	"strings"
	"time"

	tea "github.com/charmbracelet/bubbletea"
	"github.com/charmbracelet/lipgloss"
)

// ThemePreviewMsg is emitted (debounced) when highlight changes.
type ThemePreviewMsg struct{ Theme string }

// ThemePicker selects a UI theme with live preview.
// Port of goar.cli.textual_ui.panels.theme_picker_panel.ThemePickerPanel.
type ThemePicker struct {
	Themes         []string
	Index          int
	Done           bool
	Choice         string
	Cancelled      bool
	OriginalTheme  string
	PreviewTheme   string
	pendingPreview string
	Width          int
}

// NewThemePicker constructs the picker.
func NewThemePicker(themes []string, current string) ThemePicker {
	idx := 0
	for i, t := range themes {
		if t == current {
			idx = i
			break
		}
	}
	return ThemePicker{Themes: themes, Index: idx, OriginalTheme: current, PreviewTheme: current}
}

func (m ThemePicker) Init() tea.Cmd { return nil }

type themePreviewTick struct{ theme string }

func (m ThemePicker) Update(msg tea.Msg) (tea.Model, tea.Cmd) {
	switch msg := msg.(type) {
	case tea.WindowSizeMsg:
		m.Width = msg.Width
	case themePreviewTick:
		if msg.theme == m.pendingPreview {
			m.PreviewTheme = msg.theme
			return m, func() tea.Msg { return ThemePreviewMsg{Theme: msg.theme} }
		}
	case tea.KeyMsg:
		switch msg.String() {
		case "up", "k":
			if m.Index > 0 {
				m.Index--
				m.pendingPreview = m.Themes[m.Index]
				theme := m.pendingPreview
				return m, tea.Tick(80*time.Millisecond, func(t time.Time) tea.Msg {
					return themePreviewTick{theme: theme}
				})
			}
		case "down", "j":
			if m.Index < len(m.Themes)-1 {
				m.Index++
				m.pendingPreview = m.Themes[m.Index]
				theme := m.pendingPreview
				return m, tea.Tick(80*time.Millisecond, func(t time.Time) tea.Msg {
					return themePreviewTick{theme: theme}
				})
			}
		case "enter":
			if len(m.Themes) > 0 {
				m.Choice = m.Themes[m.Index]
				m.Done = true
			}
		case "esc", "q":
			m.Cancelled = true
			m.Choice = m.OriginalTheme
			m.Done = true
		}
	}
	return m, nil
}

func (m ThemePicker) View() string {
	title := lipgloss.NewStyle().Bold(true)
	sel := lipgloss.NewStyle().Foreground(lipgloss.Color("12")).Bold(true)
	muted := lipgloss.NewStyle().Faint(true)
	var b strings.Builder
	b.WriteString(title.Render("Select theme"))
	b.WriteString("\n\n")
	for i, t := range m.Themes {
		line := t
		if t == m.OriginalTheme {
			line += "  (current)"
		}
		if i == m.Index {
			b.WriteString(sel.Render("› "+line) + "\n")
		} else {
			b.WriteString("  " + line + "\n")
		}
	}
	b.WriteString("\n")
	b.WriteString(muted.Render("↑↓ preview  Enter confirm  Esc cancel"))
	return b.String()
}
