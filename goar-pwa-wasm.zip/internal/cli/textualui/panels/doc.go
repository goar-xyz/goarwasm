// Package panels implements modal TUI panels (Bubble Tea models).
package panels
