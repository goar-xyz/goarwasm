//go:build js && wasm

// Package panels compiles under WASM as a library stub.
// Interactive Bubble Tea panels are native-only; the PWA replaces this UI surface.
package panels

// Stub keeps the package non-empty for js/wasm builds.
const Stub = true
