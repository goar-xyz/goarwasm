//go:build !(js && wasm)

package panels

import (
	"fmt"
	"strings"

	tea "github.com/charmbracelet/bubbletea"
	"github.com/charmbracelet/lipgloss"

	"github.com/goarxyz/goar/internal/core/config"
)

// ConfigOptionKind classifies config panel rows.
type ConfigOptionKind string

const (
	ConfigActionModel    ConfigOptionKind = "action:model"
	ConfigActionThinking ConfigOptionKind = "action:thinking"
	ConfigTogglePrefix   ConfigOptionKind = "toggle:"
)

// IsToggle reports whether option id is a toggle.
func (k ConfigOptionKind) IsToggle() bool {
	return strings.HasPrefix(string(k), string(ConfigTogglePrefix))
}

// ToggleKey returns the config key for a toggle option id.
func (k ConfigOptionKind) ToggleKey() string {
	return strings.TrimPrefix(string(k), string(ConfigTogglePrefix))
}

// ToggleOptionID builds a toggle option id.
func ToggleOptionID(key string) ConfigOptionKind {
	return ConfigOptionKind(string(ConfigTogglePrefix) + key)
}

// ConfigClosedResult is emitted when the panel closes.
type ConfigClosedResult struct {
	Changes map[string]any
	OpenModel    bool
	OpenThinking bool
}

// ConfigPanel edits high-level settings.
// Port of goar.cli.textual_ui.panels.config_panel.ConfigPanel.
type ConfigPanel struct {
	Cfg      *config.Config
	Options  []configOption
	Index    int
	Done     bool
	Changes  map[string]any
	OpenModel    bool
	OpenThinking bool
	Width    int
}

type configOption struct {
	ID    ConfigOptionKind
	Label string
}

// NewConfigPanel builds the panel from config.
func NewConfigPanel(cfg *config.Config) ConfigPanel {
	p := ConfigPanel{Cfg: cfg, Changes: map[string]any{}}
	p.refreshOptions()
	return p
}

func (m *ConfigPanel) getCurrentModel() string {
	if m.Cfg == nil {
		return ""
	}
	return m.Cfg.ActiveModel
}

func (m *ConfigPanel) getToggleValue(key string) string {
	if m.Cfg == nil {
		return "off"
	}
	switch key {
	case "bypass_tool_permissions":
		if m.Cfg.BypassToolPermissions {
			return "on"
		}
		return "off"
	case "include_project_context":
		if m.Cfg.IncludeProjectContext {
			return "on"
		}
		return "off"
	case "session_logging":
		if m.Cfg.SessionLogging.Enabled {
			return "on"
		}
		return "off"
	default:
		return "off"
	}
}

func (m *ConfigPanel) modelPrompt() string {
	return fmt.Sprintf("Model: %s", m.getCurrentModel())
}

func (m *ConfigPanel) thinkingPrompt() string {
	// thinking lives on model config; show placeholder
	level := "off"
	if m.Cfg != nil {
		for _, mod := range m.Cfg.Models {
			if mod.Alias == m.Cfg.ActiveModel || mod.Name == m.Cfg.ActiveModel {
				if mod.Thinking != "" {
					level = mod.Thinking
				}
				break
			}
		}
	}
	return fmt.Sprintf("Thinking: %s", level)
}

func (m *ConfigPanel) togglePrompt(key, label string) string {
	return fmt.Sprintf("%s: %s", label, m.getToggleValue(key))
}

func (m *ConfigPanel) refreshOptions() {
	m.Options = []configOption{
		{ID: ConfigActionModel, Label: m.modelPrompt()},
		{ID: ConfigActionThinking, Label: m.thinkingPrompt()},
		{ID: ToggleOptionID("bypass_tool_permissions"), Label: m.togglePrompt("bypass_tool_permissions", "Bypass tool permissions")},
		{ID: ToggleOptionID("include_project_context"), Label: m.togglePrompt("include_project_context", "Include project context")},
		{ID: ToggleOptionID("session_logging"), Label: m.togglePrompt("session_logging", "Session logging")},
	}
}

func (m *ConfigPanel) applyToggle(key string) {
	if m.Cfg == nil {
		return
	}
	switch key {
	case "bypass_tool_permissions":
		m.Cfg.BypassToolPermissions = !m.Cfg.BypassToolPermissions
		m.Changes[key] = m.Cfg.BypassToolPermissions
	case "include_project_context":
		m.Cfg.IncludeProjectContext = !m.Cfg.IncludeProjectContext
		m.Changes[key] = m.Cfg.IncludeProjectContext
	case "session_logging":
		m.Cfg.SessionLogging.Enabled = !m.Cfg.SessionLogging.Enabled
		m.Changes[key] = m.Cfg.SessionLogging.Enabled
	}
	m.refreshOptions()
}

func (m ConfigPanel) Init() tea.Cmd { return nil }

func (m ConfigPanel) Update(msg tea.Msg) (tea.Model, tea.Cmd) {
	switch msg := msg.(type) {
	case tea.WindowSizeMsg:
		m.Width = msg.Width
	case tea.KeyMsg:
		switch msg.String() {
		case "up", "k":
			if m.Index > 0 {
				m.Index--
			}
		case "down", "j":
			if m.Index < len(m.Options)-1 {
				m.Index++
			}
		case "enter", " ":
			if m.Index < 0 || m.Index >= len(m.Options) {
				break
			}
			opt := m.Options[m.Index]
			switch {
			case opt.ID == ConfigActionModel:
				m.OpenModel = true
				m.Done = true
			case opt.ID == ConfigActionThinking:
				m.OpenThinking = true
				m.Done = true
			case opt.ID.IsToggle():
				m.applyToggle(opt.ID.ToggleKey())
			}
		case "esc", "q":
			m.Done = true
		}
	}
	return m, nil
}

func (m ConfigPanel) View() string {
	title := lipgloss.NewStyle().Bold(true)
	sel := lipgloss.NewStyle().Foreground(lipgloss.Color("12")).Bold(true)
	muted := lipgloss.NewStyle().Faint(true)
	var b strings.Builder
	b.WriteString(title.Render("Settings"))
	b.WriteString("\n\n")
	for i, opt := range m.Options {
		if i == m.Index {
			b.WriteString(sel.Render("› "+opt.Label) + "\n")
		} else {
			b.WriteString("  " + opt.Label + "\n")
		}
	}
	b.WriteString("\n")
	b.WriteString(muted.Render("↑↓ navigate  Enter/Space toggle or open  Esc close"))
	return b.String()
}
