//go:build !(js && wasm)

package panels

import (
	"fmt"
	"sort"
	"strings"

	tea "github.com/charmbracelet/bubbletea"
	"github.com/charmbracelet/lipgloss"

	"github.com/goarxyz/goar/internal/core/tools/mcp"
)

// MCPSourceKind distinguishes MCP vs connector sources.
type MCPSourceKind string

const (
	MCPSourceMCP       MCPSourceKind = "mcp"
	MCPSourceConnector MCPSourceKind = "connector"
)

// MCPToolIndexEntry is one discovered remote tool.
type MCPToolIndexEntry struct {
	SourceKind MCPSourceKind
	SourceName string
	ToolName   string
	FullName   string
	Disabled   bool
	Desc       string
}

// MCPToolIndex groups tools by source.
type MCPToolIndex struct {
	BySource map[string][]MCPToolIndexEntry
	Order    []string
}

// CollectMCPToolIndex builds an index from an MCP registry.
func CollectMCPToolIndex(reg *mcp.Registry) MCPToolIndex {
	idx := MCPToolIndex{BySource: map[string][]MCPToolIndexEntry{}}
	if reg == nil {
		return idx
	}
	seen := map[string]bool{}
	for _, td := range reg.Tools() {
		e := MCPToolIndexEntry{
			SourceKind: MCPSourceMCP,
			SourceName: td.Server,
			ToolName:   td.Name,
			FullName:   td.FullName,
			Desc:       td.Description,
		}
		idx.BySource[td.Server] = append(idx.BySource[td.Server], e)
		if !seen[td.Server] {
			idx.Order = append(idx.Order, td.Server)
			seen[td.Server] = true
		}
	}
	sort.Strings(idx.Order)
	return idx
}

type mcpViewMode int

const (
	mcpViewSources mcpViewMode = iota
	mcpViewTools
)

// MCPPanelOutcome is emitted when the panel closes or toggles.
type MCPPanelOutcome int

const (
	MCPOutcomeNone MCPPanelOutcome = iota
	MCPOutcomeClosed
	MCPOutcomeToggled
	MCPOutcomeAuthRequested
)

// MCPPanelResult carries panel outcomes.
type MCPPanelResult struct {
	Outcome      MCPPanelOutcome
	SourceName   string
	ToolName     string
	Disabled     bool
	AuthSource   string
}

// MCPPanel browses MCP/connector tools with enable/disable/refresh.
// Port of goar.cli.textual_ui.panels.mcp_panel.MCPPanel.
type MCPPanel struct {
	Registry       *mcp.Registry
	Index          MCPToolIndex
	Mode           mcpViewMode
	SourceIndex    int
	ToolIndex      int
	ActiveSource   string
	Help           string
	Status         string
	Refreshing     bool
	Done           bool
	Result         MCPPanelResult
	DisabledSources map[string]bool
	DisabledTools   map[string]bool
	Width          int
}

// NewMCPPanel creates the panel.
func NewMCPPanel(reg *mcp.Registry) MCPPanel {
	p := MCPPanel{
		Registry:        reg,
		DisabledSources: map[string]bool{},
		DisabledTools:   map[string]bool{},
		Help:            "↑↓ navigate  Enter open  d disable  e enable  r refresh  Esc close",
	}
	p.RefreshIndex()
	return p
}

func (m *MCPPanel) RefreshIndex() {
	m.Index = CollectMCPToolIndex(m.Registry)
	if m.Registry != nil {
		for name, cfg := range m.Registry.Servers() {
			if cfg.Disabled {
				m.DisabledSources[name] = true
			}
			for _, t := range cfg.DisabledTools {
				m.DisabledTools[name+"."+t] = true
			}
		}
	}
}

func (m MCPPanel) Init() tea.Cmd { return nil }

func (m MCPPanel) sources() []string {
	return m.Index.Order
}

func (m MCPPanel) toolsForActive() []MCPToolIndexEntry {
	return m.Index.BySource[m.ActiveSource]
}

func (m *MCPPanel) setHelp(s string) { m.Help = s }

func (m *MCPPanel) listHelpForOption() string {
	if m.Mode == mcpViewSources {
		return "Enter: browse tools · d/e: disable/enable source · r: refresh"
	}
	return "d/e: disable/enable tool · Backspace: back · Esc: close"
}

func (m *MCPPanel) rebuildPreservingScroll() {
	// indices already preserved by design; refresh labels only
	m.RefreshIndex()
}

func (m *MCPPanel) setHighlightedDisabled(disabled bool) {
	if m.Mode == mcpViewSources {
		srcs := m.sources()
		if m.SourceIndex < 0 || m.SourceIndex >= len(srcs) {
			return
		}
		name := srcs[m.SourceIndex]
		m.DisabledSources[name] = disabled
		m.Result = MCPPanelResult{Outcome: MCPOutcomeToggled, SourceName: name, Disabled: disabled}
		if m.Registry != nil {
			if cfg, ok := m.Registry.Server(name); ok {
				cfg.Disabled = disabled
				m.Registry.AddServer(cfg)
			}
		}
		m.Status = fmt.Sprintf("%s %s", name, map[bool]string{true: "disabled", false: "enabled"}[disabled])
		return
	}
	m.setHighlightedToolDisabled(disabled)
}

func (m *MCPPanel) setHighlightedToolDisabled(disabled bool) {
	tools := m.toolsForActive()
	if m.ToolIndex < 0 || m.ToolIndex >= len(tools) {
		return
	}
	t := tools[m.ToolIndex]
	key := t.SourceName + "." + t.ToolName
	m.DisabledTools[key] = disabled
	m.Result = MCPPanelResult{Outcome: MCPOutcomeToggled, SourceName: t.SourceName, ToolName: t.ToolName, Disabled: disabled}
	m.Status = fmt.Sprintf("%s %s", key, map[bool]string{true: "disabled", false: "enabled"}[disabled])
}

func (m MCPPanel) Update(msg tea.Msg) (tea.Model, tea.Cmd) {
	switch msg := msg.(type) {
	case tea.WindowSizeMsg:
		m.Width = msg.Width
	case tea.KeyMsg:
		switch msg.String() {
		case "up", "k":
			if m.Mode == mcpViewSources {
				if m.SourceIndex > 0 {
					m.SourceIndex--
				}
			} else if m.ToolIndex > 0 {
				m.ToolIndex--
			}
			m.setHelp(m.listHelpForOption())
		case "down", "j":
			if m.Mode == mcpViewSources {
				if m.SourceIndex < len(m.sources())-1 {
					m.SourceIndex++
				}
			} else if m.ToolIndex < len(m.toolsForActive())-1 {
				m.ToolIndex++
			}
			m.setHelp(m.listHelpForOption())
		case "enter":
			if m.Mode == mcpViewSources {
				srcs := m.sources()
				if m.SourceIndex >= 0 && m.SourceIndex < len(srcs) {
					m.ActiveSource = srcs[m.SourceIndex]
					m.Mode = mcpViewTools
					m.ToolIndex = 0
					m.setHelp(m.listHelpForOption())
				}
			}
		case "backspace", "left", "h":
			if m.Mode == mcpViewTools {
				m.Mode = mcpViewSources
				m.ActiveSource = ""
				m.setHelp(m.listHelpForOption())
			}
		case "d":
			m.setHighlightedDisabled(true)
		case "e":
			m.setHighlightedDisabled(false)
		case "r":
			m.Refreshing = true
			m.Status = "refreshing…"
			m.rebuildPreservingScroll()
			m.Refreshing = false
			m.Status = "refreshed"
			return m, nil
		case "a":
			// request connector auth for highlighted source
			srcs := m.sources()
			if m.Mode == mcpViewSources && m.SourceIndex >= 0 && m.SourceIndex < len(srcs) {
				m.Result = MCPPanelResult{Outcome: MCPOutcomeAuthRequested, AuthSource: srcs[m.SourceIndex]}
				m.Done = true
			}
		case "esc", "q":
			m.Result = MCPPanelResult{Outcome: MCPOutcomeClosed}
			m.Done = true
		}
	}
	return m, nil
}

func (m MCPPanel) View() string {
	title := lipgloss.NewStyle().Bold(true)
	muted := lipgloss.NewStyle().Faint(true)
	sel := lipgloss.NewStyle().Foreground(lipgloss.Color("12")).Bold(true)
	dis := lipgloss.NewStyle().Foreground(lipgloss.Color("8")).Strikethrough(true)
	var b strings.Builder
	b.WriteString(title.Render("MCP / Connectors"))
	b.WriteString("\n\n")
	if m.Mode == mcpViewSources {
		srcs := m.sources()
		if len(srcs) == 0 {
			b.WriteString(muted.Render("(no MCP servers configured)"))
			b.WriteString("\n")
		}
		for i, name := range srcs {
			tools := m.Index.BySource[name]
			label := fmt.Sprintf("%s (%d tools)", name, len(tools))
			if m.DisabledSources[name] {
				label = dis.Render(label + " [disabled]")
			}
			if i == m.SourceIndex {
				b.WriteString(sel.Render("› "+label) + "\n")
			} else {
				b.WriteString("  " + label + "\n")
			}
		}
	} else {
		b.WriteString(muted.Render("Source: "+m.ActiveSource) + "\n\n")
		tools := m.toolsForActive()
		if len(tools) == 0 {
			b.WriteString(muted.Render("(no tools)") + "\n")
		}
		for i, t := range tools {
			label := t.ToolName
			if t.Desc != "" {
				label += " — " + truncate(t.Desc, 60)
			}
			key := t.SourceName + "." + t.ToolName
			if m.DisabledTools[key] || m.DisabledSources[t.SourceName] {
				label = dis.Render(label + " [disabled]")
			}
			if i == m.ToolIndex {
				b.WriteString(sel.Render("› "+label) + "\n")
			} else {
				b.WriteString("  " + label + "\n")
			}
		}
	}
	b.WriteString("\n")
	if m.Status != "" {
		b.WriteString(muted.Render(m.Status) + "\n")
	}
	b.WriteString(muted.Render(m.Help))
	return b.String()
}

func truncate(s string, n int) string {
	if len(s) <= n {
		return s
	}
	return s[:n-1] + "…"
}
