//go:build !(js && wasm)

package panels

import (
	"fmt"
	"strings"
	"time"

	tea "github.com/charmbracelet/bubbletea"
	"github.com/charmbracelet/lipgloss"
)

// ResumeSessionInfo describes a resumable session entry.
type ResumeSessionInfo struct {
	ID           string
	Title        string
	Path         string
	UpdatedAt    time.Time
	MessageCount int
	Model        string
	Preview      string
}

// SessionPicker selects a prior session to resume.
// Port of goar.cli.textual_ui.panels.session_picker_panel.SessionPickerPanel.
type SessionPicker struct {
	Sessions  []ResumeSessionInfo
	Index     int
	Done      bool
	Choice    *ResumeSessionInfo
	Cancelled bool
	Width     int
}

// NewSessionPicker constructs the picker.
func NewSessionPicker(sessions []ResumeSessionInfo) SessionPicker {
	return SessionPicker{Sessions: sessions}
}

func formatRelativeTime(t time.Time) string {
	if t.IsZero() {
		return ""
	}
	d := time.Since(t)
	switch {
	case d < time.Minute:
		return "just now"
	case d < time.Hour:
		return fmt.Sprintf("%dm ago", int(d.Minutes()))
	case d < 24*time.Hour:
		return fmt.Sprintf("%dh ago", int(d.Hours()))
	case d < 7*24*time.Hour:
		return fmt.Sprintf("%dd ago", int(d.Hours()/24))
	default:
		return t.Format("2006-01-02")
	}
}

func buildSessionOptionText(s ResumeSessionInfo) string {
	title := s.Title
	if title == "" {
		title = s.ID
	}
	rel := formatRelativeTime(s.UpdatedAt)
	parts := []string{title}
	if rel != "" {
		parts = append(parts, rel)
	}
	if s.MessageCount > 0 {
		parts = append(parts, fmt.Sprintf("%d msgs", s.MessageCount))
	}
	if s.Model != "" {
		parts = append(parts, s.Model)
	}
	line := strings.Join(parts, " · ")
	if s.Preview != "" {
		prev := s.Preview
		if len(prev) > 80 {
			prev = prev[:77] + "…"
		}
		line += "\n    " + prev
	}
	return line
}

func (m SessionPicker) Init() tea.Cmd { return nil }

func (m SessionPicker) Update(msg tea.Msg) (tea.Model, tea.Cmd) {
	switch msg := msg.(type) {
	case tea.WindowSizeMsg:
		m.Width = msg.Width
	case tea.KeyMsg:
		switch msg.String() {
		case "up", "k":
			if m.Index > 0 {
				m.Index--
			}
		case "down", "j":
			if m.Index < len(m.Sessions)-1 {
				m.Index++
			}
		case "enter":
			if len(m.Sessions) > 0 {
				s := m.Sessions[m.Index]
				m.Choice = &s
				m.Done = true
			}
		case "esc", "q":
			m.Cancelled = true
			m.Done = true
		}
	}
	return m, nil
}

func (m SessionPicker) View() string {
	title := lipgloss.NewStyle().Bold(true)
	sel := lipgloss.NewStyle().Foreground(lipgloss.Color("12")).Bold(true)
	muted := lipgloss.NewStyle().Faint(true)
	var b strings.Builder
	b.WriteString(title.Render("Resume session"))
	b.WriteString("\n\n")
	if len(m.Sessions) == 0 {
		b.WriteString(muted.Render("(no sessions found)") + "\n")
	}
	for i, s := range m.Sessions {
		line := buildSessionOptionText(s)
		if i == m.Index {
			b.WriteString(sel.Render("› "+strings.ReplaceAll(line, "\n", "\n  ")) + "\n")
		} else {
			b.WriteString("  " + line + "\n")
		}
	}
	b.WriteString("\n")
	b.WriteString(muted.Render("↑↓ navigate  Enter resume  Esc cancel"))
	return b.String()
}
