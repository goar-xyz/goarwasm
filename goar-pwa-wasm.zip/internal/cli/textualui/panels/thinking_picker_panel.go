//go:build !(js && wasm)

package panels

import (
	"strings"

	tea "github.com/charmbracelet/bubbletea"
	"github.com/charmbracelet/lipgloss"
)

// ThinkingLevels are the supported reasoning effort levels.
var ThinkingLevels = []string{"off", "low", "medium", "high", "xhigh"}

// ThinkingPicker selects a thinking/reasoning level.
// Port of goar.cli.textual_ui.panels.thinking_picker_panel.ThinkingPickerPanel.
type ThinkingPicker struct {
	Levels    []string
	Index     int
	Done      bool
	Choice    string
	Cancelled bool
	Current   string
	Width     int
}

// NewThinkingPicker constructs the picker.
func NewThinkingPicker(current string) ThinkingPicker {
	idx := 0
	for i, l := range ThinkingLevels {
		if l == current {
			idx = i
			break
		}
	}
	return ThinkingPicker{Levels: append([]string{}, ThinkingLevels...), Index: idx, Current: current}
}

func (m ThinkingPicker) Init() tea.Cmd { return nil }

func (m ThinkingPicker) Update(msg tea.Msg) (tea.Model, tea.Cmd) {
	switch msg := msg.(type) {
	case tea.WindowSizeMsg:
		m.Width = msg.Width
	case tea.KeyMsg:
		switch msg.String() {
		case "up", "k":
			if m.Index > 0 {
				m.Index--
			}
		case "down", "j":
			if m.Index < len(m.Levels)-1 {
				m.Index++
			}
		case "enter":
			m.Choice = m.Levels[m.Index]
			m.Done = true
		case "esc", "q":
			m.Cancelled = true
			m.Done = true
		}
	}
	return m, nil
}

func (m ThinkingPicker) View() string {
	title := lipgloss.NewStyle().Bold(true)
	sel := lipgloss.NewStyle().Foreground(lipgloss.Color("12")).Bold(true)
	muted := lipgloss.NewStyle().Faint(true)
	var b strings.Builder
	b.WriteString(title.Render("Thinking level"))
	b.WriteString("\n\n")
	for i, l := range m.Levels {
		line := l
		if l == m.Current {
			line += "  (current)"
		}
		if i == m.Index {
			b.WriteString(sel.Render("› "+line) + "\n")
		} else {
			b.WriteString("  " + line + "\n")
		}
	}
	b.WriteString("\n")
	b.WriteString(muted.Render("↑↓ navigate  Enter confirm  Esc cancel"))
	return b.String()
}
