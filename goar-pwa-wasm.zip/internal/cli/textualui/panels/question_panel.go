//go:build !(js && wasm)

package panels

import (
	"fmt"
	"strings"
	"time"

	tea "github.com/charmbracelet/bubbletea"
	"github.com/charmbracelet/lipgloss"
)

const questionInputGracePeriod = 500 * time.Millisecond

// Question is one multi-choice question (AskUserQuestion tool).
type Question struct {
	Header      string
	Question    string
	Options     []QuestionOption
	AllowOther  bool
	MultiSelect bool
}

// QuestionOption is a labeled choice.
type QuestionOption struct {
	Label       string
	Description string
}

// QuestionAnswer captures the user's answer for one question.
type QuestionAnswer struct {
	QuestionIndex int
	Selected      []int
	OtherText     string
	UsedOther     bool
}

// QuestionPanel walks the user through one or more questions.
// Port of goar.cli.textual_ui.panels.question_panel.QuestionPanel.
type QuestionPanel struct {
	Questions           []Question
	CurrentQuestionIdx  int
	SelectedOption      int
	SelectedMulti       map[int]map[int]bool
	OtherText           string
	OtherEditing        bool
	Answers             []QuestionAnswer
	Done                bool
	Cancelled           bool
	mountTime           time.Time
	Width               int
	Height              int
}

// NewQuestionPanel builds a panel from questions.
func NewQuestionPanel(questions []Question) QuestionPanel {
	sel := map[int]map[int]bool{}
	for i := range questions {
		sel[i] = map[int]bool{}
	}
	return QuestionPanel{
		Questions:     questions,
		SelectedMulti: sel,
		mountTime:     time.Now(),
	}
}

// NewQuestionPanelSimple is a convenience for a single question with string options.
func NewQuestionPanelSimple(q string, opts []string) QuestionPanel {
	qo := make([]QuestionOption, 0, len(opts))
	for _, o := range opts {
		qo = append(qo, QuestionOption{Label: o})
	}
	return NewQuestionPanel([]Question{{Question: q, Options: qo, AllowOther: true}})
}

func (m QuestionPanel) Init() tea.Cmd { return nil }

func (m QuestionPanel) IsWithinGracePeriod() bool {
	return time.Since(m.mountTime) < questionInputGracePeriod
}

func (m QuestionPanel) current() *Question {
	if m.CurrentQuestionIdx < 0 || m.CurrentQuestionIdx >= len(m.Questions) {
		return nil
	}
	return &m.Questions[m.CurrentQuestionIdx]
}

func (m QuestionPanel) hasOther() bool {
	q := m.current()
	return q != nil && q.AllowOther
}

func (m QuestionPanel) totalOptions() int {
	q := m.current()
	if q == nil {
		return 0
	}
	n := len(q.Options)
	if q.AllowOther {
		n++ // Other
	}
	n++ // Submit / Next
	return n
}

func (m QuestionPanel) otherOptionIdx() int {
	q := m.current()
	if q == nil || !q.AllowOther {
		return -1
	}
	return len(q.Options)
}

func (m QuestionPanel) submitOptionIdx() int {
	q := m.current()
	if q == nil {
		return -1
	}
	n := len(q.Options)
	if q.AllowOther {
		n++
	}
	return n
}

func (m QuestionPanel) isOtherSelected() bool {
	return m.SelectedOption == m.otherOptionIdx()
}

func (m QuestionPanel) isSubmitSelected() bool {
	return m.SelectedOption == m.submitOptionIdx()
}

func (m *QuestionPanel) commitCurrent() {
	q := m.current()
	if q == nil {
		return
	}
	ans := QuestionAnswer{QuestionIndex: m.CurrentQuestionIdx}
	if q.MultiSelect {
		for idx := range m.SelectedMulti[m.CurrentQuestionIdx] {
			if m.SelectedMulti[m.CurrentQuestionIdx][idx] {
				ans.Selected = append(ans.Selected, idx)
			}
		}
	} else if m.SelectedOption < len(q.Options) {
		ans.Selected = []int{m.SelectedOption}
	}
	if m.hasOther() && (m.isOtherSelected() || m.OtherText != "") {
		ans.UsedOther = true
		ans.OtherText = m.OtherText
	}
	// replace existing answer for this index if any
	replaced := false
	for i := range m.Answers {
		if m.Answers[i].QuestionIndex == m.CurrentQuestionIdx {
			m.Answers[i] = ans
			replaced = true
			break
		}
	}
	if !replaced {
		m.Answers = append(m.Answers, ans)
	}
}

func (m *QuestionPanel) advanceOrFinish() {
	m.commitCurrent()
	if m.CurrentQuestionIdx+1 < len(m.Questions) {
		m.CurrentQuestionIdx++
		m.SelectedOption = 0
		m.OtherText = ""
		m.OtherEditing = false
		m.mountTime = time.Now()
		return
	}
	m.Done = true
}

func (m QuestionPanel) Update(msg tea.Msg) (tea.Model, tea.Cmd) {
	switch msg := msg.(type) {
	case tea.WindowSizeMsg:
		m.Width, m.Height = msg.Width, msg.Height
	case tea.KeyMsg:
		if m.OtherEditing {
			switch msg.String() {
			case "enter":
				m.OtherEditing = false
				m.advanceOrFinish()
			case "esc":
				m.OtherEditing = false
			case "backspace":
				if len(m.OtherText) > 0 {
					m.OtherText = m.OtherText[:len(m.OtherText)-1]
				}
			default:
				if len(msg.Runes) > 0 {
					m.OtherText += string(msg.Runes)
				}
			}
			return m, nil
		}
		switch msg.String() {
		case "up", "k":
			if m.SelectedOption > 0 {
				m.SelectedOption--
			}
		case "down", "j":
			if m.SelectedOption < m.totalOptions()-1 {
				m.SelectedOption++
			}
		case "left", "h":
			if m.CurrentQuestionIdx > 0 {
				m.CurrentQuestionIdx--
				m.SelectedOption = 0
			}
		case "right", "l", "tab":
			if m.CurrentQuestionIdx+1 < len(m.Questions) {
				m.commitCurrent()
				m.CurrentQuestionIdx++
				m.SelectedOption = 0
			}
		case " ":
			q := m.current()
			if q != nil && q.MultiSelect && m.SelectedOption < len(q.Options) {
				cur := m.SelectedMulti[m.CurrentQuestionIdx][m.SelectedOption]
				m.SelectedMulti[m.CurrentQuestionIdx][m.SelectedOption] = !cur
			}
		case "enter":
			if m.IsWithinGracePeriod() {
				return m, nil
			}
			if m.isOtherSelected() {
				m.OtherEditing = true
				return m, nil
			}
			if m.isSubmitSelected() || (!m.hasOther() && m.SelectedOption < m.totalOptions()) {
				m.advanceOrFinish()
			} else {
				// selecting a normal option then submit
				q := m.current()
				if q != nil && !q.MultiSelect && m.SelectedOption < len(q.Options) {
					m.advanceOrFinish()
				}
			}
		case "esc":
			m.Cancelled = true
			m.Done = true
		}
	}
	return m, nil
}

// Answer returns a flat string answer for simple single-question panels (compat).
func (m QuestionPanel) Answer() string {
	if len(m.Answers) == 0 {
		return ""
	}
	a := m.Answers[0]
	if a.UsedOther {
		return a.OtherText
	}
	q := m.Questions[0]
	if len(a.Selected) > 0 && a.Selected[0] < len(q.Options) {
		return q.Options[a.Selected[0]].Label
	}
	return ""
}

func (m QuestionPanel) View() string {
	q := m.current()
	if q == nil {
		return "No questions"
	}
	title := lipgloss.NewStyle().Bold(true)
	muted := lipgloss.NewStyle().Faint(true)
	sel := lipgloss.NewStyle().Foreground(lipgloss.Color("12")).Bold(true)
	var b strings.Builder
	if len(m.Questions) > 1 {
		b.WriteString(muted.Render(fmt.Sprintf("Question %d/%d", m.CurrentQuestionIdx+1, len(m.Questions))))
		b.WriteString("\n")
	}
	if q.Header != "" {
		b.WriteString(title.Render(q.Header))
		b.WriteString("\n")
	}
	b.WriteString(title.Render(q.Question))
	b.WriteString("\n\n")
	for i, opt := range q.Options {
		prefix := "  "
		label := opt.Label
		if q.MultiSelect {
			checked := m.SelectedMulti[m.CurrentQuestionIdx][i]
			if checked {
				prefix = "[x] "
			} else {
				prefix = "[ ] "
			}
		}
		line := fmt.Sprintf("%s%s", prefix, label)
		if opt.Description != "" {
			line += muted.Render(" — " + opt.Description)
		}
		if i == m.SelectedOption {
			b.WriteString(sel.Render("› "+line) + "\n")
		} else {
			b.WriteString("  " + line + "\n")
		}
	}
	if m.hasOther() {
		line := "Other"
		if m.OtherText != "" {
			line += ": " + m.OtherText
		}
		if m.isOtherSelected() {
			if m.OtherEditing {
				b.WriteString(sel.Render("› "+line+"▋") + "\n")
			} else {
				b.WriteString(sel.Render("› "+line) + "\n")
			}
		} else {
			b.WriteString("  " + line + "\n")
		}
	}
	submitLabel := "Submit"
	if m.CurrentQuestionIdx+1 < len(m.Questions) {
		submitLabel = "Next"
	}
	if m.isSubmitSelected() {
		b.WriteString(sel.Render("› "+submitLabel) + "\n")
	} else {
		b.WriteString("  " + submitLabel + "\n")
	}
	b.WriteString("\n")
	b.WriteString(muted.Render("↑↓ navigate  Enter select  Esc cancel"))
	return b.String()
}
