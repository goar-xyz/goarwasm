//go:build !(js && wasm)

package panels

import (
	"fmt"
	"strings"

	tea "github.com/charmbracelet/bubbletea"
	"github.com/charmbracelet/lipgloss"

	"github.com/goarxyz/goar/internal/core/config"
)

// ModelPicker selects the active model alias.
// Port of goar.cli.textual_ui.panels.model_picker_panel.ModelPickerPanel.
type ModelPicker struct {
	Models   []config.ModelConfig
	Index    int
	Done     bool
	Choice   string
	Cancelled bool
	Current  string
	Filter   string
	Width    int
}

// NewModelPicker constructs the picker.
func NewModelPicker(models []config.ModelConfig, active string) ModelPicker {
	idx := 0
	for i, m := range models {
		if m.Alias == active || m.Name == active {
			idx = i
			break
		}
	}
	return ModelPicker{Models: models, Index: idx, Current: active}
}

func (m ModelPicker) Init() tea.Cmd { return nil }

func (m ModelPicker) filtered() []config.ModelConfig {
	if m.Filter == "" {
		return m.Models
	}
	f := strings.ToLower(m.Filter)
	var out []config.ModelConfig
	for _, mod := range m.Models {
		hay := strings.ToLower(mod.Alias + " " + mod.Name + " " + mod.Provider)
		if strings.Contains(hay, f) {
			out = append(out, mod)
		}
	}
	return out
}

func (m ModelPicker) Update(msg tea.Msg) (tea.Model, tea.Cmd) {
	switch msg := msg.(type) {
	case tea.WindowSizeMsg:
		m.Width = msg.Width
	case tea.KeyMsg:
		switch msg.String() {
		case "up", "k":
			if m.Index > 0 {
				m.Index--
			}
		case "down", "j":
			flist := m.filtered()
			if m.Index < len(flist)-1 {
				m.Index++
			}
		case "enter":
			flist := m.filtered()
			if len(flist) > 0 && m.Index < len(flist) {
				choice := flist[m.Index].Alias
				if choice == "" {
					choice = flist[m.Index].Name
				}
				m.Choice = choice
				m.Done = true
			}
		case "esc", "q":
			m.Cancelled = true
			m.Done = true
		case "backspace":
			if len(m.Filter) > 0 {
				m.Filter = m.Filter[:len(m.Filter)-1]
				m.Index = 0
			}
		default:
			if len(msg.Runes) == 1 && msg.Type == tea.KeyRunes {
				m.Filter += string(msg.Runes)
				m.Index = 0
			}
		}
	}
	return m, nil
}

func buildModelOptionText(alias string, isCurrent bool) string {
	if isCurrent {
		return alias + "  (current)"
	}
	return alias
}

func (m ModelPicker) View() string {
	title := lipgloss.NewStyle().Bold(true)
	sel := lipgloss.NewStyle().Foreground(lipgloss.Color("12")).Bold(true)
	muted := lipgloss.NewStyle().Faint(true)
	var b strings.Builder
	b.WriteString(title.Render("Select model"))
	if m.Filter != "" {
		b.WriteString(muted.Render("  filter: "+m.Filter))
	}
	b.WriteString("\n\n")
	flist := m.filtered()
	if len(flist) == 0 {
		b.WriteString(muted.Render("(no models)") + "\n")
	}
	for i, mod := range flist {
		alias := mod.Alias
		if alias == "" {
			alias = mod.Name
		}
		line := buildModelOptionText(alias, alias == m.Current)
		line = fmt.Sprintf("%s (%s / %s)", line, mod.Name, mod.Provider)
		if i == m.Index {
			b.WriteString(sel.Render("› "+line) + "\n")
		} else {
			b.WriteString("  " + line + "\n")
		}
	}
	b.WriteString("\n")
	b.WriteString(muted.Render("↑↓ navigate  type to filter  Enter confirm  Esc cancel"))
	return b.String()
}
