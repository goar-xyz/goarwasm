//go:build !(js && wasm)

package panels

import (
	"fmt"
	"strings"
	"time"

	tea "github.com/charmbracelet/bubbletea"
	"github.com/charmbracelet/lipgloss"

	"github.com/goarxyz/goar/internal/core/tools"
)

const approvalInputGracePeriod = 500 * time.Millisecond

// ApprovalOutcome is the result of an approval panel selection.
type ApprovalOutcome int

const (
	ApprovalOnce ApprovalOutcome = iota
	ApprovalSession
	ApprovalPermanent
	ApprovalDenied
	ApprovalCancelled
)

// ApprovalResult is posted when the panel closes.
type ApprovalResult struct {
	Outcome             ApprovalOutcome
	ToolName            string
	ToolArgs            map[string]any
	RequiredPermissions []tools.RequiredPermission
}

// ApprovalPanel asks the user to allow/deny a tool invocation.
// Port of goar.cli.textual_ui.panels.approval_panel.ApprovalPanel.
type ApprovalPanel struct {
	ToolName            string
	ToolArgs            map[string]any
	ToolArgsSummary     string
	RequiredPermissions []tools.RequiredPermission
	Selected            int
	Done                bool
	Result              ApprovalResult
	mountTime           time.Time
	Width               int
}

const approvalNumOptions = 4

// NewApprovalPanel constructs the panel.
func NewApprovalPanel(toolName string, args map[string]any, summary string, perms []tools.RequiredPermission) ApprovalPanel {
	if args == nil {
		args = map[string]any{}
	}
	return ApprovalPanel{
		ToolName:            toolName,
		ToolArgs:            args,
		ToolArgsSummary:     summary,
		RequiredPermissions: append([]tools.RequiredPermission{}, perms...),
		mountTime:           time.Now(),
	}
}

func (m ApprovalPanel) Init() tea.Cmd { return nil }

func (m ApprovalPanel) IsWithinGracePeriod() bool {
	return time.Since(m.mountTime) < approvalInputGracePeriod
}

func (m ApprovalPanel) buildTitle() string {
	if len(m.RequiredPermissions) > 0 {
		labels := make([]string, 0, len(m.RequiredPermissions))
		for _, rp := range m.RequiredPermissions {
			if rp.Label != "" {
				labels = append(labels, rp.Label)
			} else {
				labels = append(labels, string(rp.Scope))
			}
		}
		return fmt.Sprintf("Permission for the %s tool (%s)", m.ToolName, strings.Join(labels, ", "))
	}
	return fmt.Sprintf("Permission for the %s tool", m.ToolName)
}

func (m *ApprovalPanel) selectIfUnguarded(option int) {
	if m.IsWithinGracePeriod() {
		return
	}
	m.Selected = option
	m.handleSelection(option)
}

func (m *ApprovalPanel) handleSelection(option int) {
	m.Result = ApprovalResult{
		ToolName:            m.ToolName,
		ToolArgs:            m.ToolArgs,
		RequiredPermissions: m.RequiredPermissions,
	}
	switch option {
	case 0:
		m.Result.Outcome = ApprovalOnce
	case 1:
		m.Result.Outcome = ApprovalSession
	case 2:
		m.Result.Outcome = ApprovalPermanent
	default:
		m.Result.Outcome = ApprovalDenied
	}
	m.Done = true
}

func (m ApprovalPanel) Update(msg tea.Msg) (tea.Model, tea.Cmd) {
	switch msg := msg.(type) {
	case tea.WindowSizeMsg:
		m.Width = msg.Width
	case tea.KeyMsg:
		switch msg.String() {
		case "up", "k":
			m.Selected = (m.Selected - 1 + approvalNumOptions) % approvalNumOptions
		case "down", "j":
			m.Selected = (m.Selected + 1) % approvalNumOptions
		case "enter":
			m.selectIfUnguarded(m.Selected)
		case "1", "y":
			m.selectIfUnguarded(0)
		case "2":
			m.selectIfUnguarded(1)
		case "3":
			m.selectIfUnguarded(2)
		case "4", "n", "esc":
			m.selectIfUnguarded(3)
		}
	}
	return m, nil
}

func (m ApprovalPanel) View() string {
	titleStyle := lipgloss.NewStyle().Bold(true)
	yesStyle := lipgloss.NewStyle().Foreground(lipgloss.Color("10"))
	noStyle := lipgloss.NewStyle().Foreground(lipgloss.Color("9"))
	selStyle := lipgloss.NewStyle().Bold(true)
	help := lipgloss.NewStyle().Faint(true)

	options := []struct {
		text string
		yes  bool
	}{
		{"Allow once", true},
		{"Allow for remainder of this session", true},
		{"Always allow", true},
		{"Deny", false},
	}

	var b strings.Builder
	b.WriteString(titleStyle.Render(m.buildTitle()))
	b.WriteString("\n\n")
	if m.ToolArgsSummary != "" {
		b.WriteString(m.ToolArgsSummary)
		b.WriteString("\n\n")
	} else if len(m.ToolArgs) > 0 {
		b.WriteString(fmt.Sprintf("%v\n\n", m.ToolArgs))
	}
	for idx, opt := range options {
		cursor := "  "
		line := fmt.Sprintf("%d. %s", idx+1, opt.text)
		if idx == m.Selected {
			cursor = "› "
			if opt.yes {
				line = selStyle.Render(yesStyle.Render(line))
			} else {
				line = selStyle.Render(noStyle.Render(line))
			}
		} else if opt.yes {
			line = yesStyle.Render(line)
		} else {
			line = noStyle.Render(line)
		}
		b.WriteString(cursor + line + "\n")
	}
	b.WriteString("\n")
	b.WriteString(help.Render("↑↓ navigate  Enter select  ESC reject"))
	if m.IsWithinGracePeriod() {
		b.WriteString("\n")
		b.WriteString(help.Render("(input grace period…)"))
	}
	return b.String()
}

// Allowed is true when outcome is any allow variant (compat with thin stub).
func (m ApprovalPanel) Allowed() bool {
	return m.Done && m.Result.Outcome != ApprovalDenied && m.Result.Outcome != ApprovalCancelled
}
