//go:build !(js && wasm)

package panels

import (
	"strings"

	"github.com/charmbracelet/bubbles/textinput"
	tea "github.com/charmbracelet/bubbletea"
	"github.com/charmbracelet/lipgloss"
)

// ProxySetupResult is emitted when the panel closes.
type ProxySetupResult struct {
	Saved    bool
	HTTPProxy  string
	HTTPSProxy string
	NoProxy    string
	Error    string
}

// ProxySetupPanel edits HTTP(S) proxy environment settings.
// Port of goar.cli.textual_ui.panels.proxy_setup_panel.ProxySetupPanel.
type ProxySetupPanel struct {
	Inputs   []textinput.Model
	FocusIdx int
	Done     bool
	Saved    bool
	Error    string
	Width    int
	labels   []string
}

// NewProxySetupPanel creates the panel with optional initial values.
func NewProxySetupPanel(httpProxy, httpsProxy, noProxy string) ProxySetupPanel {
	labels := []string{"HTTP_PROXY", "HTTPS_PROXY", "NO_PROXY"}
	vals := []string{httpProxy, httpsProxy, noProxy}
	inputs := make([]textinput.Model, 3)
	for i := range inputs {
		ti := textinput.New()
		ti.Placeholder = labels[i]
		ti.SetValue(vals[i])
		ti.CharLimit = 512
		ti.Width = 60
		inputs[i] = ti
	}
	inputs[0].Focus()
	return ProxySetupPanel{Inputs: inputs, labels: labels}
}

func (m ProxySetupPanel) Init() tea.Cmd { return textinput.Blink }

func (m *ProxySetupPanel) focusNext() {
	m.Inputs[m.FocusIdx].Blur()
	m.FocusIdx = (m.FocusIdx + 1) % len(m.Inputs)
	m.Inputs[m.FocusIdx].Focus()
}

func (m *ProxySetupPanel) focusPrev() {
	m.Inputs[m.FocusIdx].Blur()
	m.FocusIdx = (m.FocusIdx - 1 + len(m.Inputs)) % len(m.Inputs)
	m.Inputs[m.FocusIdx].Focus()
}

func (m *ProxySetupPanel) saveAndClose() {
	m.Saved = true
	m.Done = true
}

func (m ProxySetupPanel) Result() ProxySetupResult {
	return ProxySetupResult{
		Saved:      m.Saved,
		HTTPProxy:  m.Inputs[0].Value(),
		HTTPSProxy: m.Inputs[1].Value(),
		NoProxy:    m.Inputs[2].Value(),
		Error:      m.Error,
	}
}

func (m ProxySetupPanel) Update(msg tea.Msg) (tea.Model, tea.Cmd) {
	switch msg := msg.(type) {
	case tea.WindowSizeMsg:
		m.Width = msg.Width
	case tea.KeyMsg:
		switch msg.String() {
		case "up":
			m.focusPrev()
			return m, nil
		case "down", "tab":
			m.focusNext()
			return m, nil
		case "shift+tab":
			m.focusPrev()
			return m, nil
		case "enter":
			if m.FocusIdx == len(m.Inputs)-1 {
				m.saveAndClose()
				return m, nil
			}
			m.focusNext()
			return m, nil
		case "ctrl+s":
			m.saveAndClose()
			return m, nil
		case "esc":
			m.Done = true
			m.Saved = false
			return m, nil
		}
	}
	var cmd tea.Cmd
	m.Inputs[m.FocusIdx], cmd = m.Inputs[m.FocusIdx].Update(msg)
	return m, cmd
}

func (m ProxySetupPanel) View() string {
	title := lipgloss.NewStyle().Bold(true)
	muted := lipgloss.NewStyle().Faint(true)
	var b strings.Builder
	b.WriteString(title.Render("Proxy setup"))
	b.WriteString("\n\n")
	for i, ti := range m.Inputs {
		b.WriteString(m.labels[i] + "\n")
		b.WriteString(ti.View() + "\n\n")
	}
	if m.Error != "" {
		b.WriteString(lipgloss.NewStyle().Foreground(lipgloss.Color("9")).Render(m.Error) + "\n")
	}
	b.WriteString(muted.Render("↑↓ fields  Enter next/save  Ctrl+S save  Esc cancel"))
	return b.String()
}
