package textualui

import (
	"sort"

	"github.com/goarxyz/goar/internal/cli/textualui/uitheme"
)

// Theme is the Bubble Tea / lipgloss theme alias.
type Theme = uitheme.Theme

// Themes is the registered theme map.
var Themes = uitheme.Themes

// Agent branded theme names (Python AGENT_THEME_NAMES / DEFAULT_AGENT_THEME).
const (
	ThemeGoarDark     = "goar-dark"
	ThemeGoarLight    = "goar-light"
	DefaultAgentTheme = ThemeGoarDark
)

var agentThemeNames = map[string]bool{
	ThemeGoarDark:  true,
	ThemeGoarLight: true,
}

// GetTheme returns a theme by name (fallback goar-dark).
func GetTheme(name string) Theme { return uitheme.Get(name) }

// AllThemes returns the theme catalog (Python all_themes).
func AllThemes() map[string]Theme {
	out := map[string]Theme{}
	for k, v := range Themes {
		out[k] = v
	}
	return out
}

// SortedThemeNames returns branded themes first, then light, then dark (Python sorted_theme_names).
func SortedThemeNames() []string {
	themes := AllThemes()
	branded := []string{}
	for _, name := range []string{ThemeGoarDark, ThemeGoarLight} {
		if _, ok := themes[name]; ok {
			branded = append(branded, name)
		}
	}
	var light, dark []string
	for name, th := range themes {
		if agentThemeNames[name] {
			continue
		}
		// Heuristic: light themes have brighter backgrounds (first hex digit of bg high).
		bg := string(th.Background)
		isLight := len(bg) >= 2 && (bg[1] >= 'A' && bg[1] <= 'F' || bg[1] >= 'a' && bg[1] <= 'f' || bg[1] >= '8')
		if name == ThemeGoarLight {
			isLight = true
		}
		if isLight {
			light = append(light, name)
		} else {
			dark = append(dark, name)
		}
	}
	sort.Strings(light)
	sort.Strings(dark)
	return append(append(branded, light...), dark...)
}

// IsKnownTheme reports whether name is registered (Python is_known_theme).
func IsKnownTheme(name string) bool {
	_, ok := Themes[name]
	return ok
}

// IsAgentTheme reports a branded theme name.
func IsAgentTheme(name string) bool { return agentThemeNames[name] }
