package ports

// Notification is a user-visible notice.
type Notification struct {
	Title   string
	Message string
	Level   string // info|warning|error|success
}

// Port delivers notifications.
type Port interface {
	Notify(n Notification)
}
