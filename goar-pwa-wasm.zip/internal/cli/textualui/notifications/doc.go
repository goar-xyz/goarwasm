// Package notifications delivers TUI notifications.
package notifications
