package adapters

import (
	"fmt"
	"sync"

	"github.com/goarxyz/goar/internal/cli/textualui/notifications/ports"
)

// TextualNotificationAdapter stores notifications for the TUI status area.
type TextualNotificationAdapter struct {
	mu    sync.Mutex
	Items []ports.Notification
}

func (a *TextualNotificationAdapter) Notify(n ports.Notification) {
	a.mu.Lock()
	defer a.mu.Unlock()
	a.Items = append(a.Items, n)
	if len(a.Items) > 50 {
		a.Items = a.Items[len(a.Items)-50:]
	}
}

func (a *TextualNotificationAdapter) Latest() string {
	a.mu.Lock()
	defer a.mu.Unlock()
	if len(a.Items) == 0 {
		return ""
	}
	n := a.Items[len(a.Items)-1]
	return fmt.Sprintf("[%s] %s: %s", n.Level, n.Title, n.Message)
}
