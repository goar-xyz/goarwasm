package recording

import (
	"encoding/json"
	"os"
	"sync"
	"time"
)

// Event is a recorded UI event.
type Event struct {
	At   time.Time `json:"at"`
	Kind string    `json:"kind"`
	Data any       `json:"data"`
}

// Recorder appends events to memory and optionally a file.
type Recorder struct {
	mu     sync.Mutex
	events []Event
	path   string
}

func New(path string) *Recorder { return &Recorder{path: path} }

func (r *Recorder) Record(kind string, data any) {
	r.mu.Lock()
	defer r.mu.Unlock()
	r.events = append(r.events, Event{At: time.Now().UTC(), Kind: kind, Data: data})
}

func (r *Recorder) Flush() error {
	r.mu.Lock()
	defer r.mu.Unlock()
	if r.path == "" {
		return nil
	}
	b, err := json.MarshalIndent(r.events, "", "  ")
	if err != nil {
		return err
	}
	return os.WriteFile(r.path, b, 0o644)
}

func (r *Recorder) Events() []Event {
	r.mu.Lock()
	defer r.mu.Unlock()
	return append([]Event{}, r.events...)
}
