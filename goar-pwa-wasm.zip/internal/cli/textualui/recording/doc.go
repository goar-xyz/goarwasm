// Package recording records TUI sessions for replay.
package recording
