package windowing

import (
	"github.com/goarxyz/goar/internal/core/types"
)

// HistoryEntry describes a rendered history widget slot.
type HistoryEntry struct {
	Kind         string // user|assistant|tool_call|tool_result|reasoning
	HistoryIndex int
	MessageIndex int // runtime.messages index for user (history_index+1)
	Content      string
	ToolName     string
	ToolCallID   string
	Collapsed    bool
}

// NonSystemHistoryMessages filters out system role messages.
func NonSystemHistoryMessages(messages []types.LLMMessage) []types.LLMMessage {
	out := make([]types.LLMMessage, 0, len(messages))
	for _, m := range messages {
		if m.Role != types.RoleSystem {
			out = append(out, m)
		}
	}
	return out
}

// BuildToolCallMap maps tool_call_id → tool name from assistant messages.
func BuildToolCallMap(messages []types.LLMMessage) map[string]string {
	m := map[string]string{}
	for _, msg := range messages {
		if msg.Role != types.RoleAssistant || len(msg.ToolCalls) == 0 {
			continue
		}
		for _, tc := range msg.ToolCalls {
			if tc.ID != "" {
				name := tc.Function.Name
				if name == "" {
					name = "unknown"
				}
				m[tc.ID] = name
			}
		}
	}
	return m
}

// BuildHistoryEntries converts a batch of LLM messages into display entries.
// Port of build_history_widgets.
func BuildHistoryEntries(batch []types.LLMMessage, toolCallMap map[string]string, startIndex int, toolsCollapsed bool) []HistoryEntry {
	var entries []HistoryEntry
	for i, msg := range batch {
		historyIndex := startIndex + i
		if msg.Injected {
			continue
		}
		switch msg.Role {
		case types.RoleUser:
			if msg.Content != nil && *msg.Content != "" {
				entries = append(entries, HistoryEntry{
					Kind: "user", HistoryIndex: historyIndex, MessageIndex: historyIndex + 1, Content: *msg.Content,
				})
			}
		case types.RoleAssistant:
			if msg.Content != nil && *msg.Content != "" {
				entries = append(entries, HistoryEntry{
					Kind: "assistant", HistoryIndex: historyIndex, Content: *msg.Content,
				})
			}
			if msg.ReasoningContent != nil && *msg.ReasoningContent != "" {
				entries = append(entries, HistoryEntry{
					Kind: "reasoning", HistoryIndex: historyIndex, Content: *msg.ReasoningContent, Collapsed: true,
				})
			}
			for _, tc := range msg.ToolCalls {
				name := tc.Function.Name
				if name == "" {
					name = "unknown"
				}
				if tc.ID != "" {
					toolCallMap[tc.ID] = name
				}
				entries = append(entries, HistoryEntry{
					Kind: "tool_call", HistoryIndex: historyIndex, ToolName: name, ToolCallID: tc.ID,
				})
			}
		case types.RoleTool:
			name := ""
			if msg.Name != nil {
				name = *msg.Name
			}
			if name == "" && msg.ToolCallID != nil {
				name = toolCallMap[*msg.ToolCallID]
			}
			if name == "" {
				name = "tool"
			}
			content := ""
			if msg.Content != nil {
				content = *msg.Content
			}
			tcid := ""
			if msg.ToolCallID != nil {
				tcid = *msg.ToolCallID
			}
			entries = append(entries, HistoryEntry{
				Kind: "tool_result", HistoryIndex: historyIndex, ToolName: name, Content: content,
				ToolCallID: tcid, Collapsed: toolsCollapsed,
			})
		}
	}
	return entries
}

// SplitHistoryTail splits history into tail + backfill like the Python helper.
func SplitHistoryTail(history []types.LLMMessage, tailSize int) (tail, backfill []types.LLMMessage, tailStart int) {
	if tailSize < 0 {
		tailSize = 0
	}
	if len(history) <= tailSize {
		return append([]types.LLMMessage{}, history...), nil, 0
	}
	tailStart = len(history) - tailSize
	tail = append([]types.LLMMessage{}, history[tailStart:]...)
	backfill = append([]types.LLMMessage{}, history[:tailStart]...)
	return tail, backfill, tailStart
}

// VisibleHistoryIndices returns history indices for mounted entries.
func VisibleHistoryIndices(entries []HistoryEntry) []int {
	out := make([]int, 0, len(entries))
	for _, e := range entries {
		out = append(out, e.HistoryIndex)
	}
	return out
}

// VisibleHistoryWidgetsCount counts history-like entries.
func VisibleHistoryWidgetsCount(entries []HistoryEntry) int {
	n := 0
	for _, e := range entries {
		switch e.Kind {
		case "user", "assistant", "reasoning", "tool_call", "tool_result":
			n++
		}
	}
	return n
}
