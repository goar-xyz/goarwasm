package windowing

// Layout describes pane sizes.
type Layout struct {
	Width, Height int
	ChatHeight    int
	InputHeight   int
	StatusHeight  int
	SidebarWidth  int
	ShowSidebar   bool
}

func Compute(width, height int, showSidebar bool) Layout {
	l := Layout{Width: width, Height: height, InputHeight: 4, StatusHeight: 1, ShowSidebar: showSidebar}
	if showSidebar {
		l.SidebarWidth = width / 4
		if l.SidebarWidth < 20 {
			l.SidebarWidth = 20
		}
	}
	l.ChatHeight = height - l.InputHeight - l.StatusHeight - 2
	if l.ChatHeight < 3 {
		l.ChatHeight = 3
	}
	return l
}
