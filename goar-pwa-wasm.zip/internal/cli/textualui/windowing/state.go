package windowing

import "github.com/goarxyz/goar/internal/core/types"

const (
	// HistoryResumeTailMessages is the default number of recent messages shown on resume.
	HistoryResumeTailMessages = 20
	// LoadMoreBatchSize is how many older messages load-more prepends.
	LoadMoreBatchSize = 10
)

// LoadMoreBatch is one prepend batch of older history.
type LoadMoreBatch struct {
	StartIndex int
	Messages   []types.LLMMessage
}

// SessionWindowing tracks backfill cursor for paginated history.
type SessionWindowing struct {
	LoadMoreBatchSize int
	backfillMessages  []types.LLMMessage
	backfillCursor    int
}

// NewSessionWindowing creates windowing state.
func NewSessionWindowing(batchSize int) *SessionWindowing {
	if batchSize <= 0 {
		batchSize = LoadMoreBatchSize
	}
	return &SessionWindowing{LoadMoreBatchSize: batchSize}
}

// Remaining is how many backfill messages are still unloaded.
func (s *SessionWindowing) Remaining() int { return s.backfillCursor }

// HasBackfill reports whether older messages remain.
func (s *SessionWindowing) HasBackfill() bool { return s.backfillCursor > 0 }

// Reset clears backfill state.
func (s *SessionWindowing) Reset() {
	s.backfillMessages = nil
	s.backfillCursor = 0
}

// SetBackfill installs the older-message prefix.
func (s *SessionWindowing) SetBackfill(msgs []types.LLMMessage) {
	s.backfillMessages = append([]types.LLMMessage{}, msgs...)
	s.backfillCursor = len(s.backfillMessages)
}

// NextLoadMoreBatch returns the next older batch, or nil.
func (s *SessionWindowing) NextLoadMoreBatch() *LoadMoreBatch {
	if s.backfillCursor == 0 {
		return nil
	}
	start := s.backfillCursor - s.LoadMoreBatchSize
	if start < 0 {
		start = 0
	}
	batch := append([]types.LLMMessage{}, s.backfillMessages[start:s.backfillCursor]...)
	s.backfillCursor = start
	if len(batch) == 0 {
		return nil
	}
	return &LoadMoreBatch{StartIndex: start, Messages: batch}
}

// RecomputeBackfill syncs backfill from currently visible history indices.
// Port of SessionWindowing.recompute_backfill.
func (s *SessionWindowing) RecomputeBackfill(history []types.LLMMessage, visibleIndices []int, visibleWidgetsCount int) bool {
	if len(history) == 0 {
		s.backfillMessages = nil
		s.backfillCursor = 0
		return false
	}
	var backfillEnd int
	if len(visibleIndices) > 0 {
		oldest := visibleIndices[0]
		for _, idx := range visibleIndices {
			if idx < oldest {
				oldest = idx
			}
		}
		if oldest > s.backfillCursor {
			prefix := history[s.backfillCursor:oldest]
			allInjected := len(prefix) > 0
			for _, m := range prefix {
				if !m.Injected {
					allInjected = false
					break
				}
			}
			if allInjected {
				backfillEnd = s.backfillCursor
			} else {
				backfillEnd = oldest
			}
		} else {
			backfillEnd = s.backfillCursor
		}
	} else {
		backfillEnd = len(history) - visibleWidgetsCount
		if backfillEnd < 0 {
			backfillEnd = 0
		}
	}
	if backfillEnd > len(history) {
		backfillEnd = len(history)
	}
	s.backfillMessages = append([]types.LLMMessage{}, history[:backfillEnd]...)
	s.backfillCursor = len(s.backfillMessages)
	return s.backfillCursor > 0
}

// HistoryLoadMoreManager tracks the load-more affordance.
type HistoryLoadMoreManager struct {
	Visible   bool
	Remaining int
	Enabled   bool
}

// Show marks load-more visible with remaining count.
func (m *HistoryLoadMoreManager) Show(remaining int) {
	m.Visible = true
	m.Remaining = remaining
	m.Enabled = true
}

// Hide hides the load-more control.
func (m *HistoryLoadMoreManager) Hide() {
	m.Visible = false
	m.Remaining = 0
}

// SetVisible toggles visibility.
func (m *HistoryLoadMoreManager) SetVisible(visible bool, remaining int) {
	if visible {
		m.Show(remaining)
		return
	}
	m.Hide()
}

// SetEnabled enables/disables interaction.
func (m *HistoryLoadMoreManager) SetEnabled(enabled bool) { m.Enabled = enabled }

// SetRemaining updates the remaining count label.
func (m *HistoryLoadMoreManager) SetRemaining(remaining int) { m.Remaining = remaining }

// Label returns the UI label.
func (m *HistoryLoadMoreManager) Label() string {
	if !m.Visible {
		return ""
	}
	if m.Remaining <= 0 {
		return "▲ load older messages"
	}
	return "▲ load older messages (" + itoa(m.Remaining) + " remaining)"
}

func itoa(n int) string {
	if n == 0 {
		return "0"
	}
	neg := n < 0
	if neg {
		n = -n
	}
	var b [20]byte
	i := len(b)
	for n > 0 {
		i--
		b[i] = byte('0' + n%10)
		n /= 10
	}
	if neg {
		i--
		b[i] = '-'
	}
	return string(b[i:])
}
