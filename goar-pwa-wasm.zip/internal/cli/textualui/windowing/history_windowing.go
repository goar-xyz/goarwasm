package windowing

import "github.com/goarxyz/goar/internal/core/types"

// HistoryResumePlan describes how to mount history on session resume.
type HistoryResumePlan struct {
	ToolCallMap      map[string]string
	TailMessages     []types.LLMMessage
	BackfillMessages []types.LLMMessage
	TailStartIndex   int
}

// HasBackfill reports whether older messages exist beyond the tail.
func (p *HistoryResumePlan) HasBackfill() bool { return len(p.BackfillMessages) > 0 }

// ShouldResumeHistory is true when the messages area is empty.
func ShouldResumeHistory(mountedCount int) bool { return mountedCount == 0 }

// CreateResumePlan builds a resume plan for history_messages with the given tail size.
func CreateResumePlan(history []types.LLMMessage, tailSize int) *HistoryResumePlan {
	if len(history) == 0 {
		return nil
	}
	tail, backfill, start := SplitHistoryTail(history, tailSize)
	return &HistoryResumePlan{
		ToolCallMap:      BuildToolCallMap(history),
		TailMessages:     tail,
		BackfillMessages: backfill,
		TailStartIndex:   start,
	}
}

// SyncBackfillState recomputes windowing backfill from currently visible entries.
// Returns (hasBackfill, toolCallMap).
func SyncBackfillState(history []types.LLMMessage, entries []HistoryEntry, win *SessionWindowing) (bool, map[string]string) {
	if len(history) == 0 {
		win.Reset()
		return false, nil
	}
	visible := VisibleHistoryIndices(entries)
	count := VisibleHistoryWidgetsCount(entries)
	has := win.RecomputeBackfill(history, visible, count)
	return has, BuildToolCallMap(history)
}

// ApplyResume mounts the resume plan into windowing + returns tail entries to display.
func ApplyResume(plan *HistoryResumePlan, win *SessionWindowing, toolsCollapsed bool) []HistoryEntry {
	if plan == nil {
		return nil
	}
	win.SetBackfill(plan.BackfillMessages)
	tcmap := plan.ToolCallMap
	if tcmap == nil {
		tcmap = map[string]string{}
	}
	return BuildHistoryEntries(plan.TailMessages, tcmap, plan.TailStartIndex, toolsCollapsed)
}

// LoadMore prepends the next older batch and returns new entries + remaining.
func LoadMore(win *SessionWindowing, toolCallMap map[string]string, toolsCollapsed bool) (entries []HistoryEntry, remaining int, ok bool) {
	batch := win.NextLoadMoreBatch()
	if batch == nil {
		return nil, win.Remaining(), false
	}
	if toolCallMap == nil {
		toolCallMap = map[string]string{}
	}
	entries = BuildHistoryEntries(batch.Messages, toolCallMap, batch.StartIndex, toolsCollapsed)
	return entries, win.Remaining(), true
}
