// Package windowing manages TUI pane layout.
package windowing
