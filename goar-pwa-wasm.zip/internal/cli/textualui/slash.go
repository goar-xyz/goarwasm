package textualui

import "strings"

// ParseSlash parses "/cmd args".
func ParseSlash(line string) (cmd, args string, ok bool) {
	line = strings.TrimSpace(line)
	if !strings.HasPrefix(line, "/") {
		return "", "", false
	}
	line = strings.TrimPrefix(line, "/")
	cmd, args, _ = strings.Cut(line, " ")
	return strings.ToLower(cmd), strings.TrimSpace(args), true
}
