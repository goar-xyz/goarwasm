package textualui

import (
	"os"
	"os/exec"
)

// OpenExternalEditor opens $EDITOR on a temp file and returns the result.
func OpenExternalEditor(initial string) (string, error) {
	f, err := os.CreateTemp("", "goar-edit-*.md")
	if err != nil {
		return "", err
	}
	path := f.Name()
	_, _ = f.WriteString(initial)
	_ = f.Close()
	editor := os.Getenv("EDITOR")
	if editor == "" {
		editor = "vi"
	}
	cmd := exec.Command(editor, path)
	cmd.Stdin, cmd.Stdout, cmd.Stderr = os.Stdin, os.Stdout, os.Stderr
	if err := cmd.Run(); err != nil {
		return "", err
	}
	b, err := os.ReadFile(path)
	_ = os.Remove(path)
	return string(b), err
}
