// Package textualui is the Bubble Tea TUI (Python: goar.cli.textual_ui).
package textualui
