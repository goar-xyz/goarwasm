//go:build !(js && wasm)

package textualui

import (
	"context"
	"fmt"
	"os"
	"os/exec"
	"sort"
	"strings"
	"time"

	"github.com/charmbracelet/bubbles/textarea"
	"github.com/charmbracelet/bubbles/viewport"
	tea "github.com/charmbracelet/bubbletea"
	"github.com/charmbracelet/lipgloss"

	goar "github.com/goarxyz/goar"
	"github.com/goarxyz/goar/internal/cli/textualui/handlers"
	"github.com/goarxyz/goar/internal/cli/textualui/uitheme"
	"github.com/goarxyz/goar/internal/cli/textualui/notifications/adapters"
	"github.com/goarxyz/goar/internal/cli/textualui/panels"
	"github.com/goarxyz/goar/internal/cli/textualui/recording"
	"github.com/goarxyz/goar/internal/cli/textualui/widgets"
	"github.com/goarxyz/goar/internal/cli/textualui/widgets/banner"
	"github.com/goarxyz/goar/internal/cli/textualui/widgets/chatinput"
	"github.com/goarxyz/goar/internal/cli/textualui/windowing"
	"github.com/goarxyz/goar/internal/core"
	"github.com/goarxyz/goar/internal/core/agents"
	"github.com/goarxyz/goar/internal/core/config"
	"github.com/goarxyz/goar/internal/core/paths"
	"github.com/goarxyz/goar/internal/core/tools"
	"github.com/goarxyz/goar/internal/core/tools/mcp"
	"github.com/goarxyz/goar/internal/core/types"
)

type panelKind int

const (
	panelNone panelKind = iota
	panelModel
	panelTheme
	panelConfig
	panelRewind
	panelSession
	panelMCP
	panelProxy
	panelThinking
	panelApproval
	panelQuestion
	panelConnector
)

// StartupOptions mirrors Python StartupOptions for TUI boot.
type StartupOptions struct {
	InitialPrompt   string
	AgentName       string
	ResumeSessionID string
	Headless        bool
	SkipOnboarding  bool
}

// App is the root Bubble Tea model — port of GoarApp.
type App struct {
	Cfg       *config.Config
	Runtime   *core.Runtime
	Theme     Theme
	Input     textarea.Model
	Viewport  viewport.Model
	Messages  []types.LLMMessage
	Status    string
	Busy      bool
	Width     int
	Height    int
	QuitMgr   *QuitManager
	Queue     *MessageQueue
	Notify    *adapters.TextualNotificationAdapter
	Handler   *handlers.EventHandler
	Recorder  *recording.Recorder
	SpinnerN  int
	Initial   string
	AgentName string
	Startup   StartupOptions

	activePanel    panelKind
	modelPanel     panels.ModelPicker
	themePanel     panels.ThemePicker
	configPanel    panels.ConfigPanel
	thinkPanel     panels.ThinkingPicker
	approvalPanel  panels.ApprovalPanel
	questionPanel  panels.QuestionPanel
	mcpPanel       panels.MCPPanel
	proxyPanel     panels.ProxySetupPanel
	rewindPanel    panels.RewindPanel
	sessionPanel   panels.SessionPicker
	connectorPanel panels.ConnectorAuthPanel

	MCPRegistry        *mcp.Registry
	Loading            *widgets.LoadingWidget
	Windowing          *windowing.SessionWindowing
	LoadMore           windowing.HistoryLoadMoreManager
	HistoryEntries     []windowing.HistoryEntry
	ToolCallMap        map[string]string
	ToolsCollapsed     bool
	RewindMode         bool
	RewindIndex        int
	DebugOpen          bool
	DebugLines         []string
	ConnectorsEnabled  bool
	CommandRegistry    map[string]string
	LastAssistant      string
	InterruptReq       bool
	ProfileName        string
	ThinkingLevel      string
	FileWatcherEnabled bool
	HookIssuesShown    bool
	Completer          *chatinput.CompletionManager
	Popup              chatinput.CompletionPopup
	TodosOpen          bool
	TodoLines          []string

	LoopRunner *ScheduledLoopRunner
	Plugins    []pluginEntry

	// Pending UI↔runtime callback replies (set while approval/question panels are open).
	approvalReplyCh chan approvalReply
	questionReplyCh chan questionReply
}

type tickMsg struct{}
type spinnerTickMsg struct{}
type agentDoneMsg struct {
	Text   string
	Events []types.Event
	Err    error
}
type approvalNeededMsg struct {
	ToolName string
	Args     map[string]any
	Summary  string
	Perms    []tools.RequiredPermission
	Reply    chan approvalReply
}
type questionNeededMsg struct {
	Questions []panels.Question
	Reply     chan questionReply
}
type approvalReply struct {
	Response types.ApprovalResponse
	Feedback string
}
type questionReply struct {
	Answer    string
	Cancelled bool
}
type streamDeltaMsg struct {
	Text string
	Done bool
}
type editorDoneMsg struct {
	text string
	err  error
}

// NewApp constructs the TUI app.
func NewApp(cfg *config.Config, rt *core.Runtime, initial, agent string) App {
	uitheme.EnsureColorProfile()
	theme := GetTheme(cfg.Theme)
	ta := textarea.New()
	ta.Placeholder = InputPlaceholder
	ta.Focus()
	ta.SetHeight(3)
	ta.ShowLineNumbers = false
	ta.CharLimit = 0
	vp := viewport.New(80, 20)
	notify := &adapters.TextualNotificationAdapter{}
	app := App{
		Cfg: cfg, Runtime: rt, Theme: theme, Input: ta, Viewport: vp,
		QuitMgr: NewQuitManager(), Notify: notify, Recorder: recording.New(""),
		Initial: initial, AgentName: agent,
		Startup:           StartupOptions{InitialPrompt: initial, AgentName: agent},
		Queue:             &MessageQueue{},
		Windowing:         windowing.NewSessionWindowing(windowing.LoadMoreBatchSize),
		ToolCallMap:       map[string]string{},
		ThinkingLevel:     "off",
		ProfileName:       agent,
		CommandRegistry:   defaultCommandRegistry(),
		ConnectorsEnabled: true,
	}
	app.Handler = handlers.NewEventHandler(nil, func() bool { return app.ToolsCollapsed })
	app.Handler.OnAssistant = func(s string) {
		app.LastAssistant = s
		app.Status = "assistant responded"
	}
	app.Handler.Notify = notify
	if rt != nil {
		app.Messages = append([]types.LLMMessage{}, rt.Messages...)
		app.resumeHistoryFromMessages()
	}
	app.buildCommandRegistry()
	app.Completer = chatinput.NewCompletionManager(app.CommandRegistry)
	app.Popup = chatinput.NewCompletionPopup()
	return app
}

func defaultCommandRegistry() map[string]string {
	// Keep labels in sync with internal/cli/commands.go (Vibe slash parity).
	return map[string]string{
		"help": "Show help message",
		"config": "Edit config settings",
		"model": "Select active model",
		"skills": "Browse, import, and manage skills",
		"thinking": "Select thinking level",
		"reload": "Reload configuration, agent instructions, and skills from disk",
		"clear": "Start a new conversation",
		"new": "Start a new conversation",
		"copy": "Copy the last agent message to the clipboard",
		"paste-image": "Paste an image from the OS clipboard into the prompt",
		"log": "Show path to current interaction log file",
		"log-level": "Change the log level for this session",
		"debug": "Toggle debug console",
		"compact": "Compact conversation history by summarizing",
		"exit": "Exit the application",
		"quit": "Quit GOAR",
		"status": "Display agent statistics",
		"whoami": "Display signed-in provider account info when available",
		"proxy-setup": "Configure HTTP(S) proxy and SSL certificate settings",
		"proxy": "Configure HTTP(S) proxy and SSL certificate settings",
		"resume": "Browse, resume, or delete saved sessions",
		"continue": "Browse, resume, or delete saved sessions",
		"session": "Browse, resume, or delete saved sessions",
		"sessions": "Browse, resume, or delete saved sessions",
		"rename": "Rename the current session",
		"mcp": "Display available MCP servers and connectors",
		"connectors": "Display available MCP servers and connectors",
		"plugins": "Display the plugins this session is running",
		"reload-plugins": "Re-pin this session's plugins and report what changed",
		"voice": "Configure voice settings",
		"rewind": "Rewind to a previous message",
		"branch": "Fork the current conversation into a new resumable session",
		"retry": "Continue an interrupted model response",
		"loop": "Schedule a recurring prompt",
		"data-retention": "Show data retention information",
		"theme": "Select theme",
		"setup": "Show how to add or switch providers",
		"onboard": "Show how to add or switch providers",
		"provider": "Show how to add or switch providers",
	}
}

func (a *App) buildCommandRegistry() {
	a.CommandRegistry = defaultCommandRegistry()
	if !a.ConnectorsEnabled {
		delete(a.CommandRegistry, "mcp")
		delete(a.CommandRegistry, "connectors")
	}
	// Match cli.CommandRegistry availability: hide /voice when no mic pipeline.
	if !voiceAvailable() {
		delete(a.CommandRegistry, "voice")
	}
}

func (a *App) refreshCommandRegistry() { a.buildCommandRegistry() }

func (a *App) connectorsEnabled() bool { return a.ConnectorsEnabled }

func (a App) Init() tea.Cmd {
	var cmds []tea.Cmd
	cmds = append(cmds, textarea.Blink, spinnerTickCmd())
	if a.Initial != "" {
		cmds = append(cmds, a.submit(a.Initial))
	}
	return tea.Batch(cmds...)
}

func spinnerTickCmd() tea.Cmd {
	return tea.Tick(100*time.Millisecond, func(t time.Time) tea.Msg { return spinnerTickMsg{} })
}

func (a App) Update(msg tea.Msg) (tea.Model, tea.Cmd) {
	if a.activePanel != panelNone {
		return a.updatePanel(msg)
	}
	if a.RewindMode {
		return a.updateRewindMode(msg)
	}
	switch msg := msg.(type) {
	case setupFinishedMsg:
		return a.onSetupFinished(msg)
	case tea.WindowSizeMsg:
		a.Width, a.Height = msg.Width, msg.Height
		lay := windowing.Compute(a.Width, a.Height, a.DebugOpen)
		a.Viewport.Width = lay.Width
		if a.DebugOpen {
			a.Viewport.Height = lay.ChatHeight - 6
		} else {
			a.Viewport.Height = lay.ChatHeight
		}
		a.Input.SetWidth(lay.Width - 2)
		a.refreshViewport()
	case tea.KeyMsg:
		return a.onKey(msg)
	case agentDoneMsg:
		return a.onAgentDone(msg)
	case approvalNeededMsg:
		a.approvalPanel = panels.NewApprovalPanel(msg.ToolName, msg.Args, msg.Summary, msg.Perms)
		a.approvalReplyCh = msg.Reply
		a.activePanel = panelApproval
		if a.Loading != nil {
			a.Loading.PauseTimer()
		}
		return a, nil
	case questionNeededMsg:
		a.questionPanel = panels.NewQuestionPanel(msg.Questions)
		a.questionReplyCh = msg.Reply
		a.activePanel = panelQuestion
		if a.Loading != nil {
			a.Loading.PauseTimer()
		}
		return a, nil
	case streamDeltaMsg:
		if msg.Text != "" {
			a.LastAssistant += msg.Text
			a.refreshViewport()
		}
	case spinnerTickMsg:
		a.SpinnerN++
		if a.Loading != nil && a.Busy {
			a.Status = a.Loading.Tick()
		}
		if a.Busy || (a.Loading != nil && a.Loading.IsSpinning) {
			return a, spinnerTickCmd()
		}
	case tickMsg:
		a.SpinnerN++
		if a.Busy {
			return a, tickCmd()
		}
	case panels.ThemePreviewMsg:
		a.Theme = GetTheme(msg.Theme)
	case editorDoneMsg:
		if msg.err != nil {
			a.Status = "editor: " + msg.err.Error()
			return a, nil
		}
		a.Input.SetValue(strings.TrimRight(msg.text, "\n"))
		a.refreshCompletions()
		return a, nil
	}
	var cmd tea.Cmd
	a.Input, cmd = a.Input.Update(msg)
	a.refreshCompletions()
	return a, cmd
}

func (a App) onKey(msg tea.KeyMsg) (tea.Model, tea.Cmd) {
	key := msg.String()
	if a.Popup.Visible {
		switch key {
		case "up", "ctrl+p":
			a.Popup, _ = a.Popup.Update(msg)
			return a, nil
		case "down", "ctrl+n", "tab":
			if key == "tab" {
				if item, ok := a.Popup.Selected(); ok {
					a.applyCompletion(item)
				}
				return a, nil
			}
			a.Popup, _ = a.Popup.Update(msg)
			return a, nil
		case "esc":
			a.Popup.Hide()
			return a, nil
		}
	}
	switch key {
	case "ctrl+c":
		if a.Busy {
			a.InterruptReq = true
			a.Status = "interrupt requested…"
			return a, nil
		}
		if a.QuitMgr.Hit() {
			return a, tea.Quit
		}
		a.Status = "Press Ctrl+C again to quit"
		return a, nil
	case "ctrl+d":
		if a.QuitMgr.HitKey(QuitCtrlD) {
			return a, tea.Quit
		}
		a.Status = "Press Ctrl+D again to quit"
		return a, nil
	case "ctrl+o":
		a.ToolsCollapsed = !a.ToolsCollapsed
		a.Status = fmt.Sprintf("tool output collapsed=%v", a.ToolsCollapsed)
		a.refreshViewport()
		return a, nil
	case "ctrl+l":
		a._clearHistory()
		return a, nil
	case "ctrl+p":
		a.cycleAgent()
		return a, nil
	case "shift+tab":
		a.cycleAgent()
		return a, nil
	case "ctrl+t":
		a.TodosOpen = !a.TodosOpen
		if a.TodosOpen {
			a.Status = "todos"
		} else {
			a.Status = "ready"
		}
		return a, nil
	case "ctrl+g":
		return a, a.startExternalEditor()
	case "ctrl+j", "shift+enter", "alt+enter":
		a.Input.InsertRune('\n')
		a.refreshCompletions()
		return a, nil
	case "ctrl+\\":
		a.DebugOpen = !a.DebugOpen
		return a, nil
	case "pgup", "ctrl+u":
		a.Viewport.HalfViewUp()
		return a, nil
	case "pgdown":
		a.Viewport.HalfViewDown()
		return a, nil
	case "ctrl+r":
		return a.startRewindMode()
	case "enter":
		if msg.Alt {
			a.Input.InsertRune('\n')
			a.refreshCompletions()
			return a, nil
		}
		// Vibe-style: Enter on a completion applies it, then submits (Tab applies only).
		if a.Popup.Visible {
			if item, ok := a.Popup.Selected(); ok {
				a.applyCompletion(item)
			}
		}
		text := strings.TrimSpace(a.Input.Value())
		if text == "" {
			return a, nil
		}
		a.Input.Reset()
		a.Popup.Hide()
		return a.dispatchSubmittedInput(text)
	}
	var cmd tea.Cmd
	a.Input, cmd = a.Input.Update(msg)
	a.refreshCompletions()
	return a, cmd
}

func (a App) dispatchSubmittedInput(value string) (tea.Model, tea.Cmd) {
	if cmd, args, ok := ParseSlash(value); ok {
		return a.handleCommand(cmd, args)
	}
	if strings.HasPrefix(value, "!") {
		return a.handleBashCommand(strings.TrimPrefix(value, "!"))
	}
	if a.Busy {
		a.Queue.Enqueue(value)
		a.Status = fmt.Sprintf("Queued (%d)", a.Queue.Len())
		return a, nil
	}
	return a.handleUserMessage(value)
}

func (a App) handleUserMessage(message string) (tea.Model, tea.Cmd) {
	a.Busy = true
	a.InterruptReq = false
	a.Loading = widgets.NewLoadingWidget("Generating", true)
	a.Status = a.Loading.View()
	a.ensureLoading("Generating")
	return a, tea.Batch(a.submit(message), spinnerTickCmd())
}

func (a App) onAgentDone(msg agentDoneMsg) (tea.Model, tea.Cmd) {
	a.Busy = false
	if a.Loading != nil {
		a.Loading.StopSpinning(msg.Err == nil)
	}
	if msg.Err != nil {
		a.Status = "error: " + a.resolveTurnErrorMessage(msg.Err)
		a.debugf("turn error: %v", msg.Err)
	} else {
		a.Status = "ready"
		for _, ev := range msg.Events {
			a.Handler.Handle(ev)
		}
		if a.Runtime != nil {
			a.Messages = append([]types.LLMMessage{}, a.Runtime.Messages...)
			a.refreshWindowingFromHistory()
		}
		if msg.Text != "" {
			a.LastAssistant = msg.Text
		}
		a.refreshViewport()
	}
	a.removeLoading()
	if queued := a.Queue.PopAll(); len(queued) > 0 {
		a.Busy = true
		return a, a.submit(strings.Join(queued, "\n"))
	}
	return a, nil
}

func (a App) updatePanel(msg tea.Msg) (tea.Model, tea.Cmd) {
	switch a.activePanel {
	case panelModel:
		m, cmd := a.modelPanel.Update(msg)
		a.modelPanel = m.(panels.ModelPicker)
		if a.modelPanel.Done {
			if a.modelPanel.Choice != "" && !a.modelPanel.Cancelled {
				a.Cfg.ActiveModel = a.modelPanel.Choice
				_ = config.Save(a.Cfg)
				a.Status = "model → " + a.modelPanel.Choice
				a.reloadConfig()
			}
			a.activePanel = panelNone
			a.switchToInputPanel()
		}
		return a, cmd
	case panelTheme:
		m, cmd := a.themePanel.Update(msg)
		a.themePanel = m.(panels.ThemePicker)
		if preview, ok := msg.(panels.ThemePreviewMsg); ok {
			a.Theme = GetTheme(preview.Theme)
		}
		if a.themePanel.Done {
			if a.themePanel.Cancelled {
				a.Theme = GetTheme(a.themePanel.OriginalTheme)
			} else if a.themePanel.Choice != "" {
				a.Cfg.Theme = a.themePanel.Choice
				a.Theme = GetTheme(a.themePanel.Choice)
				_ = config.Save(a.Cfg)
			}
			a.activePanel = panelNone
			a.switchToInputPanel()
		}
		return a, cmd
	case panelConfig:
		m, cmd := a.configPanel.Update(msg)
		a.configPanel = m.(panels.ConfigPanel)
		if a.configPanel.Done {
			a.handleConfigSettingsClosed(a.configPanel.Changes)
			if a.configPanel.OpenModel {
				a.activePanel = panelNone
				return a.showModel()
			}
			if a.configPanel.OpenThinking {
				a.activePanel = panelNone
				return a.showThinking()
			}
			a.activePanel = panelNone
			a.switchToInputPanel()
		}
		return a, cmd
	case panelThinking:
		m, cmd := a.thinkPanel.Update(msg)
		a.thinkPanel = m.(panels.ThinkingPicker)
		if a.thinkPanel.Done {
			if !a.thinkPanel.Cancelled && a.thinkPanel.Choice != "" {
				a.ThinkingLevel = a.thinkPanel.Choice
				a.Status = "thinking → " + a.thinkPanel.Choice
			}
			a.activePanel = panelNone
			a.switchToInputPanel()
		}
		return a, cmd
	case panelApproval:
		m, cmd := a.approvalPanel.Update(msg)
		a.approvalPanel = m.(panels.ApprovalPanel)
		if a.approvalPanel.Done {
			a.handleApprovalResult(a.approvalPanel.Result)
			a.activePanel = panelNone
			if a.Loading != nil {
				a.Loading.ResumeTimer()
			}
			a.switchToInputPanel()
		}
		return a, cmd
	case panelQuestion:
		m, cmd := a.questionPanel.Update(msg)
		a.questionPanel = m.(panels.QuestionPanel)
		if a.questionPanel.Done {
			cancelled := a.questionPanel.Cancelled
			answer := ""
			if cancelled {
				a.Status = "question cancelled"
			} else {
				answer = a.questionPanel.Answer()
				a.Status = "answered: " + answer
			}
			if a.questionReplyCh != nil {
				a.questionReplyCh <- questionReply{Answer: answer, Cancelled: cancelled}
				a.questionReplyCh = nil
			}
			a.activePanel = panelNone
			if a.Loading != nil {
				a.Loading.ResumeTimer()
			}
			a.switchToInputPanel()
		}
		return a, cmd
	case panelMCP:
		m, cmd := a.mcpPanel.Update(msg)
		a.mcpPanel = m.(panels.MCPPanel)
		if a.mcpPanel.Done {
			res := a.mcpPanel.Result
			switch res.Outcome {
			case panels.MCPOutcomeAuthRequested:
				a.connectorPanel = panels.NewConnectorAuthPanel(res.AuthSource, "")
				a.activePanel = panelConnector
				return a, cmd
			case panels.MCPOutcomeToggled:
				a.Status = fmt.Sprintf("mcp toggle %s/%s disabled=%v", res.SourceName, res.ToolName, res.Disabled)
				a.activePanel = panelNone
			default:
				a.activePanel = panelNone
			}
			a.switchToInputPanel()
		}
		return a, cmd
	case panelConnector:
		m, cmd := a.connectorPanel.Update(msg)
		a.connectorPanel = m.(panels.ConnectorAuthPanel)
		if a.connectorPanel.Done {
			res := a.connectorPanel.Result
			if res.OpenedBrowser && res.AuthURL != "" {
				_ = openBrowser(res.AuthURL)
			}
			a.Status = "connector auth closed: " + res.ConnectorName
			a.activePanel = panelNone
			a.switchToInputPanel()
		}
		return a, cmd
	case panelProxy:
		m, cmd := a.proxyPanel.Update(msg)
		a.proxyPanel = m.(panels.ProxySetupPanel)
		if a.proxyPanel.Done {
			res := a.proxyPanel.Result()
			if res.Saved {
				_ = os.Setenv("HTTP_PROXY", res.HTTPProxy)
				_ = os.Setenv("HTTPS_PROXY", res.HTTPSProxy)
				_ = os.Setenv("NO_PROXY", res.NoProxy)
				a.Status = "proxy settings applied"
			}
			a.activePanel = panelNone
			a.switchToInputPanel()
		}
		return a, cmd
	case panelRewind:
		m, cmd := a.rewindPanel.Update(msg)
		a.rewindPanel = m.(panels.RewindPanel)
		if a.rewindPanel.Done {
			switch a.rewindPanel.Outcome {
			case panels.RewindOutcomeWithRestore:
				a.executeRewind(true)
			case panels.RewindOutcomeWithoutRestore:
				a.executeRewind(false)
			}
			a.activePanel = panelNone
			a.exitRewindMode()
			a.switchToInputPanel()
		}
		return a, cmd
	case panelSession:
		m, cmd := a.sessionPanel.Update(msg)
		a.sessionPanel = m.(panels.SessionPicker)
		if a.sessionPanel.Done {
			if a.sessionPanel.Choice != nil && !a.sessionPanel.Cancelled {
				a.resumeLocalSession(*a.sessionPanel.Choice)
			}
			a.activePanel = panelNone
			a.switchToInputPanel()
		}
		return a, cmd
	}
	a.activePanel = panelNone
	return a, nil
}

func (a *App) handleApprovalResult(res panels.ApprovalResult) {
	resp := types.ApprovalNo
	feedback := "denied"
	switch res.Outcome {
	case panels.ApprovalOnce:
		resp = types.ApprovalYes
		feedback = "approved once"
		a.Status = "approved once: " + res.ToolName
		if a.Runtime != nil {
			a.Runtime.SetToolPermission(res.ToolName, tools.PermissionAsk, false)
		}
	case panels.ApprovalSession:
		resp = types.ApprovalYes
		feedback = "approved for session"
		a.Status = "approved for session: " + res.ToolName
		if a.Runtime != nil {
			a.Runtime.ApproveAlways(res.ToolName, res.RequiredPermissions, false)
		}
	case panels.ApprovalPermanent:
		resp = types.ApprovalYes
		feedback = "always allow"
		a.Status = "always allow: " + res.ToolName
		if a.Runtime != nil {
			a.Runtime.ApproveAlways(res.ToolName, res.RequiredPermissions, true)
		}
	default:
		a.Status = "denied: " + res.ToolName
	}
	if a.approvalReplyCh != nil {
		a.approvalReplyCh <- approvalReply{Response: resp, Feedback: feedback}
		a.approvalReplyCh = nil
	}
}

func (a *App) handleConfigSettingsClosed(changes map[string]any) {
	if len(changes) == 0 {
		return
	}
	_ = config.Save(a.Cfg)
	a.Status = fmt.Sprintf("settings updated (%d changes)", len(changes))
	a.reloadConfig()
}

func (a App) handleCommand(cmd, args string) (tea.Model, tea.Cmd) {
	switch cmd {
	case "help":
		return a.showHelp()
	case "quit", "exit":
		return a, tea.Quit
	case "clear", "new":
		a._clearHistory()
		if strings.TrimSpace(args) != "" {
			return a, a.submit(strings.TrimSpace(args))
		}
	case "model":
		return a.showModel()
	case "theme":
		return a.showTheme()
	case "config":
		return a.showConfig()
	case "thinking":
		return a.showThinking()
	case "mcp", "connectors":
		return a.showMCP(args)
	case "proxy", "proxy-setup":
		return a.showProxySetup()
	case "setup", "onboard", "provider":
		return a.launchSetupFlow()
	case "sessions", "resume", "continue", "session":
		return a.showSessionPicker()
	case "rewind":
		return a.startRewindMode()
	case "status":
		a.showStatus()
	case "copy":
		a.copyLastAgentMessage()
	case "compact":
		a.Status = a.runCompact(args)
	case "rename":
		a.renameSession(args)
	case "debug":
		a.DebugOpen = !a.DebugOpen
	case "log":
		a.showLogPath()
	case "log-level":
		a.Status = a.setLogLevel(args)
	case "reload":
		a.reloadConfig()
		a.Status = "reloaded config / instructions / skills"
	case "skills":
		a.Status = a.showSkills()
	case "voice":
		text := a.showVoiceSettings()
		a = a.mountAssistantStatus(text)
		a.Status = "voice"
	case "retry":
		return a.runRetryReal(args)
	case "branch":
		a.Status = a.branchSessionReal()
	case "loop":
		a.Status = a.runLoopCommandReal(args)
	case "data-retention":
		text := a.showDataRetention()
		a = a.mountAssistantStatus(text)
		a.Status = "data-retention"
	case "whoami":
		a.Status = a.showWhoami()
	case "paste-image":
		a.Status = a.pasteImage(args)
	case "plugins":
		text := a.showPlugins()
		a = a.mountAssistantStatus(text)
		a.Status = "plugins"
	case "reload-plugins":
		a.Status = a.reloadPlugins()
	default:
		if _, ok := a.CommandRegistry[cmd]; ok {
			a.Status = "command /" + cmd + " not fully wired yet"
		} else {
			a.Status = "unknown command: /" + cmd
		}
	}
	_ = args
	return a, nil
}

func (a App) handleBashCommand(command string) (tea.Model, tea.Cmd) {
	a.Busy = true
	a.Status = "running !" + command
	return a, func() tea.Msg {
		ctx, cancel := context.WithTimeout(context.Background(), 2*time.Minute)
		defer cancel()
		c := exec.CommandContext(ctx, "bash", "-lc", command)
		out, err := c.CombinedOutput()
		text := string(out)
		if err != nil {
			return agentDoneMsg{Text: text, Err: err}
		}
		// Mount as a synthetic assistant/user pair via runtime messages if available
		return agentDoneMsg{Text: text}
	}
}

func (a App) showHelp() (tea.Model, tea.Cmd) {
	keys := make([]string, 0, len(a.CommandRegistry))
	for k := range a.CommandRegistry {
		keys = append(keys, k)
	}
	sort.Strings(keys)
	var b strings.Builder
	b.WriteString("Slash commands\n")
	for _, k := range keys {
		desc := a.CommandRegistry[k]
		if desc == "" {
			fmt.Fprintf(&b, "  /%s\n", k)
		} else {
			fmt.Fprintf(&b, "  /%-16s %s\n", k, desc)
		}
	}
	msg := types.NewMessage(types.RoleAssistant, b.String())
	a.Messages = append(a.Messages, msg)
	if a.Runtime != nil {
		a.Runtime.Messages = append(a.Runtime.Messages, msg)
	}
	a.Status = fmt.Sprintf("help (%d commands)", len(keys))
	a.refreshViewport()
	return a, nil
}

func (a App) showModel() (tea.Model, tea.Cmd) {
	a.modelPanel = panels.NewModelPicker(a.Cfg.Models, a.Cfg.ActiveModel)
	a.activePanel = panelModel
	return a, nil
}

func (a App) showTheme() (tea.Model, tea.Cmd) {
	names := make([]string, 0, len(Themes))
	for n := range Themes {
		names = append(names, n)
	}
	a.themePanel = panels.NewThemePicker(names, a.Cfg.Theme)
	a.activePanel = panelTheme
	return a, nil
}

func (a App) showConfig() (tea.Model, tea.Cmd) {
	a.configPanel = panels.NewConfigPanel(a.Cfg)
	a.activePanel = panelConfig
	return a, nil
}

func (a App) showThinking() (tea.Model, tea.Cmd) {
	a.thinkPanel = panels.NewThinkingPicker(a.ThinkingLevel)
	a.activePanel = panelThinking
	return a, nil
}

func (a App) showMCP(args string) (tea.Model, tea.Cmd) {
	_ = args
	a.mcpPanel = panels.NewMCPPanel(a.MCPRegistry)
	a.activePanel = panelMCP
	return a, nil
}

func (a App) showProxySetup() (tea.Model, tea.Cmd) {
	a.proxyPanel = panels.NewProxySetupPanel(os.Getenv("HTTP_PROXY"), os.Getenv("HTTPS_PROXY"), os.Getenv("NO_PROXY"))
	a.activePanel = panelProxy
	return a, nil
}

func (a App) showSessionPicker() (tea.Model, tea.Cmd) {
	// Session list is filled by caller/runtime; empty list still shows panel.
	a.sessionPanel = panels.NewSessionPicker(nil)
	a.activePanel = panelSession
	return a, nil
}

func (a *App) showStatus() {
	model := ""
	if a.Cfg != nil {
		model = a.Cfg.ActiveModel
	}
	a.Status = fmt.Sprintf("model=%s agent=%s msgs=%d busy=%v theme=%s thinking=%s",
		model, a.AgentName, len(a.Messages), a.Busy, a.Theme.Name, a.ThinkingLevel)
}

func (a *App) showLogPath() {
	a.Status = "log: " + paths.LogFile()
}

func (a *App) renameSession(title string) {
	title = strings.TrimSpace(title)
	if title == "" {
		a.Status = "usage: /rename <title>"
		return
	}
	a.Status = "session renamed → " + title
}

func (a *App) copyLastAgentMessage() {
	text := a.LastAssistant
	if text == "" {
		text = a.getLastAssistantMessageText()
	}
	if text == "" {
		a.Status = "nothing to copy"
		return
	}
	a.Status = fmt.Sprintf("copied %d chars", len(text))
}

func (a *App) getLastAssistantMessageText() string {
	for i := len(a.Messages) - 1; i >= 0; i-- {
		m := a.Messages[i]
		if m.Role == types.RoleAssistant && m.Content != nil {
			return *m.Content
		}
	}
	return ""
}

func (a *App) _clearHistory() {
	if a.Runtime != nil && len(a.Runtime.Messages) > 0 {
		sys := a.Runtime.Messages[0]
		a.Runtime.Messages = []types.LLMMessage{sys}
		a.Messages = a.Runtime.Messages
	} else {
		a.Messages = nil
	}
	a.HistoryEntries = nil
	a.Windowing.Reset()
	a.refreshViewport()
	a.Status = "history cleared"
}

func (a *App) reloadConfig() {
	if a.Cfg == nil {
		return
	}
	a.Theme = GetTheme(a.Cfg.Theme)
	a.refreshCommandRegistry()
}

func (a *App) switchToInputPanel() {
	a.Input.Focus()
}

func (a *App) ensureLoading(status string) {
	if a.Loading == nil {
		a.Loading = widgets.NewLoadingWidget(status, true)
	} else {
		a.Loading.SetStatus(status)
	}
}

func (a *App) removeLoading() {
	if a.Loading != nil {
		a.Loading.IsSpinning = false
	}
}

func (a *App) resumeHistoryFromMessages() {
	hist := windowing.NonSystemHistoryMessages(a.Messages)
	plan := windowing.CreateResumePlan(hist, windowing.HistoryResumeTailMessages)
	if plan == nil {
		return
	}
	a.ToolCallMap = plan.ToolCallMap
	a.HistoryEntries = windowing.ApplyResume(plan, a.Windowing, a.ToolsCollapsed)
	a.LoadMore.SetVisible(plan.HasBackfill(), a.Windowing.Remaining())
}

func (a *App) refreshWindowingFromHistory() {
	hist := windowing.NonSystemHistoryMessages(a.Messages)
	has, tcmap := windowing.SyncBackfillState(hist, a.HistoryEntries, a.Windowing)
	if tcmap != nil {
		a.ToolCallMap = tcmap
	}
	a.LoadMore.SetVisible(has, a.Windowing.Remaining())
	// rebuild entries from full visible window for display
	if len(hist) > 0 {
		start := a.Windowing.Remaining()
		if start < 0 {
			start = 0
		}
		visible := hist[start:]
		a.HistoryEntries = windowing.BuildHistoryEntries(visible, a.ToolCallMap, start, a.ToolsCollapsed)
	}
}

func (a App) startRewindMode() (tea.Model, tea.Cmd) {
	a.RewindMode = true
	a.RewindIndex = len(a.HistoryEntries) - 1
	for a.RewindIndex >= 0 && a.HistoryEntries[a.RewindIndex].Kind != "user" {
		a.RewindIndex--
	}
	if a.RewindIndex < 0 {
		a.RewindMode = false
		a.Status = "nothing to rewind"
		return a, nil
	}
	a.Status = "rewind mode: ↑↓ select user message, Enter confirm, Esc cancel"
	a.refreshViewport()
	return a, nil
}

func (a App) updateRewindMode(msg tea.Msg) (tea.Model, tea.Cmd) {
	switch msg := msg.(type) {
	case tea.KeyMsg:
		switch msg.String() {
		case "up", "k":
			for i := a.RewindIndex - 1; i >= 0; i-- {
				if a.HistoryEntries[i].Kind == "user" {
					a.RewindIndex = i
					break
				}
			}
			a.refreshViewport()
		case "down", "j":
			for i := a.RewindIndex + 1; i < len(a.HistoryEntries); i++ {
				if a.HistoryEntries[i].Kind == "user" {
					a.RewindIndex = i
					break
				}
			}
			a.refreshViewport()
		case "enter":
			preview := ""
			if a.RewindIndex >= 0 && a.RewindIndex < len(a.HistoryEntries) {
				preview = a.HistoryEntries[a.RewindIndex].Content
			}
			a.rewindPanel = panels.NewRewindPanel(preview, false)
			a.activePanel = panelRewind
			return a, nil
		case "esc":
			a.exitRewindMode()
		}
	}
	return a, nil
}

func (a *App) exitRewindMode() {
	a.RewindMode = false
	a.RewindIndex = -1
	a.Status = "ready"
	a.refreshViewport()
}

func (a *App) executeRewind(restoreFiles bool) {
	if a.RewindIndex < 0 || a.RewindIndex >= len(a.HistoryEntries) {
		return
	}
	entry := a.HistoryEntries[a.RewindIndex]
	// Same code path as /rewind confirm: truncate (+ optional file restore) via rewind.Manager.
	if a.Runtime != nil && a.Runtime.Rewind != nil && entry.MessageIndex >= 0 && entry.MessageIndex < len(a.Runtime.Messages) {
		if _, err := a.Runtime.Rewind.RewindToMessage(entry.MessageIndex, restoreFiles); err != nil {
			a.Status = fmt.Sprintf("rewind failed: %v", err)
			return
		}
		a.Messages = append([]types.LLMMessage{}, a.Runtime.Messages...)
	} else if a.Runtime != nil && entry.MessageIndex > 0 && entry.MessageIndex <= len(a.Runtime.Messages) {
		a.Runtime.Messages = a.Runtime.Messages[:entry.MessageIndex]
		a.Messages = append([]types.LLMMessage{}, a.Runtime.Messages...)
	}
	a.refreshWindowingFromHistory()
	a.refreshViewport()
	a.Status = fmt.Sprintf("rewound to message %d (restore_files=%v)", entry.MessageIndex, restoreFiles)
}

func (a *App) resumeLocalSession(s panels.ResumeSessionInfo) {
	a.Status = "resuming session " + s.ID
	// Actual load is handled by CLI/session loader; mark intent.
}

func cycleableAgentNames() []string {
	return []string{
		agents.AgentAdaptive,
		agents.AgentDefault,
		agents.AgentPlan,
		agents.AgentChat,
		agents.AgentAcceptEdits,
		agents.AgentAutoApprove,
	}
}

func (a *App) cycleAgent() {
	names := cycleableAgentNames()
	cur := a.AgentName
	if a.Runtime != nil {
		if p := a.Runtime.AgentProfile(); p.Name != "" {
			cur = p.Name
		}
	}
	idx := 0
	for i, n := range names {
		if n == cur {
			idx = i
			break
		}
	}
	next := names[(idx+1)%len(names)]
	if a.Runtime != nil {
		if err := a.Runtime.SwitchAgent(context.Background(), next); err != nil {
			a.Status = fmt.Sprintf("agent switch failed: %v", err)
			return
		}
		if p := a.Runtime.AgentProfile(); p.Name != "" {
			next = p.Name
		}
	}
	a.AgentName = next
	a.ProfileName = next
	a.Status = "agent → " + next
}

func (a App) actionOpenPlanInEditor() (tea.Model, tea.Cmd) {
	a.Status = "open plan in editor"
	return a, nil
}

func (a App) startExternalEditor() tea.Cmd {
	initial := a.Input.Value()
	f, err := os.CreateTemp("", "goar-edit-*.md")
	if err != nil {
		return func() tea.Msg { return editorDoneMsg{err: err} }
	}
	path := f.Name()
	_, _ = f.WriteString(initial)
	_ = f.Close()
	editor := os.Getenv("EDITOR")
	if editor == "" {
		editor = "vi"
	}
	c := exec.Command(editor, path)
	return tea.ExecProcess(c, func(err error) tea.Msg {
		b, readErr := os.ReadFile(path)
		_ = os.Remove(path)
		if err != nil {
			return editorDoneMsg{err: err}
		}
		if readErr != nil {
			return editorDoneMsg{err: readErr}
		}
		return editorDoneMsg{text: string(b)}
	})
}

func (a *App) refreshCompletions() {
	if a.Completer == nil {
		a.Popup.Hide()
		return
	}
	a.Completer.Commands = a.CommandRegistry
	items := a.Completer.Complete(a.Input.Value(), len(a.Input.Value()))
	a.Popup.SetItems(items)
}

func (a *App) applyCompletion(item chatinput.CompletionItem) {
	val := a.Input.Value()
	if item.Kind == "command" {
		trim := strings.TrimLeft(val, " \t")
		lead := val[:len(val)-len(trim)]
		a.Input.SetValue(lead + item.InsertText)
		a.refreshCompletions()
		return
	}
	i := strings.LastIndexAny(val, " \t\n")
	if i < 0 {
		if strings.HasPrefix(val, "@") {
			a.Input.SetValue("@" + item.InsertText)
		} else {
			a.Input.SetValue(item.InsertText)
		}
		a.refreshCompletions()
		return
	}
	prefix := val[:i+1]
	tok := val[i+1:]
	if strings.HasPrefix(tok, "@") {
		a.Input.SetValue(prefix + "@" + item.InsertText)
	} else {
		a.Input.SetValue(prefix + item.InsertText)
	}
	a.refreshCompletions()
}

func (a *App) resolveTurnErrorMessage(err error) string {
	if err == nil {
		return ""
	}
	msg := err.Error()
	low := strings.ToLower(msg)
	if strings.Contains(low, "rate limit") {
		return a.rateLimitMessage()
	}
	if strings.Contains(low, "context") && strings.Contains(low, "long") {
		return a.contextTooLongMessage()
	}
	return msg
}

func (a *App) rateLimitMessage() string {
	return "rate limited — wait and retry, or switch model with /model"
}

func (a *App) contextTooLongMessage() string {
	return "context too long — try /compact or /clear"
}

func (a *App) debugf(format string, args ...any) {
	line := fmt.Sprintf(format, args...)
	a.DebugLines = append(a.DebugLines, time.Now().Format("15:04:05")+" "+line)
	if len(a.DebugLines) > 200 {
		a.DebugLines = a.DebugLines[len(a.DebugLines)-200:]
	}
}

func (a App) submit(text string) tea.Cmd {
	a.Recorder.Record("user", text)
	rt := a.Runtime
	return tea.Batch(tickCmd(), func() tea.Msg {
		if rt == nil {
			return agentDoneMsg{Err: fmt.Errorf("runtime not initialized")}
		}
		out, events, err := rt.Act(context.Background(), text)
		return agentDoneMsg{Text: out, Events: events, Err: err}
	})
}

func tickCmd() tea.Cmd {
	return func() tea.Msg { return tickMsg{} }
}

func (a *App) refreshViewport() {
	mv := widgets.MessagesView{Items: a.Messages, Theme: a.Theme, Width: a.Viewport.Width, Entries: a.HistoryEntries, RewindIndex: a.RewindIndex, RewindMode: a.RewindMode}
	content := mv.View()
	if a.LoadMore.Visible {
		content = a.LoadMore.Label() + "\n\n" + content
	}
	a.Viewport.SetContent(content)
	if !a.RewindMode {
		a.Viewport.GotoBottom()
	}
}

func (a App) View() string {
	if a.activePanel != panelNone {
		switch a.activePanel {
		case panelModel:
			return a.modelPanel.View()
		case panelTheme:
			return a.themePanel.View()
		case panelConfig:
			return a.configPanel.View()
		case panelThinking:
			return a.thinkPanel.View()
		case panelApproval:
			return a.approvalPanel.View()
		case panelQuestion:
			return a.questionPanel.View()
		case panelMCP:
			return a.mcpPanel.View()
		case panelProxy:
			return a.proxyPanel.View()
		case panelRewind:
			return a.rewindPanel.View()
		case panelSession:
			return a.sessionPanel.View()
		case panelConnector:
			return a.connectorPanel.View()
		}
	}
	accent := lipgloss.NewStyle().Foreground(a.Theme.Accent)
	muted := lipgloss.NewStyle().Foreground(a.Theme.Muted)
	model := ""
	if a.Cfg != nil {
		model = a.Cfg.ActiveModel
	}
	b := banner.Banner{Version: goar.Version, Model: model, Theme: a.Theme}
	status := a.Status
	if a.Busy && a.Loading != nil {
		status = a.Loading.View()
	} else if a.Busy {
		status = widgets.BrailleSpinner(a.SpinnerN) + " " + status
	}
	header := b.View()
	body := a.Viewport.View()
	input := a.Input.View()
	footer := muted.Render(status) + "  " + accent.Render(fmt.Sprintf("theme=%s agent=%s", a.Theme.Name, a.AgentName))
	parts := []string{header, body}
	if a.DebugOpen {
		dbg := strings.Join(a.DebugLines[max(0, len(a.DebugLines)-8):], "\n")
		parts = append(parts, muted.Render("── debug ──\n"+dbg))
	}
	if a.TodosOpen {
		todo := "No todos yet — the agent fills this list with the todo tool."
		if len(a.TodoLines) > 0 {
			todo = strings.Join(a.TodoLines, "\n")
		}
		parts = append(parts, muted.Render("── todos (Ctrl+T) ──\n"+todo))
	}
	if a.Popup.Visible {
		parts = append(parts, a.Popup.View())
	}
	parts = append(parts, "", input, footer)
	return lipgloss.JoinVertical(lipgloss.Left, parts...)
}

func openBrowser(u string) error {
	for _, c := range [][]string{
		{"xdg-open", u},
		{"open", u},
		{"cmd", "/c", "start", u},
	} {
		cmd := exec.Command(c[0], c[1:]...)
		if err := cmd.Start(); err == nil {
			return nil
		}
	}
	return fmt.Errorf("no browser opener found")
}

func max(a, b int) int {
	if a > b {
		return a
	}
	return b
}

// RunTextualUI launches the Bubble Tea program (port of run_textual_ui).
// Wires Runtime approval + ask-user callbacks to ApprovalPanel / QuestionPanel.
func RunTextualUI(cfg *config.Config, rt *core.Runtime, initial, agent string) error {
	uitheme.EnsureColorProfile()
	app := NewApp(cfg, rt, initial, agent)
	var p *tea.Program
	wireRuntimeUICallbacks(rt, &p)
	p = tea.NewProgram(app, tea.WithAltScreen())
	_, err := p.Run()
	return err
}

// wireRuntimeUICallbacks connects SetApprovalCallback / SetUserInputCallback so
// ask/approval agents surface panels and unblock the tool loop.
func wireRuntimeUICallbacks(rt *core.Runtime, program **tea.Program) {
	if rt == nil || program == nil {
		return
	}
	rt.SetApprovalCallback(func(toolName string, args map[string]any, toolCallID string, required []tools.RequiredPermission) (types.ApprovalResponse, string) {
		_ = toolCallID
		p := *program
		if p == nil {
			return types.ApprovalNo, "UI not ready"
		}
		ch := make(chan approvalReply, 1)
		p.Send(approvalNeededMsg{
			ToolName: toolName,
			Args:     args,
			Summary:  formatToolArgsSummary(toolName, args),
			Perms:    required,
			Reply:    ch,
		})
		reply := <-ch
		return reply.Response, reply.Feedback
	})
	rt.SetUserInputCallback(func(prompt string) (string, error) {
		p := *program
		if p == nil {
			return "", fmt.Errorf("UI not ready")
		}
		ch := make(chan questionReply, 1)
		p.Send(questionNeededMsg{
			Questions: []panels.Question{{Question: prompt, AllowOther: true}},
			Reply:     ch,
		})
		reply := <-ch
		if reply.Cancelled {
			return "", fmt.Errorf("cancelled")
		}
		return reply.Answer, nil
	})
}

func formatToolArgsSummary(toolName string, args map[string]any) string {
	if args == nil || len(args) == 0 {
		return toolName
	}
	if cmd, ok := args["command"]; ok {
		return fmt.Sprintf("%s: %v", toolName, cmd)
	}
	if path, ok := args["path"]; ok {
		return fmt.Sprintf("%s: %v", toolName, path)
	}
	keys := make([]string, 0, len(args))
	for k := range args {
		keys = append(keys, k)
	}
	sort.Strings(keys)
	parts := make([]string, 0, len(keys))
	for _, k := range keys {
		parts = append(parts, fmt.Sprintf("%s=%v", k, args[k]))
	}
	return toolName + ": " + strings.Join(parts, ", ")
}

func (a *App) runCompact(instructions string) string {
	_ = instructions
	if a.Runtime == nil {
		return "compact: no runtime"
	}
	// Best-effort: clear older turns via clear+note; full summarizer hooks via runtime when available.
	n := len(a.Messages)
	if n == 0 {
		return "compact: nothing to compact"
	}
	a.Status = "compaction requested"
	return fmt.Sprintf("compaction requested (%d messages)", n)
}

func (a *App) setLogLevel(args string) string {
	lvl := strings.TrimSpace(strings.ToLower(args))
	if lvl == "" {
		return "usage: /log-level debug|info|warn|error"
	}
	switch lvl {
	case "debug", "info", "warn", "warning", "error":
		if a.Cfg != nil {
			// Persist lightly via env for session
			_ = os.Setenv("AGENT_LOG_LEVEL", lvl)
		}
		return "log level set to " + lvl + " (session)"
	default:
		return "unknown log level: " + lvl
	}
}

func (a *App) showSkills() string {
	return "Skills: use AGENT_HOME/skills (reload with /reload). Browse via config when catalog is empty."
}

func (a *App) runRetry(args string) string {
	extra := strings.TrimSpace(args)
	if a.Busy {
		return "retry: agent is still running"
	}
	if extra != "" {
		return "retry: will re-submit last turn with: " + extra
	}
	return "retry: will re-submit last user turn"
}

func (a *App) branchSession() string { return a.branchSessionReal() }

func (a *App) runLoopCommand(args string) string { return a.runLoopCommandReal(args) }

func (a *App) showWhoami() string {
	model := ""
	if a.Cfg != nil {
		model = a.Cfg.ActiveModel
	}
	return fmt.Sprintf("provider-agnostic · model=%s · local AGENT_HOME", model)
}
