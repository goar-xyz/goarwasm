package textualui

const (
	AppTitle           = "GOAR"
	DefaultTheme       = "goar-dark"
	MaxVisibleMessages = 500
	InputPlaceholder   = "Message GOAR… (/ for commands, @ for paths, ! for shell)"
)
