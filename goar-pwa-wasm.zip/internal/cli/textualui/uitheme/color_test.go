package uitheme

import (
	"os"
	"path/filepath"
	"strings"
	"testing"

	"github.com/charmbracelet/lipgloss"
	"github.com/muesli/termenv"
)

func TestAccentRedANSI(t *testing.T) {
	t.Setenv("NO_COLOR", "")
	t.Setenv("COLORTERM", "truecolor")
	t.Setenv("TERM", "xterm-256color")
	ApplyColorProfileForTest()
	if lipgloss.ColorProfile() == termenv.Ascii {
		t.Fatalf("expected non-ascii profile with COLORTERM=truecolor, got ascii")
	}
	sample := AccentSample()
	if !strings.Contains(sample, "\x1b[") {
		t.Fatalf("accent sample missing ANSI escapes: %q", sample)
	}
	outDir := "/workspace/goar-go-shots/gaps"
	if err := os.MkdirAll(outDir, 0o755); err != nil {
		t.Fatalf("mkdir: %v", err)
	}
	proof := filepath.Join(outDir, "03-cli-red.txt")
	var body strings.Builder
	body.WriteString("CLI red accent proof\n")
	body.WriteString("theme accent: #E11D2E\n")
	body.WriteString("COLORTERM=" + os.Getenv("COLORTERM") + " TERM=" + os.Getenv("TERM") + "\n")
	body.WriteString("lipgloss profile: " + ColorProfileName() + "\n")
	body.WriteString("sample (raw ANSI):\n")
	body.WriteString(sample)
	body.WriteString("\n")
	body.WriteString("esc-dump: ")
	body.WriteString(strings.ReplaceAll(sample, "\x1b", "ESC"))
	body.WriteString("\n")
	if strings.Contains(sample, "38;2;225;29;46") {
		body.WriteString("rgb: 225,29,46 (#E11D2E) present in truecolor SGR\n")
	} else {
		body.WriteString("note: profile may map #E11D2E to nearest ANSI256 red; sample still colored\n")
		body.WriteString("expected truecolor SGR contains 38;2;225;29;46 when profile=truecolor\n")
	}
	if err := os.WriteFile(proof, []byte(body.String()), 0o644); err != nil {
		t.Fatalf("write proof: %v", err)
	}
}

func TestNoColorForcesAscii(t *testing.T) {
	t.Setenv("NO_COLOR", "1")
	t.Setenv("COLORTERM", "truecolor")
	t.Setenv("TERM", "xterm-256color")
	ApplyColorProfileForTest()
	if lipgloss.ColorProfile() != termenv.Ascii {
		t.Fatalf("NO_COLOR should force ascii, got %v", lipgloss.ColorProfile())
	}
}
