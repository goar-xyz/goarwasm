package uitheme

import (
	"os"
	"strings"
	"sync"

	"github.com/charmbracelet/lipgloss"
	"github.com/muesli/termenv"
)

var (
	colorOnce sync.Once
	colorMu   sync.Mutex
)

// EnsureColorProfile forces lipgloss to use truecolor / 256-color when the
// environment advertises it. Without this, termenv often picks Ascii when
// stdout is not a TTY (tests, pipes, some IDE runners), stripping brand red.
//
// Rules:
//   - NO_COLOR set → Ascii (respect user preference)
//   - COLORTERM=truecolor|24bit → TrueColor
//   - TERM contains 256color / truecolor / xterm → TrueColor or ANSI256
//   - otherwise leave termenv auto-detect (never force-mono incorrectly)
func EnsureColorProfile() {
	colorOnce.Do(func() { applyColorProfile() })
}

// ApplyColorProfileForTest re-applies profile selection (tests only).
func ApplyColorProfileForTest() {
	colorMu.Lock()
	defer colorMu.Unlock()
	applyColorProfile()
}

func applyColorProfile() {
	if os.Getenv("NO_COLOR") != "" {
		lipgloss.SetColorProfile(termenv.Ascii)
		return
	}
	colorTerm := strings.ToLower(strings.TrimSpace(os.Getenv("COLORTERM")))
	term := strings.ToLower(strings.TrimSpace(os.Getenv("TERM")))
	switch {
	case colorTerm == "truecolor" || colorTerm == "24bit" || strings.Contains(term, "truecolor"):
		lipgloss.SetColorProfile(termenv.TrueColor)
	case strings.Contains(term, "256color"):
		// Prefer TrueColor when COLORTERM is set at all; else ANSI256 so hex
		// accents still map to a vivid red rather than being stripped.
		if colorTerm != "" {
			lipgloss.SetColorProfile(termenv.TrueColor)
		} else {
			lipgloss.SetColorProfile(termenv.ANSI256)
		}
	case strings.Contains(term, "xterm") || strings.Contains(term, "screen") || strings.Contains(term, "tmux"):
		lipgloss.SetColorProfile(termenv.ANSI256)
	default:
		// Do not force Ascii. If auto-detect collapsed to Ascii on a non-dumb
		// TERM, bump to ANSI256 so brand accents remain visible.
		p := lipgloss.ColorProfile()
		if p == termenv.Ascii && term != "" && term != "dumb" {
			lipgloss.SetColorProfile(termenv.ANSI256)
		}
	}
}

// AccentSample renders the brand accent swatch with ANSI escape sequences.
func AccentSample() string {
	EnsureColorProfile()
	th := Get(DefaultTheme)
	style := lipgloss.NewStyle().Foreground(th.Accent).Bold(true)
	return style.Render("GOAR accent #E11D2E")
}

// ColorProfileName returns a short label for the active lipgloss profile.
func ColorProfileName() string {
	EnsureColorProfile()
	switch lipgloss.ColorProfile() {
	case termenv.TrueColor:
		return "truecolor"
	case termenv.ANSI256:
		return "ansi256"
	case termenv.ANSI:
		return "ansi"
	default:
		return "ascii"
	}
}
