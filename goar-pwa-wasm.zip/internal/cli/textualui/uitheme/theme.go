package uitheme

import "github.com/charmbracelet/lipgloss"

const DefaultTheme = "goar-dark"

// Theme holds UI colors.
type Theme struct {
	Name       string
	Background lipgloss.Color
	Foreground lipgloss.Color
	Accent     lipgloss.Color
	Muted      lipgloss.Color
	Error      lipgloss.Color
	Success    lipgloss.Color
	Border     lipgloss.Color
}

var Themes = map[string]Theme{
	"goar-dark": {
		Name: "goar-dark", Background: "#0B0D10", Foreground: "#E8E4D9",
		Accent: "#E11D2E", Muted: "#8B93A7", Error: "#E25B4A", Success: "#3DDC97", Border: "#3A4250",
	},
	"goar-light": {
		Name: "goar-light", Background: "#E8E4D9", Foreground: "#0B0D10",
		Accent: "#C4121F", Muted: "#5A6270", Error: "#B33A2E", Success: "#1FA870", Border: "#C5C0B4",
	},
}

func Get(name string) Theme {
	if t, ok := Themes[name]; ok {
		return t
	}
	return Themes[DefaultTheme]
}

func Names() []string {
	out := make([]string, 0, len(Themes))
	for n := range Themes {
		out = append(out, n)
	}
	return out
}
