//go:build js && wasm

package textualui

import (
	"fmt"

	"github.com/goarxyz/goar/internal/core"
	"github.com/goarxyz/goar/internal/core/config"
)

// App is a compile-time stub; the interactive Bubble Tea app is native-only.
type App struct{}

// NewApp returns an empty stub App under WASM.
func NewApp(cfg *config.Config, rt *core.Runtime, initial, agent string) App {
	_, _, _, _ = cfg, rt, initial, agent
	return App{}
}

// RunTextualUI refuses to start a terminal UI in the browser.
// Runtime UI is the PWA chat which drives core.RunProgrammatic via goar.runAgent.
func RunTextualUI(cfg *config.Config, rt *core.Runtime, initial, agent string) error {
	_, _, _, _ = cfg, rt, initial, agent
	return fmt.Errorf("textual UI is not available under GOOS=js/wasm; use PWA goar.runAgent")
}
