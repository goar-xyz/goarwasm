package textualui

import (
	"context"
	"fmt"
	"strings"
	"sync"
	"time"

	"github.com/goarxyz/goar/internal/core"
	"github.com/goarxyz/goar/internal/core/session"
)

// LoopCommandKind classifies /loop command outcomes.
type LoopCommandKind string

const (
	LoopCommandList  LoopCommandKind = "list"
	LoopCommandOK    LoopCommandKind = "ok"
	LoopCommandError LoopCommandKind = "error"
)

// LoopCommandResult is returned by HandleCommand.
type LoopCommandResult struct {
	Kind    LoopCommandKind
	Message string
	Loops   []core.ScheduledLoop
}

// ScheduledLoopRunner fires due loops into a callback (Python ScheduledLoopRunner).
type ScheduledLoopRunner struct {
	mu       sync.Mutex
	Logger   *session.Logger
	Manager  *core.LoopManager
	CanFire  func() bool
	OnFire   func(prompt string)
	OnMount  func(message string)
	Interval time.Duration
	cancel   context.CancelFunc
}

// NewScheduledLoopRunner constructs a runner bound to a session logger.
func NewScheduledLoopRunner(logger *session.Logger) *ScheduledLoopRunner {
	return &ScheduledLoopRunner{
		Logger:   logger,
		Manager:  core.NewLoopManager(logger),
		Interval: time.Second,
		CanFire:  func() bool { return true },
	}
}

// RestoreFromSession reloads loops from session metadata.
func (r *ScheduledLoopRunner) RestoreFromSession() {
	if r.Logger == nil || r.Manager == nil {
		return
	}
	meta := r.Logger.SessionMetadata()
	if meta == nil {
		return
	}
	r.Manager.Restore(meta.Loops)
}

// Start begins the poll loop.
func (r *ScheduledLoopRunner) Start(ctx context.Context) {
	r.mu.Lock()
	if r.cancel != nil {
		r.mu.Unlock()
		return
	}
	ctx, cancel := context.WithCancel(ctx)
	r.cancel = cancel
	interval := r.Interval
	if interval <= 0 {
		interval = time.Second
	}
	r.mu.Unlock()

	go r.poll(ctx, interval)
}

// Stop cancels the poll loop.
func (r *ScheduledLoopRunner) Stop() {
	r.mu.Lock()
	defer r.mu.Unlock()
	if r.cancel != nil {
		r.cancel()
		r.cancel = nil
	}
}

func (r *ScheduledLoopRunner) poll(ctx context.Context, interval time.Duration) {
	t := time.NewTicker(interval)
	defer t.Stop()
	for {
		select {
		case <-ctx.Done():
			return
		case <-t.C:
			now := float64(time.Now().UnixNano()) / 1e9
			sleepHint := r.Manager.NextDueIn(now)
			if sleepHint > 1 {
				// ticker already ~1s; nothing due soon
			}
			if r.CanFire != nil && !r.CanFire() {
				continue
			}
			due := r.Manager.PopDue(now)
			if due == nil {
				continue
			}
			if r.OnFire != nil {
				r.OnFire(due.Prompt)
			}
			if r.OnMount != nil {
				r.OnMount(fmt.Sprintf("Loop `%s` fired", due.ID))
			}
		}
	}
}

// HandleCommand processes /loop command arguments (Python handle_command).
func (r *ScheduledLoopRunner) HandleCommand(cmdArgs string) LoopCommandResult {
	args := strings.TrimSpace(cmdArgs)
	if args == "" || args == "list" {
		loops := r.Manager.Loops()
		return LoopCommandResult{Kind: LoopCommandList, Message: formatLoopList(loops), Loops: loops}
	}
	parts := strings.Fields(args)
	if len(parts) == 0 {
		return LoopCommandResult{Kind: LoopCommandError, Message: core.UsageHint()}
	}
	switch parts[0] {
	case "cancel":
		id := "all"
		if len(parts) > 1 {
			id = parts[1]
		}
		n := r.Manager.Cancel(id)
		return LoopCommandResult{Kind: LoopCommandOK, Message: fmt.Sprintf("Cancelled %d loop(s).", n)}
	case "add":
		if len(parts) < 3 {
			return LoopCommandResult{Kind: LoopCommandError, Message: "usage: /loop add <interval> <prompt>\n" + core.UsageHint()}
		}
		interval := parts[1]
		prompt := strings.TrimSpace(strings.TrimPrefix(args, "add "+interval))
		if err := r.Manager.Add(interval, prompt); err != nil {
			return LoopCommandResult{Kind: LoopCommandError, Message: err.Error() + "\n" + core.UsageHint()}
		}
		return LoopCommandResult{Kind: LoopCommandOK, Message: fmt.Sprintf("Scheduled loop every %s.", interval)}
	default:
		// Shorthand: /loop 5m prompt...
		if len(parts) >= 2 {
			interval := parts[0]
			prompt := strings.TrimSpace(strings.TrimPrefix(args, interval))
			if err := r.Manager.Add(interval, prompt); err != nil {
				return LoopCommandResult{Kind: LoopCommandError, Message: err.Error() + "\n" + core.UsageHint()}
			}
			return LoopCommandResult{Kind: LoopCommandOK, Message: fmt.Sprintf("Scheduled loop every %s.", interval)}
		}
		return LoopCommandResult{Kind: LoopCommandError, Message: core.UsageHint()}
	}
}

func formatLoopList(loops []core.ScheduledLoop) string {
	if len(loops) == 0 {
		return "No scheduled loops."
	}
	now := float64(time.Now().UnixNano()) / 1e9
	rows := []string{"| Prompt | Next in | Every | ID |", "|--------|------|-------|----|"}
	for _, loop := range loops {
		remaining := core.FormatDuration(maxInt(0, int(loop.NextFireAt-now)), true)
		interval := core.FormatDuration(loop.IntervalSeconds, false)
		prompt := strings.ReplaceAll(strings.ReplaceAll(loop.Prompt, "|", "\\|"), "\n", " ")
		rows = append(rows, fmt.Sprintf("| %s | %s | %s | `%s` |", prompt, remaining, interval, loop.ID))
	}
	return strings.Join(rows, "\n")
}

func maxInt(a, b int) int {
	if a > b {
		return a
	}
	return b
}
