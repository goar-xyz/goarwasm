package widgets

import (
	"sync"
	"time"

	"github.com/charmbracelet/lipgloss"
	"github.com/goarxyz/goar/internal/cli/textualui/uitheme"
)

// StatusMessage shows a spinning or settled status line (Python StatusMessage).
type StatusMessage struct {
	mu           sync.Mutex
	Text         string
	Kind         string // info|warn|error|success
	Theme        uitheme.Theme
	Success      bool
	spinning     bool
	frame        int
	frames       []string
	tickerStop   chan struct{}
}

// NewStatusMessage constructs a status widget with optional initial text.
func NewStatusMessage(initial string) *StatusMessage {
	s := &StatusMessage{
		Text:     initial,
		Success:  true,
		spinning: true,
		frames:   []string{"⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏"},
	}
	return s
}

// StartSpinner begins frame animation (caller may ignore when using View ticks).
func (s *StatusMessage) StartSpinner() {
	s.mu.Lock()
	defer s.mu.Unlock()
	s.spinning = true
}

// StopSpinning settles the indicator (Python stop_spinning).
func (s *StatusMessage) StopSpinning(success bool) {
	s.mu.Lock()
	defer s.mu.Unlock()
	s.spinning = false
	s.Success = success
	if success {
		s.Kind = "success"
	} else {
		s.Kind = "error"
	}
}

// SetText updates the status text.
func (s *StatusMessage) SetText(text string) {
	s.mu.Lock()
	defer s.mu.Unlock()
	s.Text = text
}

// Tick advances the spinner frame.
func (s *StatusMessage) Tick() {
	s.mu.Lock()
	defer s.mu.Unlock()
	if !s.spinning || len(s.frames) == 0 {
		return
	}
	s.frame = (s.frame + 1) % len(s.frames)
}

// Indicator returns the current icon glyph.
func (s *StatusMessage) Indicator() string {
	s.mu.Lock()
	defer s.mu.Unlock()
	if s.spinning && len(s.frames) > 0 {
		return s.frames[s.frame]
	}
	if s.Success {
		return "✓"
	}
	return "✕"
}

// GetContent returns the text content (Python get_content).
func (s *StatusMessage) GetContent() string {
	s.mu.Lock()
	defer s.mu.Unlock()
	return s.Text
}

// View renders indicator + text.
func (s *StatusMessage) View() string {
	c := s.Theme.Muted
	switch s.Kind {
	case "error":
		c = s.Theme.Error
	case "success":
		c = s.Theme.Success
	case "warn":
		c = s.Theme.Accent
	}
	ind := s.Indicator()
	text := s.GetContent()
	style := lipgloss.NewStyle().Foreground(c)
	return style.Render(ind + " " + text)
}

// RunSpinnerUntil drives Tick until stop is closed (optional helper).
func (s *StatusMessage) RunSpinnerUntil(stop <-chan struct{}, every time.Duration) {
	if every <= 0 {
		every = 80 * time.Millisecond
	}
	t := time.NewTicker(every)
	defer t.Stop()
	for {
		select {
		case <-stop:
			return
		case <-t.C:
			s.Tick()
		}
	}
}
