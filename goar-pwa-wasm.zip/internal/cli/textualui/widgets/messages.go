package widgets

import (
	"fmt"
	"strings"

	"github.com/charmbracelet/lipgloss"
	"github.com/goarxyz/goar/internal/cli/textualui/uitheme"
	"github.com/goarxyz/goar/internal/cli/textualui/windowing"
	"github.com/goarxyz/goar/internal/core/types"
)

// MessageKind identifies rendered message widget types (port of messages.py widgets).
type MessageKind string

const (
	KindUser         MessageKind = "user"
	KindAssistant    MessageKind = "assistant"
	KindReasoning    MessageKind = "reasoning"
	KindToolCall     MessageKind = "tool_call"
	KindToolResult   MessageKind = "tool_result"
	KindSlash        MessageKind = "slash"
	KindError        MessageKind = "error"
	KindInterrupt    MessageKind = "interrupt"
	KindBashOutput   MessageKind = "bash"
	KindStatus       MessageKind = "status"
)

// RenderedMessage is a display-side message widget model.
type RenderedMessage struct {
	Kind       MessageKind
	Content    string
	ToolName   string
	Collapsed  bool
	Pending    bool
	Streaming  bool
	Index      int
	Selected   bool // rewind highlight
}

// UserMessage creates a user bubble.
func UserMessage(content string, messageIndex int) RenderedMessage {
	return RenderedMessage{Kind: KindUser, Content: content, Index: messageIndex}
}

// AssistantMessage creates an assistant bubble.
func AssistantMessage(content string) RenderedMessage {
	return RenderedMessage{Kind: KindAssistant, Content: content}
}

// ReasoningMessage creates a collapsible reasoning block.
func ReasoningMessage(content string, collapsed bool) RenderedMessage {
	return RenderedMessage{Kind: KindReasoning, Content: content, Collapsed: collapsed}
}

// ToolCallMessage creates a tool-call indicator.
func ToolCallMessage(toolName string) RenderedMessage {
	return RenderedMessage{Kind: KindToolCall, ToolName: toolName}
}

// ToolResultMessage creates a tool result block.
func ToolResultMessage(toolName, content string, collapsed bool) RenderedMessage {
	return RenderedMessage{Kind: KindToolResult, ToolName: toolName, Content: content, Collapsed: collapsed}
}

// ErrorMessage creates an error bubble.
func ErrorMessage(content string) RenderedMessage {
	return RenderedMessage{Kind: KindError, Content: content}
}

// InterruptMessage creates an interrupt notice.
func InterruptMessage(content string) RenderedMessage {
	return RenderedMessage{Kind: KindInterrupt, Content: content}
}

// BashOutputMessage streams shell output.
type BashOutputMessage struct {
	Command  string
	Output   strings.Builder
	Finished bool
	Spinner  SpinnerState
}

// NewBashOutputMessage starts a bash output widget.
func NewBashOutputMessage(command string) *BashOutputMessage {
	b := &BashOutputMessage{Command: command}
	b.Spinner.InitSpinner(SpinnerBraille)
	return b
}

func (b *BashOutputMessage) Append(s string) { b.Output.WriteString(s) }
func (b *BashOutputMessage) Finish() {
	b.Finished = true
	b.Spinner.StopSpinning(true)
}

func (b *BashOutputMessage) View(theme uitheme.Theme) string {
	muted := lipgloss.NewStyle().Foreground(theme.Muted)
	head := muted.Render("! " + b.Command)
	if !b.Finished {
		head = b.Spinner.Next() + " " + head
	}
	return head + "\n" + b.Output.String()
}

// MessagesView renders conversation history for the viewport.
type MessagesView struct {
	Items       []types.LLMMessage
	Entries     []windowing.HistoryEntry
	Theme       uitheme.Theme
	Width       int
	RewindIndex int
	RewindMode  bool
	ToolsCollapsed bool
}

func (m MessagesView) View() string {
	if len(m.Entries) > 0 {
		return m.viewEntries()
	}
	return m.viewItems()
}

func (m MessagesView) viewItems() string {
	var b strings.Builder
	roleStyle := lipgloss.NewStyle().Bold(true).Foreground(m.Theme.Accent)
	muted := lipgloss.NewStyle().Foreground(m.Theme.Muted)
	for _, msg := range m.Items {
		if msg.Role == types.RoleSystem {
			continue
		}
		b.WriteString(roleStyle.Render(string(msg.Role)))
		b.WriteString("\n")
		content := ""
		if msg.Content != nil {
			content = *msg.Content
		} else {
			content = msg.ContentString()
		}
		b.WriteString(m.wrap(content))
		b.WriteString("\n")
		if msg.ReasoningContent != nil && *msg.ReasoningContent != "" {
			b.WriteString(muted.Render("  reasoning (collapsed)"))
			b.WriteString("\n")
		}
		if len(msg.ToolCalls) > 0 {
			for _, tc := range msg.ToolCalls {
				name := tc.Function.Name
				if name == "" {
					name = "tool"
				}
				b.WriteString(muted.Render("  ↳ call " + name))
				b.WriteString("\n")
			}
		}
		b.WriteString("\n")
	}
	return b.String()
}

func (m MessagesView) viewEntries() string {
	var b strings.Builder
	userStyle := lipgloss.NewStyle().Bold(true).Foreground(m.Theme.Accent)
	asstStyle := lipgloss.NewStyle().Bold(true).Foreground(m.Theme.Foreground)
	muted := lipgloss.NewStyle().Foreground(m.Theme.Muted)
	sel := lipgloss.NewStyle().Background(m.Theme.Accent).Foreground(lipgloss.Color("0"))
	for i, e := range m.Entries {
		selected := m.RewindMode && i == m.RewindIndex
		switch e.Kind {
		case "user":
			head := "you"
			if selected {
				head = sel.Render(" › you ")
			} else {
				head = userStyle.Render(head)
			}
			b.WriteString(head + "\n")
			b.WriteString(m.wrap(e.Content) + "\n\n")
		case "assistant":
			b.WriteString(asstStyle.Render("assistant") + "\n")
			b.WriteString(m.wrap(e.Content) + "\n\n")
		case "reasoning":
			if e.Collapsed {
				b.WriteString(muted.Render("  ▸ reasoning") + "\n\n")
			} else {
				b.WriteString(muted.Render("  reasoning") + "\n")
				b.WriteString(m.wrap(e.Content) + "\n\n")
			}
		case "tool_call":
			b.WriteString(muted.Render("  ↳ " + FormatToolCallSummary(e.ToolName, "calling…")) + "\n")
		case "tool_result":
			if e.Collapsed || m.ToolsCollapsed {
				b.WriteString(muted.Render(fmt.Sprintf("  ✓ %s (collapsed)", e.ToolName)) + "\n")
			} else {
				b.WriteString(muted.Render("  ✓ "+e.ToolName) + "\n")
				b.WriteString(m.wrap(e.Content) + "\n")
			}
			b.WriteString("\n")
		default:
			b.WriteString(m.wrap(e.Content) + "\n\n")
		}
	}
	return b.String()
}

func (m MessagesView) wrap(content string) string {
	if m.Width > 0 {
		return lipgloss.NewStyle().Width(m.Width).Render(content)
	}
	return content
}

// StreamingMessage accumulates streamed assistant text.
type StreamingMessage struct {
	Content strings.Builder
	Stopped bool
}

func (s *StreamingMessage) Append(delta string) {
	if s.Stopped {
		return
	}
	s.Content.WriteString(delta)
}

func (s *StreamingMessage) Stop() { s.Stopped = true }
func (s *StreamingMessage) Text() string { return s.Content.String() }
func (s *StreamingMessage) Empty() bool {
	return strings.TrimSpace(s.Content.String()) == ""
}
