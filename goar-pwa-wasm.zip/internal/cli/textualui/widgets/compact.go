package widgets

import (
	"fmt"

	"github.com/charmbracelet/lipgloss"
	"github.com/goarxyz/goar/internal/cli/textualui/uitheme"
)

// CompactNotice is a simple post-compact notice (legacy).
type CompactNotice struct{ Tokens int }

func (c CompactNotice) View() string {
	return fmt.Sprintf("Compacted context (~%d tokens retained summary)", c.Tokens)
}

// CompactNoticeThemed renders with theme colors.
func (c CompactNotice) ViewThemed(theme uitheme.Theme) string {
	return lipgloss.NewStyle().Foreground(theme.Success).Render(c.View())
}

// CompactProgress tracks compact start/end for the transcript.
type CompactProgress struct {
	Started      bool
	Finished     bool
	OldSessionID string
	NewSessionID string
	SummaryLen   int
}

func (c *CompactProgress) Start() { c.Started = true; c.Finished = false }

func (c *CompactProgress) End(oldID, newID string, summaryLen int) {
	c.Finished = true
	c.OldSessionID = oldID
	c.NewSessionID = newID
	c.SummaryLen = summaryLen
}

func (c CompactProgress) View(theme uitheme.Theme) string {
	if c.Finished {
		return lipgloss.NewStyle().Foreground(theme.Success).Render(
			fmt.Sprintf("Compacted (%d chars) session %s → %s", c.SummaryLen, shortID(c.OldSessionID), shortID(c.NewSessionID)))
	}
	if c.Started {
		return lipgloss.NewStyle().Foreground(theme.Accent).Render("Compacting…")
	}
	return ""
}
