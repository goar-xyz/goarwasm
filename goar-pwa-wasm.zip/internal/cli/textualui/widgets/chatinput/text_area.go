//go:build !(js && wasm)

package chatinput

import (
	"strings"
	"unicode"

	"github.com/charmbracelet/bubbles/textarea"
	tea "github.com/charmbracelet/bubbletea"
)

// TextArea wraps bubbles textarea with Goar-specific behaviors
// (port of chat_input/text_area.py).
type TextArea struct {
	Model          textarea.Model
	History        []string
	HistoryIndex   int
	Draft          string
	SubmitOnEnter  bool
	Multiline      bool
	LastKey        string
	DebounceTyping bool
}

// NewTextArea constructs the input.
func NewTextArea() TextArea {
	ta := textarea.New()
	ta.Placeholder = "Message Goar… (/ for commands, ! for shell)"
	ta.ShowLineNumbers = false
	ta.CharLimit = 0
	ta.SetHeight(3)
	ta.Focus()
	return TextArea{Model: ta, SubmitOnEnter: true, HistoryIndex: -1}
}

func (t TextArea) Init() tea.Cmd { return textarea.Blink }

// Value returns current text.
func (t TextArea) Value() string { return t.Model.Value() }

// SetValue replaces content.
func (t *TextArea) SetValue(s string) { t.Model.SetValue(s) }

// Reset clears the input.
func (t *TextArea) Reset() {
	t.Model.Reset()
	t.HistoryIndex = -1
	t.Draft = ""
}

// PushHistory records a submitted line.
func (t *TextArea) PushHistory(s string) {
	s = strings.TrimSpace(s)
	if s == "" {
		return
	}
	if len(t.History) > 0 && t.History[len(t.History)-1] == s {
		return
	}
	t.History = append(t.History, s)
	if len(t.History) > 500 {
		t.History = t.History[len(t.History)-500:]
	}
	t.HistoryIndex = -1
	t.Draft = ""
}

func (t *TextArea) historyUp() {
	if len(t.History) == 0 {
		return
	}
	if t.HistoryIndex < 0 {
		t.Draft = t.Model.Value()
		t.HistoryIndex = len(t.History) - 1
	} else if t.HistoryIndex > 0 {
		t.HistoryIndex--
	}
	t.Model.SetValue(t.History[t.HistoryIndex])
}

func (t *TextArea) historyDown() {
	if t.HistoryIndex < 0 {
		return
	}
	if t.HistoryIndex+1 >= len(t.History) {
		t.HistoryIndex = -1
		t.Model.SetValue(t.Draft)
		return
	}
	t.HistoryIndex++
	t.Model.SetValue(t.History[t.HistoryIndex])
}

// SubmittedMsg is emitted when the user submits.
type SubmittedMsg struct{ Value string }

func (t TextArea) Update(msg tea.Msg) (TextArea, tea.Cmd) {
	switch msg := msg.(type) {
	case tea.KeyMsg:
		t.LastKey = msg.String()
		switch msg.String() {
		case "up":
			if t.cursorOnFirstLine() {
				t.historyUp()
				return t, nil
			}
		case "down":
			if t.cursorOnLastLine() {
				t.historyDown()
				return t, nil
			}
		case "enter":
			if msg.Alt || !t.SubmitOnEnter {
				break
			}
			val := strings.TrimSpace(t.Model.Value())
			if val != "" {
				t.PushHistory(val)
				t.Model.Reset()
				return t, func() tea.Msg { return SubmittedMsg{Value: val} }
			}
			return t, nil
		case "ctrl+j", "shift+enter", "alt+enter":
			t.Model.InsertRune('\n')
			return t, nil
		}
	}
	var cmd tea.Cmd
	t.Model, cmd = t.Model.Update(msg)
	return t, cmd
}

func (t TextArea) cursorOnFirstLine() bool {
	v := t.Model.Value()
	// bubbles textarea doesn't expose cursor line easily; approximate: no newline before end
	return !strings.Contains(v, "\n") || strings.Count(v[:min(len(v), t.Model.LineCount())], "\n") == 0
}

func (t TextArea) cursorOnLastLine() bool {
	v := t.Model.Value()
	return !strings.Contains(v, "\n")
}

func (t TextArea) View() string { return t.Model.View() }

func (t TextArea) SetWidth(w int)  { t.Model.SetWidth(w) }
func (t TextArea) SetHeight(h int) { t.Model.SetHeight(h) }
func (t TextArea) Focus()          { t.Model.Focus() }
func (t TextArea) Blur()           { t.Model.Blur() }

// StartsWithSlash reports a slash command prefix.
func (t TextArea) StartsWithSlash() bool {
	v := strings.TrimLeftFunc(t.Model.Value(), unicode.IsSpace)
	return strings.HasPrefix(v, "/")
}

// StartsWithBang reports a shell command prefix.
func (t TextArea) StartsWithBang() bool {
	v := strings.TrimLeftFunc(t.Model.Value(), unicode.IsSpace)
	return strings.HasPrefix(v, "!")
}

func min(a, b int) int {
	if a < b {
		return a
	}
	return b
}
