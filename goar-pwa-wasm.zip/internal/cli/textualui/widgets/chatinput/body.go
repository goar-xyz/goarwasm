//go:build !(js && wasm)

package chatinput

import (
	"strings"

	tea "github.com/charmbracelet/bubbletea"
	"github.com/charmbracelet/lipgloss"
)

// Body is the chat-input body widget (Python chat_input/body.py).
// It composes the text area, completion popup, and submit/cancel chrome.
type Body struct {
	Container
	Placeholder    string
	SubmitLabel    string
	CancelLabel    string
	Disabled       bool
	MultilineHint  string
	BorderColor    lipgloss.Color
	FocusBorder    lipgloss.Color
	LastSubmit     string
	OnSubmit       func(text string) tea.Cmd
	OnCancel       func() tea.Cmd
}

// NewBody constructs the chat input body (alias for NewContainer with body chrome).
func NewBody(commands map[string]string) Body {
	return Body{
		Container:     NewContainer(commands),
		Placeholder:   "Message GOAR…  (/ for commands, @ for files)",
		SubmitLabel:   "send",
		CancelLabel:   "esc",
		MultilineHint: "Ctrl+J newline",
		BorderColor:   lipgloss.Color("240"),
		FocusBorder:   lipgloss.Color("39"),
	}
}

// NewBodyFromContainer wraps an existing container.
func NewBodyFromContainer(c Container) Body {
	b := NewBody(nil)
	b.Container = c
	return b
}

func (b Body) Init() tea.Cmd { return b.Container.Init() }

func (b Body) Update(msg tea.Msg) (Body, tea.Cmd) {
	if b.Disabled {
		return b, nil
	}
	var cmd tea.Cmd
	b.Container, cmd = b.Container.Update(msg)
	switch m := msg.(type) {
	case tea.KeyMsg:
		switch m.String() {
		case "enter":
			if b.ShowPopup && b.Popup.Visible {
				return b, cmd
			}
			text := strings.TrimSpace(b.Input.Value())
			if text == "" {
				return b, cmd
			}
			b.LastSubmit = text
			b.Input.SetValue("")
			b.refreshCompletions()
			if b.OnSubmit != nil {
				return b, tea.Batch(cmd, b.OnSubmit(text))
			}
		case "esc":
			if b.OnCancel != nil {
				return b, tea.Batch(cmd, b.OnCancel())
			}
		}
	}
	return b, cmd
}

func (b Body) View() string {
	border := b.BorderColor
	if b.Focused {
		border = b.FocusBorder
	}
	box := lipgloss.NewStyle().Border(lipgloss.RoundedBorder()).BorderForeground(border).Padding(0, 1)
	inner := b.Container.View()
	if strings.TrimSpace(b.Input.Value()) == "" && b.Placeholder != "" && !b.Popup.Visible {
		hint := lipgloss.NewStyle().Foreground(lipgloss.Color("240")).Render(b.Placeholder)
		inner = hint + "\n" + inner
	}
	footer := lipgloss.NewStyle().Foreground(lipgloss.Color("240")).Render(
		b.SubmitLabel + "  ·  " + b.MultilineHint + "  ·  " + b.CancelLabel)
	return box.Render(inner) + "\n" + footer
}

// SetDisabled enables/disables input.
func (b *Body) SetDisabled(v bool) { b.Disabled = v }

// Clear resets the text area.
func (b *Body) Clear() {
	b.Input.SetValue("")
	b.refreshCompletions()
}

// Value returns the current input text.
func (b Body) Value() string { return b.Input.Value() }

// SetValue replaces the input text and refreshes completions.
func (b *Body) SetValue(v string) {
	b.Input.SetValue(v)
	b.refreshCompletions()
}
