//go:build !(js && wasm)

package chatinput

import (
	"fmt"
	"strings"

	tea "github.com/charmbracelet/bubbletea"
	"github.com/charmbracelet/lipgloss"
)

// CompletionPopup shows autocomplete candidates.
// Port of chat_input/completion_popup.py.
type CompletionPopup struct {
	Items    []CompletionItem
	Index    int
	Visible  bool
	MaxShown int
}

// NewCompletionPopup constructs the popup.
func NewCompletionPopup() CompletionPopup {
	return CompletionPopup{MaxShown: 10}
}

// SetItems replaces candidates and shows the popup when non-empty.
func (p *CompletionPopup) SetItems(items []CompletionItem) {
	p.Items = items
	p.Index = 0
	p.Visible = len(items) > 0
}

// Hide closes the popup.
func (p *CompletionPopup) Hide() {
	p.Visible = false
	p.Items = nil
	p.Index = 0
}

// Selected returns the highlighted item.
func (p CompletionPopup) Selected() (CompletionItem, bool) {
	if !p.Visible || p.Index < 0 || p.Index >= len(p.Items) {
		return CompletionItem{}, false
	}
	return p.Items[p.Index], true
}

func (p CompletionPopup) Update(msg tea.Msg) (CompletionPopup, tea.Cmd) {
	if !p.Visible {
		return p, nil
	}
	switch msg := msg.(type) {
	case tea.KeyMsg:
		switch msg.String() {
		case "up", "ctrl+p":
			if p.Index > 0 {
				p.Index--
			}
		case "down", "ctrl+n", "tab":
			if p.Index < len(p.Items)-1 {
				p.Index++
			}
		case "esc":
			p.Hide()
		}
	}
	return p, nil
}

func (p CompletionPopup) View() string {
	if !p.Visible || len(p.Items) == 0 {
		return ""
	}
	sel := lipgloss.NewStyle().Foreground(lipgloss.Color("12")).Bold(true)
	muted := lipgloss.NewStyle().Faint(true)
	start := 0
	max := p.MaxShown
	if max <= 0 {
		max = 10
	}
	if p.Index >= max {
		start = p.Index - max + 1
	}
	end := start + max
	if end > len(p.Items) {
		end = len(p.Items)
	}
	var b strings.Builder
	for i := start; i < end; i++ {
		it := p.Items[i]
		line := it.Label
		if it.Description != "" {
			line += muted.Render("  "+it.Description)
		}
		if i == p.Index {
			b.WriteString(sel.Render("› "+line) + "\n")
		} else {
			b.WriteString("  " + line + "\n")
		}
	}
	if len(p.Items) > max {
		b.WriteString(muted.Render(fmt.Sprintf("  (%d more)", len(p.Items)-max)))
	}
	return strings.TrimRight(b.String(), "\n")
}
