package chatinput

import (
	"os"
	"path/filepath"
	"sort"
	"strings"
)

// CompletionItem is one autocomplete suggestion.
type CompletionItem struct {
	Label       string
	InsertText  string
	Kind        string // command|path|file|dir
	Description string
}

// CompletionManager produces slash-command and path completions.
// Port of chat_input/completion_manager.py.
type CompletionManager struct {
	Commands map[string]string
	Cwd      string
	MaxItems int
}

// NewCompletionManager constructs the manager.
func NewCompletionManager(commands map[string]string) *CompletionManager {
	cwd, _ := os.Getwd()
	return &CompletionManager{Commands: commands, Cwd: cwd, MaxItems: 20}
}

// Complete returns suggestions for the current input value.
func (m *CompletionManager) Complete(value string, cursor int) []CompletionItem {
	if cursor < 0 || cursor > len(value) {
		cursor = len(value)
	}
	prefix := value[:cursor]
	trim := strings.TrimLeft(prefix, " \t")
	if strings.HasPrefix(trim, "/") {
		return m.completeCommands(trim)
	}
	// path completion after last whitespace token starting with ./ ~/ or /
	tok := lastToken(prefix)
	if tok == "" {
		return nil
	}
	if strings.HasPrefix(tok, "./") || strings.HasPrefix(tok, "../") || strings.HasPrefix(tok, "/") || strings.HasPrefix(tok, "~/") || strings.HasPrefix(tok, "@") {
		return m.completePaths(strings.TrimPrefix(tok, "@"))
	}
	return nil
}

func (m *CompletionManager) completeCommands(trim string) []CompletionItem {
	body := strings.TrimPrefix(trim, "/")
	parts := strings.SplitN(body, " ", 2)
	partial := parts[0]
	var items []CompletionItem
	for name, desc := range m.Commands {
		if partial == "" || strings.HasPrefix(name, partial) {
			items = append(items, CompletionItem{
				Label: "/" + name, InsertText: "/" + name + " ", Kind: "command", Description: desc,
			})
		}
	}
	sort.Slice(items, func(i, j int) bool { return items[i].Label < items[j].Label })
	if len(items) > m.MaxItems {
		items = items[:m.MaxItems]
	}
	return items
}

func (m *CompletionManager) completePaths(partial string) []CompletionItem {
	partial = expandHome(partial)
	dir, base := filepath.Split(partial)
	search := dir
	if search == "" {
		search = m.Cwd
	}
	entries, err := os.ReadDir(search)
	if err != nil {
		return nil
	}
	var items []CompletionItem
	for _, e := range entries {
		name := e.Name()
		if base != "" && !strings.HasPrefix(name, base) {
			continue
		}
		insert := filepath.Join(dir, name)
		kind := "file"
		if e.IsDir() {
			kind = "dir"
			insert += string(filepath.Separator)
		}
		items = append(items, CompletionItem{Label: name, InsertText: insert, Kind: kind})
		if len(items) >= m.MaxItems {
			break
		}
	}
	sort.Slice(items, func(i, j int) bool {
		if items[i].Kind != items[j].Kind {
			return items[i].Kind == "dir"
		}
		return items[i].Label < items[j].Label
	})
	return items
}

func lastToken(s string) string {
	s = strings.TrimRight(s, " \t")
	i := strings.LastIndexAny(s, " \t\n")
	if i < 0 {
		return s
	}
	return s[i+1:]
}

func expandHome(p string) string {
	if strings.HasPrefix(p, "~/") {
		home, err := os.UserHomeDir()
		if err == nil {
			return filepath.Join(home, p[2:])
		}
	}
	return p
}
