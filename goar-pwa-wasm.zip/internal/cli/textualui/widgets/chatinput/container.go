//go:build !(js && wasm)

package chatinput

import (
	"strings"

	tea "github.com/charmbracelet/bubbletea"
	"github.com/charmbracelet/lipgloss"
)

// Container owns the text area + completion popup (port of container.py).
type Container struct {
	Input      TextArea
	Popup      CompletionPopup
	Completer  *CompletionManager
	Width      int
	Height     int
	Focused    bool
	ShowPopup  bool
}

// NewContainer builds the chat input container.
func NewContainer(commands map[string]string) Container {
	return Container{
		Input:     NewTextArea(),
		Popup:     NewCompletionPopup(),
		Completer: NewCompletionManager(commands),
		Focused:   true,
		ShowPopup: true,
	}
}

func (c Container) Init() tea.Cmd { return c.Input.Init() }

func (c *Container) refreshCompletions() {
	if !c.ShowPopup || c.Completer == nil {
		c.Popup.Hide()
		return
	}
	items := c.Completer.Complete(c.Input.Value(), len(c.Input.Value()))
	c.Popup.SetItems(items)
}

func (c Container) Update(msg tea.Msg) (Container, tea.Cmd) {
	switch msg := msg.(type) {
	case tea.WindowSizeMsg:
		c.Width, c.Height = msg.Width, msg.Height
		c.Input.SetWidth(msg.Width - 2)
	case tea.KeyMsg:
		if c.Popup.Visible {
			switch msg.String() {
			case "tab", "enter":
				if item, ok := c.Popup.Selected(); ok && msg.String() == "tab" {
					c.applyCompletion(item)
					c.refreshCompletions()
					return c, nil
				}
			case "up", "down", "ctrl+n", "ctrl+p", "esc":
				var cmd tea.Cmd
				c.Popup, cmd = c.Popup.Update(msg)
				return c, cmd
			}
		}
	}
	var cmd tea.Cmd
	c.Input, cmd = c.Input.Update(msg)
	if _, ok := msg.(tea.KeyMsg); ok {
		c.refreshCompletions()
	}
	return c, cmd
}

func (c *Container) applyCompletion(item CompletionItem) {
	val := c.Input.Value()
	if item.Kind == "command" {
		// replace from leading slash
		trim := strings.TrimLeft(val, " \t")
		lead := val[:len(val)-len(trim)]
		c.Input.SetValue(lead + item.InsertText)
		return
	}
	// replace last token
	i := strings.LastIndexAny(val, " \t\n")
	if i < 0 {
		c.Input.SetValue(item.InsertText)
		return
	}
	c.Input.SetValue(val[:i+1] + item.InsertText)
}

func (c Container) View() string {
	parts := []string{c.Input.View()}
	if c.Popup.Visible {
		parts = append(parts, c.Popup.View())
	}
	return lipgloss.JoinVertical(lipgloss.Left, parts...)
}

// SetCommands replaces the slash-command map used by the completer.
func (c *Container) SetCommands(commands map[string]string) {
	if c.Completer == nil {
		c.Completer = NewCompletionManager(commands)
		return
	}
	c.Completer.Commands = commands
}

// Focus focuses the text area.
func (c *Container) Focus() { c.Focused = true; c.Input.Focus() }

// Blur unfocuses the text area and hides the popup.
func (c *Container) Blur() { c.Focused = false; c.Popup.Hide() }

// Value returns the current input text.
func (c Container) Value() string { return c.Input.Value() }
