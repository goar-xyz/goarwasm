package widgets

import (
	"fmt"
	"strings"

	"github.com/charmbracelet/lipgloss"
	"github.com/goarxyz/goar/internal/cli/textualui/uitheme"
)

// QueuedKind distinguishes prompt vs bash queued entries.
type QueuedKind string

const (
	QueuedKindPrompt QueuedKind = "prompt"
	QueuedKindBash   QueuedKind = "bash"
)

// QueueEntry is one rendered queued entry (widget-local; mirrors textualui.QueuedItem).
type QueueEntry struct {
	Kind    QueuedKind
	Content string
}

// MessageQueueSource is the queue surface QueuedMessages binds to (avoids import cycle).
type MessageQueueSource interface {
	Len() int
	Paused() bool
	ItemsAsEntries() []QueueEntry
	SetChangeListener(func())
}

// QueuedMessageItem is one rendered queued entry.
type QueuedMessageItem struct {
	Entry QueueEntry
}

// View renders a single queued item.
func (q QueuedMessageItem) View() string {
	prefix := ""
	if q.Entry.Kind == QueuedKindBash {
		prefix = "$ "
	}
	return prefix + q.Entry.Content
}

// QueuedMessages is the queue panel widget (Python QueuedMessages).
type QueuedMessages struct {
	Queue      MessageQueueSource
	JobRunning bool
	Theme      uitheme.Theme
	Visible    bool
	Title      string
	Hint       string
	Items      []QueuedMessageItem
}

// Bind attaches a queue and registers a change listener.
func (q *QueuedMessages) Bind(queue MessageQueueSource) {
	q.Queue = queue
	if queue != nil {
		queue.SetChangeListener(q.refresh)
	}
	q.refresh()
}

// SetJobRunning updates the running-job hint.
func (q *QueuedMessages) SetJobRunning(running bool) {
	if q.JobRunning == running {
		return
	}
	q.JobRunning = running
	q.refresh()
}

func (q *QueuedMessages) refresh() {
	queue := q.Queue
	if queue == nil || queue.Len() == 0 {
		q.Visible = false
		q.Items = nil
		q.Hint = ""
		q.Title = "Queue"
		return
	}
	q.Visible = true
	title := fmt.Sprintf("Queue (%d)", queue.Len())
	if queue.Paused() {
		title += " — paused"
	}
	q.Title = title
	entries := queue.ItemsAsEntries()
	q.Items = make([]QueuedMessageItem, 0, len(entries))
	for _, it := range entries {
		q.Items = append(q.Items, QueuedMessageItem{Entry: it})
	}
	switch {
	case queue.Paused():
		q.Hint = "Enter send queue • Ctrl+C drop last queued"
	case q.JobRunning:
		q.Hint = "Esc cancel job + pause • Ctrl+C drop last queued"
	default:
		q.Hint = ""
	}
}

// View renders the queue panel.
func (q QueuedMessages) View() string {
	if !q.Visible || len(q.Items) == 0 {
		return ""
	}
	titleStyle := lipgloss.NewStyle().Foreground(q.Theme.Accent).Bold(true)
	hintStyle := lipgloss.NewStyle().Foreground(q.Theme.Muted)
	var b strings.Builder
	b.WriteString(titleStyle.Render(q.Title))
	b.WriteByte('\n')
	for _, it := range q.Items {
		b.WriteString("  ")
		b.WriteString(it.View())
		b.WriteByte('\n')
	}
	if q.Hint != "" {
		b.WriteString(hintStyle.Render(q.Hint))
	}
	return strings.TrimRight(b.String(), "\n")
}

// Count returns the number of queued items (compat).
func (q QueuedMessages) Count() int {
	if q.Queue == nil {
		return len(q.Items)
	}
	return q.Queue.Len()
}
