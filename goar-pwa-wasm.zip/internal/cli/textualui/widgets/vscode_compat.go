package widgets

import (
	"os"
	"strings"
)

// IsVSCodeTerminal detects VS Code integrated terminal (compat).
func IsVSCodeTerminal() bool {
	if os.Getenv("TERM_PROGRAM") == "vscode" || os.Getenv("VSCODE_PID") != "" {
		return true
	}
	return NeedsVSCodeCompat()
}

// PatchVSCodeSpace fixes space key events sent as CSI u by VS Code 1.110+
// (Python patch_vscode_space).
//
// VS Code encodes space as "\x1b[32u" (CSI u), which some TUI frameworks parse
// as Key("space", character=None, is_printable=false). Assigning character=" "
// restores normal Input behaviour. Callers should invoke this before handling
// a key event.
func PatchVSCodeSpace(key string, character *string) {
	if character == nil {
		return
	}
	if (key == "space" || key == "shift+space") && *character == "" {
		*character = " "
	}
}

// NormalizeKeyCharacter applies VS Code / Cursor quirks to a key event.
func NormalizeKeyCharacter(key, character string) string {
	ch := character
	PatchVSCodeSpace(key, &ch)
	if key == "space" && ch == "" {
		return " "
	}
	return ch
}

// NeedsVSCodeCompat reports whether the current terminal needs CSI-u patches.
func NeedsVSCodeCompat() bool {
	termProgram := strings.ToLower(os.Getenv("TERM_PROGRAM"))
	if termProgram == "vscode" {
		return true
	}
	indicators := []string{
		"VSCODE_GIT_ASKPASS_NODE",
		"VSCODE_GIT_ASKPASS_MAIN",
		"VSCODE_IPC_HOOK_CLI",
		"VSCODE_NLS_CONFIG",
		"VSCODE_PID",
	}
	for _, v := range indicators {
		if os.Getenv(v) != "" {
			return true
		}
	}
	return false
}
