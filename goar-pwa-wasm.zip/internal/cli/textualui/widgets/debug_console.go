package widgets

import (
	"fmt"
	"strings"
	"sync"
	"time"

	"github.com/charmbracelet/lipgloss"
	"github.com/goarxyz/goar/internal/cli/textualui/uitheme"
)

// DebugConsole is a ring-buffered debug log panel.
// Port of goar.cli.textual_ui.widgets.debug_console.
type DebugConsole struct {
	mu      sync.Mutex
	lines   []string
	max     int
	Visible bool
	Filter  string
}

// NewDebugConsole creates a console with capacity.
func NewDebugConsole(capacity int) *DebugConsole {
	if capacity <= 0 {
		capacity = 500
	}
	return &DebugConsole{max: capacity}
}

// Append adds a timestamped line.
func (d *DebugConsole) Append(format string, args ...any) {
	d.mu.Lock()
	defer d.mu.Unlock()
	line := time.Now().Format("15:04:05.000") + " " + fmt.Sprintf(format, args...)
	d.lines = append(d.lines, line)
	if len(d.lines) > d.max {
		d.lines = d.lines[len(d.lines)-d.max:]
	}
}

// Clear empties the buffer.
func (d *DebugConsole) Clear() {
	d.mu.Lock()
	defer d.mu.Unlock()
	d.lines = nil
}

// Lines returns a copy of buffered lines (optionally filtered).
func (d *DebugConsole) Lines() []string {
	d.mu.Lock()
	defer d.mu.Unlock()
	if d.Filter == "" {
		out := make([]string, len(d.lines))
		copy(out, d.lines)
		return out
	}
	f := strings.ToLower(d.Filter)
	var out []string
	for _, l := range d.lines {
		if strings.Contains(strings.ToLower(l), f) {
			out = append(out, l)
		}
	}
	return out
}

// View renders the last n lines.
func (d *DebugConsole) View(theme uitheme.Theme, height int) string {
	if !d.Visible {
		return ""
	}
	if height <= 0 {
		height = 8
	}
	lines := d.Lines()
	if len(lines) > height {
		lines = lines[len(lines)-height:]
	}
	muted := lipgloss.NewStyle().Foreground(theme.Muted)
	header := lipgloss.NewStyle().Bold(true).Foreground(theme.Accent).Render("── debug console ──")
	return header + "\n" + muted.Render(strings.Join(lines, "\n"))
}

// Toggle visibility.
func (d *DebugConsole) Toggle() { d.Visible = !d.Visible }

// Levels returns distinct level tags found in the buffer (best-effort parse).
func (d *DebugConsole) Levels() []string {
	d.mu.Lock()
	defer d.mu.Unlock()
	seen := map[string]bool{}
	var out []string
	for _, line := range d.lines {
		for _, lvl := range []string{"DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"} {
			if strings.Contains(line, lvl) && !seen[lvl] {
				seen[lvl] = true
				out = append(out, lvl)
			}
		}
	}
	return out
}

// Len returns the number of buffered lines.
func (d *DebugConsole) Len() int {
	d.mu.Lock()
	defer d.mu.Unlock()
	return len(d.lines)
}

