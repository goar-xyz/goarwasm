package widgets

import (
	"fmt"
	"strings"
	"sync"

	"github.com/charmbracelet/lipgloss"
	"github.com/goarxyz/goar/internal/cli/textualui/uitheme"
	"github.com/goarxyz/goar/internal/core/types"
)

// ToolStatus is a compact one-line tool status (legacy).
type ToolStatus struct {
	Name    string
	Summary string
	Running bool
	OK      bool
	Theme   uitheme.Theme
}

func (t ToolStatus) View() string {
	style := lipgloss.NewStyle().Foreground(t.Theme.Muted)
	if t.Running {
		style = lipgloss.NewStyle().Foreground(t.Theme.Accent)
	} else if t.OK {
		style = lipgloss.NewStyle().Foreground(t.Theme.Success)
	}
	return style.Render(fmt.Sprintf("⚙ %s — %s", t.Name, t.Summary))
}

// ToolCallMessage is the UI widget for an in-flight / completed tool call (Python ToolCallMessage).
type ToolCallWidget struct {
	mu            sync.Mutex
	Event         types.ToolCallEvent
	StreamMessage string
	Spinning      bool
	Success       *bool
	Collapsed     bool
}

// NewToolCallMessage constructs a tool-call widget from an event.
func NewToolCallWidget(event types.ToolCallEvent) *ToolCallWidget {
	return &ToolCallWidget{Event: event, Spinning: true}
}

// UpdateEvent refreshes the underlying tool-call event (e.g. args filled in).
func (t *ToolCallWidget) UpdateEvent(event types.ToolCallEvent) {
	t.mu.Lock()
	defer t.mu.Unlock()
	t.Event = event
}

// SetStreamMessage updates the live stream line under the tool call.
func (t *ToolCallWidget) SetStreamMessage(msg string) {
	t.mu.Lock()
	defer t.mu.Unlock()
	t.StreamMessage = msg
}

// StopSpinning ends the spinner with success/failure.
func (t *ToolCallWidget) StopSpinning(success bool) {
	t.mu.Lock()
	defer t.mu.Unlock()
	t.Spinning = false
	t.Success = &success
}

// View renders the tool call widget.
func (t *ToolCallWidget) View(theme uitheme.Theme) string {
	t.mu.Lock()
	defer t.mu.Unlock()
	icon := "⚙"
	if t.Spinning {
		icon = "…"
	} else if t.Success != nil && *t.Success {
		icon = "✓"
	} else if t.Success != nil {
		icon = "✗"
	}
	style := lipgloss.NewStyle().Foreground(theme.Accent)
	line := fmt.Sprintf("%s %s", icon, t.Event.Name)
	if t.Event.ArgsJSON != "" && !t.Collapsed {
		line += " " + truncateRunes(t.Event.ArgsJSON, 80)
	}
	out := style.Render(line)
	if t.StreamMessage != "" {
		out += "\n" + lipgloss.NewStyle().Foreground(theme.Muted).Render("  "+t.StreamMessage)
	}
	return out
}

// ToolResultMessage is the UI widget for a tool result (Python ToolResultMessage).
type ToolResultWidget struct {
	Event     types.ToolResultEvent
	Call      *ToolCallWidget
	Collapsed bool
}

// NewToolResultMessage constructs a tool-result widget.
func NewToolResultWidget(event types.ToolResultEvent, call *ToolCallWidget, collapsed bool) *ToolResultWidget {
	if call != nil {
		ok := event.Error == "" && event.SkipReason == ""
		call.StopSpinning(ok)
	}
	return &ToolResultWidget{Event: event, Call: call, Collapsed: collapsed}
}

// View renders the tool result.
func (t *ToolResultWidget) View(theme uitheme.Theme) string {
	muted := lipgloss.NewStyle().Foreground(theme.Muted)
	errStyle := lipgloss.NewStyle().Foreground(theme.Error)
	if t.Event.Error != "" {
		return errStyle.Render("✗ " + t.Event.Name + ": " + truncateRunes(t.Event.Error, 200))
	}
	if t.Event.SkipReason != "" {
		return muted.Render("⏭ " + t.Event.Name + " skipped — " + truncateRunes(t.Event.SkipReason, 120))
	}
	body := t.Event.ResultJSON
	if t.Collapsed {
		body = truncateRunes(body, 120)
	} else {
		body = truncateRunes(body, 2000)
	}
	return muted.Render("↳ " + t.Event.Name + "\n" + body)
}

// AssistantMessage is a streaming assistant bubble.
type AssistantWidget struct {
	mu        sync.Mutex
	Content   string
	Streaming bool
}

func NewAssistantWidget(content string) *AssistantWidget {
	return &AssistantWidget{Content: content, Streaming: true}
}

func (m *AssistantWidget) AppendContent(s string) {
	m.mu.Lock()
	defer m.mu.Unlock()
	m.Content += s
}

func (m *AssistantWidget) StopStream() {
	m.mu.Lock()
	defer m.mu.Unlock()
	m.Streaming = false
}

func (m *AssistantWidget) IsEmpty() bool {
	m.mu.Lock()
	defer m.mu.Unlock()
	return strings.TrimSpace(m.Content) == ""
}

func (m *AssistantWidget) View(theme uitheme.Theme) string {
	m.mu.Lock()
	defer m.mu.Unlock()
	return lipgloss.NewStyle().Foreground(theme.Foreground).Render(m.Content)
}

// ReasoningMessage is a collapsible reasoning bubble.
type ReasoningWidget struct {
	mu        sync.Mutex
	Content   string
	Collapsed bool
	Spinning  bool
	Streaming bool
}

func NewReasoningWidget(content string, collapsed bool) *ReasoningWidget {
	return &ReasoningWidget{Content: content, Collapsed: collapsed, Spinning: true, Streaming: true}
}

func (m *ReasoningWidget) AppendContent(s string) {
	m.mu.Lock()
	defer m.mu.Unlock()
	m.Content += s
}

func (m *ReasoningWidget) StopSpinning() {
	m.mu.Lock()
	defer m.mu.Unlock()
	m.Spinning = false
}

func (m *ReasoningWidget) StopStream() {
	m.mu.Lock()
	defer m.mu.Unlock()
	m.Streaming = false
}

func (m *ReasoningWidget) View(theme uitheme.Theme) string {
	m.mu.Lock()
	defer m.mu.Unlock()
	body := m.Content
	if m.Collapsed {
		body = truncateRunes(body, 100)
	}
	return lipgloss.NewStyle().Foreground(theme.Muted).Italic(true).Render("💭 " + body)
}

// UserMessage is a user bubble.
type UserWidget struct{ Content string }

func NewUserWidget(content string) *UserWidget { return &UserWidget{Content: content} }

func (m *UserWidget) View(theme uitheme.Theme) string {
	return lipgloss.NewStyle().Foreground(theme.Accent).Bold(true).Render("You: "+m.Content)
}

// CompactMessage is the compact-in-progress widget (Python CompactMessage).
type CompactWidget struct {
	mu           sync.Mutex
	Spinning     bool
	Complete     bool
	OldSessionID string
	NewSessionID string
}

func NewCompactWidget() *CompactWidget { return &CompactWidget{Spinning: true} }

func (c *CompactWidget) SetComplete(oldSession, newSession string) {
	c.mu.Lock()
	defer c.mu.Unlock()
	c.Spinning = false
	c.Complete = true
	c.OldSessionID = oldSession
	c.NewSessionID = newSession
}

func (c *CompactWidget) StopSpinning(success bool) {
	c.mu.Lock()
	defer c.mu.Unlock()
	c.Spinning = false
	c.Complete = success
}

func (c *CompactWidget) View(theme uitheme.Theme) string {
	c.mu.Lock()
	defer c.mu.Unlock()
	if c.Complete {
		return lipgloss.NewStyle().Foreground(theme.Success).Render(
			fmt.Sprintf("Compact complete (%s → %s)", shortID(c.OldSessionID), shortID(c.NewSessionID)))
	}
	return lipgloss.NewStyle().Foreground(theme.Accent).Render("Compacting conversation…")
}

// PlanFileMessage watches a plan file during plan-review.
type PlanFileMessage struct {
	FilePath  string
	watching  bool
}

func NewPlanFileMessage(path string) *PlanFileMessage {
	return &PlanFileMessage{FilePath: path, watching: true}
}

func (p *PlanFileMessage) StopWatching() { p.watching = false }

func (p *PlanFileMessage) View(theme uitheme.Theme) string {
	status := "watching"
	if !p.watching {
		status = "done"
	}
	return lipgloss.NewStyle().Foreground(theme.Muted).Render(fmt.Sprintf("Plan review (%s): %s", status, p.FilePath))
}

// HookRunContainer groups hook system messages.
type HookRunContainer struct {
	Messages []string
}

func NewHookRunContainer() *HookRunContainer { return &HookRunContainer{} }

func (h *HookRunContainer) AddMessage(line string) { h.Messages = append(h.Messages, line) }

func (h *HookRunContainer) View(theme uitheme.Theme) string {
	if len(h.Messages) == 0 {
		return ""
	}
	return lipgloss.NewStyle().Foreground(theme.Muted).Render(strings.Join(h.Messages, "\n"))
}

// NewNoMarkupStatic wraps plain text for unknown events.
func NewNoMarkupStatic(text string) NoMarkupStatic { return NoMarkupStatic{Text: text} }

func truncateRunes(s string, n int) string {
	r := []rune(s)
	if len(r) <= n {
		return s
	}
	return string(r[:n]) + "…"
}

func shortID(id string) string {
	if len(id) <= 8 {
		return id
	}
	return id[:8]
}
