package widgets


import (
	"encoding/json"
	"fmt"
	"strings"

	"github.com/charmbracelet/lipgloss"
	"github.com/goarxyz/goar/internal/cli/textualui/uitheme"
)

// ApprovalWidget renders tool args for the approval panel.
type ApprovalWidget struct {
	ToolName string
	Args     map[string]any
	Summary  string
}

// GetApprovalWidget builds an approval summary widget (port of get_approval_widget).
func GetApprovalWidget(toolName string, args map[string]any) ApprovalWidget {
	return ApprovalWidget{ToolName: toolName, Args: args, Summary: SummarizeToolArgs(toolName, args)}
}

// View renders the approval widget body.
func (w ApprovalWidget) View(theme uitheme.Theme) string {
	muted := lipgloss.NewStyle().Foreground(theme.Muted)
	var b strings.Builder
	b.WriteString(lipgloss.NewStyle().Bold(true).Render(w.ToolName))
	b.WriteString("\n")
	if w.Summary != "" {
		b.WriteString(w.Summary)
		b.WriteString("\n")
	}
	if len(w.Args) > 0 {
		b.WriteString(muted.Render(prettyArgs(w.Args)))
	}
	return b.String()
}

// SummarizeToolArgs produces a one-line human summary for common tools.
func SummarizeToolArgs(toolName string, args map[string]any) string {
	if args == nil {
		return ""
	}
	switch strings.ToLower(toolName) {
	case "bash", "shell":
		if c, ok := args["command"].(string); ok {
			return "$ " + truncateStr(c, 200)
		}
	case "read_file", "read":
		if p, ok := args["path"].(string); ok {
			return "read " + p
		}
	case "search_replace", "edit":
		if p, ok := args["path"].(string); ok {
			return "edit " + p
		}
	case "write_file", "write":
		if p, ok := args["path"].(string); ok {
			return "write " + p
		}
	case "grep":
		pat, _ := args["pattern"].(string)
		path, _ := args["path"].(string)
		return fmt.Sprintf("grep %q in %s", pat, path)
	case "web_search", "websearch":
		if q, ok := args["query"].(string); ok {
			return "search: " + q
		}
	case "web_fetch", "webfetch":
		if u, ok := args["url"].(string); ok {
			return "fetch " + u
		}
	}
	return ""
}

func prettyArgs(args map[string]any) string {
	b, err := json.MarshalIndent(args, "", "  ")
	if err != nil {
		return fmt.Sprintf("%v", args)
	}
	s := string(b)
	if len(s) > 2000 {
		return s[:2000] + "…"
	}
	return s
}

func truncateStr(s string, n int) string {
	if len(s) <= n {
		return s
	}
	return s[:n-1] + "…"
}

// ToolCallDisplay is the inline tool-call chip.
type ToolCallDisplay struct {
	Name    string
	Summary string
	Running bool
}

func (t ToolCallDisplay) View(theme uitheme.Theme) string {
	muted := lipgloss.NewStyle().Foreground(theme.Muted)
	prefix := "↳"
	if t.Running {
		prefix = "…"
	}
	return muted.Render(fmt.Sprintf("%s [%s] %s", prefix, t.Name, t.Summary))
}

// ToolResultDisplay is the inline tool-result chip.
type ToolResultDisplay struct {
	Name    string
	Success bool
	Message string
	Collapsed bool
}

func (t ToolResultDisplay) View(theme uitheme.Theme) string {
	muted := lipgloss.NewStyle().Foreground(theme.Muted)
	ok := "✓"
	if !t.Success {
		ok = "✕"
	}
	if t.Collapsed {
		return muted.Render(fmt.Sprintf("%s %s (collapsed)", ok, t.Name))
	}
	msg := t.Message
	if len(msg) > 300 {
		msg = msg[:297] + "…"
	}
	return muted.Render(fmt.Sprintf("%s %s\n%s", ok, t.Name, msg))
}


// FormatToolCallSummary mirrors Python ToolCallDisplay one-liner.
func FormatToolCallSummary(name, summary string) string {
	if summary == "" {
		return fmt.Sprintf("[%s]", name)
	}
	return fmt.Sprintf("[%s] %s", name, summary)
}

// FormatToolCallLine builds a single-line tool call label for the transcript.
func FormatToolCallLine(name, argsJSON string) string {
	summary := SummarizeToolArgs(name, nil)
	if argsJSON != "" {
		var m map[string]any
		if json.Unmarshal([]byte(argsJSON), &m) == nil {
			summary = SummarizeToolArgs(name, m)
		}
	}
	if summary == "" {
		return "⚙ " + name
	}
	return "⚙ " + name + " — " + summary
}

// FormatToolResultLine builds a single-line tool result label.
func FormatToolResultLine(name, resultJSON, errText string) string {
	if errText != "" {
		return "✗ " + name + ": " + truncateStr(errText, 120)
	}
	return "↳ " + name + " " + truncateStr(resultJSON, 120)
}
