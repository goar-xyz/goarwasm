package widgets

import (
	"fmt"

	"github.com/charmbracelet/lipgloss"
	"github.com/goarxyz/goar/internal/cli/textualui/uitheme"
)

// HistoryLoadMoreRequested is posted when the user asks for older history.
type HistoryLoadMoreRequested struct{}

// LoadMore / HistoryLoadMoreMessage is the "load earlier messages" control
// (Python HistoryLoadMoreMessage).
type LoadMore struct {
	HasMore   bool
	Remaining *int
	Enabled   bool
	Theme     uitheme.Theme
}

// NewLoadMore constructs a load-more control.
func NewLoadMore() *LoadMore {
	return &LoadMore{Enabled: true}
}

func (l *LoadMore) labelText() string {
	if l.Remaining == nil {
		return "Load more messages"
	}
	return fmt.Sprintf("Load more messages (%d)", *l.Remaining)
}

// SetEnabled enables/disables the control.
func (l *LoadMore) SetEnabled(enabled bool) { l.Enabled = enabled }

// SetRemaining updates the remaining-count label.
func (l *LoadMore) SetRemaining(remaining *int) {
	l.Remaining = remaining
	l.HasMore = remaining == nil || *remaining > 0
}

// Request fires a load-more request when enabled.
func (l *LoadMore) Request() *HistoryLoadMoreRequested {
	if !l.Enabled || !l.HasMore {
		return nil
	}
	return &HistoryLoadMoreRequested{}
}

// View renders the control.
func (l LoadMore) View() string {
	if !l.HasMore {
		return ""
	}
	style := lipgloss.NewStyle().Foreground(l.Theme.Accent)
	if !l.Enabled {
		style = lipgloss.NewStyle().Foreground(l.Theme.Muted)
	}
	return style.Render("↑ " + l.labelText())
}
