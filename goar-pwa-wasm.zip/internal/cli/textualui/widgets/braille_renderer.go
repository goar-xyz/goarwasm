package widgets

import "strings"

var brailleFrames = []string{"⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏"}

// BrailleSpinner returns a frame for tick n (compat helper).
func BrailleSpinner(n int) string {
	return brailleFrames[n%len(brailleFrames)]
}

// BrailleProgress renders a braille-ish bar.
func BrailleProgress(pct float64, width int) string {
	if width < 1 {
		width = 10
	}
	if pct < 0 {
		pct = 0
	}
	if pct > 1 {
		pct = 1
	}
	filled := int(pct * float64(width))
	return strings.Repeat("⣿", filled) + strings.Repeat("⣀", width-filled)
}

// braille cell bit order (Unicode braille patterns):
// 0 3
// 1 4
// 2 5
// 6 7
var brailleBitOrder = [8]int{0, 1, 2, 6, 3, 4, 5, 7}

// RenderBraille paints occupied complex positions onto a braille glyph grid.
// Port of goar.cli.textual_ui.widgets.braille_renderer.render_braille.
func RenderBraille(positions []complex128, mapWidth, mapHeight int) string {
	if mapWidth < 1 || mapHeight < 1 {
		return ""
	}
	// Each braille char covers 2x4 dots
	cols := (mapWidth + 1) / 2
	rows := (mapHeight + 3) / 4
	grid := make([][]rune, rows)
	for r := range grid {
		grid[r] = make([]rune, cols)
		for c := range grid[r] {
			grid[r][c] = '⠀' // blank braille
		}
	}
	occupied := map[[2]int]bool{}
	for _, p := range positions {
		x, y := int(real(p)), int(imag(p))
		if x >= 0 && x < mapWidth && y >= 0 && y < mapHeight {
			occupied[[2]int{x, y}] = true
		}
	}
	for y := 0; y < mapHeight; y++ {
		for x := 0; x < mapWidth; x++ {
			if !occupied[[2]int{x, y}] {
				continue
			}
			col, row := x/2, y/4
			if row >= rows || col >= cols {
				continue
			}
			lx, ly := x%2, y%4
			dotIndex := ly + lx*4
			bit := brailleBitOrder[dotIndex]
			ch := grid[row][col]
			grid[row][col] = rune(int(ch) | (1 << bit))
		}
	}
	var b strings.Builder
	for r := 0; r < rows; r++ {
		if r > 0 {
			b.WriteByte('\n')
		}
		for c := 0; c < cols; c++ {
			b.WriteRune(grid[r][c])
		}
	}
	return b.String()
}
