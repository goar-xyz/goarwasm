package widgets

import (
	"fmt"
	"github.com/charmbracelet/lipgloss"
	"github.com/goarxyz/goar/internal/cli/textualui/uitheme"
)

type ContextProgress struct {
	Used, Limit int
	Theme       uitheme.Theme
	Width       int
}

func (c ContextProgress) View() string {
	if c.Limit <= 0 {
		c.Limit = 200000
	}
	pct := float64(c.Used) / float64(c.Limit)
	if pct > 1 { pct = 1 }
	w := c.Width
	if w <= 0 { w = 20 }
	filled := int(pct * float64(w))
	bar := lipgloss.NewStyle().Foreground(c.Theme.Accent).Render(repeat("█", filled)) + repeat("░", w-filled)
	return fmt.Sprintf("ctx %s %d/%d", bar, c.Used, c.Limit)
}
func repeat(s string, n int) string {
	out := ""
	for i := 0; i < n; i++ { out += s }
	return out
}
