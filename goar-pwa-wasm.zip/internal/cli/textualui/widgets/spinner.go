package widgets

import (
	"math/rand"
	"sync"
)

// SpinnerType selects spinner animation style.
type SpinnerType int

const (
	SpinnerBraille SpinnerType = iota
	SpinnerPulse
	SpinnerSnake
)

// Spinner advances frame-by-frame animations for loading indicators.
type Spinner interface {
	NextFrame() string
	CurrentFrame() string
	Reset()
}

type frameSpinner struct {
	frames []string
	pos    int
}

func (s *frameSpinner) NextFrame() string {
	f := s.frames[s.pos]
	s.pos = (s.pos + 1) % len(s.frames)
	return f
}
func (s *frameSpinner) CurrentFrame() string { return s.frames[s.pos] }
func (s *frameSpinner) Reset()               { s.pos = 0 }

// BrailleFrameSpinner cycles classic braille dots.
func BrailleFrameSpinner() Spinner {
	return &frameSpinner{frames: []string{"⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏"}}
}

// PulseSpinner alternates filled/empty blocks.
func PulseSpinner() Spinner {
	return &frameSpinner{frames: []string{"■", "■", "■", "■", "■", "■", "□", "□", "□", "□"}}
}

// SnakeSpinner walks a 4x4 braille grid (ported from Python SnakeSpinner).
type SnakeSpinner struct {
	positions []complex128
	mu        sync.Mutex
}

const (
	snakeMapW = 4
	snakeMapH = 4
	snakeLen  = 3
)

// NewSnakeSpinner creates a snake spinner.
func NewSnakeSpinner() *SnakeSpinner {
	return &SnakeSpinner{positions: []complex128{1, 0, 1i}}
}

func (s *SnakeSpinner) currentDirection() complex128 {
	return s.positions[0] - s.positions[1]
}

func (s *SnakeSpinner) inBounds(p complex128) bool {
	return real(p) >= 0 && real(p) < float64(snakeMapW) && imag(p) >= 0 && imag(p) < float64(snakeMapH)
}

func (s *SnakeSpinner) contains(p complex128) bool {
	for _, x := range s.positions {
		if x == p {
			return true
		}
	}
	return false
}

func (s *SnakeSpinner) getDirection() complex128 {
	cur := s.currentDirection()
	reals := map[float64]struct{}{}
	imags := map[float64]struct{}{}
	for _, z := range s.positions {
		reals[real(z)] = struct{}{}
		imags[imag(z)] = struct{}{}
	}
	if len(reals) > 1 && len(imags) > 1 && s.inBounds(s.positions[0]+cur) {
		return cur
	}
	var valid []complex128
	for _, rot := range []complex128{1, 1i, -1i} {
		offset := rot * cur
		np := s.positions[0] + offset
		if s.inBounds(np) && !s.contains(np) {
			valid = append(valid, offset)
		}
	}
	if len(valid) == 0 {
		return cur
	}
	return valid[rand.Intn(len(valid))]
}

func (s *SnakeSpinner) nextPositions() []complex128 {
	if len(s.positions) > snakeLen {
		return s.positions[:snakeLen]
	}
	head := s.positions[0]
	dir := s.getDirection()
	if s.currentDirection() != dir {
		return append([]complex128{head + dir}, s.positions...)
	}
	return append([]complex128{head + dir}, s.positions[:len(s.positions)-1]...)
}

// CurrentFrame renders the snake as braille.
func (s *SnakeSpinner) CurrentFrame() string {
	s.mu.Lock()
	defer s.mu.Unlock()
	return RenderBraille(s.positions, snakeMapW, snakeMapH)
}

// NextFrame advances and renders.
func (s *SnakeSpinner) NextFrame() string {
	s.mu.Lock()
	defer s.mu.Unlock()
	s.positions = s.nextPositions()
	return RenderBraille(s.positions, snakeMapW, snakeMapH)
}

// Reset restores initial snake positions.
func (s *SnakeSpinner) Reset() {
	s.mu.Lock()
	defer s.mu.Unlock()
	s.positions = []complex128{1, 0, 1i}
}

// CreateSpinner builds a spinner of the given type.
func CreateSpinner(t SpinnerType) Spinner {
	switch t {
	case SpinnerPulse:
		return PulseSpinner()
	case SpinnerSnake:
		return NewSnakeSpinner()
	default:
		return BrailleFrameSpinner()
	}
}

// SpinnerState is a reusable mixin-like helper for widgets that spin.
type SpinnerState struct {
	Spinner    Spinner
	IsSpinning bool
	SpinningText  string
	CompletedText string
}

// InitSpinner prepares default braille spinner.
func (s *SpinnerState) InitSpinner(t SpinnerType) {
	s.Spinner = CreateSpinner(t)
	s.IsSpinning = true
}

// StopSpinning marks success/failure and stops animation.
func (s *SpinnerState) StopSpinning(success bool) (indicator string) {
	s.IsSpinning = false
	if success {
		return "✓"
	}
	return "✕"
}

// Next returns next frame or completed glyph.
func (s *SpinnerState) Next() string {
	if s.Spinner == nil {
		s.InitSpinner(SpinnerBraille)
	}
	if !s.IsSpinning {
		return "✓"
	}
	return s.Spinner.NextFrame()
}
