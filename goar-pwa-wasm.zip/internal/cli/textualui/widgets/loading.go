package widgets

import (
	"fmt"
	"math/rand"
	"strings"
	"time"

	"github.com/charmbracelet/lipgloss"
)

const DefaultLoadingStatus = "Generating"

var (
	loadingTargetColors = []string{"#F2F2F2", "#D4D4D4", "#A3A3A3", "#737373", "#525252"}
	easterEggs = []string{
		"Reviewing requirements", "Checking implementation details", "Thinking through trade-offs",
		"Preparing the next step", "Checking the workspace", "Validating the approach",
		"Reviewing the codebase", "Keeping context organized", "Counting tokens carefully",
		"Loading model weights", "Reviewing the plan", "Preparing Goar", "Petting le chat",
	}
	easterEggsHalloween = []string{"Trick or treating", "Carving pumpkins", "Summoning spirits", "Brewing potions", "Haunting the terminal", "Petting le chat noir"}
	easterEggsDecember  = []string{"Wrapping presents", "Decorating the tree", "Drinking hot chocolate", "Building snowmen", "Writing holiday cards"}
)

// FormatElapsed formats seconds as Ns / NmNs / NhNmNs.
func FormatElapsed(seconds int) string {
	if seconds < 60 {
		return fmt.Sprintf("%ds", seconds)
	}
	minutes, secs := seconds/60, seconds%60
	if minutes < 60 {
		return fmt.Sprintf("%dm%ds", minutes, secs)
	}
	hours, mins := minutes/60, minutes%60
	return fmt.Sprintf("%dh%dm%ds", hours, mins, secs)
}

// LoadingWidget is the animated status line while the agent runs.
type LoadingWidget struct {
	SpinnerState
	Status             string
	ShowHint           bool
	ShowDebounce       bool
	CurrentColorIndex  int
	ColorDirection     int
	TransitionProgress int
	StartTime          time.Time
	PausedTotal        time.Duration
	PauseStart         *time.Time
	lastElapsed        int
	Accent             lipgloss.Color
}

// NewLoadingWidget constructs a loading indicator.
func NewLoadingWidget(status string, showHint bool) *LoadingWidget {
	w := &LoadingWidget{
		ShowHint:       showHint,
		ColorDirection: 1,
		StartTime:      time.Now(),
		lastElapsed:    -1,
		Accent:         lipgloss.Color("#A3A3A3"),
	}
	w.InitSpinner(SpinnerSnake)
	if status == "" {
		w.Status = w.defaultStatus()
	} else {
		w.Status = w.applyEasterEgg(status)
	}
	return w
}

func (w *LoadingWidget) pickEasterEgg() string {
	if rand.Float64() >= 0.10 {
		return ""
	}
	eggs := append([]string{}, easterEggs...)
	now := time.Now()
	if now.Month() == time.October && now.Day() == 31 {
		eggs = append(eggs, easterEggsHalloween...)
	}
	if now.Month() == time.December {
		eggs = append(eggs, easterEggsDecember...)
	}
	return eggs[rand.Intn(len(eggs))]
}

func (w *LoadingWidget) defaultStatus() string {
	if e := w.pickEasterEgg(); e != "" {
		return e
	}
	return DefaultLoadingStatus
}

func (w *LoadingWidget) applyEasterEgg(status string) string {
	if e := w.pickEasterEgg(); e != "" {
		return e
	}
	return status
}

// SetStatus updates the loading label (may swap to easter egg).
func (w *LoadingWidget) SetStatus(status string) {
	w.Status = w.applyEasterEgg(status)
}

// ShowDebounceHint displays "typing detected, waiting…".
func (w *LoadingWidget) ShowDebounceHint() { w.ShowDebounce = true }

// HideDebounceHint hides the debounce hint.
func (w *LoadingWidget) HideDebounceHint() { w.ShowDebounce = false }

// PauseTimer pauses elapsed time accounting.
func (w *LoadingWidget) PauseTimer() {
	if w.PauseStart == nil {
		now := time.Now()
		w.PauseStart = &now
	}
}

// ResumeTimer resumes elapsed time accounting.
func (w *LoadingWidget) ResumeTimer() {
	if w.PauseStart != nil {
		w.PausedTotal += time.Since(*w.PauseStart)
		w.PauseStart = nil
	}
}

// ElapsedSeconds returns active elapsed seconds.
func (w *LoadingWidget) ElapsedSeconds() int {
	paused := w.PausedTotal
	if w.PauseStart != nil {
		paused += time.Since(*w.PauseStart)
	}
	return int(time.Since(w.StartTime.Add(paused)).Seconds())
}

func (w *LoadingWidget) nextColorIndex() int {
	return w.CurrentColorIndex + w.ColorDirection
}

func (w *LoadingWidget) colorForPosition(pos int) string {
	cur := loadingTargetColors[w.CurrentColorIndex]
	nextIdx := w.nextColorIndex()
	if nextIdx < 0 {
		nextIdx = 0
	}
	if nextIdx >= len(loadingTargetColors) {
		nextIdx = len(loadingTargetColors) - 1
	}
	next := loadingTargetColors[nextIdx]
	if pos < w.TransitionProgress {
		return next
	}
	return cur
}

// Tick advances color wipe + spinner and returns the view string.
func (w *LoadingWidget) Tick() string {
	if !w.IsSpinning {
		ind := w.StopSpinning(true)
		return ind + " " + w.Status
	}
	total := 1 + len(w.Status) + 1
	spin := w.Spinner.NextFrame()
	spinColor := w.colorForPosition(0)
	var parts []string
	parts = append(parts, lipgloss.NewStyle().Foreground(lipgloss.Color(spinColor)).Render(spin))
	for i, ch := range w.Status {
		c := w.colorForPosition(1 + i)
		parts = append(parts, lipgloss.NewStyle().Foreground(lipgloss.Color(c)).Render(string(ch)))
	}
	ellColor := w.colorForPosition(1 + len(w.Status))
	parts = append(parts, lipgloss.NewStyle().Foreground(lipgloss.Color(ellColor)).Render("… "))
	w.TransitionProgress++
	if w.TransitionProgress > total {
		w.CurrentColorIndex = w.nextColorIndex()
		if w.CurrentColorIndex <= 0 || w.CurrentColorIndex >= len(loadingTargetColors)-1 {
			w.ColorDirection *= -1
		}
		if w.CurrentColorIndex < 0 {
			w.CurrentColorIndex = 0
		}
		if w.CurrentColorIndex >= len(loadingTargetColors) {
			w.CurrentColorIndex = len(loadingTargetColors) - 1
		}
		w.TransitionProgress = 0
	}
	line := strings.Join(parts, "")
	if w.ShowHint {
		elapsed := w.ElapsedSeconds()
		w.lastElapsed = elapsed
		line += " " + lipgloss.NewStyle().Faint(true).Render(fmt.Sprintf("(%s Esc/Ctrl+C to interrupt)", FormatElapsed(elapsed)))
	}
	if w.ShowDebounce {
		line += " " + lipgloss.NewStyle().Italic(true).Faint(true).Render("typing detected, waiting…")
	}
	return line
}

// View renders current frame without advancing.
func (w *LoadingWidget) View() string {
	spin := "⠋"
	if w.Spinner != nil {
		spin = w.Spinner.CurrentFrame()
	}
	line := spin + " " + w.Status + "…"
	if w.ShowHint {
		line += fmt.Sprintf(" (%s Esc/Ctrl+C to interrupt)", FormatElapsed(w.ElapsedSeconds()))
	}
	return line
}

// WithPausedTimer runs fn while the loading timer is paused.
func WithPausedTimer(w *LoadingWidget, fn func()) {
	if w != nil {
		w.PauseTimer()
		defer w.ResumeTimer()
	}
	fn()
}
