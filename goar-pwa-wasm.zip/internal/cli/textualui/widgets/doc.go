// Package widgets implements TUI chat widgets.
package widgets
