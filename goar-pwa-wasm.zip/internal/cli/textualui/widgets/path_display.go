package widgets

import (
	"os"
	"path/filepath"
	"strings"
)

// PathDisplay renders a filesystem path with ~ home abbreviation.
type PathDisplay struct {
	Path string
}

// NewPathDisplay creates a path display.
func NewPathDisplay(path string) PathDisplay {
	return PathDisplay{Path: path}
}

// String returns the display form.
func (p PathDisplay) String() string {
	return FormatPathDisplay(p.Path)
}

// SetPath updates the underlying path.
func (p *PathDisplay) SetPath(path string) { p.Path = path }

// FormatPathDisplay abbreviates $HOME as ~/.
func FormatPathDisplay(path string) string {
	if path == "" {
		return ""
	}
	abs := path
	if !filepath.IsAbs(path) {
		if a, err := filepath.Abs(path); err == nil {
			abs = a
		}
	}
	home, err := os.UserHomeDir()
	if err != nil || home == "" {
		return abs
	}
	if abs == home {
		return "~"
	}
	prefix := home + string(filepath.Separator)
	if strings.HasPrefix(abs, prefix) {
		return "~/" + filepath.ToSlash(abs[len(prefix):])
	}
	return abs
}
