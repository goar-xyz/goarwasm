package widgets

// NoMarkupStatic renders plain text without markup interpretation.
type NoMarkupStatic struct{ Text string }

func (n NoMarkupStatic) View() string { return n.Text }
