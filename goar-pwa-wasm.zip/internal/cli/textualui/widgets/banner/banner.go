package banner

import (
	"fmt"
	"strings"

	"github.com/charmbracelet/lipgloss"
	"github.com/goarxyz/goar/internal/cli/textualui/uitheme"
)

const (
	brandName = "GOAR"
	tagline   = "Autonomous CLI coding agent. Provider-agnostic. Local-first."
	asciiMark = `  ██████╗  ██████╗  █████╗ ██████╗
 ██╔════╝ ██╔═══██╗██╔══██╗██╔══██╗
 ██║  ███╗██║   ██║███████║██████╔╝
 ██║   ██║██║   ██║██╔══██║██╔══██╗
 ╚██████╔╝╚██████╔╝██║  ██║██║  ██║
  ╚═════╝  ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═╝`
)

// CompactMark is a one-line brand mark for narrow terminals.
const CompactMark = "GOAR"

// Banner renders the startup splash (Python banner.py).
type Banner struct {
	Version     string
	Model       string
	Theme       uitheme.Theme
	Agent       string
	SessionID   string
	Width       int
	ShowASCII   bool
	ExtraLines  []string
}

// NewBanner constructs a banner with defaults.
func NewBanner(version, model string, theme uitheme.Theme) Banner {
	return Banner{Version: version, Model: model, Theme: theme, ShowASCII: true, Width: 80}
}

// View renders the banner.
func (b Banner) View() string {
	accent := lipgloss.NewStyle().Bold(true).Foreground(b.Theme.Accent)
	fg := lipgloss.NewStyle().Foreground(b.Theme.Foreground)
	muted := lipgloss.NewStyle().Foreground(b.Theme.Muted)
	var parts []string
	if b.ShowASCII && (b.Width == 0 || b.Width >= 48) {
		parts = append(parts, accent.Render(asciiMark))
	} else {
		parts = append(parts, accent.Render(CompactMark))
	}
	meta := fmt.Sprintf("%s v%s", brandName, b.Version)
	if b.Model != "" {
		meta += " · model " + b.Model
	}
	if b.Agent != "" {
		meta += " · agent " + b.Agent
	}
	parts = append(parts, fg.Render(meta))
	parts = append(parts, muted.Render(tagline))
	if b.SessionID != "" {
		parts = append(parts, muted.Render("session "+short(b.SessionID)))
	}
	for _, line := range b.ExtraLines {
		parts = append(parts, muted.Render(line))
	}
	out := strings.Join(parts, "\n") + "\n"
	if b.Width > 0 {
		box := lipgloss.NewStyle().Width(b.Width)
		return box.Render(out)
	}
	return out
}

// Height estimates rendered line count.
func (b Banner) Height() int {
	h := 2 // meta + tagline
	if b.ShowASCII && (b.Width == 0 || b.Width >= 48) {
		h += strings.Count(asciiMark, "\n") + 1
	} else {
		h++
	}
	if b.SessionID != "" {
		h++
	}
	h += len(b.ExtraLines)
	return h + 1
}

func short(id string) string {
	if len(id) <= 8 {
		return id
	}
	return id[:8]
}
