package textualui

// SessionExitReason explains why the TUI exited.
type SessionExitReason string

const (
	ExitQuit     SessionExitReason = "quit"
	ExitError    SessionExitReason = "error"
	ExitComplete SessionExitReason = "complete"
)

// SessionExit carries exit metadata.
type SessionExit struct {
	Reason  SessionExitReason
	Message string
}
