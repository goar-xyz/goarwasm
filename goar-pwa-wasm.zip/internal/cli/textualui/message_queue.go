package textualui

import (
	"sync"

	"github.com/goarxyz/goar/internal/cli/textualui/widgets"
)

// QueuedItemKind distinguishes prompt vs bash queued entries (Python QueuedItemKind).
type QueuedItemKind string

const (
	QueuedPrompt QueuedItemKind = "prompt"
	QueuedBash   QueuedItemKind = "bash"
)

// QueuedItem is one queued user entry (Python QueuedItem).
type QueuedItem struct {
	Kind    QueuedItemKind
	Content string
}

// MessageQueue holds user messages typed while the agent is busy (Python MessageQueue).
type MessageQueue struct {
	mu       sync.Mutex
	items    []QueuedItem
	paused   bool
	onChange func()
}

// SetChangeListener registers a callback invoked after mutations.
func (q *MessageQueue) SetChangeListener(listener func()) {
	q.mu.Lock()
	defer q.mu.Unlock()
	q.onChange = listener
}

// Len returns the number of queued items.
func (q *MessageQueue) Len() int {
	q.mu.Lock()
	defer q.mu.Unlock()
	return len(q.items)
}

// Empty reports whether the queue has no items.
func (q *MessageQueue) Empty() bool { return q.Len() == 0 }

// Items returns a copy of queued items.
func (q *MessageQueue) Items() []QueuedItem {
	q.mu.Lock()
	defer q.mu.Unlock()
	out := make([]QueuedItem, len(q.items))
	copy(out, q.items)
	return out
}

// Paused reports whether the queue is paused.
func (q *MessageQueue) Paused() bool {
	q.mu.Lock()
	defer q.mu.Unlock()
	return q.paused
}

// AppendPrompt enqueues a user prompt.
func (q *MessageQueue) AppendPrompt(content string) {
	q.mu.Lock()
	q.items = append(q.items, QueuedItem{Kind: QueuedPrompt, Content: content})
	fn := q.onChange
	q.mu.Unlock()
	if fn != nil {
		fn()
	}
}

// AppendBash enqueues a bash command.
func (q *MessageQueue) AppendBash(content string) {
	q.mu.Lock()
	q.items = append(q.items, QueuedItem{Kind: QueuedBash, Content: content})
	fn := q.onChange
	q.mu.Unlock()
	if fn != nil {
		fn()
	}
}

// Enqueue is a compat alias for AppendPrompt.
func (q *MessageQueue) Enqueue(s string) { q.AppendPrompt(s) }

// PopLast removes and returns the last item.
func (q *MessageQueue) PopLast() *QueuedItem {
	q.mu.Lock()
	if len(q.items) == 0 {
		q.mu.Unlock()
		return nil
	}
	item := q.items[len(q.items)-1]
	q.items = q.items[:len(q.items)-1]
	fn := q.onChange
	q.mu.Unlock()
	if fn != nil {
		fn()
	}
	return &item
}

// PopFirst removes and returns the first item.
func (q *MessageQueue) PopFirst() *QueuedItem {
	q.mu.Lock()
	if len(q.items) == 0 {
		q.mu.Unlock()
		return nil
	}
	item := q.items[0]
	q.items = q.items[1:]
	fn := q.onChange
	q.mu.Unlock()
	if fn != nil {
		fn()
	}
	return &item
}

// PopAll returns and clears all items (compat).
func (q *MessageQueue) PopAll() []string {
	q.mu.Lock()
	out := make([]string, 0, len(q.items))
	for _, it := range q.items {
		out = append(out, it.Content)
	}
	q.items = nil
	fn := q.onChange
	q.mu.Unlock()
	if fn != nil {
		fn()
	}
	return out
}

// Pause marks the queue paused.
func (q *MessageQueue) Pause() {
	q.mu.Lock()
	if q.paused {
		q.mu.Unlock()
		return
	}
	q.paused = true
	fn := q.onChange
	q.mu.Unlock()
	if fn != nil {
		fn()
	}
}

// Resume clears the paused flag.
func (q *MessageQueue) Resume() {
	q.mu.Lock()
	if !q.paused {
		q.mu.Unlock()
		return
	}
	q.paused = false
	fn := q.onChange
	q.mu.Unlock()
	if fn != nil {
		fn()
	}
}

// Clear removes all items and unpauses.
func (q *MessageQueue) Clear() {
	q.mu.Lock()
	if len(q.items) == 0 && !q.paused {
		q.mu.Unlock()
		return
	}
	q.items = nil
	q.paused = false
	fn := q.onChange
	q.mu.Unlock()
	if fn != nil {
		fn()
	}
}

// ItemsAsEntries adapts queue items for the QueuedMessages widget.
func (q *MessageQueue) ItemsAsEntries() []widgets.QueueEntry {
	items := q.Items()
	out := make([]widgets.QueueEntry, 0, len(items))
	for _, it := range items {
		kind := widgets.QueuedKindPrompt
		if it.Kind == QueuedBash {
			kind = widgets.QueuedKindBash
		}
		out = append(out, widgets.QueueEntry{Kind: kind, Content: it.Content})
	}
	return out
}
