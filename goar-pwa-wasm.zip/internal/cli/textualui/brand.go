package textualui

const (
	BrandName = "GOAR"
	Tagline   = "Autonomous CLI coding agent. Provider-agnostic. Local-first."
	ASCIIMark = `  ██████╗  ██████╗  █████╗ ██████╗
 ██╔════╝ ██╔═══██╗██╔══██╗██╔══██╗
 ██║  ███╗██║   ██║███████║██████╔╝
 ██║   ██║██║   ██║██╔══██║██╔══██╗
 ╚██████╔╝╚██████╔╝██║  ██║██║  ██║
  ╚═════╝  ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═╝`
)
