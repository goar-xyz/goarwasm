// Package handlers processes runtime events for the TUI.
package handlers
