package handlers

import (
	"encoding/json"
	"os"
	"strings"
	"sync"

	"github.com/goarxyz/goar/internal/cli/textualui/notifications/ports"
	"github.com/goarxyz/goar/internal/cli/textualui/widgets"
	"github.com/goarxyz/goar/internal/core/types"
	"github.com/goarxyz/goar/internal/core/utils"
)

// MountFunc mounts a UI widget/message into the chat transcript.
type MountFunc func(widget any, after any) error

// LoadingStatusSetter updates the loading spinner text.
type LoadingStatusSetter func(status string)

// EventHandler routes runtime events to UI sinks (Python EventHandler).
type EventHandler struct {
	mu sync.Mutex

	Mount              MountFunc
	GetToolsCollapsed  func() bool
	OnProfileChanged   func()
	OnAssistant        func(string)
	OnReasoning        func(string)
	OnToolCall         func(name, args string)
	OnToolResult       func(name, result string)
	OnCompactStart     func()
	OnCompactEnd       func(oldSession, newSession string)
	OnUserMessage      func(string)
	OnUnknown          func(string)
	SetLoadingStatus   LoadingStatusSetter
	Notify             ports.Port
	IsRemote           bool
	DefaultLoadStatus  string

	toolCalls                 map[string]*widgets.ToolCallWidget
	currentCompact            *widgets.CompactWidget
	currentStreamingMessage   *widgets.AssistantWidget
	currentStreamingReasoning *widgets.ReasoningWidget
	planFileMessage           *widgets.PlanFileMessage
	hookRunActive             bool
}

// NewEventHandler constructs an event handler with required mount + collapse callbacks.
func NewEventHandler(mount MountFunc, getToolsCollapsed func() bool) *EventHandler {
	return &EventHandler{
		Mount:             mount,
		GetToolsCollapsed: getToolsCollapsed,
		toolCalls:         map[string]*widgets.ToolCallWidget{},
		DefaultLoadStatus: "Thinking…",
	}
}

// Handle routes a typed runtime event (compat simple API).
func (h *EventHandler) Handle(ev types.Event) {
	_, _ = h.HandleEvent(ev, nil)
}

// HandleEvent is the full Python handle_event port.
func (h *EventHandler) HandleEvent(ev types.Event, loadingStatus LoadingStatusSetter) (*widgets.ToolCallWidget, error) {
	h.mu.Lock()
	defer h.mu.Unlock()
	if loadingStatus == nil {
		loadingStatus = h.SetLoadingStatus
	}
	switch ev.Type {
	case "reasoning":
		var payload map[string]any
		_ = json.Unmarshal(ev.Payload, &payload)
		content, _ := payload["content"].(string)
		return nil, h.handleReasoningMessage(content)
	case "assistant":
		var ae types.AssistantEvent
		_ = json.Unmarshal(ev.Payload, &ae)
		return nil, h.handleAssistantMessage(ae)
	case "tool_call":
		_ = h.finalizeStreaming()
		var te types.ToolCallEvent
		_ = json.Unmarshal(ev.Payload, &te)
		return h.handleToolCall(te, loadingStatus)
	case "tool_result":
		_ = h.finalizeStreaming()
		var te types.ToolResultEvent
		_ = json.Unmarshal(ev.Payload, &te)
		te = h.sanitizeEvent(te)
		return nil, h.handleToolResult(te)
	case "tool_stream":
		var payload map[string]any
		_ = json.Unmarshal(ev.Payload, &payload)
		id, _ := payload["tool_call_id"].(string)
		msg, _ := payload["message"].(string)
		h.handleToolStream(id, msg)
		return nil, nil
	case "compact_start":
		_ = h.finalizeStreaming()
		return nil, h.handleCompactStart()
	case "compact_end":
		_ = h.finalizeStreaming()
		var payload map[string]any
		_ = json.Unmarshal(ev.Payload, &payload)
		oldS, _ := payload["old_session_id"].(string)
		newS, _ := payload["new_session_id"].(string)
		h.handleCompactEnd(oldS, newS)
		return nil, nil
	case "agent_profile_changed":
		if h.OnProfileChanged != nil {
			h.OnProfileChanged()
		}
		return nil, nil
	case "session_title_updated":
		return nil, nil
	case "user_message":
		_ = h.finalizeStreaming()
		if h.IsRemote {
			var payload map[string]any
			_ = json.Unmarshal(ev.Payload, &payload)
			content, _ := payload["content"].(string)
			if h.OnUserMessage != nil {
				h.OnUserMessage(content)
			}
			if h.Mount != nil {
				_ = h.Mount(widgets.NewUserWidget(content), nil)
			}
		}
		return nil, nil
	case "hook_run_start":
		h.hookRunActive = true
		if h.Mount != nil {
			_ = h.Mount(widgets.NewHookRunContainer(), nil)
		}
		return nil, nil
	case "hook_run_end":
		h.hookRunActive = false
		return nil, nil
	case "hook_start":
		_ = h.finalizeStreaming()
		var payload map[string]any
		_ = json.Unmarshal(ev.Payload, &payload)
		name, _ := payload["hook_name"].(string)
		if loadingStatus != nil {
			loadingStatus("Running hook " + name)
		}
		return nil, nil
	case "hook_end":
		var payload map[string]any
		_ = json.Unmarshal(ev.Payload, &payload)
		if loadingStatus != nil {
			loadingStatus(h.DefaultLoadStatus)
		}
		return nil, nil
	case "plan_review_requested":
		var payload map[string]any
		_ = json.Unmarshal(ev.Payload, &payload)
		path, _ := payload["file_path"].(string)
		return nil, h.handleStartPlanReview(path)
	case "plan_review_ended":
		h.handleStopPlanReview()
		return nil, nil
	case "waiting_for_input":
		_ = h.finalizeStreaming()
		return nil, nil
	default:
		_ = h.finalizeStreaming()
		return nil, h.handleUnknownEvent(ev)
	}
}

func (h *EventHandler) sanitizeEvent(event types.ToolResultEvent) types.ToolResultEvent {
	if event.Error != "" {
		event.Error = stripTagged(event.Error)
	}
	if event.SkipReason != "" {
		event.SkipReason = stripTagged(event.SkipReason)
	}
	return event
}

func stripTagged(s string) string {
	s = strings.TrimSpace(s)
	for _, tag := range []string{utils.ToolErrorTag, utils.CancellationTag, utils.GoarWarningTag} {
		open := "<" + tag + ">"
		close := "</" + tag + ">"
		if strings.HasPrefix(s, open) && strings.HasSuffix(s, close) {
			s = strings.TrimSuffix(strings.TrimPrefix(s, open), close)
			return strings.TrimSpace(s)
		}
	}
	return s
}

func (h *EventHandler) handleToolCall(event types.ToolCallEvent, loadingStatus LoadingStatusSetter) (*widgets.ToolCallWidget, error) {
	id := event.ToolCallID
	existing := h.toolCalls[id]
	var toolCall *widgets.ToolCallWidget
	if existing != nil {
		existing.UpdateEvent(event)
		toolCall = existing
	} else {
		toolCall = widgets.NewToolCallWidget(event)
		if id != "" {
			h.toolCalls[id] = toolCall
		}
		if h.Mount != nil {
			_ = h.Mount(toolCall, nil)
		}
	}
	if h.OnToolCall != nil {
		h.OnToolCall(event.Name, event.ArgsJSON)
	}
	if loadingStatus != nil && event.Name != "" {
		loadingStatus("Running " + event.Name + "…")
	}
	return toolCall, nil
}

func (h *EventHandler) handleToolResult(event types.ToolResultEvent) error {
	collapsed := false
	if h.GetToolsCollapsed != nil {
		collapsed = h.GetToolsCollapsed()
	}
	var callWidget *widgets.ToolCallWidget
	if event.ToolCallID != "" {
		callWidget = h.toolCalls[event.ToolCallID]
	}
	result := widgets.NewToolResultWidget(event, callWidget, collapsed)
	if h.Mount != nil {
		_ = h.Mount(result, callWidget)
	}
	if h.OnToolResult != nil {
		h.OnToolResult(event.Name, event.ResultJSON)
	}
	if event.ToolCallID != "" {
		delete(h.toolCalls, event.ToolCallID)
	}
	return nil
}

func (h *EventHandler) handleToolStream(toolCallID, message string) {
	if tc := h.toolCalls[toolCallID]; tc != nil {
		tc.SetStreamMessage(message)
	}
}

func (h *EventHandler) handleAssistantMessage(event types.AssistantEvent) error {
	if h.currentStreamingReasoning != nil {
		h.currentStreamingReasoning.StopSpinning()
		h.currentStreamingReasoning.StopStream()
		h.currentStreamingReasoning = nil
	}
	if h.OnAssistant != nil {
		h.OnAssistant(event.Content)
	}
	if h.currentStreamingMessage == nil {
		msg := widgets.NewAssistantWidget(event.Content)
		h.currentStreamingMessage = msg
		if h.Mount != nil {
			return h.Mount(msg, nil)
		}
		return nil
	}
	h.currentStreamingMessage.AppendContent(event.Content)
	return nil
}

func (h *EventHandler) handleReasoningMessage(content string) error {
	if h.currentStreamingMessage != nil {
		h.currentStreamingMessage.StopStream()
		if h.currentStreamingMessage.IsEmpty() {
			// leave removal to the UI layer via Mount semantics
		}
		h.currentStreamingMessage = nil
	}
	if h.OnReasoning != nil {
		h.OnReasoning(content)
	}
	if h.currentStreamingReasoning == nil {
		collapsed := false
		if h.GetToolsCollapsed != nil {
			collapsed = h.GetToolsCollapsed()
		}
		msg := widgets.NewReasoningWidget(content, collapsed)
		h.currentStreamingReasoning = msg
		if h.Mount != nil {
			return h.Mount(msg, nil)
		}
		return nil
	}
	h.currentStreamingReasoning.AppendContent(content)
	return nil
}

func (h *EventHandler) handleCompactStart() error {
	msg := widgets.NewCompactWidget()
	h.currentCompact = msg
	if h.OnCompactStart != nil {
		h.OnCompactStart()
	}
	if h.Mount != nil {
		return h.Mount(msg, nil)
	}
	return nil
}

func (h *EventHandler) handleCompactEnd(oldSession, newSession string) {
	if h.currentCompact != nil {
		h.currentCompact.SetComplete(oldSession, newSession)
		h.currentCompact = nil
	}
	if h.OnCompactEnd != nil {
		h.OnCompactEnd(oldSession, newSession)
	}
}

func (h *EventHandler) handleUnknownEvent(ev types.Event) error {
	text := string(ev.Payload)
	if h.OnUnknown != nil {
		h.OnUnknown(text)
	}
	if h.Mount != nil {
		return h.Mount(widgets.NewNoMarkupStatic(text), nil)
	}
	return nil
}

// FinalizeStreaming ends any in-flight assistant/reasoning streams.
func (h *EventHandler) FinalizeStreaming() error {
	h.mu.Lock()
	defer h.mu.Unlock()
	return h.finalizeStreaming()
}

func (h *EventHandler) finalizeStreaming() error {
	if h.currentStreamingReasoning != nil {
		h.currentStreamingReasoning.StopSpinning()
		h.currentStreamingReasoning.StopStream()
		h.currentStreamingReasoning = nil
	}
	if h.currentStreamingMessage != nil {
		h.currentStreamingMessage.StopStream()
		h.currentStreamingMessage = nil
	}
	return nil
}

// StopCurrentToolCall stops all in-flight tool call widgets.
func (h *EventHandler) StopCurrentToolCall(success bool) {
	h.mu.Lock()
	defer h.mu.Unlock()
	for _, tc := range h.toolCalls {
		tc.StopSpinning(success)
	}
	h.toolCalls = map[string]*widgets.ToolCallWidget{}
}

// StopCurrentCompact stops the compact spinner.
func (h *EventHandler) StopCurrentCompact() {
	h.mu.Lock()
	defer h.mu.Unlock()
	if h.currentCompact != nil {
		h.currentCompact.StopSpinning(false)
		h.currentCompact = nil
	}
}

func (h *EventHandler) handleStartPlanReview(filePath string) error {
	if filePath != "" {
		f, err := os.OpenFile(filePath, os.O_CREATE|os.O_RDONLY, 0o644)
		if err == nil {
			_ = f.Close()
		}
	}
	msg := widgets.NewPlanFileMessage(filePath)
	h.planFileMessage = msg
	if h.Mount != nil {
		return h.Mount(msg, nil)
	}
	return nil
}

func (h *EventHandler) handleStopPlanReview() {
	if h.planFileMessage == nil {
		return
	}
	h.planFileMessage.StopWatching()
	h.planFileMessage = nil
}
