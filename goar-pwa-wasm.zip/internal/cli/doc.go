// Package cli implements the GOAR command-line interface and Bubble Tea TUI.
package cli
