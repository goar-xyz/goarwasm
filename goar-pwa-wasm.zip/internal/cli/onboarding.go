package cli

import (
	"errors"
	"fmt"

	"github.com/goarxyz/goar/internal/cli/onboardui"
	"github.com/goarxyz/goar/internal/core/config"
	"github.com/goarxyz/goar/internal/core/paths"
)

// ErrOnboardingCancelled is returned when the user hits Esc / Ctrl+C.
var ErrOnboardingCancelled = errors.New("setup cancelled")

// RunOnboarding launches the Vibe-style Bubble Tea setup wizard.
func RunOnboarding(force ...bool) error {
	_ = force
	res, err := onboardui.Run()
	if err != nil {
		return err
	}
	if res.Cancelled {
		fmt.Println("\nSetup cancelled. See you next time!")
		return ErrOnboardingCancelled
	}
	name := BrandName
	if res.Preset != nil {
		name = res.Preset.DisplayName
	}
	fmt.Printf("\nSetup complete 🎉. Run %q to start using the %s CLI.\n", "goar", BrandName)
	fmt.Printf("  Home     %s\n  Config   %s\n  Secrets  %s\n  Provider %s\n  Model    %s (%s)\n  Base     %s\n  Theme    %s\n",
		paths.Home(), paths.ConfigFile(), paths.EnvFile(),
		name, res.Alias, res.ModelID, res.APIBase, res.Theme)
	_ = config.LoadDotEnv()
	return nil
}

func version() string {
	return "1.1.1"
}

// NeedsOnboarding reports missing user config.
func NeedsOnboarding() bool { return config.NeedsSetup() }
