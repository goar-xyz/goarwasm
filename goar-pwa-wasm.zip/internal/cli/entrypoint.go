package cli

import (
	"context"
	"errors"
	"fmt"
	"os"

	"github.com/spf13/cobra"

	goar "github.com/goarxyz/goar"
	"github.com/goarxyz/goar/internal/core"
	"github.com/goarxyz/goar/internal/core/config"
	"github.com/goarxyz/goar/internal/core/paths"
)

// RootOptions holds global flags.
type RootOptions struct {
	Setup        bool
	Prompt       string
	MaxTurns     int
	MaxPrice     float64
	MaxTokens    int
	Agent        string
	Workdir      string
	Output       string
	Trust        bool
	Continue     bool
	Resume       string
	EnabledTools []string
}

// NewRootCmd builds the cobra root command.
func NewRootCmd() *cobra.Command {
	opt := &RootOptions{}
	cmd := &cobra.Command{
		Use:           "goar",
		Short:         "GOAR — Autonomous CLI coding agent",
		Version:       goar.Version,
		SilenceUsage:  true,
		SilenceErrors: true,
		Long: `GOAR — Autonomous execution engine

Environment variables:
  AGENT_HOME                 Override agent home directory (default: ~/.agent)
  OPENAI_API_KEY             Default API key for OpenAI-compatible providers
  OPENAI_BASE_URL            Override API base URL for OpenAI/custom providers
  OPENAI_MODEL               Override active model
  AGENT_THEME                Override UI theme
  AGENT_DEFAULT_AGENT        Override default agent
  AGENT_API_TIMEOUT          Override API timeout (seconds)
  AGENT_BYPASS_TOOL_PERMISSIONS  Set 1/true to bypass tool permission prompts
  LOG_LEVEL                  Logging level

First run opens an interactive provider wizard.
Re-run anytime with --setup.`,
		Args: cobra.MaximumNArgs(1),
		RunE: func(cmd *cobra.Command, args []string) error {
			return runRoot(opt, args)
		},
	}
	cmd.Flags().BoolVar(&opt.Setup, "setup", false, "Run the provider onboarding wizard and exit")
	cmd.Flags().StringVarP(&opt.Prompt, "prompt", "p", "", "Run in programmatic mode and exit")
	cmd.Flags().IntVar(&opt.MaxTurns, "max-turns", 0, "Maximum assistant turns (programmatic)")
	cmd.Flags().Float64Var(&opt.MaxPrice, "max-price", 0, "Maximum cost in dollars (programmatic)")
	cmd.Flags().IntVar(&opt.MaxTokens, "max-tokens", 0, "Maximum session tokens (programmatic)")
	cmd.Flags().StringVar(&opt.Agent, "agent", "", "Agent profile to use")
	cmd.Flags().StringVar(&opt.Workdir, "workdir", "", "Change to this directory before running")
	cmd.Flags().StringVar(&opt.Output, "output", "text", "Output format: text|json|streaming")
	cmd.Flags().BoolVar(&opt.Trust, "trust", false, "Trust working directory for this invocation")
	cmd.Flags().BoolVarP(&opt.Continue, "continue", "c", false, "Continue most recent session")
	cmd.Flags().StringVar(&opt.Resume, "resume", "", "Resume a session by id")
	cmd.Flags().StringArrayVar(&opt.EnabledTools, "enabled-tools", nil, "Enable specific tools")

	cmd.AddCommand(newRunCmd())
	cmd.AddCommand(newServeCmd())
	return cmd
}

func newRunCmd() *cobra.Command {
	var agent string
	var maxTurns int
	c := &cobra.Command{
		Use:          "run [prompt]",
		Short:        "Run a headless prompt",
		SilenceUsage: true,
		Args:         cobra.ExactArgs(1),
		RunE: func(cmd *cobra.Command, args []string) error {
			return runProgrammatic(args[0], agent, maxTurns, 0, 0, "text")
		},
	}
	c.Flags().StringVar(&agent, "agent", "auto-approve", "Agent profile")
	c.Flags().IntVar(&maxTurns, "max-turns", 0, "Max turns")
	return c
}

func runRoot(opt *RootOptions, args []string) error {
	if opt.Workdir != "" {
		if err := os.Chdir(opt.Workdir); err != nil {
			return err
		}
	}
	_ = paths.EnsureHome()
	if opt.Setup || NeedsOnboarding() {
		if err := RunOnboarding(); err != nil {
			if errors.Is(err, ErrOnboardingCancelled) {
				return nil
			}
			return err
		}
		if opt.Setup {
			return nil
		}
	}
	prompt := opt.Prompt
	if prompt == "" && len(args) > 0 {
		prompt = args[0]
	}
	// Full CLI orchestration: onboarding, --continue/--resume, hooks,
	// enabled-tools, streaming runtime, and interactive TUI via RunCLI.
	return RunCLI(opt, prompt)
}

func runProgrammatic(prompt, agent string, maxTurns int, maxPrice float64, maxTokens int, output string) error {
	cfg, err := config.Load()
	if err != nil {
		return err
	}
	if agent == "" {
		agent = cfg.DefaultAgent
	}
	opt := core.RuntimeOptions{
		AgentName: agent, Headless: true, MaxTurns: maxTurns, MaxPrice: maxPrice, MaxSessionTokens: maxTokens,
	}
	_, err = core.RunProgrammatic(context.Background(), cfg, prompt, opt)
	return err
}

// Execute runs the root command.
func Execute() {
	if err := NewRootCmd().Execute(); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
}
