//go:build !(js && wasm)

package cli

import (
	"fmt"

	"github.com/goarxyz/goar/internal/cli/textualui"
	"github.com/goarxyz/goar/internal/cli/textualui/uitheme"
	"github.com/goarxyz/goar/internal/core"
	"github.com/goarxyz/goar/internal/core/config"
)

// RunTUI launches the Bubble Tea interactive UI (thin helper).
// Prefer RunCLI for full orchestration (--continue/--resume/hooks/streaming).
func RunTUI(initialPrompt, agent string) error {
	uitheme.EnsureColorProfile()
	cfg, err := config.Load()
	if err != nil {
		return err
	}
	if agent == "" {
		agent = cfg.DefaultAgent
	}
	rt, err := core.NewRuntime(cfg, core.RuntimeOptions{AgentName: agent, Headless: false})
	if err != nil {
		return fmt.Errorf("runtime: %w", err)
	}
	defer rt.Close()
	return textualui.RunTextualUI(cfg, rt, initialPrompt, agent)
}
