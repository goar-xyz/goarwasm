package cli

import (
	"bytes"
	"io"
	"os"
	"sync"
)

// StderrGuard captures/redirects stderr for the duration of a critical section
// (Python stderr_guard) so TUI rendering is not corrupted by library noise.
type StderrGuard struct {
	mu       sync.Mutex
	orig     *os.File
	reader   *os.File
	writer   *os.File
	buf      bytes.Buffer
	done     chan struct{}
	active   bool
	copyErr  error
}

// GuardStderr temporarily redirects stderr to w (compat helper).
func GuardStderr(w io.Writer) func() {
	g := &StderrGuard{}
	_ = g.Start()
	go func() {
		_, _ = io.Copy(w, &g.buf)
	}()
	return func() { _ = g.Stop() }
}

// Start begins redirecting os.Stderr into an internal buffer.
func (g *StderrGuard) Start() error {
	g.mu.Lock()
	defer g.mu.Unlock()
	if g.active {
		return nil
	}
	r, w, err := os.Pipe()
	if err != nil {
		return err
	}
	g.orig = os.Stderr
	g.reader = r
	g.writer = w
	g.done = make(chan struct{})
	os.Stderr = w
	g.active = true
	go func() {
		_, g.copyErr = io.Copy(&g.buf, r)
		close(g.done)
	}()
	return nil
}

// Stop restores stderr and returns captured bytes.
func (g *StderrGuard) Stop() []byte {
	g.mu.Lock()
	if !g.active {
		g.mu.Unlock()
		return nil
	}
	_ = g.writer.Close()
	os.Stderr = g.orig
	g.active = false
	done := g.done
	g.mu.Unlock()
	<-done
	g.mu.Lock()
	defer g.mu.Unlock()
	out := append([]byte{}, g.buf.Bytes()...)
	g.buf.Reset()
	_ = g.reader.Close()
	return out
}

// Bytes returns a copy of captured stderr so far.
func (g *StderrGuard) Bytes() []byte {
	g.mu.Lock()
	defer g.mu.Unlock()
	return append([]byte{}, g.buf.Bytes()...)
}

// IsStderrATTY reports whether the original stderr is a terminal.
func IsStderrATTY() bool {
	fi, err := os.Stderr.Stat()
	if err != nil {
		return false
	}
	return (fi.Mode() & os.ModeCharDevice) != 0
}

// WithStderrGuard runs fn while stderr is redirected; restores afterward.
func WithStderrGuard(fn func()) []byte {
	g := &StderrGuard{}
	_ = g.Start()
	defer func() { _ = g.Stop() }()
	fn()
	return g.Stop()
}

// cleanup mirrors Python _cleanup for pipe fds.
func cleanup(r, w *os.File, orig *os.File) {
	if w != nil {
		_ = w.Close()
	}
	if r != nil {
		_ = r.Close()
	}
	if orig != nil {
		os.Stderr = orig
	}
}
