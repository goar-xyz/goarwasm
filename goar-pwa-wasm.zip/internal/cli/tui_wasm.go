//go:build js && wasm

package cli

import "fmt"

// RunTUI is unavailable in the browser; use the PWA chat (goar.runAgent) instead.
func RunTUI(initialPrompt, agent string) error {
	_ = initialPrompt
	_ = agent
	return fmt.Errorf("Bubble Tea TUI is not available under GOOS=js/wasm; use the PWA (goar.runAgent) or native CLI")
}
