package cli

import (
	"context"
	"errors"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"strings"

	"github.com/goarxyz/goar/internal/cli/textualui"
	"github.com/goarxyz/goar/internal/core"
	"github.com/goarxyz/goar/internal/core/config"
	harnessfiles "github.com/goarxyz/goar/internal/core/config/harness_files"
	"github.com/goarxyz/goar/internal/core/hooks"
	"github.com/goarxyz/goar/internal/core/paths"
	"github.com/goarxyz/goar/internal/core/session"
	"github.com/goarxyz/goar/internal/core/types"
	"golang.org/x/term"
)

// Run is an alias entry used by older call sites.
func Run() { Execute() }

// GetInitialAgentName resolves the agent from flags or config default.
func GetInitialAgentName(opt *RootOptions, cfg *config.Config) string {
	if opt != nil && opt.Agent != "" {
		return opt.Agent
	}
	if cfg != nil && cfg.DefaultAgent != "" {
		return cfg.DefaultAgent
	}
	return config.DefaultAgent
}

// GetPromptFromStdin reads a non-TTY stdin prompt once.
func GetPromptFromStdio(r io.Reader) (string, bool) {
	if f, ok := r.(*os.File); ok {
		if term.IsTerminal(int(f.Fd())) {
			return "", false
		}
	}
	b, err := io.ReadAll(r)
	if err != nil {
		return "", false
	}
	s := strings.TrimSpace(string(b))
	if s == "" {
		return "", false
	}
	return s, true
}

// LoadConfigOrExit loads config, optionally forcing onboarding on missing API key.
func LoadConfigOrExit(allowSetup bool) (*config.Config, error) {
	cfg, err := config.Load()
	if err == nil {
		return cfg, nil
	}
	if _, ok := err.(*config.MissingAPIKeyError); ok && allowSetup {
		if term.IsTerminal(int(os.Stdin.Fd())) && term.IsTerminal(int(os.Stdout.Fd())) {
			fmt.Fprintf(os.Stderr, "%v\nNo usable API key for the active provider. Starting setup.\n", err)
			if onErr := RunOnboarding(true); onErr != nil {
				if errors.Is(onErr, ErrOnboardingCancelled) {
					return nil, onErr
				}
				return nil, onErr
			}
			config.LoadDotenvValues()
			cfg, err = config.Load()
			if err != nil {
				return nil, err
			}
			return cfg, nil
		}
	}
	return nil, err
}

// BootstrapConfigFiles creates default user config + history if missing.
func BootstrapConfigFiles() {
	mgr := harnessfiles.Get()
	configFile := mgr.UserConfigFile
	if _, err := os.Stat(configFile); os.IsNotExist(err) {
		_ = os.MkdirAll(filepath.Dir(configFile), 0o755)
		cfg := config.Default()
		if err := config.Save(cfg); err != nil {
			fmt.Fprintf(os.Stderr, "Could not create default config file: %v\n", err)
		}
	}
	hist := paths.HistoryFile()
	if _, err := os.Stat(hist); os.IsNotExist(err) {
		_ = os.MkdirAll(filepath.Dir(hist), 0o755)
		if err := os.WriteFile(hist, []byte("GOAR ready.\n"), 0o644); err != nil {
			fmt.Fprintf(os.Stderr, "Could not create history file: %v\n", err)
		}
	}
}

// LoadSessionResult is messages + path for a resumed session.
type LoadSessionResult struct {
	Messages []types.LLMMessage
	Path     string
}

// LoadSession resolves --continue / --resume into messages.
func LoadSession(opt *RootOptions, cfg *config.Config) (*LoadSessionResult, error) {
	if opt == nil || cfg == nil {
		return nil, nil
	}
	if !opt.Continue && opt.Resume == "" {
		return nil, nil
	}
	if !cfg.SessionLogging.Enabled {
		return nil, fmt.Errorf("session logging is disabled; enable it to use --continue or --resume")
	}
	var sessionPath string
	cwd, _ := os.Getwd()
	if opt.Continue {
		pointerID := session.LoadLastSessionPointer(cfg.SessionLogging)
		if pointerID != "" {
			sessionPath = session.FindSessionByID(pointerID, cfg.SessionLogging, cwd)
		}
		if sessionPath == "" {
			sessionPath = session.FindLatestSession(cfg.SessionLogging, cwd)
		}
		if sessionPath == "" {
			return nil, fmt.Errorf("no previous sessions found in %s for cwd=%s", cfg.SessionLogging.SaveDir, cwd)
		}
	} else {
		sessionPath = session.FindSessionByID(opt.Resume, cfg.SessionLogging, "")
		if sessionPath == "" {
			return nil, fmt.Errorf("session %q not found in %s", opt.Resume, cfg.SessionLogging.SaveDir)
		}
	}
	msgs, _, err := session.LoadSession(sessionPath)
	if err != nil {
		return nil, fmt.Errorf("failed to load session: %w", err)
	}
	return &LoadSessionResult{Messages: msgs, Path: sessionPath}, nil
}

// ResumePreviousSession attaches loaded messages onto a runtime.
func ResumePreviousSession(rt *core.Runtime, loaded []types.LLMMessage, sessionPath string) {
	nonSystem := make([]types.LLMMessage, 0, len(loaded))
	for _, m := range loaded {
		if m.Role != types.RoleSystem {
			nonSystem = append(nonSystem, m)
		}
	}
	rt.Messages = append(rt.Messages, nonSystem...)
	_, meta, err := session.LoadSession(sessionPath)
	if err == nil {
		if sid, ok := meta["session_id"].(string); ok && sid != "" {
			rt.SessionID = sid
		}
		if rt.SessionLogger != nil {
			_ = rt.SessionLogger.ResumeExistingSession(rt.SessionID, sessionPath)
		}
	}
}

// RunCLI is the high-level CLI orchestration (port of run_cli).
func RunCLI(opt *RootOptions, initialPrompt string) error {
	config.LoadDotenvValues()
	if opt.Setup || NeedsOnboarding() {
		if !term.IsTerminal(int(os.Stdin.Fd())) || !term.IsTerminal(int(os.Stdout.Fd())) {
			return fmt.Errorf("GOAR has no config. Run `goar --setup` in a terminal")
		}
		if err := RunOnboarding(true); err != nil {
			if errors.Is(err, ErrOnboardingCancelled) {
				return nil
			}
			return err
		}
		config.LoadDotenvValues()
		if opt.Setup && opt.Prompt == "" && initialPrompt == "" {
			return nil
		}
	} else {
		BootstrapConfigFiles()
	}

	cfg, err := LoadConfigOrExit(true)
	if err != nil {
		return err
	}
	agentName := GetInitialAgentName(opt, cfg)
	hookResult := hooks.LoadHooksFromFS(cfg)

	if len(opt.EnabledTools) > 0 {
		cfg.EnabledTools = opt.EnabledTools
	}

	loaded, err := LoadSession(opt, cfg)
	if err != nil {
		return err
	}

	// Avoid blocking ReadAll on non-TTY stdin when -p already provided a prompt
	// (common under CI / agent shells that pipe stdin without EOF).
	var stdinPrompt string
	if opt.Prompt == "" {
		stdinPrompt, _ = GetPromptFromStdio(os.Stdin)
	}
	if opt.Prompt != "" || hasPromptFlag() {
		cfg.DisabledTools = append(cfg.DisabledTools, "ask_user_question", "exit_plan_mode")
		prog := opt.Prompt
		if prog == "" {
			prog = stdinPrompt
		}
		if prog == "" {
			return fmt.Errorf("no prompt provided for programmatic mode")
		}
		var prev []types.LLMMessage
		if loaded != nil {
			prev = loaded.Messages
		}
		ropt := core.RuntimeOptions{
			AgentName: agentName, Headless: true, HookResult: &hookResult,
			MaxTurns: opt.MaxTurns, MaxPrice: opt.MaxPrice, MaxSessionTokens: opt.MaxTokens,
		}
		_ = prev
		out, err := core.RunProgrammatic(context.Background(), cfg, prog, ropt)
		if err != nil {
			return err
		}
		if out != "" {
			fmt.Println(out)
		}
		return nil
	}

	rt, err := core.NewRuntime(cfg, core.RuntimeOptions{
		AgentName: agentName, EnableStreaming: true, HookResult: &hookResult,
		MaxTurns: opt.MaxTurns, MaxPrice: opt.MaxPrice, MaxSessionTokens: opt.MaxTokens,
	})
	if err != nil {
		return err
	}
	defer rt.Close()
	if loaded != nil {
		ResumePreviousSession(rt, loaded.Messages, loaded.Path)
	}
	prompt := initialPrompt
	if prompt == "" {
		prompt = stdinPrompt
	}
	return textualui.RunTextualUI(cfg, rt, prompt, agentName)
}

func hasPromptFlag() bool {
	for _, a := range os.Args[1:] {
		if a == "-p" || a == "--prompt" || strings.HasPrefix(a, "--prompt=") {
			return true
		}
	}
	return false
}
