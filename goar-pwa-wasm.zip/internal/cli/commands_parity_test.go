package cli

import "testing"

func TestVibeSlashParity(t *testing.T) {
	r := NewCommandRegistry(nil, nil)
	need := []string{"help", "config", "model", "skills", "thinking", "reload", "clear", "copy", "paste-image", "log", "log-level", "debug", "compact", "exit", "status", "whoami", "proxy-setup", "resume", "rename", "mcp", "plugins", "reload-plugins", "rewind", "branch", "retry", "loop", "data-retention", "theme", "setup", "quit"}
	// /voice is gated via IsAvailable (mic / GOAR_VOICE); only require when available.
	if VoiceAvailable() {
		need = append(need, "voice")
	}
	for _, n := range need {
		if !r.HasCommand(n) {
			t.Fatalf("missing %s", n)
		}
	}
	if !VoiceAvailable() && r.HasCommand("voice") {
		t.Fatalf("voice should be gated out when VoiceAvailable=false")
	}
	for _, a := range []string{"/new", "/continue", "/connectors", "/proxy", "/onboard"} {
		if r.GetCommandName(a) == "" {
			t.Fatalf("alias %s", a)
		}
	}
	name, _, _, ok := r.ParseCommand("/rewind")
	if !ok || name != "rewind" {
		t.Fatalf("rewind: %v %v", name, ok)
	}
	name, _, args, ok := r.ParseCommand("/retry please continue")
	if !ok || name != "retry" || args != "please continue" {
		t.Fatalf("retry: %v %v %q", name, ok, args)
	}
}
