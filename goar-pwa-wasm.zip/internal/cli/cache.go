package cli

import (
	"os"
	"sync"

	"github.com/BurntSushi/toml"
	"github.com/goarxyz/goar/internal/core/paths"
)

// Cache is a simple TOML key/value cache.
type Cache struct {
	mu   sync.Mutex
	Data map[string]string `toml:"data"`
}

func LoadCache() *Cache {
	c := &Cache{Data: map[string]string{}}
	_, _ = toml.DecodeFile(paths.CacheFile(), c)
	if c.Data == nil {
		c.Data = map[string]string{}
	}
	return c
}

func (c *Cache) Get(k string) (string, bool) {
	c.mu.Lock()
	defer c.mu.Unlock()
	v, ok := c.Data[k]
	return v, ok
}

func (c *Cache) Set(k, v string) error {
	c.mu.Lock()
	defer c.mu.Unlock()
	c.Data[k] = v
	_ = paths.EnsureHome()
	f, err := os.Create(paths.CacheFile())
	if err != nil {
		return err
	}
	defer f.Close()
	return toml.NewEncoder(f).Encode(c)
}
