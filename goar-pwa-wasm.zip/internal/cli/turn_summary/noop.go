package turnsummary

// Noop is a no-op Port (Python NoopTurnSummary).
type Noop struct{}

func (Noop) Generation() int                          { return 0 }
func (Noop) OnSummary() func(Result)                  { return nil }
func (Noop) SetOnSummary(func(Result))                {}
func (Noop) StartTurn(string)                         {}
func (Noop) Track(any)                               {}
func (Noop) SetError(string)                          {}
func (Noop) CancelTurn()                              {}
func (Noop) EndTurn() func() bool                     { return nil }
func (Noop) Close()                                   {}
func (Noop) Snapshot() Snapshot                       { return Snapshot{} }

// Compat aliases matching the older stats-only interface.
func (Noop) OnTurnStart()                {}
func (Noop) OnTurnEnd(int, int, float64) {}
