package turnsummary

import (
	"context"
	"strings"
	"sync"

	"github.com/goarxyz/goar/internal/core/config"
	"github.com/goarxyz/goar/internal/core/llm"
	"github.com/goarxyz/goar/internal/core/prompts"
	"github.com/goarxyz/goar/internal/core/types"
)

// Tracker implements Port with optional LLM narration (Python TurnSummaryTracker).
type Tracker struct {
	mu       sync.Mutex
	backend  llm.BackendLike
	model    config.ModelConfig
	onSummary func(Result)
	maxTokens int
	sessionMeta func() map[string]any

	generation int
	data       *Data
	snapshot   Snapshot
	cancels    []context.CancelFunc
}

// NewTracker creates a stats-only tracker (no LLM).
func NewTracker() *Tracker {
	return &Tracker{maxTokens: 512, sessionMeta: func() map[string]any { return map[string]any{} }}
}

// NewTrackerWithBackend creates a tracker that generates LLM summaries.
func NewTrackerWithBackend(backend llm.BackendLike, model config.ModelConfig, onSummary func(Result), maxTokens int) *Tracker {
	if maxTokens <= 0 {
		maxTokens = 512
	}
	return &Tracker{
		backend: backend, model: model, onSummary: onSummary, maxTokens: maxTokens,
		sessionMeta: func() map[string]any { return map[string]any{} },
	}
}

// SetSessionMetadataGetter sets the optional metadata provider.
func (t *Tracker) SetSessionMetadataGetter(fn func() map[string]any) {
	t.mu.Lock()
	defer t.mu.Unlock()
	if fn == nil {
		t.sessionMeta = func() map[string]any { return map[string]any{} }
		return
	}
	t.sessionMeta = fn
}

func (t *Tracker) Generation() int {
	t.mu.Lock()
	defer t.mu.Unlock()
	return t.generation
}

func (t *Tracker) OnSummary() func(Result) {
	t.mu.Lock()
	defer t.mu.Unlock()
	return t.onSummary
}

func (t *Tracker) SetOnSummary(fn func(Result)) {
	t.mu.Lock()
	defer t.mu.Unlock()
	t.onSummary = fn
}

// StartTurn begins collecting turn material.
func (t *Tracker) StartTurn(userMessage string) {
	t.mu.Lock()
	defer t.mu.Unlock()
	t.generation++
	t.data = &Data{UserMessage: userMessage}
}

// OnTurnStart is a compat alias used by older callers.
func (t *Tracker) OnTurnStart() { t.StartTurn("") }

// Track observes stream events for the current turn.
func (t *Tracker) Track(event any) {
	t.mu.Lock()
	defer t.mu.Unlock()
	if t.data == nil || event == nil {
		return
	}
	switch e := event.(type) {
	case types.AssistantEvent:
		if e.Content != "" {
			t.data.AssistantFragments = append(t.data.AssistantFragments, e.Content)
		}
	case *types.AssistantEvent:
		if e != nil && e.Content != "" {
			t.data.AssistantFragments = append(t.data.AssistantFragments, e.Content)
		}
	case map[string]any:
		if mid, ok := e["message_id"].(string); ok && mid != "" {
			t.data.MessageID = mid
		}
		if c, ok := e["content"].(string); ok && c != "" {
			t.data.AssistantFragments = append(t.data.AssistantFragments, c)
		}
	}
}

func (t *Tracker) SetError(message string) {
	t.mu.Lock()
	defer t.mu.Unlock()
	if t.data != nil {
		t.data.Error = message
	}
}

func (t *Tracker) CancelTurn() {
	t.mu.Lock()
	defer t.mu.Unlock()
	t.data = nil
}

// OnTurnEnd records token/duration stats (compat) and may end the narrative turn.
func (t *Tracker) OnTurnEnd(promptTokens, completionTokens int, durationSec float64) {
	t.mu.Lock()
	t.snapshot.PromptTokens += promptTokens
	t.snapshot.CompletionTokens += completionTokens
	t.snapshot.DurationSec += durationSec
	t.snapshot.Turns++
	t.mu.Unlock()
}

func (t *Tracker) Snapshot() Snapshot {
	t.mu.Lock()
	defer t.mu.Unlock()
	return t.snapshot
}

// EndTurn kicks off async summary generation; returns a cancel func.
func (t *Tracker) EndTurn() (cancel func() bool) {
	t.mu.Lock()
	if t.data == nil {
		t.mu.Unlock()
		return nil
	}
	data := *t.data
	data.AssistantFragments = append([]string{}, t.data.AssistantFragments...)
	gen := t.generation
	backend := t.backend
	model := t.model
	maxTok := t.maxTokens
	onSummary := t.onSummary
	t.data = nil
	t.mu.Unlock()

	if backend == nil {
		if onSummary != nil {
			onSummary(Result{Generation: gen, Summary: nil})
		}
		return func() bool { return false }
	}

	ctx, cancelFn := context.WithCancel(context.Background())
	t.mu.Lock()
	t.cancels = append(t.cancels, cancelFn)
	t.mu.Unlock()

	go t.generateSummary(ctx, data, gen, backend, model, maxTok, onSummary)

	return func() bool {
		cancelFn()
		return true
	}
}

func (t *Tracker) Close() {
	t.mu.Lock()
	cancels := append([]context.CancelFunc{}, t.cancels...)
	t.cancels = nil
	t.data = nil
	t.mu.Unlock()
	for _, c := range cancels {
		c()
	}
}

func (t *Tracker) generateSummary(ctx context.Context, data Data, gen int, backend llm.BackendLike, model config.ModelConfig, maxTokens int, onSummary func(Result)) {
	emit := func(summary *string) {
		if onSummary != nil {
			onSummary(Result{Generation: gen, Summary: summary})
		}
	}
	select {
	case <-ctx.Done():
		emit(nil)
		return
	default:
	}

	promptText, err := prompts.LoadPrompt("turn_summary")
	if err != nil {
		emit(nil)
		return
	}

	sections := []string{"## User Request\n" + data.UserMessage}
	fullText := strings.Join(data.AssistantFragments, "")
	if fullText != "" {
		sections = append(sections, "## Assistant Response\n"+fullText)
	}
	if data.Error != "" {
		sections = append(sections, "## Error\n"+data.Error)
	}
	extraction := strings.Join(sections, "\n\n")

	req := llm.CompleteRequest{
		ModelName: model.Alias,
		Messages: []types.LLMMessage{
			types.NewMessage(types.RoleSystem, promptText),
			types.NewMessage(types.RoleUser, extraction),
		},
		Temperature: 0,
		MaxTokens:   &maxTokens,
	}
	if model.Name != "" {
		req.ModelName = model.Name
	}

	chunk, err := backend.Complete(req)
	if err != nil || ctx.Err() != nil {
		emit(nil)
		return
	}
	summary := chunk.Message.ContentString()
	emit(&summary)
}
