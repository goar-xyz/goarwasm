// Package turnsummary tracks per-turn metrics for the TUI.
package turnsummary
