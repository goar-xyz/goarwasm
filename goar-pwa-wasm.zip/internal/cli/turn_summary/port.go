package turnsummary

// Data holds the in-flight turn material used to generate a summary (Python TurnSummaryData).
type Data struct {
	UserMessage         string
	MessageID           string
	AssistantFragments  []string
	Error               string
}

// Result is a completed summary callback payload (Python TurnSummaryResult).
type Result struct {
	Generation int
	Summary    *string
}

// Snapshot is immutable turn token/duration stats (compat helpers).
type Snapshot struct {
	PromptTokens     int
	CompletionTokens int
	DurationSec      float64
	Turns            int
}

// Port is the turn summary interface (Python TurnSummaryPort).
type Port interface {
	Generation() int
	OnSummary() func(Result)
	SetOnSummary(fn func(Result))
	StartTurn(userMessage string)
	Track(event any)
	SetError(message string)
	CancelTurn()
	// EndTurn starts async summary generation and returns a cancel func, or nil.
	EndTurn() (cancel func() bool)
	Close()
	// Snapshot returns cumulative token stats when tracked.
	Snapshot() Snapshot
}
