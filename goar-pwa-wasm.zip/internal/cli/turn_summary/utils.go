package turnsummary

import (
	"fmt"
	"os"

	"github.com/goarxyz/goar/internal/core/config"
	"github.com/goarxyz/goar/internal/core/llm"
	"github.com/goarxyz/goar/internal/core/llm/backend"
	"github.com/goarxyz/goar/internal/core/types"
)

// FormatSnapshot renders a one-line summary of token/duration stats.
func FormatSnapshot(s Snapshot) string {
	return fmt.Sprintf("turns=%d tokens=%d+/%d- duration=%.2fs", s.Turns, s.PromptTokens, s.CompletionTokens, s.DurationSec)
}

// NarratorPair is a backend + model used for turn narration.
type NarratorPair struct {
	Backend llm.BackendLike
	Model   config.ModelConfig
}

// CreateNarratorBackend builds an LLM backend for turn summaries (Python create_narrator_backend).
// Returns nil when the active model/provider cannot be resolved or the API key is missing.
func CreateNarratorBackend(cfg *config.Config) *NarratorPair {
	if cfg == nil {
		return nil
	}
	model, err := cfg.GetActiveModel()
	if err != nil {
		return nil
	}
	provider, err := cfg.GetProviderForModel(model)
	if err != nil {
		return nil
	}
	if provider.APIKeyEnvVar != "" && os.Getenv(provider.APIKeyEnvVar) == "" {
		return nil
	}
	backendName := types.Backend(provider.Backend)
	if backendName == "" {
		backendName = types.BackendGeneric
	}
	ctor, ok := backend.BackendFactory[backendName]
	if !ok {
		// Fall back to generic constructor.
		b := backend.NewGenericBackend(provider, cfg.APITimeout)
		return &NarratorPair{Backend: b, Model: model}
	}
	return &NarratorPair{Backend: ctor(provider, cfg.APITimeout), Model: model}
}
