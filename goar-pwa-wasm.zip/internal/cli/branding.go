package cli

const (
	BrandName = "GOAR"
	Tagline   = "Autonomous CLI coding agent. Provider-agnostic. Local-first."
	ASCIIMark = `  ██████╗  ██████╗  █████╗ ██████╗
 ██╔════╝ ██╔═══██╗██╔══██╗██╔══██╗
 ██║  ███╗██║   ██║███████║██████╔╝
 ██║   ██║██║   ██║██╔══██║██╔══██╗
 ╚██████╔╝╚██████╔╝██║  ██║██║  ██║
  ╚═════╝  ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═╝`
	ColorInk  = "#0B0D10"
	ColorBone = "#E8E4D9"
	// ColorRed is the primary GOAR brand accent (Vibe orange → red).
	ColorRed = "#E11D2E"
	// ColorRedStrong is the bright hover/emphasis red.
	ColorRedStrong = "#ff2a3d"
	// ColorAmber is reserved for warnings only — not primary brand.
	ColorAmber = "#E8B84A"
)
