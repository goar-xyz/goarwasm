package autocompletion

import (
	"strings"

	"github.com/goarxyz/goar/internal/cli"
	coreac "github.com/goarxyz/goar/internal/core/autocompletion"
)

// SlashCommandController drives /command completions (Python SlashCommandController).
type SlashCommandController struct {
	Completer *coreac.CommandCompleter
	View      CompletionView
	suggestions [][2]string
	selected    int
}

// NewSlashCommandController constructs a controller.
func NewSlashCommandController(completer *coreac.CommandCompleter, view CompletionView) *SlashCommandController {
	return &SlashCommandController{Completer: completer, View: view}
}

// DefaultSlashCompleter builds a CommandCompleter from built-in slash commands.
func DefaultSlashCompleter() *coreac.CommandCompleter {
	return &coreac.CommandCompleter{Entries: func() [][2]string {
		cmds := cli.DefaultSlashCommands()
		out := make([][2]string, 0, len(cmds))
		for _, c := range cmds {
			out = append(out, [2]string{c.Name, c.Description})
		}
		return out
	}}
}

// CanHandle reports whether text starts with '/'.
func (c *SlashCommandController) CanHandle(text string, cursorIndex int) bool {
	_ = cursorIndex
	return strings.HasPrefix(text, "/")
}

// Reset clears suggestions.
func (c *SlashCommandController) Reset() {
	if len(c.suggestions) == 0 {
		return
	}
	c.suggestions = nil
	c.selected = 0
	if c.View != nil {
		c.View.ClearSuggestions()
		c.View.Hide()
	}
}

// OnTextChanged refreshes suggestions for the current input.
func (c *SlashCommandController) OnTextChanged(text string, cursorIndex int) {
	if cursorIndex < 0 || cursorIndex > len(text) {
		c.Reset()
		return
	}
	if !c.CanHandle(text, cursorIndex) {
		c.Reset()
		return
	}
	if c.Completer == nil {
		c.Reset()
		return
	}
	items := c.Completer.GetCompletionItems(text, cursorIndex)
	if len(items) == 0 {
		c.Reset()
		return
	}
	c.suggestions = make([][2]string, 0, len(items))
	for _, it := range items {
		c.suggestions = append(c.suggestions, [2]string{it.Insert, it.Display})
	}
	c.selected = 0
	if c.View != nil {
		c.View.SetSuggestions(c.suggestions)
		c.View.SetSelectedIndex(0)
		c.View.Show()
	}
}

// OnKey handles tab/enter/up/down while suggestions are visible.
func (c *SlashCommandController) OnKey(key, text string, cursorIndex int) CompletionResult {
	if len(c.suggestions) == 0 {
		return CompletionIgnored
	}
	switch key {
	case "tab":
		if c.applySelected(text, cursorIndex) {
			return CompletionHandled
		}
		return CompletionIgnored
	case "enter":
		if c.applySelected(text, cursorIndex) {
			return CompletionSubmit
		}
		return CompletionHandled
	case "down":
		c.moveSelection(1)
		return CompletionHandled
	case "up":
		c.moveSelection(-1)
		return CompletionHandled
	default:
		return CompletionIgnored
	}
}

func (c *SlashCommandController) moveSelection(delta int) {
	if len(c.suggestions) == 0 {
		return
	}
	n := len(c.suggestions)
	c.selected = (c.selected + delta%n + n) % n
	if c.View != nil {
		c.View.SetSelectedIndex(c.selected)
		c.View.SetSuggestions(c.suggestions)
	}
}

func (c *SlashCommandController) applySelected(text string, cursorIndex int) bool {
	if len(c.suggestions) == 0 || c.Completer == nil {
		return false
	}
	alias := c.suggestions[c.selected][0]
	start, end := c.Completer.GetReplacementRange(text, cursorIndex)
	if c.View != nil {
		// Path CompletionView doesn't have ReplaceRange; best-effort SetSuggestions clear.
		_ = start
		_ = end
		_ = alias
		c.View.ClearSuggestions()
		c.View.Hide()
	}
	c.suggestions = nil
	c.selected = 0
	return true
}

// SelectedAlias returns the currently highlighted insert text.
func (c *SlashCommandController) SelectedAlias() string {
	if len(c.suggestions) == 0 {
		return ""
	}
	return c.suggestions[c.selected][0]
}

// SlashProvider completes slash commands (compat Provider).
type SlashProvider struct{}

func (SlashProvider) Complete(line string, cursor int) []string {
	if !strings.HasPrefix(strings.TrimLeft(line, " "), "/") {
		return nil
	}
	cc := DefaultSlashCompleter()
	items := cc.GetCompletionItems(line, cursor)
	out := make([]string, 0, len(items))
	for _, it := range items {
		out = append(out, it.Insert)
	}
	return out
}
