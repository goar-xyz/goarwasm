package autocompletion

import (
	"strings"
	"sync"

	"github.com/goarxyz/goar/internal/core/autocompletion"
	"github.com/goarxyz/goar/internal/core/autocompletion/fileindexer"
)

const maxSuggestionsCount = 10

// CompletionView is the UI surface for showing path suggestions.
type CompletionView interface {
	SetSuggestions(items [][2]string) // insert, display
	ClearSuggestions()
	SelectedIndex() int
	SetSelectedIndex(i int)
	Visible() bool
	Show()
	Hide()
}

// PathCompletionController drives @path completions (Python PathCompletionController).
type PathCompletionController struct {
	mu        sync.Mutex
	Completer *autocompletion.PathCompleter
	View      CompletionView
	active    bool
	query     string
	cursor    int
	items     [][2]string
	selected  int
}

// NewPathProvider completes @paths (compat).
type PathProvider struct {
	Completer *autocompletion.PathCompleter
}

func NewPathProvider(idx *fileindexer.Indexer) *PathProvider {
	return &PathProvider{Completer: autocompletion.NewPathCompleter(idx)}
}

func (p *PathProvider) Complete(line string, cursor int) []string {
	_, query, _, ok := autocompletion.AdaptInputForPathCompletion(line, cursor)
	if !ok {
		return nil
	}
	return p.Completer.Complete(query)
}

// NewPathCompletionController wires a completer to a view.
func NewPathCompletionController(completer *autocompletion.PathCompleter, view CompletionView) *PathCompletionController {
	return &PathCompletionController{Completer: completer, View: view}
}

// CanHandle reports whether the cursor is inside an @path token.
func (c *PathCompletionController) CanHandle(text string, cursorIndex int) bool {
	_, _, _, ok := autocompletion.AdaptInputForPathCompletion(text, cursorIndex)
	return ok
}

// Reset clears suggestions and selection.
func (c *PathCompletionController) Reset() {
	c.mu.Lock()
	defer c.mu.Unlock()
	c.active = false
	c.query = ""
	c.items = nil
	c.selected = 0
	if c.View != nil {
		c.View.ClearSuggestions()
		c.View.Hide()
	}
}

// OnTextChanged recomputes suggestions for the current text/cursor.
func (c *PathCompletionController) OnTextChanged(text string, cursorIndex int) {
	c.mu.Lock()
	defer c.mu.Unlock()
	if !c.CanHandle(text, cursorIndex) {
		c.active = false
		c.items = nil
		if c.View != nil {
			c.View.ClearSuggestions()
			c.View.Hide()
		}
		return
	}
	c.active = true
	c.cursor = cursorIndex
	_, query, _, _ := autocompletion.AdaptInputForPathCompletion(text, cursorIndex)
	c.query = query
	c.updateSuggestions(c.computeCompletions(text, cursorIndex))
}

func (c *PathCompletionController) computeCompletions(text string, cursorIndex int) [][2]string {
	if c.Completer == nil {
		return nil
	}
	items := c.Completer.GetCompletionItems(text, cursorIndex)
	out := make([][2]string, 0, len(items))
	for _, it := range items {
		out = append(out, [2]string{it.Insert, it.Display})
		if len(out) >= maxSuggestionsCount {
			break
		}
	}
	return out
}

func (c *PathCompletionController) updateSuggestions(suggestions [][2]string) {
	c.items = suggestions
	c.selected = 0
	if c.View == nil {
		return
	}
	if len(suggestions) == 0 {
		c.View.ClearSuggestions()
		c.View.Hide()
		return
	}
	c.View.SetSuggestions(suggestions)
	c.View.SetSelectedIndex(0)
	c.View.Show()
}

// OnKey handles navigation/accept keys. Returns true if consumed.
func (c *PathCompletionController) OnKey(key, text string, cursorIndex int) (newText string, newCursor int, consumed bool) {
	c.mu.Lock()
	defer c.mu.Unlock()
	if !c.active || len(c.items) == 0 {
		return text, cursorIndex, false
	}
	switch key {
	case "up", "ctrl+p":
		c.moveSelection(-1)
		return text, cursorIndex, true
	case "down", "ctrl+n", "tab":
		c.moveSelection(1)
		return text, cursorIndex, true
	case "enter", "right":
		ok := false
		text, cursorIndex, ok = c.applySelectedCompletion(text, cursorIndex)
		return text, cursorIndex, ok
	case "esc":
		c.active = false
		c.items = nil
		if c.View != nil {
			c.View.Hide()
		}
		return text, cursorIndex, true
	default:
		return text, cursorIndex, false
	}
}

func (c *PathCompletionController) moveSelection(delta int) {
	if len(c.items) == 0 {
		return
	}
	c.selected = (c.selected + delta) % len(c.items)
	if c.selected < 0 {
		c.selected += len(c.items)
	}
	if c.View != nil {
		c.View.SetSelectedIndex(c.selected)
	}
}

func (c *PathCompletionController) applySelectedCompletion(text string, cursorIndex int) (string, int, bool) {
	if c.selected < 0 || c.selected >= len(c.items) || c.Completer == nil {
		return text, cursorIndex, false
	}
	insert := c.items[c.selected][0]
	start, end := c.Completer.GetReplacementRange(text, cursorIndex)
	if start < 0 || end > len(text) || start > end {
		return text, cursorIndex, false
	}
	newText := text[:start] + insert + text[end:]
	newCursor := start + len(insert)
	c.active = false
	c.items = nil
	if c.View != nil {
		c.View.Hide()
	}
	_ = strings.TrimSpace
	return newText, newCursor, true
}

// Items returns the current suggestion list.
func (c *PathCompletionController) Items() [][2]string {
	c.mu.Lock()
	defer c.mu.Unlock()
	return append([][2]string{}, c.items...)
}
