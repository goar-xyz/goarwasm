package autocompletion

// CompletionResult classifies key handling outcomes (Python CompletionResult).
type CompletionResult string

const (
	CompletionIgnored CompletionResult = "ignored"
	CompletionHandled CompletionResult = "handled"
	CompletionSubmit  CompletionResult = "submit"
)

// Provider yields completions for the current input (compat).
type Provider interface {
	Complete(line string, cursor int) []string
}

// SuggestionPair is insert text + display label.
type SuggestionPair = [2]string

// Note: CompletionView lives in path_completion.go and is shared by slash/path controllers.
