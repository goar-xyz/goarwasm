// Package cliauto wires slash and path completion into the TUI input.
package autocompletion
