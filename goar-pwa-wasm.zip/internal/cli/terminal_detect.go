package cli

import (
	"os"
	"strings"

	"golang.org/x/term"
)

// Terminal identifies the host terminal emulator (Python Terminal).
type Terminal string

const (
	TerminalVSCode          Terminal = "vscode"
	TerminalVSCodeInsiders  Terminal = "vscode_insiders"
	TerminalCursor          Terminal = "cursor"
	TerminalJetBrains       Terminal = "jetbrains"
	TerminalITerm2          Terminal = "iterm2"
	TerminalWezTerm         Terminal = "wezterm"
	TerminalGhostty         Terminal = "ghostty"
	TerminalAlacritty       Terminal = "alacritty"
	TerminalKitty           Terminal = "kitty"
	TerminalHyper           Terminal = "hyper"
	TerminalWindowsTerminal Terminal = "windows_terminal"
	TerminalUnknown         Terminal = "unknown"
)

func isCursor() bool {
	indicators := []string{
		"VSCODE_GIT_ASKPASS_NODE",
		"VSCODE_GIT_ASKPASS_MAIN",
		"VSCODE_IPC_HOOK_CLI",
		"VSCODE_NLS_CONFIG",
	}
	for _, v := range indicators {
		val := strings.ToLower(os.Getenv(v))
		if strings.Contains(val, "cursor") {
			return true
		}
	}
	return false
}

func detectVSCodeTerminal() Terminal {
	termVersion := strings.ToLower(os.Getenv("TERM_PROGRAM_VERSION"))
	if strings.HasSuffix(termVersion, "-insider") {
		return TerminalVSCodeInsiders
	}
	return TerminalVSCode
}

func detectTerminalFromEnv() Terminal {
	envMarkers := map[string]Terminal{
		"WEZTERM_PANE":          TerminalWezTerm,
		"GHOSTTY_RESOURCES_DIR": TerminalGhostty,
		"KITTY_WINDOW_ID":       TerminalKitty,
		"ALACRITTY_SOCKET":      TerminalAlacritty,
		"ALACRITTY_LOG":         TerminalAlacritty,
		"WT_SESSION":            TerminalWindowsTerminal,
	}
	for v, t := range envMarkers {
		if os.Getenv(v) != "" {
			return t
		}
	}
	if strings.Contains(strings.ToLower(os.Getenv("TERMINAL_EMULATOR")), "jetbrains") {
		return TerminalJetBrains
	}
	return ""
}

// DetectTerminal identifies the current terminal emulator (Python detect_terminal).
func DetectTerminal() Terminal {
	termProgram := strings.ToLower(os.Getenv("TERM_PROGRAM"))
	if termProgram == "vscode" {
		if isCursor() {
			return TerminalCursor
		}
		return detectVSCodeTerminal()
	}
	termMap := map[string]Terminal{
		"iterm.app": TerminalITerm2,
		"wezterm":   TerminalWezTerm,
		"ghostty":   TerminalGhostty,
		"alacritty": TerminalAlacritty,
		"kitty":     TerminalKitty,
		"hyper":     TerminalHyper,
	}
	if t, ok := termMap[termProgram]; ok {
		return t
	}
	if t := detectTerminalFromEnv(); t != "" {
		return t
	}
	return TerminalUnknown
}

// IsInteractive reports whether stdin is a terminal.
func IsInteractive() bool {
	return term.IsTerminal(int(os.Stdin.Fd()))
}

// IsColorTerminal reports color-capable stdout.
func IsColorTerminal() bool {
	if os.Getenv("NO_COLOR") != "" {
		return false
	}
	return term.IsTerminal(int(os.Stdout.Fd()))
}

// TermSize returns terminal width/height.
func TermSize() (w, h int) {
	w, h, err := term.GetSize(int(os.Stdout.Fd()))
	if err != nil {
		return 80, 24
	}
	return w, h
}

// IsVSCodeFamily reports VS Code / Insiders / Cursor.
func IsVSCodeFamily() bool {
	t := DetectTerminal()
	return t == TerminalVSCode || t == TerminalVSCodeInsiders || t == TerminalCursor
}
