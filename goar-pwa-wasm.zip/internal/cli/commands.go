package cli

import (
	"fmt"
	"os"
	"runtime"
	"sort"
	"strings"
)

// AltKey is the platform modifier label used in help text.
var AltKey = func() string {
	if runtime.GOOS == "darwin" {
		return "⌥"
	}
	return "Alt"
}()

// CommandAvailabilityContext is reserved for future command-availability rules.
type CommandAvailabilityContext struct{}

// CommandAvailability decides whether a command is offered.
type CommandAvailability func(CommandAvailabilityContext) bool

// Command is a slash-command definition (Python Command).
type Command struct {
	Name        string
	Aliases     []string
	Description string
	Handler     string
	Exits       bool
	IsAvailable CommandAvailability
}

// SlashCommand is a TUI slash command with an optional live handler.
type SlashCommand struct {
	Name        string
	Description string
	Handler     func(args string) error
}

// CommandRegistry holds the slash-command catalog (Python CommandRegistry).
type CommandRegistry struct {
	disabled            map[string]bool
	availabilityContext CommandAvailabilityContext
	commands            map[string]Command
}

// NewCommandRegistry builds a registry, optionally excluding commands.
func NewCommandRegistry(excluded []string, ctx *CommandAvailabilityContext) *CommandRegistry {
	r := &CommandRegistry{disabled: map[string]bool{}, commands: map[string]Command{}}
	for _, e := range excluded {
		r.disabled[e] = true
	}
	if ctx != nil {
		r.availabilityContext = *ctx
	}
	r.Refresh(ctx)
	return r
}

func (r *CommandRegistry) buildCommands() map[string]Command {
	// Catalog aligned with Mistral Vibe vibe/cli/commands.py (+ GOAR /setup).
	// HTTP(S) proxy-setup only — no SOCKS5 / AGENT_SOCKS UI.
	return map[string]Command{
		"help": {Name: "help", Aliases: []string{"/help"}, Description: "Show help message", Handler: "_show_help"},
		"config": {Name: "config", Aliases: []string{"/config"}, Description: "Edit config settings", Handler: "_show_config"},
		"model": {Name: "model", Aliases: []string{"/model"}, Description: "Select active model", Handler: "_show_model"},
		"skills": {Name: "skills", Aliases: []string{"/skills"}, Description: "Browse, import, and manage skills", Handler: "_show_skills"},
		"thinking": {Name: "thinking", Aliases: []string{"/thinking"}, Description: "Select thinking level", Handler: "_show_thinking"},
		"reload": {Name: "reload", Aliases: []string{"/reload"}, Description: "Reload configuration, agent instructions, and skills from disk", Handler: "_reload_config"},
		"clear": {Name: "clear", Aliases: []string{"/clear", "/new"}, Description: "Start a new conversation. Optionally pass a prompt to seed it.", Handler: "_clear_history"},
		"copy": {Name: "copy", Aliases: []string{"/copy"}, Description: "Copy the last agent message to the clipboard", Handler: "_copy_last_agent_message"},
		"paste-image": {Name: "paste-image", Aliases: []string{"/paste-image"}, Description: "Paste an image from the OS clipboard into the prompt", Handler: "_paste_clipboard_image_command"},
		"log": {Name: "log", Aliases: []string{"/log"}, Description: "Show path to current interaction log file", Handler: "_show_log_path"},
		"log-level": {Name: "log-level", Aliases: []string{"/log-level"}, Description: "Change the log level for this session or persist it to config.toml.", Handler: "_log_level_command"},
		"debug": {Name: "debug", Aliases: []string{"/debug"}, Description: "Toggle debug console", Handler: "action_toggle_debug_console"},
		"compact": {Name: "compact", Aliases: []string{"/compact"}, Description: "Compact conversation history by summarizing. Optionally pass instructions to guide the summary", Handler: "_compact_history"},
		"exit": {Name: "exit", Aliases: []string{"/exit", "exit", "quit", ":q", ":quit"}, Description: "Exit the application", Handler: "_exit_app", Exits: true},
		"status": {Name: "status", Aliases: []string{"/status"}, Description: "Display agent statistics", Handler: "_show_status"},
		"whoami": {Name: "whoami", Aliases: []string{"/whoami"}, Description: "Display signed-in provider account info when available", Handler: "_show_whoami"},
		"proxy-setup": {Name: "proxy-setup", Aliases: []string{"/proxy-setup", "/proxy"}, Description: "Configure HTTP(S) proxy and SSL certificate settings", Handler: "_show_proxy_setup"},
		"resume": {Name: "resume", Aliases: []string{"/resume", "/continue", "/session"}, Description: "Browse, resume, or delete saved sessions", Handler: "_show_session_picker"},
		"rename": {Name: "rename", Aliases: []string{"/rename"}, Description: "Rename the current session", Handler: "_rename_session"},
		"mcp": {Name: "mcp", Aliases: []string{"/mcp", "/connectors"}, Description: "Display available MCP servers and connectors. Pass a name to list tools; subcommands: add, status, login, logout", Handler: "_show_mcp"},
		"plugins": {Name: "plugins", Aliases: []string{"/plugins"}, Description: "Display the plugins this session is running", Handler: "_show_plugins"},
		"reload-plugins": {Name: "reload-plugins", Aliases: []string{"/reload-plugins"}, Description: "Re-pin this session's plugins and report what changed", Handler: "_reload_plugins"},
		"voice": {Name: "voice", Aliases: []string{"/voice"}, Description: "Configure voice settings", Handler: "_show_voice_settings", IsAvailable: voiceCommandAvailable},
		"rewind": {Name: "rewind", Aliases: []string{"/rewind"}, Description: "Rewind to a previous message (or press Esc twice)", Handler: "_start_rewind_mode"},
		"branch": {Name: "branch", Aliases: []string{"/branch"}, Description: "Fork the current conversation into a new resumable session, leaving this session unchanged", Handler: "_branch_session"},
		"retry": {Name: "retry", Aliases: []string{"/retry"}, Description: "Continue an interrupted model response; optionally pass additional instructions", Handler: "_retry"},
		"loop": {Name: "loop", Aliases: []string{"/loop"}, Description: "Schedule a recurring prompt. Use `/loop <interval> <prompt>`, `/loop list`, or `/loop cancel <id|all>`", Handler: "_loop_command"},
		"data-retention": {Name: "data-retention", Aliases: []string{"/data-retention"}, Description: "Show data retention information", Handler: "_show_data_retention"},
		"theme": {Name: "theme", Aliases: []string{"/theme"}, Description: "Select theme", Handler: "_show_theme"},
		"setup": {Name: "setup", Aliases: []string{"/setup", "/onboard", "/provider"}, Description: "Show how to add or switch providers (OpenAI, Claude, Cursor, local, custom)", Handler: "_show_setup"},
		"quit": {Name: "quit", Aliases: []string{"/quit"}, Description: "Quit GOAR", Handler: "_exit_app", Exits: true},
	}
}

// Commands returns the active command map.
func (r *CommandRegistry) Commands() map[string]Command { return r.commands }

// Refresh rebuilds the catalog from exclusions + availability.
func (r *CommandRegistry) Refresh(ctx *CommandAvailabilityContext) {
	if ctx != nil {
		r.availabilityContext = *ctx
	}
	out := map[string]Command{}
	for name, cmd := range r.buildCommands() {
		if r.disabled[name] {
			continue
		}
		if !r.isCommandAvailable(cmd) {
			continue
		}
		out[name] = cmd
	}
	r.commands = out
}

func (r *CommandRegistry) isCommandAvailable(cmd Command) bool {
	if cmd.IsAvailable == nil {
		return true
	}
	return cmd.IsAvailable(r.availabilityContext)
}

func (r *CommandRegistry) aliasMap() map[string]string {
	out := map[string]string{}
	for name, cmd := range r.commands {
		for _, a := range cmd.Aliases {
			out[strings.ToLower(a)] = name
		}
		out["/"+strings.ToLower(name)] = name
		out[strings.ToLower(name)] = name
	}
	return out
}

// Get returns a command by canonical name.
func (r *CommandRegistry) Get(name string) (Command, bool) {
	c, ok := r.commands[name]
	return c, ok
}

// HasCommand reports whether a canonical name is registered.
func (r *CommandRegistry) HasCommand(name string) bool {
	_, ok := r.commands[name]
	return ok
}

// GetCommandName resolves an alias or slash token to a canonical name.
func (r *CommandRegistry) GetCommandName(userInput string) string {
	return r.aliasMap()[strings.ToLower(strings.TrimSpace(userInput))]
}

// ParseCommand parses "/cmd args" into name, command, and args.
func (r *CommandRegistry) ParseCommand(userInput string) (name string, cmd Command, args string, ok bool) {
	parts := strings.Fields(strings.TrimSpace(userInput))
	if len(parts) == 0 {
		return "", Command{}, "", false
	}
	cmdWord := parts[0]
	if len(parts) > 1 {
		args = strings.TrimSpace(userInput[len(parts[0]):])
	}
	cmdName := r.GetCommandName(cmdWord)
	if cmdName == "" {
		return "", Command{}, "", false
	}
	command, found := r.commands[cmdName]
	if !found {
		return "", Command{}, "", false
	}
	return cmdName, command, args, true
}

// GetHelpText renders markdown help (Python get_help_text).
func (r *CommandRegistry) GetHelpText() string {
	lines := []string{
		"### Keyboard Shortcuts",
		"",
		"- `Enter` Submit message",
		"- `Ctrl+J` / `Shift+Enter` Insert newline",
		"- `Escape` Interrupt agent or close dialogs",
		"- `Ctrl+C` Quit (or clear input if text present)",
		"- `Ctrl+G` Edit input in external editor",
		"- `Ctrl+O` Toggle tool output view",
		"- `Shift+Tab` Cycle through agents (default, plan, ...)",
		fmt.Sprintf("- `%s+↑↓` / `Ctrl+P/N` Rewind to previous/next message", AltKey),
		"",
		"### Special Features",
		"",
		"- `!<command>` Execute bash command directly",
		"- `@path/to/file/` Autocompletes file paths",
		"",
		"### Commands",
		"",
	}
	names := make([]string, 0, len(r.commands))
	for n := range r.commands {
		names = append(names, n)
	}
	sort.Strings(names)
	for _, n := range names {
		cmd := r.commands[n]
		aliases := make([]string, len(cmd.Aliases))
		copy(aliases, cmd.Aliases)
		sort.Strings(aliases)
		quoted := make([]string, len(aliases))
		for i, a := range aliases {
			quoted[i] = "`" + a + "`"
		}
		lines = append(lines, fmt.Sprintf("- %s: %s", strings.Join(quoted, ", "), cmd.Description))
	}
	return strings.Join(lines, "\n")
}

// DefaultSlashCommands returns built-in slash commands metadata (compat).
func DefaultSlashCommands() []SlashCommand {
	reg := NewCommandRegistry(nil, nil)
	names := make([]string, 0, len(reg.commands))
	for n := range reg.commands {
		names = append(names, n)
	}
	sort.Strings(names)
	out := make([]SlashCommand, 0, len(names))
	for _, n := range names {
		c := reg.commands[n]
		out = append(out, SlashCommand{Name: c.Name, Description: c.Description})
	}
	return out
}

// ParseSlash parses "/cmd args".
func ParseSlash(line string) (cmd, args string, ok bool) {
	line = strings.TrimSpace(line)
	if !strings.HasPrefix(line, "/") {
		return "", "", false
	}
	line = strings.TrimPrefix(line, "/")
	cmd, args, _ = strings.Cut(line, " ")
	return strings.ToLower(cmd), strings.TrimSpace(args), true
}

// EntriesForCompleter returns (alias, description) pairs for slash completion.
func (r *CommandRegistry) EntriesForCompleter() [][2]string {
	var out [][2]string
	for _, cmd := range r.commands {
		for _, a := range cmd.Aliases {
			out = append(out, [2]string{a, cmd.Description})
		}
	}
	sort.Slice(out, func(i, j int) bool { return out[i][0] < out[j][0] })
	return out
}

// VoiceAvailable reports whether a microphone / voice pipeline is usable.
// Set GOAR_VOICE=1 to opt into the /voice command when a pipeline exists.
func VoiceAvailable() bool {
	v := strings.TrimSpace(strings.ToLower(os.Getenv("GOAR_VOICE")))
	return v == "1" || v == "true" || v == "yes"
}

func voiceCommandAvailable(_ CommandAvailabilityContext) bool {
	return VoiceAvailable()
}
