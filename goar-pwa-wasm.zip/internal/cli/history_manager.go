package cli

import (
	"bufio"
	"os"
	"sync"

	"github.com/goarxyz/goar/internal/core/paths"
)

// HistoryManager persists prompt history.
type HistoryManager struct {
	mu      sync.Mutex
	entries []string
	path    string
}

func NewHistoryManager() *HistoryManager {
	h := &HistoryManager{path: paths.HistoryFile()}
	h.load()
	return h
}

func (h *HistoryManager) load() {
	f, err := os.Open(h.path)
	if err != nil {
		return
	}
	defer f.Close()
	sc := bufio.NewScanner(f)
	for sc.Scan() {
		h.entries = append(h.entries, sc.Text())
	}
}

func (h *HistoryManager) Add(line string) error {
	h.mu.Lock()
	defer h.mu.Unlock()
	h.entries = append(h.entries, line)
	_ = paths.EnsureHome()
	f, err := os.OpenFile(h.path, os.O_CREATE|os.O_APPEND|os.O_WRONLY, 0o644)
	if err != nil {
		return err
	}
	defer f.Close()
	_, err = f.WriteString(line + "\n")
	return err
}

func (h *HistoryManager) Entries() []string {
	h.mu.Lock()
	defer h.mu.Unlock()
	return append([]string{}, h.entries...)
}
