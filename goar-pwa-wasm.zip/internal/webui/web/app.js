/* RETIRED — GOAR is a single Go WASM app.
 * UI, agent, browsernet/Wisp/SSH, persist, and terminal host live in goar.wasm
 * (cmd/goar-wasm + internal/appui). This file is intentionally empty so old
 * caches do not reintroduce a JS app layer. See docs/NATIVE_PARITY.md.
 */
console.info("GOAR: app.js retired — UI boots from goar.wasm");
