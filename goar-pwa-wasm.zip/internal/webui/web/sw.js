/* GOAR PWA service worker — shell cache + notify/background hooks.
 * Session truth lives in OPFS/IndexedDB via goar.wasm; SW keeps the shell
 * warm, relays attention notifications, and claims clients across tabs. */
const CACHE = "goar-pwa-v7-vibe-first";
const SHELL = [
  "./",
  "./index.html",
  "./vibe.css",
  "./manifest.webmanifest",
  "./icons/icon-192.png",
  "./icons/icon-512.png",
  "./vendor/wasm_exec.js",
  "./vendor/xterm/addon-web-links.js",
  "./vendor/xterm/addon-fit.js",
  "./vendor/xterm/xterm.js",
  "./vendor/xterm/xterm.css",
  "./vendor/gecko/browsernet-wisp-bridge.js",
  "./vendor/gecko/gecko-plane.js",
  "./assets/brand/g.png",
];

self.addEventListener("install", (event) => {
  event.waitUntil(
    caches.open(CACHE).then((cache) => cache.addAll(SHELL)).then(() => self.skipWaiting())
  );
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(keys.filter((k) => k !== CACHE).map((k) => caches.delete(k)))
    ).then(() => self.clients.claim())
  );
});

function isHuge(url) {
  return /gecko\.wasm\.zst|gecko\.js$|goar\.wasm$/i.test(url);
}

function isShellDoc(url) {
  return /\/(index\.html)?$|vibe\.css$|sw\.js$|manifest\.webmanifest$/i.test(url);
}

self.addEventListener("fetch", (event) => {
  const req = event.request;
  if (req.method !== "GET") return;
  const url = req.url;

  if (isHuge(url) || isShellDoc(url)) {
    event.respondWith(
      fetch(req)
        .then((res) => {
          if (res && res.ok && isShellDoc(url) && !isHuge(url)) {
            const copy = res.clone();
            caches.open(CACHE).then((c) => c.put(req, copy));
          }
          return res;
        })
        .catch(() => caches.match(req).then((c) => c || caches.match("./index.html")))
    );
    return;
  }

  event.respondWith(
    caches.match(req).then((cached) => {
      const fetched = fetch(req)
        .then((res) => {
          if (res && res.ok && new URL(req.url).origin === self.location.origin && !isHuge(req.url)) {
            const copy = res.clone();
            caches.open(CACHE).then((c) => c.put(req, copy));
          }
          return res;
        })
        .catch(() => cached);
      return cached || fetched;
    })
  );
});

/* ---- Notifications (from page postMessage or Push) ---- */
self.addEventListener("message", (event) => {
  const data = event.data || {};
  if (data.type === "goar-notify") {
    event.waitUntil(
      self.registration.showNotification(data.title || "GOAR", {
        body: data.body || "Needs attention",
        tag: "goar-attention",
        renotify: true,
        icon: "./icons/icon-192.png",
        badge: "./icons/icon-192.png",
        data: { url: "./" },
      })
    );
  }
  if (data.type === "goar-keepalive") {
    // Page ping — keep SW alive while agent runs in a background tab.
    event.waitUntil(self.clients.matchAll({ type: "window" }).then(() => undefined));
  }
});

self.addEventListener("notificationclick", (event) => {
  event.notification.close();
  const target = (event.notification.data && event.notification.data.url) || "./";
  event.waitUntil(
    self.clients.matchAll({ type: "window", includeUncontrolled: true }).then((clientList) => {
      for (const client of clientList) {
        if ("focus" in client) {
          client.postMessage({ type: "goar-focus", reason: "notificationclick" });
          return client.focus();
        }
      }
      if (self.clients.openWindow) {
        return self.clients.openWindow(target);
      }
    })
  );
});

/* Background Sync / periodic hooks (register from page when supported). */
self.addEventListener("sync", (event) => {
  if (event.tag === "goar-session-sync") {
    event.waitUntil(
      self.clients.matchAll({ type: "window" }).then((clients) => {
        clients.forEach((c) => c.postMessage({ type: "goar-sync" }));
      })
    );
  }
});

self.addEventListener("periodicsync", (event) => {
  if (event.tag === "goar-keepalive") {
    event.waitUntil(
      self.clients.matchAll({ type: "window" }).then((clients) => {
        clients.forEach((c) => c.postMessage({ type: "goar-keepalive-tick" }));
      })
    );
  }
});

/* Push-ready stub — payload JSON {title, body} when a push endpoint is configured. */
self.addEventListener("push", (event) => {
  let title = "GOAR";
  let body = "Needs attention";
  try {
    if (event.data) {
      const j = event.data.json();
      if (j.title) title = j.title;
      if (j.body) body = j.body;
    }
  } catch (_) {
    try {
      body = event.data ? event.data.text() : body;
    } catch (_) {}
  }
  event.waitUntil(
    self.registration.showNotification(title, {
      body,
      tag: "goar-attention",
      renotify: true,
      icon: "./icons/icon-192.png",
      data: { url: "./" },
    })
  );
});
