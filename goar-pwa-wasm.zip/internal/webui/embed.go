// Package webui embeds the GOAR browser PWA and exposes it as an http.FileSystem.
package webui

import (
	"embed"
	"io/fs"
	"net/http"
)

//go:embed all:web
var embedded embed.FS

// FS returns an http.FileSystem for the embedded web UI (contents of web/).
func FS() (http.FileSystem, error) {
	sub, err := fs.Sub(embedded, "web")
	if err != nil {
		return nil, err
	}
	return http.FS(sub), nil
}

// Sub returns the embedded web directory as an fs.FS.
func Sub() (fs.FS, error) {
	return fs.Sub(embedded, "web")
}

// Handler returns an http.Handler that serves the embedded web UI.
func Handler() (http.Handler, error) {
	sub, err := Sub()
	if err != nil {
		return nil, err
	}
	return http.FileServer(http.FS(sub)), nil
}
